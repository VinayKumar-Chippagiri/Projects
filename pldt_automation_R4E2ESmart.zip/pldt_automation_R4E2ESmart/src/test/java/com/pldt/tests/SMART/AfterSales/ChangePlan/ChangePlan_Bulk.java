package com.pldt.tests.SMART.AfterSales.ChangePlan;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ExcelReader;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class ChangePlan_Bulk extends BaseTest {
	WebUtilities util = new WebUtilities();
	String type = null;
	String caseURL = null;
	String quoteURL = null;
	String orderURL = null;
	ArrayList<String> orderList = null;
	String caseID = null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Login", key = "${key.name}")
	@Test(description = "MNP PortIn")
	public void loginAsAdmin(Map<String, String> data) throws InterruptedException {
		scenario().given("I Log into PLDT Application as admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
		}).when("I log in as Admin", () -> {
			App().Pages().getLoginpage().LoginAsAdmin();
		}).then("I verified that I logged in as an Admin", () -> {
			Reporter.logWithScreenShot(" Logged in as Relationship Manager", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Login", key = "${key.name}")
	@Test(description = "Login as Relationship Manager", priority = 2, dependsOnMethods = { "loginAsAdmin" })
	public void switchToRM(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Home Page", () -> {
		}).when("I Switched as Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("RM"));
		}).then("I verified that I Switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Switched to Relationship Manager", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Creating new Case for Change Plan", priority = 3, dependsOnMethods = { "switchToRM" })
	public void createNewCase(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Home Page", () -> {
		}).when("I navigate to Account Page and choose an Account", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account Name"), "Account");
		}).and("I click on Assets and create a new Case", () -> {
			App().Pages().getAccountDetailsPage().getAccountRecordType();
			App().Pages().getAccountDetailsPage().clickOnRelated("Assets");
			App().Pages().getAssetsListPage().openAssetforEEAccount(data.get("Asset_Name"), data.get("MIN_Number"),data.get("SFServiceID"), true);
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			App().Pages().getCasepage().createChangePlanNewCase(data.get("BillingAccount"));
		}).then("i verified that Case is Created", () -> {
			Reporter.logWithScreenShot("Case is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Modifying the case", priority = 4, dependsOnMethods = { "createNewCase" })
	public void caseModification(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I search for the case", () -> {
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
		}).and("i modified the case and changed the status to resolution in progress", () -> {
			util.waitForCasePage();
			caseURL = getDriver().getCurrentUrl();
			App().Pages().getCaseDetailsPage().caseModification(data.get("MigrationType"),data);
			if (data.get("EFSAM") != null && !data.get("EFSAM").equalsIgnoreCase("SKIP")) {
				App().Pages().getCaseDetailsPage().changeOwner(data.get("EFSAM"));
				App().Pages().getLoginpage().logoutCurrentUser();
				App().Pages().getHomepage().switchToAnyUser(data.get("EFSAM"));
				Reporter.logWithScreenShot("Switched to EFSAM", MessageTypes.Info);
				getDriver().get(caseURL);
				util.waitForCasePage();
			}
			// App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("i verified that case is modified", () -> {
			Reporter.logWithScreenShot(" Case is Modified", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Change Plan", priority = 5, dependsOnMethods = { "caseModification" })
	public void changePlan(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I perform Change Plan", () -> {
			if (data.get("Case Origin").equalsIgnoreCase("Bulk")) {
				App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
				caseID = getDriver().findElement(By.xpath(
						"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
						.getText();
				try {
					ExcelReader.updateCSV(data, "\t" + caseID);
				} catch (IOException e) {
					e.printStackTrace();
				}
				if (!App().Pages().getCaseDetailsPage().bulkUpload(data)) {
					Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
				}
				getDriver().get(caseURL);
			} else {
				App().Pages().getCaseDetailsPage().requestChangePlan(data.get("Plan"), data.get("Addons"), data);
				App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
			}
			App().Pages().getCaseDetailsPage().requestChangePlan(data.get("Plan"), data.get("Addons"), data);
		}).then("i verified that change plan is executed", () -> {
			Reporter.logWithScreenShot("change plan executed", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Update Quote", priority = 6, dependsOnMethods = { "changePlan" })
	public void updateQuote(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Update Quotation Validity period, Contacts and Delivery Date", () -> {
			util.refreshPage();
			util.waitForQuotePage();
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl());
			quoteURL = getDriver().getCurrentUrl();
			App().Pages().getQuoteDetailsPage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);

		}).then("i verified that All the necessary fields are updated", () -> {
			Reporter.logWithScreenShot(" Updated Quotation Validity Period, Contacts, Delivery Date",
					MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Validate Cart", priority = 7, dependsOnMethods = { "updateQuote" })
	public void validateCart(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I perform Validate Cart", () -> {
			util.waitFor(5);
			util.refreshPage();
			util.waitFor(5);
			App().Pages().getQuoteDetailsPage().ValidateCart();
			util.waitTillLoaderDissapear();
			util.waitForQuotePage();

			type = data.get("Transaction Type");
		}).then("i verified that Cart is Validated", () -> {
			Reporter.logWithScreenShot(" Validate Cart", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Login as Credit Analyst", priority = 8, dependsOnMethods = { "validateCart" })
	public void loginAsCA(Map<String, String> data) throws InterruptedException {

		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("logout and Login as Credit Analyst", () -> {
			if (type.equalsIgnoreCase("Upgrade / plan upgrade")) {
				App().Pages().getLoginpage().logoutCurrentUser();
				util.waitFor(5);
				if (getDriver().findElements(By.xpath("//input[@id='username']")).size() != 0) {
					App().Pages().getLoginpage().LoginAsAdmin();
					App().Pages().getHomepage().switchToAnyUser(data.get("CA"));
					try {
						Thread.sleep(5000);
					} catch (Exception e) {

					}
				} else {

					App().Pages().getHomepage().switchToAnyUser(data.get("CA"));
				}
			}
		}).then("i verified that I am Logged in as Credit Analyst", () -> {
			Reporter.logWithScreenShot(" Logged in as Credit Analyst ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Update Credit Information", priority = 9, dependsOnMethods = { "loginAsCA" })
	public void updateCreditInformation(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I update Credit Information using Credit Analyst", () -> {
			type = data.get("Transaction Type");
			if (type.equalsIgnoreCase("Upgrade / plan upgrade")) {
				getDriver().get(ProjectBeans.getQuoteURL());
				App().Pages().getQuoteDetailsPage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
						data.get("CreditApprovalCondition"), data.get("Credit Check Remark"));

			}
		}).then("i verified that Credit Information Fields are Updated", () -> {
			Reporter.logWithScreenShot("Credit Information ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "login as Relationship Manager", priority = 10, dependsOnMethods = {
			"updateCreditInformation" })
	public void loginAsRM(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("logout and Login as Relationship Manager", () -> {

			if (type.equalsIgnoreCase("Upgrade / plan upgrade")) {
				App().Pages().getLoginpage().logoutCurrentUser();
				util.waitFor(10);
				App().Pages().getHomepage().switchToAnyUser(data.get("RM"));
				try {
					Thread.sleep(3000);
				} catch (Exception e) {
				}

				getDriver().get(ProjectBeans.getQuoteURL());
			}
		}).then("i verified that I am Logged in as Relationship Manager", () -> {
			Reporter.logWithScreenShot(" Logged in as Relationship Manager ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Quote to PDF and change status to Accepted", priority = 11, dependsOnMethods = {
			"validateCart" })
	public void QuotetoPDF(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I Click on Quote to PDF", () -> {
			if (!props.getPropertyValue("accountRecType").equalsIgnoreCase("Enterprise Extension")) {
				util.ChangeStatus("Internal Approval");
				util.ChangeStatus("Presented");
				App().Pages().getQuotepage().QuotetoPDF();
				util.ChangeStatus("Customer Approved");
				App().Pages().getQuoteDetailsPage().ChangeStatusToAccepted();
			} else {
				// util.ChangeStatus("Customer Approved");
				App().Pages().getQuoteDetailsPage().ChangeStatusToAccepted();
			}

		}).then("i verified that Quote status has been changed to Accepted", () -> {
			Reporter.logWithScreenShot("Changed status to Accepted", MessageTypes.Info);

		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Contract Creation", priority = 12, dependsOnMethods = { "QuotetoPDF" })
	public void contractCreation(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I Click on Create Contract", () -> {
			App().Pages().getQuoteDetailsPage().CreateContract();
			util.waitForContractPage();
			ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // Set Contract URL
		}).when("I change the status to Awaiting Signature", () -> {
			Reporter.logWithScreenShot(util.ChangeStatus("Negotiating"));
			util.waitFor(5);
			util.scrollUp();
			Reporter.logWithScreenShot(util.ChangeStatus("Awaiting Signature"));
			util.waitFor(5);
			util.scrollUp();
			util.waitTillLoaderDissapear();
			util.waitForContractPage();
		}).then("i verified that Contract is created and Status is changed to Awaiting Signature", () -> {
			Reporter.logWithScreenShot("Contract is Created", MessageTypes.Info);

		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Generate Documents", priority = 13, dependsOnMethods = { "contractCreation" })
	public void GenerateDocuments(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Contract Page", () -> {
		}).when("I click on generate Documents ", () -> {
			util.refreshPage();
			util.waitForContractPage();
			App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
			util.waitForContractPage();
			Reporter.logWithScreenShot(util.ChangeStatus("Signed"));
			util.waitFor(5);
			util.scrollUp();
		}).then("i verified that File is Uploaded", () -> {
			Reporter.logWithScreenShot(" Generate Documents ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Verify Orders", priority = 14, dependsOnMethods = { "validateCart" })
	private void verifyOrderDetails() {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to order search page", () -> {
//			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
//			util.waitForQuotePage();
//			orderList = App().Pages().getOrdersPage().VerifyOrders();
//			util.refreshOrders(40, 2);
			App().Pages().getCasepage().verifyOrdersFromCasePage(caseURL);
			orderList = util.refreshOrders(40, 2);

		}).then("I verify the order generation", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@Test(priority = 15, dependsOnMethods = { "verifyOrderDetails" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Quote URL :" + quoteURL, MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order_" + i + 1 + ": " + orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
