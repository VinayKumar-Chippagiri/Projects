package com.pldt.tests.SMART.NewConnect;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.MyScreenRecorder;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class NewConnect_BAUR41SIT extends BaseTest {
	ArrayList<String> orderList = null;

//	@BeforeSuite
//	public void startrecord() {
//		try {
//			MyScreenRecorder.startRecording("NewConnect_BAUR41SIT");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//	@AfterSuite
//	public void stoprecord() {
//		try {
//			MyScreenRecorder.stopRecording();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Lead",key = "${key.name}")
	@Test(description = "Admin Login", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		AppCommons app = new AppCommons();
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		scenario().given("I Log into PLDT Application as admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			driver.getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
			App().Pages().getLoginpage().LoginAsAdmin();
			driver.getDriver().executeScript("return document.readyState").equals("complete");
			util.waitFor(10);
			app.mouseMover();
		}).then("I verify I Logged in as Admin", () -> {
			String title = driver.getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Lead", key = "${key.name}")
	@Test(description = "Switch to RelationShip Manager", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void Switching_to_RelationShipManager(Map<String, String> data) {
		AppCommons app = new AppCommons();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I Switch to RelationShip Manager", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			String strRM = data.get("Relationship Manager");
			Reporter.log("Relationship Manager: " + strRM);
			App().Pages().getHomepage().switchToAnyUser(strRM);
			ConfigurationManager.getBundle().setProperty("RelationShip_Manager", strRM);
			ConfigurationManager.getBundle().setProperty("Credit_Analyst", data.get("Credit Analyst"));
			app.mouseMover();
		}).then("I verify I Switched as RelationShip Manager", () -> {
			String heading = driver.getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[1]")).getText();
			Validator.verifyThat("login as RM", heading,
					Matchers.containsString("Logged in as " + data.get("Relationship Manager")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Account", priority = 3, dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void OpenExistingAccount(Map<String, String> data) {
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I am in home page", () -> {
			util.refreshPage();
			util.waitFor(5);
		}).when("I open " + data.get("Account_Name") + " account", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			ConfigurationManager.getBundle().setProperty("Account", data.get("Account_Name"));
			ProjectBeans.setAccountURL(driver.getDriver().getCurrentUrl()); // setting account url
			//ConfigurationManager.getBundle().setProperty("AccountURL", driver.getDriver().getCurrentUrl());
			util.waitFor(10);
		}).then("I verify that account details page of " + data.get("Account_Name") + " is displayed", () -> {
			String heading =driver.getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
					.getText();
			Validator.verifyThat("Account name", heading, Matchers.containsString(data.get("Account_Name")));
		}).when("I click on contacts", () -> {
			driver.getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
			util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
			app.mouseMover();
		}).and("I captured the contact name", () -> {
			String BillRecipient = driver.getDriver().findElement(By.xpath("//span[.='Bill Recipient']/ancestor::tr//th//a"))
					.getText();
			ConfigurationManager.getBundle().setProperty("contact.BillRecipient", BillRecipient);
			Reporter.log("Technical Contact: " + BillRecipient);
			String DeliveryRecipient = driver.getDriver()
					.findElement(By.xpath("//span[.='Delivery Recipient - Smart']/ancestor::tr//th//a")).getText();
			ConfigurationManager.getBundle().setProperty("contact.DeliveryRecipient", DeliveryRecipient);
			Reporter.log("Technical Contact: " + DeliveryRecipient);
			String Authorized_Signatory = driver.getDriver()
					.findElement(By.xpath("//span[.='Authorized Signatory']/ancestor::tr//th//a")).getText();
			ConfigurationManager.getBundle().setProperty("Lead.fullName", Authorized_Signatory);
			Reporter.log("Authorized Signatory: " + Authorized_Signatory);
			Reporter.logWithScreenShot("Account Contact Details");
		}).and("I clicked on account and navigate back to account details page", () -> {
			QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
			AccountName.click();
		}).then("then i verified that account details page is dispayed", () -> {
			util.waitFor(20);
			//App().Pages().getLoginpage().logoutCurrentUser();
			Reporter.logWithScreenShot("Account Details Page");
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Lead", key = "${key.name}")
	@Test(description = "Creating Lead And Converting To Account", priority = 3, dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void CreatingLead(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I am on list of lead page", () -> {
			util.waitFor(5);
			pages.getHomepage().goToAPP("Leads");
			pages.getLeadpage().getLeadNewButton().verifyVisible();
			pages.getLeadpage().getLeadNewButton().click();
			pages.getLeadpage().selectRecordType("business");
			pages.getLeadpage().getLeadNextButton().click();
		}).when("I add Lead Information for the New Lead: Business ", () -> {
			pages.getLeadpage().fillTheLeadForm(data);
			util.waitForLeadPage();
			util.waitFor(20);
			Reporter.logWithScreenShot("Lead info is entered", MessageTypes.Info);
			pages.getLeadpage().markLeadStatusAsQualified();
			ProjectBeans.setLeadURL(driver.getDriver().getCurrentUrl());
			Reporter.log(driver.getDriver().getCurrentUrl());
			app.mouseMover();
		}).then("I verify that user is changed as Credit Analyst and perform credit", () -> {
			pages.getLoginpage().logoutCurrentUser();
			util.waitFor(20);
			pages.getHomepage().switchToAnyUser(ConfigurationManager.getBundle().getPropertyValue("Credit_Analyst"));
			driver.getDriver().get(ProjectBeans.getLeadURL());
			util.waitForLeadPage();
			util.waitFor(20);
			pages.getLeadpage().validateCreditCheck();
			pages.getLeadpage().convertLead();
			App().Pages().getLoginpage().logoutCurrentUser();
			util.waitFor(20);
			String title = driver.getDriver().getTitle();
			Validator.verifyThat("verify user able to logout as Credit Analyst", title,
					Matchers.equalTo("Home | Salesforce"));
			app.mouseMover();
			pages.getHomepage().switchToAnyUser(ConfigurationManager.getBundle().getPropertyValue("RelationShip_Manager"));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Contact")
	@Test(description = "Creating New Contact", priority = 4, dependsOnMethods = { "CreatingLead" })
	public void contactCreationTest(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("Navigating to Accounts to create Contact", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			driver.getDriver().get(ProjectBeans.getAccountURL());
			util.waitFor(20);
			pages.getAccountpage().ClickContacts();
			pages.getContactpage().clickNewAccContact();
		}).when("I add Contact Information for the New Contact", () -> {
			pages.getContactpage().fillContactForm();
			pages.getContactpage().clickSaveButton();
			util.waitFor(10);
		}).then("I verify that information is entered", () -> {
			Reporter.logWithScreenShot("Contact info is entered", MessageTypes.Info);
			//pages.getLoginpage().logoutCurrentUser();
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Opportunity",key = "${key.name}")
	@Test(description = "QuoteCreationTest", priority = 5, dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void QuoteCreationTest(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().when("Navigating to Accounts to create Quote", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			//pages.getHomepage().switchToAnyUser(ConfigurationManager.getBundle().getPropertyValue("RelationShip_Manager"));
			driver.getDriver().get(ProjectBeans.getAccountURL());
			util.waitFor(20);
			pages.getQuotepage().createQuoteSMARTR4EndtoEnd(data);
		}).then("I verified that Quote is Created", () -> {
			Reporter.logWithScreenShot("Quote is Created", MessageTypes.Info);
			String title = driver.getDriver().findElement(By.xpath("//div[text()='Quote']/following::span[1]"))
					.getText();
			Validator.verifyThat("I verify quote is created", title,
					Matchers.equalTo(ConfigurationManager.getBundle().getPropertyValue("Quote_name")));
			app.mouseMover();
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Opening already existing quote", priority = 5, dependsOnMethods = { "OpenExistingAccount" })
	public void OpenExistingQuote(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I am on account page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			util.waitFor(20);
		}).when("I go to Quote list page and open quote", () -> {	
			App().Pages().getAccountDetailsPage().clickOnQuote("Quotes__r");
			App().Pages().getCaseListPage().FilterQuote(data.get("Quote_Name"));
			QAFExtendedWebElement quoteline = new QAFExtendedWebElement(By.xpath("(//tbody//tr/th//a)[last()]"));
			quoteline.click();
			util.waitFor(20);
		}).then("I verified that Quote is Created", () -> {
			Reporter.logWithScreenShot("Quote is opened", MessageTypes.Info);
			String title = driver.getDriver().findElement(By.xpath("//div[text()='Quote']/following::span[1]"))
					.getText();
			Validator.verifyThat("I verify quote is opened", title,
					Matchers.equalTo(data.get("Quote_Name")));
			app.mouseMover();
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "CartDetails",key = "${key.name}")
	@Test(description = "Adding Products To Cart", priority = 6, dependsOnMethods = { "QuoteCreationTest" })
	public void AddProductsToCart(Map<String, String> data) throws InterruptedException {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Add the products into the cart ", () -> {
			pages.getQuotepage().ClickAddProducts();
			util.waitFor(15);
			Reporter.logWithScreenShot("Working Cart", MessageTypes.Info);
			pages.getCartpage().QuickActionsAddProductsToCart(data);
		}).then("I verified that products are added in to cart", () -> {
			util.waitFor(15);
			Reporter.logWithScreenShot("Products are Added and Redirected to quote page", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "CartDetails",key = "${key.name}")
	@Test(description = "Performing device Availability Check", priority = 7, dependsOnMethods = { "AddProductsToCart" })
	public void availabilityChecks(Map<String, String> data) throws InterruptedException {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I perform device Availability Check", () -> {
			if (util.getEnvironment().equalsIgnoreCase("R32SIT")) {
				pages.getQuotepage().numberAvailabilityCheck();
			}
			pages.getQuotepage().deviceAvailabilityCheck();
			util.waitFor(15);
			ProjectBeans.setQuoteURL(driver.getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("I verified that checks are completed", () -> {
			Reporter.logWithScreenShot("Availability Checks", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Updating QuoteValidatyPeriod,DeliveryDate and ContactDetails", priority = 8, dependsOnMethods = {
			"availabilityChecks" })
	public void updateQuote(Map<String, String> data) {PageLib pages = new PageLib();
	AppCommons app = new AppCommons();
	WebUtilities util = new WebUtilities();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I update contact and Validity period Information ", () -> {
			pages.getQuotepage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
			util.waitFor(10);
		}).then("I verified that Details are populated", () -> {
			Reporter.logWithScreenShot("Details are populated", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "BillingAccounts", key = "${key.name}")
	@Test(description = "Creating BillingAccount", priority = 9, dependsOnMethods = {
			"updateQuote" })
	public void createBillingAccount(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Billing Account ", () -> {
			pages.getBillingAndServiceAccount().createBillingAccount();
		}).then("I verified that Billing Account is Created", () -> {
			Reporter.logWithScreenShot("Billing Account is Created", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "ServiceAccounts", key = "${key.name}")
	@Test(description = "Creating Service Account", priority = 10, dependsOnMethods = { "createBillingAccount" })
	public void createServiceAccount(Map<String, String> data) throws InterruptedException {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Service Account ", () -> {
			driver.getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			pages.getBillingAndServiceAccount().createServiceAccount();
		}).then("I verified that Service Account is Created", () -> {
			Reporter.logWithScreenShot("Service Account is Created", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "CartDetails", key = "${key.name}")
	@Test(description = "Updating Billing and Service Accounts", priority = 11, dependsOnMethods = {
			"createServiceAccount" })
	public void updateAccounts(Map<String, String> data) throws InterruptedException {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Update Billing and Service Account", () -> {
			driver.getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			pages.getQuotepage().ModifyProducts(data.get("Plan"));
			pages.getCartpage().clickPlanDownArrow(data);
			pages.getCartpage().UpdateAccounts(data);
			pages.getAddressassignmentpage().AssignBillingAccount(ConfigurationManager.getBundle().getPropertyValue("BillingAccountName"));
			app.mouseMover();
			pages.getAddressassignmentpage().AssignServiceAccount(ConfigurationManager.getBundle().getPropertyValue("ServiceAccountName"));
			pages.getCartpage().SaveWorkingCart();
			pages.getCartpage().WorkingCartConfigure();
			util.waitForQuotePage();
			if (data.get("SecondPlan").contains("Y")) {
				pages.getQuotepage().ModifyProducts(data.get("SecondPlan"));
				pages.getCartpage().clickSecondPlanDownArrow(data);
				pages.getCartpage().SecondUpdateAccounts(data);
				pages.getAddressassignmentpage().AssignBillingAccount(ConfigurationManager.getBundle().getPropertyValue("BillingAccountName"));
				pages.getAddressassignmentpage().AssignServiceAccount(ConfigurationManager.getBundle().getPropertyValue("ServiceAccountName"));
				pages.getCartpage().SaveWorkingCart();
				pages.getCartpage().WorkingCartConfigure();
				util.waitForQuotePage();
			}
		}).then("I verified that Billing Account and Service Account is Updated", () -> {
			app.mouseMover();
		}).execute();
	}

	@Test(description = "Validating cart", priority = 12, dependsOnMethods = { "updateAccounts" })
	public void validateCart() {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		scenario().given("I am on Quote Page", () -> {
		}).when("I Validate the Cart", () -> {
			pages.getQuotepage().ValidateCart();
		}).then("I verified that Cart is Validated", () -> {
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Quote",key = "${key.name}" )
	@Test(description = "Performing Credit Check", priority = 13, dependsOnMethods = { "validateCart" })
	public void creditCheck(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I perform Credit Check", () -> {
			pages.getQuotepage().CreditCheck();
			util.waitForQuotePage();
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(ConfigurationManager.getBundle().getPropertyValue("Credit_Analyst"));
			driver.getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			pages.getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
					data.get("CreditApprovalCondition"), data.get("CreditRemark"));
			util.waitFor(10);
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(ConfigurationManager.getBundle().getPropertyValue("RelationShip_Manager"));
			driver.getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
		}).then("I verified that Credit information is Updated ", () -> {
			Reporter.logWithScreenShot("after Credit info update");
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Opportunity",key = "${key.name}" )
	@Test(description = "EBIT", priority = 14, dependsOnMethods = { "creditCheck" })
	public void performEbitApprovalTest(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I Checking the EBIT Value and Submitting for Approval", () -> {
			util.scrollIntoElement(By.xpath("(//h3[.='Internal Approvals'])[1]"));
			if (!util.isElementDisplayed(By.xpath("//span[.='EBIT']/following::span[contains(text(),'40.00%')]"))) {
				pages.getQuotepage().submitEBITForApproval(data);
				pages.getLoginpage().logoutCurrentUser();
				pages.getHomepage().switchToAnyUser(data.get("Business Head"));
				pages.getQuotepage().approveEBIT(data);
				pages.getHomepage().switchToAnyUser(ConfigurationManager.getBundle().getPropertyValue("RelationShip_Manager"));
				driver.getDriver().get(ProjectBeans.getQuoteURL());
			} else {
				pages.getQuotepage().changeStatusToInternalApproval();
			}
		}).then("I verified that Quote Status is moved to Internal Approval", () -> {
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Quote to PDF", priority = 15, dependsOnMethods = { "performEbitApprovalTest" })
	public void quotetoPDF(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I Converting Quote to PDF", () -> {
			pages.getQuotepage().QuotetoPDF();
			app.pickLatestFileFromDownloads("Q"+context.getName());
			Reporter.logWithScreenShot("Quote Status Changed to Presented", MessageTypes.Info);
			pages.getQuotepage().changeStatusToApproved1();
		}).then("I verified that Quote to PDF is Converted and Status Changed to Approved", () -> {
			util.scrollUp();
			Reporter.logWithScreenShot("Quote Status Changed to Approved", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Device Reservations", priority = 16, dependsOnMethods = { "quotetoPDF" })
	public void deviceReservations(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Device Reservation", () -> {
			pages.getQuotepage().DeviceReservation(data);
		}).then("I verified that Device reservation is completed", () -> {
			Reporter.logWithScreenShot("Device reservation", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "CartDetails",key = "${key.name}")
	@Test(description = "Number Reservations", priority = 17, dependsOnMethods = { "deviceReservations" })
	public void numberReservation(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Number Reservation", () -> {
			pages.getQuotepage().numberReservationCheck(data);
			if (data.get("SecondPlan").contains("Y")) {
				pages.getQuotepage().numberReservationCheck(data);
			}
		}).then("I verified that Number Reservation is completed", () -> {
			Reporter.logWithScreenShot("Number Reservation is Completed", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "CartDetails",key = "${key.name}")
	@Test(description = "Syncronizing QLI Items", priority = 18, dependsOnMethods = { "numberReservation" })
	public void syncronizeQLIItems(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I perform the Synchronization", () -> {
			App().Pages().getQuotepage().SynchronizingAccount(data.get("Plan"), ConfigurationManager.getBundle().getPropertyValue("RelationShip_Manager"));
			pages.getQuotepage().ChangeStatusToAccepted(data);
		}).then("I verified that Status changed to Accepted", () -> {
			app.mouseMover();
		}).execute();
	}

	@Test(description = "Creating Contract", priority = 19, dependsOnMethods = { "syncronizeQLIItems" })
	public void CreateContract() {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Create Contract", () -> {
			pages.getQuotepage().CreatingContract();
		}).then("I verified that Contract is Created", () -> {
			Reporter.logWithScreenShot("Contract is Created", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "Contract", key = "${key.name}")
	@Test(description = "Upload file", priority = 20, dependsOnMethods = { "CreateContract" })
	public void generateDocuments(Map<String, String> data) {
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Contract Page", () -> {
		}).when("I click on generate Documents ", () -> {
			util.refreshPage();
			util.waitForContractPage();
			App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
			app.pickLatestFileFromDownloads("C"+context.getName());
			util.waitForContractPage();
		}).then("i verified that File is Uploaded", () -> {
			Reporter.logWithScreenShot(" Generate Documents ", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "CartDetails", key = "${key.name}")
	@Test(description = "Creating Contract", priority = 21, dependsOnMethods = { "generateDocuments" })
	public void ChangingContractStatus(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Create Contract", () -> {
			pages.getQuotepage().ChangeTheStatusToSigned();
			ProjectBeans.setContractURL(driver.getDriver().getCurrentUrl()); // setting Contract Url
		}).then("I verified that Contract Status is Changed", () -> {
			Reporter.logWithScreenShot("Contract Status is Changed to Signed", MessageTypes.Info);
			app.mouseMover();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/BAUR41SITNewConn.xlsx", sheetName = "CartDetails", key = "${key.name}")
	@Test(description = "Checking Orders", priority = 22, dependsOnMethods = { "ChangingContractStatus" })
	public void orders(Map<String, String> data) {
		PageLib pages = new PageLib();
		AppCommons app = new AppCommons();
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I am on Contract Page", () -> {
		}).when("I move to orders page", () -> {
			driver.getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList = pages.getQuotepage().VerifyOrders();
		}).then("I verified the status of Orders", () -> {
			Reporter.logWithScreenShot(" Orders", MessageTypes.Info);
			app.mouseMover();
		}).execute();

	}

	@Test(priority = 23)//, dependsOnMethods = { "numberReservation" })
	public void getReferenceData() {
		AppCommons app = new AppCommons();
		Reporter.log("Lead URL :" + ProjectBeans.getLeadURL(), MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :" + ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :" + ProjectBeans.getContractURL(), MessageTypes.Info);
//		if (orderList.size() > 0) {
//			for (int i = 0; i < orderList.size(); i++) {
//				Reporter.log("Order _" + (i + 1) + " URL : " + orderList.get(i), MessageTypes.Info);
//			}
//		}
	}
}
