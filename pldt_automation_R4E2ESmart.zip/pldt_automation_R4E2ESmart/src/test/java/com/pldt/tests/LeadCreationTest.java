package com.pldt.tests;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.Map;

import org.apache.oro.text.regex.Util;
import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class LeadCreationTest extends BaseTest{
	PageLib pages =new PageLib();
	WebUtilities util = new WebUtilities();
	@QAFDataProvider(dataFile = "resources/testdata/PLDT_RegressionSuite.xlsx", sheetName = "Lead")
	@Test(description="Sample Test ")
	public void newConnect_TC01(Map<String, String> data) throws InterruptedException {
		scenario().given("I Log into PLDT Application as admin", () -> {
		 getDriver().get("https://pldtoneenterprise--r32sit.my.salesforce.com/");
		 getDriver().manage().window().maximize();
		 ConfigurationManager.getBundle().setProperty("testdata", data);
		 pages.getLoginpage().LoginAsAdmin();
		 try {
			pages.getHomepage().SwitchToUser("Jay Vinn Abaday", "RM");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 pages.getHomepage().goToAPP("Leads");
		 pages.getLeadpage().getLeadNewButton().verifyVisible();
		 pages.getLeadpage().getLeadNewButton().click();
		 pages.getLeadpage().selectRecordType("business");
		 pages.getLeadpage().getLeadNextButton().click();
		}).
		when("I add Lead Information for the New Lead: Enterprise Extension ", () -> {
		 try {
			pages.getLeadpage().fillTheLeadForm(data);
			Reporter.logWithScreenShot("Lead info is entered", MessageTypes.Info);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 pages.getLeadpage().markLeadStatusAsQualified();
		
		}).
		then("i verify that user is changed and perform credit", () -> {
		 try {
			pages.getLoginpage().logoutCurrentUser();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 try {
			pages.getHomepage().SwitchToUser("Brix Jado Jesus Baes","CA");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 pages.getHomepage().goToAPP("Leads");
		 pages.getLeadpage().searchAndOpenLead("All Open Leads",data.get("First Name").toString(),data.get("Middle Name").toString(),data.get("Last Name").toString(),data.get("Suffix").toString());
		 pages.getLeadpage().validateCreditCheck();
		 pages.getLeadpage().convertLead(data);
		 Reporter.logWithScreenShot("user is changed and perform credit", MessageTypes.Info);
		 try {
			Thread.sleep(60000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		}).execute();
	}
}
