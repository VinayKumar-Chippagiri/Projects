package com.pldt.tests.SMART.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class CaseManage extends BaseTest {

	String caseID = null;
	String caseURL = null;

//	@QAFDataProvider(dataFile = "resources/testdata/NewConnectProducts.xlsx", sheetName = "Lead", key = "${key.name}")
//	@BeforeSuite
//	public void startrecord() {
//		try {
//			// MyScreenRecorder.startRecording(context.getSuite().getName());
//			MyScreenRecorder.startRecording(context.getName());
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//	@AfterSuite
//	public void stoprecord() {
//		try {
//			MyScreenRecorder.stopRecording();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	public void LoginAsAdmin(Map<String, String> data) {
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on Salesforce Login page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			driver.getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
			Reporter.logWithScreenShot("Login page");
		}).when("I enter admin username and password", () -> {
			App().Pages().getLoginpage().LoginAsAdmin();
			driver.getDriver().executeScript("return document.readyState").equals("complete");
			util.waitFor(20);
		}).then("I verify user able to login and navigated to home page", () -> {
			String title = driver.getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void SwitchToRM(Map<String, String> data) {
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on Salesforce home page, login as Admin", () -> {
		}).when("I Switched to RelationShip Manager", () -> {
			String strRM = data.get("Relationship_Manager");
			Reporter.log("Relationship Manager: " + strRM);
			App().Pages().getHomepage().switchToAnyUser(strRM);
			ConfigurationManager.getBundle().setProperty("RelationShip_Manager", strRM);
			ConfigurationManager.getBundle().setProperty("Credit_Analyst", data.get("Credit_Analyst"));
			ConfigurationManager.getBundle().setProperty("Owner", strRM);
		}).then("I verify switched to RelationShip Manager", () -> {
			util.waitFor(20);
			String heading = driver.getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[1]")).getText();
			Validator.verifyThat("login as RM", heading,
					Matchers.containsString("Logged in as " + data.get("Relationship_Manager")));
			QAFExtendedWebElement PLDTTitle = new QAFExtendedWebElement(By.xpath("//span[@title='PLDT Enterprise']"));
			Validator.verifyTrue(PLDTTitle.isPresent(), "PLDT Enterprise App Is Not Present On Home Page",
					"PLDT Enterprise App Is Present On Home Page");
			AppUtils.mouseMover();
		}).execute();
	}

	public void SwitchToCA(Map<String, String> data) {
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on Salesforce home page, login as Admin", () -> {
		}).when("I Switched to Credit Analyst", () -> {
			String strCA = data.get("Credit_Analyst");
			Reporter.log("Credit Analyst: " + strCA);
			App().Pages().getHomepage().switchToAnyUser(strCA);
			ConfigurationManager.getBundle().setProperty("RelationShip_Manager", data.get("Relationship_Manager"));
			ConfigurationManager.getBundle().setProperty("Credit_Analyst", strCA);
			ConfigurationManager.getBundle().setProperty("Owner", strCA);
		}).then("I verify switched to Credit Analyst", () -> {
			util.waitFor(20);
			String heading = driver.getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[1]")).getText();			
			Validator.verifyThat("login as CA", heading,
					Matchers.containsString("Logged in as " + data.get("Credit_Analyst")));
			QAFExtendedWebElement PLDTTitle = new QAFExtendedWebElement(By.xpath("//span[@title='PLDT Enterprise']"));
			Validator.verifyTrue(PLDTTitle.isPresent(), "PLDT Enterprise App Is Not Present On Home Page",
					"PLDT Enterprise App Is Present On Home Page");
			AppUtils.mouseMover();
		}).execute();
	}
	
	public void SwitchToSmartEnterpriseSupportUser (Map<String, String> data) {
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on Salesforce home page, login as Admin", () -> {
		}).when("I Switched to Credit Analyst", () -> {
			String strCA = data.get("Credit_Analyst");
			Reporter.log("Credit Analyst: " + strCA);
			App().Pages().getHomepage().switchToAnyUser(strCA);
			ConfigurationManager.getBundle().setProperty("RelationShip_Manager", data.get("Relationship_Manager"));
			ConfigurationManager.getBundle().setProperty("Credit_Analyst", strCA);
			ConfigurationManager.getBundle().setProperty("Owner", strCA);
		}).then("I verify switched to Credit Analyst", () -> {
			util.waitFor(20);
			String heading = driver.getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[1]")).getText();			
			Validator.verifyThat("login as CA", heading,
					Matchers.containsString("Logged in as " + data.get("Credit_Analyst")));
			QAFExtendedWebElement PLDTTitle = new QAFExtendedWebElement(By.xpath("//span[@title='PLDT Enterprise']"));
			Validator.verifyTrue(PLDTTitle.isPresent(), "PLDT Enterprise App Is Not Present On Home Page",
					"PLDT Enterprise App Is Present On Home Page");
			AppUtils.mouseMover();
		}).execute();
	}

	
	public void OpenExistingAccount(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on home page", () -> {
			util.implicitlyWait(10);
			Reporter.log("given AC: " + data.get("Account_Name"));
		}).when("I am on " + data.get("Account_Name") + " Account page", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			ConfigurationManager.getBundle().setProperty("Account", data.get("Account_Name"));
			util.implicitlyWait(20);
		}).then("I verify Account", () -> {
			String heading = driver.getDriver()
					.findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']")).getText();
			Validator.verifyThat("Account name", heading, Matchers.containsString(data.get("Account_Name")));
			ConfigurationManager.getBundle().setProperty("AccountURL", driver.getDriver().getCurrentUrl());
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseCreationOnAsset(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on " + data.get("Account_Name") + " Account page", () -> {
			util.implicitlyWait(10);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I choose asset and creat new case", () -> {
			App().Pages().getAccountDetailsPage().getAccountRecordType();
			App().Pages().getAccountDetailsPage().clickOnRelated("Assets");
			App().Pages().getAssetsListPage().openAssetforEEAccount(data.get("Asset_Name"), data.get("MIN_Number"),
					data.get("SFServiceID"), true);
			App().Pages().getAssetDetailsPage().getBillAccountNumber();
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			Reporter.log("Clicked on Cases link from Related section");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(15);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record_Type"));
			App().Pages().getNewCaseModal().CreatingNewCase(data);
			util.waitFor(20);
		}).then("I verify case created", () -> {
			caseID = App().Pages().getCaseListPage().FilterCaseOnAsset(data.get("Subject"));
			util.waitFor(15);
			Reporter.logWithScreenShot("New Case ID" + caseID);
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseCreationOnAccount(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on " + data.get("Account_Name") + " Account page", () -> {
			util.implicitlyWait(10);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I am creating new case", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			Reporter.log("Clicked on Cases link from Related section");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(15);
			App().Pages().getNewCaseModal().SelectNewCaseType(data.get("Record_Type"));
			App().Pages().getNewCaseModal().CreatingNewCase(data);
			util.waitFor(25);
		}).then("I verify case created", () -> {
			caseID = App().Pages().getCaseListPage().FilterCaseOnAccount(data);
			util.waitFor(15);
			Reporter.logWithScreenShot("New Case ID" + caseID);
			AppUtils.mouseMover();
		}).execute();
	}

	public void AcceptCase(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I ", () -> {
			util.implicitlyWait(15);
			App().Pages().getHomepage().goToAPP("Cases");
			QAFExtendedWebElement downArrowbtn = new QAFExtendedWebElement(By.xpath("//button[@title='Select a List View']"));
			QAFExtendedWebElement searchBarCaseType = new QAFExtendedWebElement(By.xpath("//input[contains(@aria-owns,'virtualAutocompleteListbox')]"));
			QAFExtendedWebElement suggestFirstOption = new QAFExtendedWebElement(By.xpath("(//ul[contains(@id,'virtualAutocompleteListbox')]//a)[1]"));
			QAFExtendedWebElement searchBarCase = new QAFExtendedWebElement(By.xpath("//input[@name='Case-search-input']"));
			QAFExtendedWebElement caseCheckbox = new QAFExtendedWebElement(By.xpath("(//tbody//tr//td//span[@class='slds-checkbox--faux'])[1]"));
			QAFExtendedWebElement Acceptbtn = new QAFExtendedWebElement(By.xpath("//a[@title='Accept']"));		
			downArrowbtn.click();
			util.waitFor(3);
			searchBarCaseType.sendKeys(data.get(""));
			util.waitFor(3);
			suggestFirstOption.click();
			util.waitFor(5);
			searchBarCase.sendKeys(caseID);
			searchBarCase.sendKeys(Keys.ENTER);
			util.waitFor(5);
			caseCheckbox.click();
			util.waitFor(3);
			Acceptbtn.click();
			util.waitFor(15);
		}).when("I ", () -> {
			
		}).then("I ", () -> {
			
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationTIN(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationTIN(data.get("NewCompanyTIN"), data.get("Remarks"));
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationChangeBusiness(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationChangeBusiness(data.get("New Company Trade Name"),
					data.get("Remarks"));
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationTHSRating(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationTHSRating(data);
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}
	
	public void CaseModificationVIPCodeChange(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationVIPCode(data);
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			QAFExtendedWebElement submitApprovalBtn = new QAFExtendedWebElement(By.xpath("//ul[@class='slds-button-group-list']//li//button[@name='Submit']"));
			QAFExtendedWebElement submitApprovaltextArea = new QAFExtendedWebElement(By.xpath("//textarea[@class='inputTextArea cuf-messageTextArea textarea']"));
			QAFExtendedWebElement submitApprovalSubmit = new QAFExtendedWebElement(By.xpath("(//span[text()='Submit']//parent::button)[1]"));
			submitApprovalBtn.click();
			util.waitFor(3);
			submitApprovaltextArea.sendKeys(data.get("Subject"));
			util.waitFor(5);
			submitApprovalSubmit.click();
			util.waitFor(15);
		}).then("I Logout as current user", () -> {
			App().Pages().getLoginpage().logoutAsCurrentUser();
			util.waitFor(15);
			AppUtils.mouseMover();
		}).execute();
	}

	
	public void CaseModificationBillCycle(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationBillCycle(data);
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	
	public void VerifyTransaction(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case page ", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).then("I Verify Transaction generation", () -> {
//			App().Pages().getCaseDetailsPage().markCaseStatusToResolved();
//			util.waitFor(15);
//			QAFWebElement status = new QAFExtendedWebElement(By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
//			Validator.verifyThat("Status of case",status.getText(), Matchers.equalTo("Status: Resolved"));
			QAFWebElement showAlllink = new QAFExtendedWebElement(By.xpath("//a[contains(text(),'Show All')]"));
			QAFWebElement transactionlink = new QAFExtendedWebElement(
					By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'Transaction__r')]"));
			QAFWebElement transactionID = new QAFExtendedWebElement(By.xpath("(//tbody//tr//th//a)[1]"));
			showAlllink.click();
			util.waitFor(5);
			transactionlink.click();
			util.waitFor(10);
			util.refreshPage();
			util.waitFor(10);
			int numberOfRefresh = 0;
			while (!transactionID.isDisplayed() || !transactionID.isPresent() && numberOfRefresh < 5) {
				util.waitFor(30);
				util.refreshPage();
				util.waitFor(10);
				AppUtils.mouseMover();
				numberOfRefresh++;
			}
			String transID = transactionID.getText();
			Reporter.logWithScreenShot("Transaction ID: " + transID);
		}).then("I navigate back to case page", () -> {	
			driver.getDriver().navigate().to(caseURL);
			util.waitFor(30);
			QAFWebElement status = new QAFExtendedWebElement(By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			//Validator.verifyThat("Status of case",status.getText(), Matchers.equalTo("Status: Resolved"));
			Reporter.log("current status of the case: "+ status);
		}).execute();
	}
	
	public void ApproveCase(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am login as ECM Head", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			String strECM = data.get("ECM_Head");
			Reporter.log("ECM Head: " + strECM);
			App().Pages().getHomepage().switchToAnyUser(strECM);
			util.implicitlyWait(10);
		}).when("I open case page and open approval history", () -> {
			driver.getDriver().navigate().to(caseURL);
			util.waitFor(15);
			QAFWebElement showAlllink = new QAFExtendedWebElement(By.xpath("//a[contains(text(),'Show All')]"));
			QAFWebElement approvalHistlink = new QAFExtendedWebElement(
					By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'ProcessSteps')]"));
			showAlllink.click();
			util.waitFor(5);
			approvalHistlink.click();
			util.waitFor(10);
			util.refreshPage();
			util.waitFor(10);
		}).then("I approve the case", () -> {
			QAFWebElement approveBtnApprovalHistory = new QAFExtendedWebElement(By.xpath("(//div[@title='Approve']//parent::a)[1]"));
			QAFWebElement txtAreaApprovalHistory = new QAFExtendedWebElement(By.xpath("//textarea[@class='inputTextArea cuf-messageTextArea textarea']"));
			QAFWebElement ApprveBtnApprovalHistory = new QAFExtendedWebElement(By.xpath("(//span[text()='Approve']//parent::button)[1]"));
			approveBtnApprovalHistory.click();
			util.waitFor(5);
			txtAreaApprovalHistory.sendKeys(data.get("Subject"));
			util.waitFor(2);
			ApprveBtnApprovalHistory.click();
			util.waitFor(15);
			AppUtils.mouseMover();
		}).execute();
	}
	
	public void VerifyCaseApproved(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I login as RM", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			String strRM = data.get("Relationship_Manager");
			Reporter.log("Relationship Manager: " + strRM);
			App().Pages().getHomepage().switchToAnyUser(strRM);
			util.implicitlyWait(15);
		}).when("I open case page", () -> {
			driver.getDriver().navigate().to(caseURL);
			util.waitFor(15);
		}).then("I verify status", () -> {
			QAFWebElement status = new QAFExtendedWebElement(By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case",status.getText(), Matchers.equalTo("Status: Approved"));
			AppUtils.mouseMover();
		}).execute();
	}
	
	

}
