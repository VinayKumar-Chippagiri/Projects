package com.pldt.tests.SMART.AfterSales.Treatment;

import java.util.ArrayList;
import java.util.Map;

import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

public class Involuntary_Suspension_Kenan_Triggered extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL=null;
	String orderURL=null;
	ArrayList<String> orderList =null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).when("User Switched as RM", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to Relationship manager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to RM user", () -> {
			Reporter.logWithScreenShot("Successfully switched to Relationship Manager");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 2, dependsOnMethods = { "Login" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().
		given("Going in account", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).when("Creating case and changing case owner", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getCasepage().createNewCaseAfterSalesTreatment(data.get("BillingAccount"));
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
			App().Pages().getCasepage().changeOwner(data.get("Change Owner"));
			App().Pages().getLoginpage().logoutCurrentUser();			
		}).and("Log in as case owner", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Credit Analyst"));
		}).and("Opening the case page", () -> {
			util.goToURL(caseURL);
		}).then("User verify the case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Fill Transaction Details in casepage", priority = 3, dependsOnMethods = { "CreateNewCase" })
	public void UpdateTransactionDetails(Map<String, String> data) {
		scenario().given("Updating TransactionDetails from case page", () -> {
		}).when("User upadtae fields in transaction Details", () -> {
			App().Pages().getCasepage().caseModificationfortreatment(data.get("Asset_Name"),data.get("Asset ID"),data);
		}).and("Change status to Resolution in Progress", () -> {	
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
	}).then("User Verify Changes made in Case page", () -> {
		Reporter.logWithScreenShot("UpdateTransactionDetails", MessageTypes.Info);
	}).execute();
}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Checking Transcation Id", priority = 4, dependsOnMethods = { "UpdateTransactionDetails" })
	public void CheckingTransctionId(Map<String, String> data) {
		scenario().given("Checking Transaction ID creation and status", () -> {
		}).when("User check TransactionID got Created", () -> {
			App().Pages().getCasepage().CheckingTransactionID(caseURL,data);
			util.refreshPage();
		}).then("User verify TransactionID status is successful ", () -> {
			Reporter.logWithScreenShot("TransactionID status is successful", MessageTypes.Info);
			}).execute();
	}
	
	
	@Test(priority = 5,dependsOnMethods = { "CheckingTransctionId" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
	}
}