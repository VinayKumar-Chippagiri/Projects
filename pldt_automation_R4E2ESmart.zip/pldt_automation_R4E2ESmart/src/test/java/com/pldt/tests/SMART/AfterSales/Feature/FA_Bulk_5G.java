package com.pldt.tests.SMART.AfterSales.Feature;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.io.IOException;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ExcelReader;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

// FA_FD = Feature activation and Deactivation
public class FA_Bulk_5G extends BaseTest {
	WebUtilities util = new WebUtilities();
	String type = null;
	String caseURL = null;
	String orderURL = null;
	String caseID = null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Login",key = "${key.name}")
	@Test(description = "Login As Admin")
	public void loginAsAdmin(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Login Page", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
		}).when("I log in as Admin", () -> {
			App().Pages().getLoginpage().LoginAsAdmin();
		}).then("I verified that I logged in as an Admin", () -> {
			Reporter.logWithScreenShot(" Logged in as Relationship Manager", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx",sheetName = "Login",key = "${key.name}")
	@Test(description = "Login as Relationship Manager", priority = 2, dependsOnMethods = { "loginAsAdmin" })
	public void switchToRM(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Home Page", () -> {
		}).when("I Switched as Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("RM"));
		}).then("I verified that I Switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Switched to Relationship Manager", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Features", key = "${key.name}")
	@Test(description = "Creating new Case", priority = 3, dependsOnMethods = { "switchToRM" })
	public void createCase(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Home Page", () -> {
		}).when("I navigate to Account Page and choose an Account", () -> {
			//App().Pages().getHomepage().goToAPP("Accounts");
			//App().Pages().getAccountListPage().launchPage(null, null);
			util.waitFor(5);
			//App().Pages().getAccountListPage().openAccount(data.get("Account Name"));
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account Name"), "Account");
		}).and("I click on Asset and create an new Case", () -> {
			App().Pages().getAccountDetailsPage().clickOnRelated("Assets");
			App().Pages().getAssetsListPage().openAsset(data.get("Asset_Name"), data.get("MIN_Number"), true);
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			// App().Pages().getAssetpage().clickNewCase();
			App().Pages().getCaseListPage().clickNewCaseButton();
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			// App().Pages().getAssetpage().getBillAccountNumber();
			 App().Pages().getCasepage().createChangePlanNewCase(data.get("BillingAccount"));
			//App().Pages().getNewCaseModal().createNewCase(data.get("Account Name"),data.get("Contact Name"),data.get("Consignee Name"),data.get("Billing Account"));
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			util.waitFor(3);
			caseID = getDriver().findElement(By.xpath(
					"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
					.getText();
		}).then("i verified that Case is Created", () -> {
			Reporter.logWithScreenShot("Case is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Login",key = "${key.name}")
	@Test(description = "logoutasRMandLoginAsSmartEnterpriseSupport", priority = 4, dependsOnMethods = { "createCase" })
	public void loginAsSmartEnterprise(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I Logout as Relationship manager", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("I login as Smart Enterprise Support", () -> {
			App().Pages().getHomepage().SwitchToUser(data.get("CA"), "CA");
			// App().Pages().getHomepage().switchToAnyUser(data.get("Credit Analyst"));
		}).then("i verified that i Switched to Smart Enterprise Support", () -> {
			Reporter.logWithScreenShot("Switched to Smart Enterprise Support", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Features",key = "${key.name}")
	@Test(description = "Accepting and Modifying the case", priority = 5, dependsOnMethods = {
			"loginAsSmartEnterprise" })
	public void caseModification(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I accept the case", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
			App().Pages().getCaseListPage().acceptCase(caseID);
		}).and("i modify the case/perform Bulk Upload and mark the status as resolution in progress", () -> {
			caseURL = getDriver().getCurrentUrl();
			if (data.get("Case Origin").equalsIgnoreCase("Bulk")) {
				App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
				caseID = getDriver().findElement(By.xpath(
						"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
						.getText();
				try {
					ExcelReader.updateCSV(data, "\t" + caseID);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// util.UpdateCaseIDWithzeroInCSVFile(".\\resources\\testdata\\BulkFile.csv",
				// "\t"+caseID);
				if (!App().Pages().getCaseDetailsPage().bulkUpload(data)) {
					Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
				}
				getDriver().get(caseURL);
			} else {
				App().Pages().getCasepage().featurecasemodification(data.get("Features"));
				App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
			}
//			App().Pages().getCasepage().clickOnResolInProgress();
//			App().Pages().getCasepage().markCaseStatusToResolutionInprogress();
		}).then("i verified that case is modified", () -> {
			Reporter.logWithScreenShot(" Case is Modified/Bulk Upload is completed", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Features",key = "${key.name}")
	@Test(description = "Modifying the case", priority = 6, dependsOnMethods = { "caseModification" })
	public void features(Map<String, String> data) throws InterruptedException {
		scenario().given("I'm on case page", () -> {
		}).when("I perform Feature Activation/Deactivation", () -> {
			// getDriver().navigate().to("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Case/5001s000005iqwhAAA/view");
			App().Pages().getCaseDetailsPage().features(data.get("Transaction Type"));
		}).then("I verify the feature Activation/Deactivation is performed", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Features",key = "${key.name}")
	@Test(description = "Verify Orders", priority = 7, dependsOnMethods = { "features" })
	private void verifyOrderDetails() {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to order search page", () -> {
			App().Pages().getOrdersPage().verifyOrdersFromCasePage(caseURL);
			util.waitForOrderPage();
			orderURL = getDriver().getCurrentUrl();
			util.refreshOrders(40, 1);
		}).then("I verify the order generation", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}
	@Test(priority = 8, dependsOnMethods = { "verifyOrderDetails" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Order URL :" + orderURL, MessageTypes.Info);
		
	}
}
