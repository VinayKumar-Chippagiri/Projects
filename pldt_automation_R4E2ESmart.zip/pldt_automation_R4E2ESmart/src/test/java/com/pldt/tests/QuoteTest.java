package com.pldt.tests;

import java.util.Map;

import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.pldt.lib.PageLib;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;

public class QuoteTest extends BaseTest {
	PageLib pages = new PageLib();
	@QAFDataProvider(dataFile = "resources/testdata/PLDT_RegressionSuite.xlsx", sheetName = "CartDetails")
	@Test(description = "Opportunity", priority = 1)
	
	public void Opportunity(Map<String, String> data) throws InterruptedException {
		getDriver().get("https://test.salesforce.com/");
		ConfigurationManager.getBundle().setProperty("testdata", data);
		App().Pages().getLoginpage().LoginAsAdmin();
		pages.getHomepage().switchToAnyUser("Jay Vinn Abaday");
		getDriver().get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Quote/0Q01s0000006EBkCAM/view");
		
		//App().Pages().getQuotepage().SynchronizingAccount(data.get("Plan"));
		//App().Pages().getQuotepage().DeviceReservation();
		//App().Pages().getQuotepage().numberReservationCheck();
		//App().Pages().getQuotepage().numberAvailabilityCheck();        
		//App().Pages().getQuotepage().deviceAvailabilityCheck();
		//App().Pages().getQuotepage().CreditCheck();
		//App().Pages().getQuotepage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
//		App().Pages().getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
//				data.get("CreditApprovalCondition"), data.get("CreditRemark"));
		//App().Pages().getQuotepage().updateContactDetails(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/PLDT_RegressionSuite.xlsx", sheetName = "BillingAccounts")
	@Test(description = "Opportunity", priority = 2)
	public void createBillingAccount(Map<String, String> data) throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		App().Pages().getBillingAndServiceAccount().createBillingAccount();
		ProjectBeans.getQuoteURL();  //Nimesh
	}

	@QAFDataProvider(dataFile = "resources/testdata/PLDT_RegressionSuite.xlsx", sheetName = "ServiceAccounts")
	@Test(description = "Opportunity", priority = 3)
	public void createServiceAccount(Map<String, String> data) throws InterruptedException {
		getDriver().get("https://test.salesforce.com/");
		ConfigurationManager.getBundle().setProperty("testdata", data);
		App().Pages().getLoginpage().LoginAsAdmin();
		pages.getHomepage().switchToAnyUser("Jay Vinn Abaday");
		getDriver().get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Quote/0Q01s0000006Df0CAE/view");
		App().Pages().getBillingAndServiceAccount().createServiceAccount();
		ProjectBeans.getQuoteURL();  //Nimesh
	}

	@QAFDataProvider(dataFile = "resources/testdata/PLDT_RegressionSuite.xlsx", sheetName = "Quote")
	@Test(description = "Opportunity", priority = 4)
	public void quoteUpdateValidate(Map<String, String> data) throws InterruptedException {
		App().Pages().getCartpage().UpdateAccounts(data);
		App().Pages().getAddressassignmentpage().AssignBillingAccount(data.get("BillingAccountName"));
		App().Pages().getAddressassignmentpage().AssignServiceAccount(data.get("ServiceAccountName"));
		App().Pages().getQuotepage().ValidateCart();
		App().Pages().getQuotepage().CreditCheck();
		App().Pages().getQuotepage().changeStatusToApproved();
		App().Pages().getQuotepage().DeviceReservation(data);
		// App().Pages().getQuotepage().numberReservation();
		App().Pages().getQuotepage().ChangeStatusToAccepted(data);
		App().Pages().getQuotepage().CreateContract();
		App().Pages().getQuotepage().VerifyOrders();
	}
}
