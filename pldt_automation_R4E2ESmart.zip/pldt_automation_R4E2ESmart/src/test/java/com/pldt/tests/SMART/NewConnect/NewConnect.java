package com.pldt.tests.SMART.NewConnect;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class NewConnect extends BaseTest {
	PageLib pages = new PageLib();
	AppCommons app = new AppCommons();
	WebUtilities util = new WebUtilities();
    ArrayList<String> orderList =null;
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Lead")
	@Test(description = "Lead creation for NewConnect", priority = 1)
	public void leadCreationAndConvertionTest(Map<String, String> data) {
		scenario().given("I Log into PLDT Application as admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
		}).when("I Switched as RM", () -> {
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
		}).then("I verify that successfully switched to RM", () -> {
			Reporter.logWithScreenShot("Successfully switched to RM");
			props.setProperty("Credit_Analyst", data.get("Credit Analyst"));
		}).given("Navigating to Lead as RM", () -> {
			pages.getHomepage().goToAPP("Leads");
			pages.getLeadpage().getLeadNewButton().verifyVisible();
			pages.getLeadpage().getLeadNewButton().click();
			pages.getLeadpage().selectRecordType("business");
			pages.getLeadpage().getLeadNextButton().click();
		}).when("I add Lead Information for the New Lead: Business ", () -> {
			pages.getLeadpage().fillTheLeadForm(data);
			util.waitForLeadPage();
			Reporter.logWithScreenShot("Lead info is entered", MessageTypes.Info);
			pages.getLeadpage().markLeadStatusAsQualified();
			ProjectBeans.setLeadURL(getDriver().getCurrentUrl());
		}).then("I verify that user is changed as Credit Analyst and perform credit", () -> {
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			getDriver().get(ProjectBeans.getLeadURL());
			util.waitForLeadPage();
//			getDriver().get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Lead/00Q1s000002rxfpEAA/view");
			pages.getLeadpage().validateCreditCheck();
			pages.getLeadpage().convertLead(data);
			pages.getLoginpage().logoutCurrentUser();
			Reporter.logWithScreenShot("user is changed and perform credit", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Contact")
	@Test(description = "CreatingNewContactforNewConnect", priority = 2, dependsOnMethods = { "leadCreationAndConvertionTest" })
	public void contactCreationTest(Map<String, String> data) {
		scenario().given("Navigating to Accounts to create Contact", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
			getDriver().get(ProjectBeans.getAccountURL());
			util.waitForAccountPage();
			pages.getAccountpage().ClickContacts();
			pages.getContactpage().clickNewAccContact();
		}).when("I add Contact Information for the New Contact", () -> {
			pages.getContactpage().fillContactForm();
			pages.getContactpage().clickSaveButton();
			pages.getLoginpage().logoutCurrentUser();
		}).then("I verify that information is entered", () -> {
			Reporter.logWithScreenShot("Laed info is entered", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile =  "resources/testdata/NewConnect.xlsx", sheetName = "Opportunity")
	@Test( priority = 3, dependsOnMethods = { "contactCreationTest" })
	public void opportunityCreationTest(Map<String, String> data) {
		scenario().when("Navigating to Accounts to create Opportunity", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			ProjectBeans.setOpportunityName(data.get("Opportunity Name"));
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
			getDriver().get(ProjectBeans.getAccountURL());
			util.waitForAccountPage();
			pages.getAccountpage().ClickOpportunities();
		}).when("I add Opportunity Information for the New Opportunity ", () -> {
			pages.getOpportunitypage().createOpportunity();
		}).then("I verified that Opportunity is Created", () -> {
			Reporter.logWithScreenShot("Opportunity is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile =  "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test(description = "add products to cart",priority = 4, dependsOnMethods = { "opportunityCreationTest" })
	public void addProductsToCart(Map<String, String> data) {
		scenario().given("I am on Opportunity Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I Search for an opportunity ", () -> {
			pages.getOpportunitypage().SearchOpportunity();
			//pages.getOpportunitypage().SearchOpportunity(ProjectBeans.getOpportunityName());
		}).when("I Click on Configure to go to Cart Page", () -> {
			pages.getOpportunitypage().ClickConfigure();
		}).when("I am adding Products and Devices ", () -> {
			pages.getCartpage().ConfigureCart(data);
			pages.getOpportunitypage().changestatustoEstablishNeed();
		}).then("I verified that Products and Devices are added into Cart", () -> {
			Reporter.logWithScreenShot("Cart is Configured", MessageTypes.Info);
		}).execute();
	}

	@Test(description = "create quote", priority = 5, dependsOnMethods = { "addProductsToCart" })
	public void createQuote() {
		scenario().given("I am on Opportunity Page", () -> {
			
		}).when("I click on Create Quote ", () -> {
			
			pages.getOpportunitypage().CreateQuote();
		}).then("I verified that Quote is created", () -> {
			Reporter.logWithScreenShot("Create Quote", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test( priority = 6, dependsOnMethods = { "createQuote" })
	public void availabilityChecks(Map<String, String> data) throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I performed various availability checks ", () -> {
//			getDriver().get("https://pldtoneenterprise--r32sit.my.salesforce.com/");
//			pages.getLoginpage().LoginAsAdmin();
//			pages.getHomepage().switchToAnyUser("Jay Vinn Abaday");
//			getDriver().get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Quote/0Q01s0000006FiuCAE/view");
//			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
			
			if(util.getEnvironment().equalsIgnoreCase("NR32SIT")) 
			{
				pages.getQuotepage().ClickAddProducts();
				pages.getCartpage().QuickActionsAddProductsToCart(data);
				
			}
			if(util.getEnvironment().equalsIgnoreCase("R32SIT")) 
			{			
			pages.getQuotepage().numberAvailabilityCheck();
			}
			pages.getQuotepage().deviceAvailabilityCheck();
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("I verified that checks are completed", () -> {
			Reporter.logWithScreenShot("Availability Checks", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote")
	@Test( priority = 7,dependsOnMethods = { "availabilityChecks" })
	public void updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I update Credit Information ", () -> {
			pages.getQuotepage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
		}).then("I verified that checks are completed", () -> {
			Reporter.logWithScreenShot("Availability Checks", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile =  "resources/testdata/NewConnect.xlsx", sheetName = "BillingAccounts")
	@Test( priority = 8,dependsOnMethods = { "updateQuoteValidatyPeriod_DeliveryDate_ContactDetails" })
	public void createBillingAccount(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Billing Account ", () -> {

			pages.getBillingAndServiceAccount().createBillingAccount();
		}).then("I verified that Billing Account is Created", () -> {
			Reporter.logWithScreenShot("Billing Account is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "ServiceAccounts")
	@Test( priority = 9,dependsOnMethods = { "createBillingAccount" })
	public void createServiceAccount(Map<String, String> data) throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Billing Account ", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			pages.getBillingAndServiceAccount().createServiceAccount();
		}).then("I verified that Billing Account is Created", () -> {
			Reporter.logWithScreenShot("Billing Account is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test( priority = 10,dependsOnMethods = { "createServiceAccount" })
	public void updateAccounts(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I Update Billing and Service Account", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			pages.getQuotepage().ModifyProducts(data.get("Plan")); 
			pages.getCartpage().clickPlanDownArrow(data);
			pages.getCartpage().UpdateAccounts(data);
			pages.getAddressassignmentpage().AssignBillingAccount(props.getPropertyValue("BillingAccountName"));
			pages.getAddressassignmentpage().AssignServiceAccount(props.getPropertyValue("ServiceAccountName"));
			if(data.get("SecondPlan").contains("Y")) 
			{
			pages.getCartpage().clickSecondPlanDownArrow(data);
			pages.getCartpage().SecondUpdateAccounts(data);
			pages.getAddressassignmentpage().AssignBillingAccount(props.getPropertyValue("BillingAccountName"));
			pages.getAddressassignmentpage().AssignServiceAccount(props.getPropertyValue("ServiceAccountName"));
			}
			pages.getCartpage().SaveWorkingCart();
//			pages.getCartpage().ViewRecord(); 
			if(!util.getEnvironment().equalsIgnoreCase("R32SIT"))
			{
			pages.getCartpage().WorkingCartConfigure();
			}
			util.waitForQuotePage();
		}).then("I verified that Billing Account and Service Account is Updated", () -> {
			Reporter.logWithScreenShot(" Updated Billing and Service Accounts", MessageTypes.Info);
		}).execute();
	}

	
	@Test(description = "Validating cart", priority = 11,dependsOnMethods = { "updateAccounts" })
	public void validateCart() {
		scenario().given("I am on Quote Page", () -> {
		}).when("I Validate the Cart", () -> {
			pages.getQuotepage().ValidateCart();
			Reporter.logWithScreenShot("Cart is Validated", MessageTypes.Info);
			pages.getLoginpage().logoutCurrentUser();                                               
		}).then("I verified that Cart is Validated", () -> {
		}).execute();
	}
	@QAFDataProvider(dataFile =  "resources/testdata/NewConnect.xlsx", sheetName = "Quote")
	@Test( priority = 12,dependsOnMethods = { "validateCart" })
	public void creditCheck(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I perform and move the status to approved", () -> {		
//			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			pages.getHomepage().switchToAnyUser(props.getPropertyValue("Credit_Analyst"));
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			pages.getQuotepage().CreditCheck();
			pages.getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
					data.get("CreditApprovalCondition"), data.get("CreditRemark"));
			pages.getLoginpage().logoutCurrentUser(); 
//			getDriver().get("https://pldtoneenterprise--r32sit.my.salesforce.com/");
//			getDriver().manage().window().maximize();
//			pages.getLoginpage().LoginAsAdmin();
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
//			getDriver().get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Quote/0Q01s0000006ES7CAM/view");
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			
		}).then("I verified that Credit Check is completed and Status is moved to Approved", () -> {
			Reporter.logWithScreenShot("Credit check and moved status to Approved", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Opportunity")
	@Test(description = "EBIT", priority = 13,dependsOnMethods = { "creditCheck" })
	public void performEbitApprovalTest(Map<String, String> data)
	{
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I perform and move the status to approved", () -> {
		
//			getDriver().get("https://pldtoneenterprise--r32sit.my.salesforce.com/");
//			getDriver().manage().window().maximize();
//			pages.getLoginpage().LoginAsAdmin();
//			pages.getHomepage().switchToAnyUser("Jay Vinn Abaday");
//			getDriver().get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Quote/0Q01s0000006JgOCAU/view");
//			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
//			util.waitForQuotePage();
			util.scrollIntoElement(By.xpath("(//h3[.='Internal Approvals'])[1]"));
			if(!util.isElementDisplayed(By.xpath("//span[.='EBIT']/following::span[contains(text(),'40.00%')]"))) {
			pages.getQuotepage().submitEBITForApproval(data);
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("Business Head"));
			pages.getQuotepage().approveEBIT(data);
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
			getDriver().get(ProjectBeans.getQuoteURL());
			}
			pages.getQuotepage().changeStatusToApproved();
		}).then("I verified that Credit Check is completed and Status is moved to Approved", () -> {
			Reporter.logWithScreenShot("Credit check and moved status to Approved", MessageTypes.Info);
		}).execute();
		
		
		
	}
	

	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test( priority = 14,dependsOnMethods = { "performEbitApprovalTest" })
	public void deviceReservations(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Device Reservation and move the status to Accepted", () -> {

			pages.getQuotepage().DeviceReservation(data);
		}).then("I verified that Device reservation is completed and Status is moved to Accepted", () -> {
			Reporter.logWithScreenShot(" Device reservation", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test( priority = 15,dependsOnMethods = { "deviceReservations" })
	public void numberReservation(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Number Reservation", () -> {
			
				pages.getQuotepage().numberReservationCheck(data);
				if(data.get("SecondPlan").contains("Y")) 
				{
					pages.getQuotepage().numberReservationCheck(data);
				}
				
		}).then("I verified that Number Reservation is completed", () -> {
			Reporter.logWithScreenShot("Number Reservation is Completed", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile =  "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")

	@Test( priority = 16,dependsOnMethods = { "numberReservation" })
	public void syncronizeQLIItems(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Create Contract", () -> {
//			ConfigurationManager.getBundle().setProperty("testdata", data);
//			getDriver().get("https://pldtoneenterprise--r32sit.my.salesforce.com/");
//			getDriver().manage().window().maximize();
//			pages.getLoginpage().LoginAsAdmin();
//			pages.getHomepage().switchToAnyUser("Jay Vinn Abaday");
//			getDriver().get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Quote/0Q01s0000006FNrCAM/view");
			App().Pages().getQuotepage().SynchronizingAccount(data.get("Plan"),data.get("Relationship Manager"));
			pages.getQuotepage().ChangeStatusToAccepted(data);

		}).then("I verified that Contract is Created", () -> {
			Reporter.logWithScreenShot("Contract is Created", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile =  "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test( priority = 17,dependsOnMethods = { "syncronizeQLIItems" })
	public void CreateContract(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Create Contract", () -> {
			pages.getQuotepage().CreateContract();
			pages.getQuotepage().ChangeTheStatusToSigned();
			ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
		}).then("I verified that Contract is Created", () -> {
			Reporter.logWithScreenShot("Contract is Created", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile =  "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test( priority = 18,dependsOnMethods = { "CreateContract" })
	public void orders(Map<String, String> data) {
		scenario().given("I am on Contract Page", () -> {
		}).when("I move to orders page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList=pages.getQuotepage().VerifyOrders();
		}).then("I verified the status of Orders", () -> {
			Reporter.logWithScreenShot(" Orders", MessageTypes.Info);
		}).execute();
	}
	
	@Test( priority = 19,dependsOnMethods = { "orders" })
	public void getReferenceData()
	{
		Reporter.log("Lead URL :"+ProjectBeans.getLeadURL(), MessageTypes.Info);
		Reporter.log("Account URL :"+ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Opportunity URL :"+ProjectBeans.getOpportunityURL(), MessageTypes.Info);
		Reporter.log("Quote URL :"+ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :"+ProjectBeans.getContractURL(), MessageTypes.Info);
		

		if(orderList.size()>0)
		{
			for(int i=0;i<orderList.size();i++)
			{
				Reporter.log("Order _"+(i+1)+" URL : "+orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
