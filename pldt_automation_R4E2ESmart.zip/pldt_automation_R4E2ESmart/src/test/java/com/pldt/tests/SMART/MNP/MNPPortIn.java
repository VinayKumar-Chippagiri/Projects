package com.pldt.tests.SMART.MNP;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class MNPPortIn extends BaseTest {
	WebUtilities util = new WebUtilities();
	ArrayList<String> orderList = null;
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();


	
	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Login", key = "${key.name}")
	@Test(description = "MNP PortIn")
	public void loginAsAdmin(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Login Page", () -> {
//			props.setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
		}).when("I log in as Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().LoginAsAdmin();
		}).then("I verified that I logged in as an Admin", () -> {
			Reporter.logWithScreenShot(" Logged in as Relationship Manager", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Login",key = "${key.name}")
	@Test(description = "MNP PortIn", priority = 2, dependsOnMethods = { "loginAsAdmin" })
	public void switchToRelationshipManager(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Home Page", () -> {
			props.setProperty("testdata", data);
		}).when("I Switched as Relationship Manager", () -> {
			util.waitFor(5);
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).then("I verified that I Switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Switched to Relationship Manager", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Account", priority = 3, dependsOnMethods = { "switchToRelationshipManager" })
	public void Open_Existing_Account(Map<String, String> data) {
	scenario().given("I am in home page", () -> {
	util.refreshPage();
	util.waitFor(5);
	}).when("I open " + data.get("Account_Name") + " account", () -> {
	App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
	props.setProperty("Account", data.get("Account_Name"));
	util.waitFor(10);
	}).then("I verify that account details page of " + data.get("Account_Name") +" is displayed", () -> {
	String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
	.getText();
	Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
	}).when("I click on contacts", () -> {
	getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
	util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
	}).and("I captured the contact name", () -> {
	String AuthorizedSignatory = getDriver().findElement(By.xpath("//span[.='Authorized Signatory']/ancestor::tr//th//a"))
	.getText();
	props.setProperty("Authorized.Signatory", AuthorizedSignatory);
	Reporter.log("Authorized Signatory: " + AuthorizedSignatory);
	String Bill_Recipient = getDriver()
	.findElement(By.xpath("//span[.='Bill Recipient']/ancestor::tr//th//a")).getText();
	props.setProperty("Bill.Recipient", Bill_Recipient);
	Reporter.log("Bill Recipient: " + Bill_Recipient);
	String Delivery_Recipient = getDriver()
			.findElement(By.xpath("//span[.='Delivery Recipient - Smart']/ancestor::tr//th//a")).getText();
			props.setProperty("Delivery.Recipient", Delivery_Recipient);
			Reporter.log("Delivery Recipient: " + Delivery_Recipient);
	Reporter.logWithScreenShot("Account Contact Details");
	}).and("I clicked on account and navigate back to account details page", () -> {
	QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
	AccountName.click();
	}).then("then i verified that account details page is dispayed", () -> {
	util.waitForAccountPage();
	Reporter.logWithScreenShot("Account Details Page");
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "LeadPage")
	@Test(description = "Creating Lead", priority = 3,dependsOnMethods = { "switchToRelationshipManager" })
	public void CreatingLead(Map <String,String> data) {
		scenario().given("I am on list of lead page", () -> {
			util.waitFor(5);
			pages.getHomepage().goToAPP("Leads");
			pages.getLeadpage().getLeadNewButton().verifyVisible();
			pages.getLeadpage().getLeadNewButton().click();
			pages.getLeadpage().selectRecordType("ee");
			pages.getLeadpage().getLeadNextButton().click();
		}).when("I add Lead Information for the New Lead: Enterprise Extension ", () -> {
			pages.getLeadpage().fillTheLeadForm(data);
			util.waitForLeadPage();  
			Reporter.logWithScreenShot("Lead info is entered", MessageTypes.Info);
			pages.getLeadpage().markLeadStatusAsQualified();
			ProjectBeans.setLeadURL(getDriver().getCurrentUrl());
		}).then("I verify that user is changed as Credit Analyst and perform credit", () -> {
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			getDriver().get(ProjectBeans.getLeadURL());
			util.waitForLeadPage();
			pages.getLeadpage().validateCreditCheck();
			pages.getLeadpage().convertLead(data);
			pages.getLoginpage().logoutCurrentUser();
			Reporter.logWithScreenShot("user is changed and perform credit", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Contact")
	@Test(description = "CreatingNewContactforNewConnect", priority = 4, dependsOnMethods = {"CreatingLead" })
	public void contactCreationTest(Map<String, String> data) {
		scenario().given("Navigating to Accounts to create Contact", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
			getDriver().get(ProjectBeans.getAccountURL());
			util.waitForAccountPage();
			pages.getAccountpage().ClickContacts();
			pages.getContactpage().clickNewAccContact();
		}).when("I add Contact Information for the New Contact", () -> {
			pages.getContactpage().fillContactForm();
			pages.getContactpage().clickSaveButton();
			pages.getLoginpage().logoutCurrentUser();
		}).then("I verify that information is entered", () -> {
			Reporter.logWithScreenShot("Laed info is entered", MessageTypes.Info);
		}).execute();
	}


	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Creating new opportunity for MNP portin", priority = 5, dependsOnMethods = { "switchToRelationshipManager" })
	public void createQuote(Map<String, String> data) throws InterruptedException {
		scenario().when("Navigating to Accounts to create Opportunity", () -> {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
		getDriver().get(ProjectBeans.getAccountURL());
		util.waitForAccountPage();
		if (util.getEnvironment().equalsIgnoreCase("NSIT234")) {
			pages.getAccountpage().CreateQuoteinAccountpage(data, data.get("OpportunityRecordType"),
					data.get("OpportunityType"), data.get("ContractingParty"), data.get("CurrentProvider"));
		} 
	}).when("I add Opportunity Information for the New Opportunity ", () -> {
	}).then("I verified that Opportunity is Created", () -> {
		Reporter.logWithScreenShot("Opportunity is Created", MessageTypes.Info);
	}).execute();
}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Cart",key = "${key.name}")
	@Test(description = "Configure Cart", priority = 6, dependsOnMethods = { "createQuote" })
	public void configureCart(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Opportunity Page", () -> {
		}).when("I click on configure", () -> {
			
			App().Pages().getQuotepage().ClickAddProducts();					//Flow2
			//App().Pages().getOpportunityDetailsPage().ClickConfigure();
		}).and("Configured the cart by adding plan and device", () -> {
			
			App().Pages().getCartpage().QuickActionsAddProductsToCart(data);
		}).then("i verified that Cart is Updated", () -> {
			Reporter.logWithScreenShot(" Cart is Updated", MessageTypes.Info);
		}).execute();
	}

	@Test(description = "Device Availability", priority = 7, dependsOnMethods = { "configureCart" })
	public void deviceAvailability() {
		scenario().given("I am on Opportunity Page", () -> {
		}).when("I perform Device Availability", () -> {
			//App().Pages().getOpportunityDetailsPage().DeviceAvailability();
			App().Pages().getQuotepage().deviceAvailabilityCheck();
		}).then("i verified that Device Availability is Completed", () -> {
			Reporter.logWithScreenShot("Device Availability", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "BillingAccount",key = "${key.name}")
	@Test(description = "Creating new Quote and Billing Acccounts", priority = 8, dependsOnMethods = {
			"deviceAvailability" })
	public void createQuoteAndBillingAccount(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Opportunity Page", () -> {
		}).when("I Click on Create Quote", () -> {
//			App().Pages().getOpportunityDetailsPage().CreateQuote();
//			util.waitForQuotePage();
			
		}).and("I Create a Billing Account", () -> {
			//util.waitFor(12);
			util.waitForQuotePage();
			util.waitFor(3);
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl());	// SET Quote URL
			
			App().Pages().getBillingAndServiceAccount().createBillingAccount();
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		}).then("i verified that Quote, Billing Account is Created", () -> {
			Reporter.logWithScreenShot("Billing Account is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "ServiceAccount",key = "${key.name}")
	@Test(description = "Creating new  Service Acccounts", priority = 9, dependsOnMethods = {
			"createQuoteAndBillingAccount" })
	public void createServiceAccount(Map<String, String> data) throws InterruptedException {

		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Service Account", () -> {
			util.waitForQuotePage();
			App().Pages().getBillingAndServiceAccount().createServiceAccount();
			getDriver().get(ProjectBeans.getQuoteURL());
		}).then("i verified that Service Account is Created", () -> {
			Reporter.logWithScreenShot("Service Account is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Cart",key = "${key.name}")
	@Test(description = "Update Billing account In Cart Page", priority = 10, dependsOnMethods = {
			"createServiceAccount" })
	public void updateBillingAccount(Map<String, String> data) throws InterruptedException {

		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Update Billing and Service Account", () -> {
			util.waitForQuotePage();
			App().Pages().getQuotepage().ModifyProducts(data.get("Plan")); 
			App().Pages().getCartpage().clickPlanDownArrow(data);
			App().Pages().getCartpage().UpdateAccounts(data);
			App().Pages().getAddressassignmentpage().AssignBillingAccount(props.getPropertyValue("BillingAccountName"));
		}).then("i verified that Billing Account is Updated", () -> {
			Reporter.logWithScreenShot(" Updated Billing  Accounts", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "ServiceAccount",key = "${key.name}")
	@Test(description = "Update Service Account In Cart Page", priority =11, dependsOnMethods = {
			"updateBillingAccount" })
	public void updateServiceAccount(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Address Assignment Page", () -> {
		}).when("I Update Service Account", () -> {
			App().Pages().getAddressassignmentpage().AssignServiceAccount(props.getPropertyValue("ServiceAccountName"));
			App().Pages().getCartpage().SaveWorkingCart();
			if(!util.getEnvironment().equalsIgnoreCase("R32SIT"))
			{
				util.waitFor(5);
				App().Pages().getCartpage().WorkingCartConfigure();
			}
			util.waitForQuotePage();
		}).then("i verified Service Account is Updated", () -> {
			Reporter.logWithScreenShot(" Updated Service Accounts", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Update Quotation Validity period, Contacts, Delivery Date", priority = 12, dependsOnMethods = {
			"updateServiceAccount" })
	
	public void updateQuote(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Update Quotation Validity period, Contacts and Delivery Date", () -> {
			util.refreshPage();
			util.waitForQuotePage();		
			App().Pages().getQuoteDetailsPage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
		}).then("i verified that All the necessary fields are updated", () -> {
			Reporter.logWithScreenShot(" Updated Quotation Validity Period, Contacts, Delivery Date",
					MessageTypes.Info);
		}).execute();
	}

	@Test(description = "Validate Cart", priority = 13, dependsOnMethods = {
			"updateQuote" })
	public void validateCart() {
		scenario().given("I am on Quote Page", () -> {
		}).when("I perform Validate Cart", () -> {
			util.waitFor(3);
			util.refreshPage();
			util.waitForQuotePage();
			App().Pages().getQuoteDetailsPage().ValidateCart();
		}).then("i verified that Cart is Validated", () -> {
			Reporter.logWithScreenShot(" Validate Cart", MessageTypes.Info);
		}).execute();
	}

	@Test(description = "Credit Check", priority = 14, dependsOnMethods = {
			"validateCart" })
	public void creditCheck() {
		scenario().given("I am on Quote Page", () -> {
		}).when("I perform Credit Check", () -> {
			util.waitForQuotePage();
			App().Pages().getQuoteDetailsPage().CreditCheck(); // Next Button
		}).then("i verified that Credit Check is Initiated", () -> {
			Reporter.logWithScreenShot(" Credit Check is Initiated ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Login",key = "${key.name}")
	@Test(description = "Logout and Login as CA", priority = 15, dependsOnMethods = { "updateQuote" })
	public void logoutAndLoginAsCreditAnalyst(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("logout and Login as Credit Analyst", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
				App().Pages().getHomepage().switchToAnyUser(data.get("Credit Analyst"));			
		}).then("i verified that I am Logged in as Credit Analyst", () -> {
			Reporter.logWithScreenShot(" Logged in as Credit Analyst ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Credit check using Credit Analyst", priority = 16, dependsOnMethods = {
			"logoutAndLoginAsCreditAnalyst" })
	public void updateCreditInformation(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I update Credit Information using Credit Analyst", () -> {
			try {
				Thread.sleep(5000);
			} catch (Exception e) {
			}
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			App().Pages().getQuoteDetailsPage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
					data.get("CreditApprovalCondition"), data.get("CreditRemark"));
			util.waitTillLoaderDissapear();
		}).then("i verified that Credit Information Fields are Updated", () -> {
			Reporter.logWithScreenShot("Credit Information ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Login",key = "${key.name}")
	@Test(description = "Logout and Login as RM", priority = 17, dependsOnMethods = { "updateCreditInformation" })
	public void logoutAndLoginAsRelationshipManager(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("logout and Login as Relationship Manager", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
			util.waitFor(5);
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).then("i verified that I am Logged in as Relationship Manager", () -> {
			Reporter.logWithScreenShot(" Logged in as Relationship Manager ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Cart",key = "${key.name}")
	@Test(description = "Synchronizing Account", priority = 18, dependsOnMethods = {
			"logoutAndLoginAsRelationshipManager" })
	public void synchronizingAccounts(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I navigate to Quote Line Items ", () -> {
			try {
				Thread.sleep(6000);
			} catch (Exception e) {
			}
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			App().Pages().getQuoteDetailsPage().SynchronizingAccount(data.get("Plan"),data.get("Relationship Manager"));
		}).then("i verified that Synchronization is completed", () -> {
			Reporter.logWithScreenShot("Synchronization", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Quote",key = "${key.name}")
    @Test(description = "Device Reservation", priority = 19, dependsOnMethods = { "synchronizingAccounts" })
	public void deviceReservation(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I perform Device Reservation", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
		util.waitForQuotePage();
		App().Pages().getQuotepage().DeviceReservation(data);
		}).and("I changed the status to Accepted", () -> {
			App().Pages().getQuoteDetailsPage().ChangeStatusToAccepted();
			util.waitTillLoaderDissapear();
		}).then("i verified that Device Reservation is Completed and Status is changed to Accepted", () -> {
			Reporter.logWithScreenShot(" Device Reservation", MessageTypes.Info);
		}).execute();
	}
	

	@Test(description = "Contract", priority = 20, dependsOnMethods = { "deviceReservation" })
	public void contract() {
		scenario().given("I am on Quote Page", () -> {
		}).when("I Click on Create Contract", () -> {
			App().Pages().getQuoteDetailsPage().CreateContract();
			util.waitForContractPage();
			ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // Set Contract URL
		}).when("I change the status to Awaiting Signature", () -> {
			App().Pages().getContractpage().ChangeTheStatusToSigned();
			util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 10, false);
			util.waitForContractPage();
		}).then("i verified that Contract is created and Status is changed to Awaiting Signature", () -> {
			Reporter.logWithScreenShot("Contract is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Contract",key = "${key.name}")
	@Test(description = "Upload file", priority = 21, dependsOnMethods = { "contract" })
	public void generateDocuments(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Contract Page", () -> {
		}).when("I click on generate Documents ", () -> {
			util.refreshPage();
			util.waitForContractPage();
			App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
		}).then("i verified that File is Uploaded", () -> {
			Reporter.logWithScreenShot(" Generate Documents ", MessageTypes.Info);
		}).execute();
	}

	@Test(description = "Orders", priority = 22, dependsOnMethods = { "generateDocuments" })
	public void verifyOrders() {
		scenario().given("I am on Contract Page", () -> {
		}).when("I move to orders page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList=pages.getQuotepage().VerifyOrders();
		}).then("I verified the status of Orders", () -> {
			Reporter.logWithScreenShot(" Orders", MessageTypes.Info);
		}).execute();
	}
	
	@Test(priority = 23, dependsOnMethods = { "verifyOrders" })
	public void getReferenceData()
	{
		
		Reporter.log("Account URL :"+ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :"+ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :"+ProjectBeans.getContractURL(), MessageTypes.Info);
		if(orderList.size()>0)
		{
			for(int i=0;i<orderList.size();i++)
			{
				Reporter.log("Order _"+(i+1)+" URL : "+orderList.get(i), MessageTypes.Info);
			}
		}
	}
	
	
	}

