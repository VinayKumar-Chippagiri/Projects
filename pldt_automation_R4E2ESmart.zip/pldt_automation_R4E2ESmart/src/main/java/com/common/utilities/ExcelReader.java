package com.common.utilities;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;

public class ExcelReader {
	
	public static String[][] readExcel(String absolutePathToFile) {

		// A Two dimensional array of Strings which represents the data in the
		// sheet
		String[][] data = null;
		try {
			// A Buffered File Input Stream to read the data
			InputStream is = new BufferedInputStream(new FileInputStream(
					absolutePathToFile));
			// Workbook representing the excel file
			XSSFWorkbook wb = new XSSFWorkbook(is);
			// Next a sheet which represents the sheet within that excel file
			XSSFSheet sheet = wb.getSheet("Details");
			// No of rows in the sheet
			int rowNum = sheet.getLastRowNum() + 1;
			// No of columns in the sheet
			int colNum = 0;
			//int colNum = sheet.getRow(0).getLastCellNum();
			data = new String[rowNum][colNum];
			for (int i = 0; i < rowNum; i++) {
				// Get the row
				XSSFRow row = sheet.getRow(i);
				for (int j = 0; j < colNum; j++) {
					// Get the columns or cells for the first row and keep
					// looping
					// for the other rows
					XSSFCell cell = row.getCell(j);
					// Make a call to the method cellToString which actually
					// converts the cell contents to String
					String value = cellToString(cell);
					data[i][j] = value;
					// Logic for handling the data
					// You can write the logic here, or leave the method as it
					// is to return a two dimensional array
					// representing the excel data
					System.out.println("Value:" + value);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;

	}

	private static String cellToString(XSSFCell cell) {

		Object result;

		switch (cell.getCellType()) {
		case NUMERIC:
			result = cell.getNumericCellValue();
			break;

		case STRING:
			result = cell.getStringCellValue();
			break;

		case BOOLEAN:
			result = cell.getBooleanCellValue();
			break;

		case FORMULA:
			result = cell.getCellFormula();
			break;

		default:
			throw new RuntimeException("Unknown Cell Type");
		}

		return result.toString();
	}
	
	public static void updateCSV(Map<String ,String> data,String caseID) throws IOException {
		File inputFile;
		if(!data.get("Transaction Type").contains("SIM Activation")) {
         inputFile = new File(".\\resources\\testdata\\BulkFile (5).csv");
		}else {
			 inputFile = new File(".\\resources\\testdata\\Bulk_Transaction Asset_SIM Activation.csv");	
		}
		// Read existing file
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        List<String[]> csvBody = null;
		try {
			csvBody = reader.readAll();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CsvException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // get CSV row column and replace with by using row and column
        for(int i=1; i<csvBody.size(); i++){
            String[] strArray = csvBody.get(i);
            strArray[0]=caseID;
//            for(int j=0; j<strArray.length; j++){
//                if(strArray[j].equalsIgnoreCase("CaseID")){ //String to be replaced
//                    csvBody.get(i)[j] = caseID; //Target replacement
//                }
//            }
        }
        reader.close();

        // Write to CSV file which is open
        CSVWriter writer = new CSVWriter(new FileWriter(inputFile));
        writer.writeAll(csvBody);
        writer.flush();
        writer.close();
    }
	
}
