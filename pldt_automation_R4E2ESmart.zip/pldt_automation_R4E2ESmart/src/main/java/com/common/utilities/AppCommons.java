package com.common.utilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class AppCommons extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	static JavascriptExecutor executor = null;
	List<String> listId = new ArrayList<String>();

	public void markCaseStatus(QAFWebElement status) {
		executor = (JavascriptExecutor) driver;
		int temp = 0;
		while (temp <= 5) {
			if (status.isDisplayed()) {
				System.out.println(status.isDisplayed());
				status.waitForEnabled(10000);
				util.clickUsingJs(status);
				break;
			}
			QAFWebElement nextArrow = new QAFExtendedWebElement("//button/span[text()='Next']");
			util.clickUsingJs(nextArrow);
			temp++;
		}
	}

	public void UpdateIDInCSVFile(String file, String value) {
		try {
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader);
			List<String[]> csvBody = csvReader.readAll();
			Iterator<String[]> iterator = csvBody.iterator();
			iterator.next();
			int rowno = 1;
			while (iterator.hasNext()) {
				String[] row = iterator.next();
				for (int i = 1; i < row.length; i++) {
					csvBody.get(rowno)[0] = value;
					System.out.println(csvBody.get(rowno)[0] = value);
				}
				rowno = rowno + 1;
			}
			csvReader.close();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeAll(csvBody);
			writer.flush();
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void refreshOrders(int refreshAttempts, int numberOfOrders) throws InterruptedException {
		String orderNumber = null;
		int ordercount = 0;
		int count = 0;
		while (ordercount < numberOfOrders) {
			try {
				orderNumber = driver.findElement(By.xpath("//span[@class='countSortedByFilteredBy']")).getText();
				ordercount = Integer.parseInt(orderNumber.split(" ")[0]);
				System.out.println(ordercount);
			} catch (Exception e) {
			}
			if (count == refreshAttempts) {
				break;
			}
			Thread.sleep(1000);
			driver.navigate().refresh();
			count++;
		}
	}

	public List<String> ReadListOfIDInCSVFile(String file) {
		try {
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader);
			List<String[]> csvBody = csvReader.readAll();
			Iterator<String[]> iterator = csvBody.iterator();
			iterator.next();
			int rowno = 1;
			while (iterator.hasNext()) {
				String[] row = iterator.next();
				String ids = csvBody.get(rowno)[0].toString();
				((ArrayList<String>) listId).add(ids);
				rowno = rowno + 1;
			}
			csvReader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listId;
	}

	public void UpdateListOfIDInCSVFile(String file, List<String> value) {
		try {
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader);
			List<String[]> csvBody = csvReader.readAll();
			Iterator<String[]> iterator = csvBody.iterator();
			iterator.next();
			int rowno = 1;
			for (int i = 0; i < csvBody.size() - 1; i++) {
				csvBody.get(rowno)[0] = value.get(i);
				System.out.println(csvBody.get(rowno)[0] = value.get(i));
				rowno = rowno + 1;
			}
			csvReader.close();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeAll(csvBody);
			writer.flush();
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// created by waseem
		public String pickLatestFileFromDownloads(String testname) {
			String currentUsersHomeDir = System.getProperty("user.home");
			String downloadFolder = currentUsersHomeDir + File.separator + "Downloads" + File.separator;
			File dir = new File(downloadFolder);
			File[] files = dir.listFiles();
			if (files == null || files.length == 0) {
				Reporter.log("There is no file in the folder");
			}
			File lastModifiedFile = files[0];
			for (int i = 1; i < files.length; i++) {
				if (lastModifiedFile.lastModified() < files[i].lastModified()) {
					lastModifiedFile = files[i];
				}
			}
			String k = lastModifiedFile.toString();
			System.out.println(lastModifiedFile);
			Path p = Paths.get(k);
			String file = p.getFileName().toString();
			String fileSuffix = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			new File(System.getProperty("user.dir") + "//Downloads//").mkdir();
			boolean newfile = new File(System.getProperty("user.dir") + "//Downloads//" + testname + fileSuffix).mkdir();
			Path sourcepath = Paths.get(k);
			Path destinationepath = Paths
					.get(System.getProperty("user.dir") + "//Downloads//" + testname + fileSuffix + "/" + file);
			try {
				Files.walk(sourcepath)
						.forEach(source -> copy(source, destinationepath.resolve(sourcepath.relativize(source))));
			} catch (IOException e) {
				e.printStackTrace();
			}
			return file;
		}
		
		static void copy(Path source, Path dest) {
			try {
				Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage(), e);
			}
		}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}
	
	public void cartPageSaveButton() {
	        util.scrollIntoElement(By.xpath("//button[@type='submit']"));
	        util.waitFor(2);
	        util.clickUsingJs(By.xpath("//button[@type='submit']"));
	        util.waitFor(3);
	        util.waitFor(By.xpath("//div[@class='slds-spinner_container']"), 50, false);
	}
	
	/**
	 * OrderQuantity --It increases the quantity of Products in the Cart Page.
	 * 
	 * @author Vinay
	 * @param Product --name of the product which is going to increase the quantity
	 *                .
	 * @return No return value.
	 */
	public void OrderQuantity(Map<String, String> data,String product) {
		util.clickUsingJs(
				driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]")));
		driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]")).clear();
		util.enterTextUsingJs(
				driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]")),
				data.get("Order Quantity").toString());
		driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]"))
				.sendKeys(Keys.BACK_SPACE);
		util.waitFor(8);
		util.waitForCartPageToastMessage();
		util.typeDataTo(driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]")),
				data.get("Order Quantity").toString().charAt(data.get("Order Quantity").toString().length() - 1) + "");
		util.waitFor(8);
		util.waitForCartPageToastMessage();
	}
	
	/**
	 * mousemover method help to move the mouse
	 * 
	 * @author Waseem
	 * @return No return value.
	 * @throws AWTException
	 */
	public void mouseMover() {
		Robot robot = null;
		try {
			robot = new Robot();
			Random random = new Random();
			int x = random.nextInt() % 640;
			int y = random.nextInt() % 480;
			robot.mouseMove(x, y);
		} catch (AWTException e) {
			e.printStackTrace();
		}
	}
}
