package com.pldt.elements;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.common.utilities.JSUtils;
import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class LookUp extends WebDriverBaseTestPage<WebDriverTestPage>{
	JSUtils js=new JSUtils();
	WebUtilities util = new WebUtilities();
	static String billingAccountNumber = null;
	public static By details = By.xpath("//span[text()='Details']");
	public static By billAccountNumber = By
			.xpath("//span[text()='CRM Billing Account Number']/parent::div/following-sibling::div/span/span");
	public static By related = By.xpath("//span[text()='Related']");
	
	public void getBillAccountNumber() {
		util.clickUsingJs(details);
		util.waitFor(billAccountNumber, 5, true);
		billingAccountNumber = driver.findElement(billAccountNumber).getText();
		pageProps.setProperty("billingAccountNumber", billingAccountNumber);
		util.clickUsingJs(related);
	}
	
	public void selectAndClickCaseSuggestedValue(By locator, String fieldName) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(locator);
			if (fieldName != null && !fieldName.equalsIgnoreCase("skip")) {
				js.enterTextUsingJavaScript(element, fieldName);
//				enterTextUsingJs(element, fieldName);
				element.sendKeys(Keys.BACK_SPACE);
				element.sendKeys(fieldName.charAt(fieldName.length() - 1) + "");
				StringBuffer check = new StringBuffer(fieldName);
				js.clickUsingJavaScript(By.xpath(("//lightning-primitive-icon/following::span[contains(text(),'" + "\"" + fieldName
						+ "\"" + " in')]").replace("\\", "")));
//				clickUsingJs(By.xpath(("//lightning-primitive-icon/following::span[contains(text(),'" + "\"" + fieldName
//						+ "\"" + " in')]").replace("\\", "")));
				if (fieldName.matches("^[0-9]*$")) {
					js.clickUsingJavaScript(By.xpath("(//span[.='" + fieldName + "']/preceding::td[1]//a)[last()]"));
//					clickUsingJs(By.xpath("(//span[.='" + fieldName + "']/preceding::td[1]//a)[last()]"));
				} else {
//					clickUsingJs(By.xpath("//a[.='" + fieldName + "']"));
					js.clickUsingJavaScript(By.xpath("//a[.='" + fieldName + "']"));
				}
				Reporter.logWithScreenShot("Entered:-" + fieldName + "", MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Typing data to :" + fieldName + " is failed");
		}

}
//	public void moveFromAvailableToChosen(String Available) {
//		driver.findElementByXPath("//span[@title='"+Available+"']").click();
//		util.clickUsingJs(moveDocumentArrow);
//	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
}
