package com.pldt.locators;

public interface ContractPageLocators 
{
	static final String Generate="xpath=//span[text()='Generate']/ancestor::button";
	static final String Negotiating="xpath=//span[text()='Negotiating']";
	static final String Awaiting_Signature="xpath=//span[text()='Awaiting Signature']";
	static final String Signed="xpath=//span[text()='Signed']";
	static final String Mark_Status_As_Complete="xpath=(//span[text()='Mark Status as Complete'])[2]";
	static final String Template_Select="xpath=//select[@id='template-select']";
//(//option[text()='SMART_LOU_MNPInterConsumerToCorporate_2021 (version 1) [Web]'])[1]
	static final String Check_In="xpath=//button[text()='Check In']";
	static final String Details="xpath=(//span[text()='Details'])";
	static final String Qoute="xpath=(//span[text()='Quote']/parent::*/following-sibling::div//a)[1]";
	static final String Mark_As_Current_Status="xpath=//span[text()='Mark as Current Status']";
}
