package com.pldt.locators;

public interface QuotePageLocators
{

	static final String Menu="xpath=(//i[@class='icon icon-v-menu2'])[1]";
	static final String CreateBillingAccount="xpath=(//span[text()='Create New Billing Account'])[1]";
	static final String CreateServiceAccount="xpath=(//span[text()='Create New Service Account'])[1]";
	static final String ServiceAccountName = "xpath=//span[normalize-space(text())='Account Information']/following::span[normalize-space(text())='Account Name']/following::input[1]";
	static final String BillingAccountName = "xpath=//span[normalize-space(text())='Account Information']/following::span[normalize-space(text())='Account Name']/following::input[1]";
	static final String Country = "xpath=//span[normalize-space(text())='Country']/following::div[1]";
	static final String Street = "xpath=//span[normalize-space(text())='Street']/following::textarea[1]";
	static final String City = "xpath=//span[normalize-space(text())='City']/following::input[1]";
	static final String State = "xpath=//span[normalize-space(text())='State/Province']/following::div[1]";
	static final String ZipCode = "xpath=//span[normalize-space(text())='Zip/Postal Code']/following::input[1]";
	static final String Save = "xpath=//span[normalize-space(text())='Save']";
	static final String LOB = "xpath=(//span[normalize-space(text())='LoB (Line of Business)']/following::div[1])";
	static final String AccountTypeCode = "xpath=(//span[normalize-space(text())='Account Type Code']/following::input[1])";
	static final String NotifyEmailID = "xpath=(//span[normalize-space(text())='Notify Email ID']/following::input[1])";
	static final String NotifyMobileNo = "xpath=(//span[normalize-space(text())='Notify Mobile No']/following::input[1])";
	static final String BillingAddress = "xpath=(//span[normalize-space(text())='Billing Address Line 1']/following::input[1])";
	static final String BillingCity = "xpath=(//span[normalize-space(text())='Billing City']/following::input[1])";
	static final String Barangay = "xpath=(//span[normalize-space(text())='BARANGAY']/following::input[1])";
	static final String BillingZipCode = "xpath=(//span[normalize-space(text())='Billing Zip/Postal Code']/following::input[1])";
	static final String Configure = "xpath=(//span[text()='Configure']/parent::div)[1]";
	static final String Edit_Quote_Validity = "xpath=//button[@title='Edit Quotation Validity Period (Days)']";
	static final String Quote_Validity = "xpath=//span[text()='Quotation Validity Period (Days)']/parent::label/following-sibling::input";
	static final String Authorized_Signatory = "xpath=//span[text()='Authorized Signatory']/parent::label/following-sibling::div//input";
	static final String Bill_Recipient = "xpath=//span[text()='Bill Recipient']/parent::label/following-sibling::div//input";
	static final String Delivery_Recipient = "xpath=//span[text()='Delivery Recipient']/parent::label/following-sibling::div//input";
	static final String CAP_Contact = "xpath=//span[text()='CAP Contact']/parent::label/following-sibling::div//input";
	static final String Edit_Delivery_Date = "xpath=//button[@title='Edit Delivery Date']";
	static final String Delivery_Date="xpath=//span[text()='Delivery Date']/parent::label/following-sibling::div/input";
	static final String Quote_Save="xpath=//button[@title='Save']";
	static final String Validate_Cart="xpath=(//span[text()='Validate Cart']/parent::div)[1]";
	static final String Go_To_Quote="xpath=//div[@id='GoToQuote']";
	static final String Credit_Check="xpath=(//span[text()='Credit Check'])[1]/parent::div/i/following-sibling::div/following-sibling::span";
	static final String Credit_Check_Next_Button="xpath=(//p[text()='Next'])[1]";
	static final String Edit_Credit_Approval_Status="xpath=//button[@title='Edit Credit Approval Status']";
	static final String Credit_Approval_Status="xpath=//span[text()='Credit Approval Status']/parent::span/following-sibling::div//a";
	static final String Credit_Approval_Condition="xpath=//span[text()='Credit Approval Condition']/parent::span/following-sibling::div//a";
	static final String Credit_Remarks="xpath=//span[text()='Credit Remarks']/parent::label/following-sibling::textarea";
	static final String Quote_Search_Page="xpath=//input[@name='Quote-search-input']";
	static final String QuickFilter= "xpath=//button[@title='Show quick filters']";
	static final String QuoteNameSearch="xpath=(//label[text()='Quote Name']/following::input)[1]";
	static final String Related="xpath=//span[text()='Related']"; 
	static final String QLI_Related="xpath=(//span[text()='Related'])[2]"; 
	static final String Quote_Line_Items="xpath=//span[@title='Quote Line Items']";
	static final String Quote_Line_Account_Details="xpath=//span[@title='QLI Account Detail']";
	static final String Device_Reservation="xpath=(//span[text()='Device Reservation']/parent::div)[1]";
	static final String Device_Reservation_Next_Button="xpath=(//p[text()='Next'])[1]";// new
	static final String Accepted="xpath=//span[text()='Accepted']"; 
	static final String Mark_Status_As_Complete="xpath=//span[text()='Mark Status as Complete']";
	static final String Mark_As_Current_Status="xpath=//span[text()='Mark as Current Status']";
	static final String Create_Contract="xpath=(//span[text()='Create Contract']/parent::div)[1]";
	static final String Contract_Next_Button="xpath=//p[text()='Next']";
	static final String Orders="xpath=//span[@title='Orders']";
	static final String Listview = "xpath=//button[@title='Select List View']";
	static final String Smart_Credit_Team_Pending_Items = "xpath=(//span[text()='SMART Credit Team Pending Items'])[1]";
	static final String Credit_Check_Status_Next_Button = "xpath=(//p[text()='Next'])[2]";
	static final String Assign_PortIn_MIN = "xpath=(//span[text()='Assign PortIn MIN']/parent::div)[1]";
	static final String Assign = "xpath=//span[text()='Assign']";
	static final String Back_To_Quote = "xpath=//span[text()='Back To Quote']";
	//static final String Upload = "xpath=(//input[@type='file']/following::label)[3]";
	static final String Upload = "xpath=(//span[text()='Upload Files'])[2]";
	static final String Done = "xpath=//span[text()='Done']";
}
