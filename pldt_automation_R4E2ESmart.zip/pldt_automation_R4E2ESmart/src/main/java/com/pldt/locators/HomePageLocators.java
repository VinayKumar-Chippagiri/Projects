package com.pldt.locators;

public interface HomePageLocators {
	static final String global_search="xpath=(//lightning-primitive-icon)[1]";
	static final String global_search_input="xpath=//input[@placeholder='Search...']";
	static final String User_Detail="xpath=(//div[@title='User Detail'])[1]/parent::a";
	static final String login_btn="xpath=(//input[@title='Login'])[1]";
	static final String frame="xpath=//*[@id=\"setupComponent\"]/div[2]/div/div/force-aloha-page/div/iframe";
	
	static final String appLauncher = "xpath=//*[@aria-label='App']/one-app-launcher-header/button/div";
	static final String appSearch = "xpath=//input[@placeholder='Search apps and items...']";
	
	static final String logout_UserBtn = "xpath=//a[@class='action-link']";
	static final String user_appLauncher= "xpath=//div[@class='slds-icon-waffle']";
	static final String LOGIN_LOGO = "xpath=//div[@id='logo_wrapper' and @class='standard_logo_wrapper mb24']";
	
	static final String SETUP_HOMEPAGEbtn = "xpath=//div[@class='setupGear']//a";
	static final String SETUP_Link= "xpath=//li[@id='related_setup_app_home']";
	static final String SETUPUSERHEADING = "css=div.slds-page-header.branding-setup.onesetupSetupHeader";
}
