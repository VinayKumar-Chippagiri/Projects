package com.pldt.locators;



public interface LeadPageLocators {
	static final String LEAD_NEW_BUTTON = "//div[@title=\"New\"]";
	static final String LEAD_TYPE_ENTERPRISE_EXTENSION = "//span[text()='Enterprise Extension']";
	static final String LEAD_TYPE_BUSINESS = "//span[text()='Business']";
	static final String LEAD_TYPE_INFINITY = "//span[text()='Infinity']";
	static final String LEAD_NEXT_BUTTON = "//span[text()='Next']/parent::button";
	static final String LEAD_CONVERTED_TITLE = "xpath=//lightning-formatted-text[text()='Your lead has been converted']";
	static final String LEAD_SALUTATION = "xpath=//input[@name=\"salutation\"]";
	static final String LEAD_FIRST_NAME = "xpath=//input[@placeholder='First Name']";
	static final String LEAD_MID_NAME = "xpath=//input[@placeholder='Middle Name']";
	static final String LEAD_LAST_NAME = "xpath=//input[@placeholder='Last Name']";
	static final String LEAD_SUFFIX = "xpath=//input[@placeholder='Suffix']";
	static final String LEAD_TITLE = "xpath=//input[@name=\"Title\"]";
	static final String LEAD_ROLE = "xpath=//label[text()='Lead Role']//parent::lightning-combobox//input";
	static final String LEAD_STATUS = "xpath=//label[text()='Lead Status']//parent::lightning-combobox//input";
	static final String LEAD_NOT_QUALIFIED_REASON = "xpath=//*[text()='Not Qualified Reason']//following::div[3]";
	static final String LEAD_SOURCE = "xpath=//label[text()='Lead Source']//parent::lightning-combobox//input";
	static final String LEAD_PRODUCT_INTEREST = "xpath=//label[text()='Product Interest']//parent::lightning-combobox//input";
	static final String LEAD_OTHER = "xpath=//input[@name=\"Other__c\"]";
	static final String LEAD_DESCRIPTION = "xpath=//label[text()='Description']//parent::lightning-textarea //div/textarea";
	static final String LEAD_TYPE = "xpath=//label[text()=\"Lead Type\"]//parent::lightning-combobox//div/lightning-base-combobox/div/div/input";
	static final String LEAD_PRODUCT_OF_INTEREST = "xpath=//label[text()=\"Lead Product of Interest\"]//parent::lightning-textarea/div/textarea";
	static final String LEAD_RTS_REASON = "xpath=//label[text()=\"RTS Reasons\"]//parent::lightning-combobox/div/lightning-base-combobox/div/div/input";
	static final String LEAD_RFS_DATE = "xpath=//input[@name='RFS_Date__c']";
	static final String LEAD_CALL_BACKDATE = "xpath=//input[@name='Call_Back_Date__c']";
	static final String LEAD_ANNUAL_REVENUE = "xpath=//input[@name=\"AnnualRevenue\"]";
	static final String LEAD_MIN_FOR_PORT_IN = "xpath=//input[@name=\"MNP_MIN_for_Port_In__c\"]";
	static final String LEAD_CURRENT_PROVIDER = "xpath=//label[text()='Current Provider']//parent::lightning-combobox//input";
	static final String LEAD_OFFER_PACKAGE = "xpath=//*[text()='Offer package']//following::div[3]/input";
	static final String LEAD_PHONE = "xpath=//input[@name=\"Phone\"]";
	static final String LEAD_MOBILE = "xpath=//input[@name=\"MobilePhone\"]";
	static final String LEAD_BIRTHDATE = "xpath=//input[@name='Birthdate__c']";
	static final String LEAD_EMAIL = "xpath=//input[@name=\"Email\"]";
	static final String LEAD_CREDIT_CHECK = "xpath=//input[@name=\"Credit_Check__c\"]";
	static final String LEAD_SEARCH_ADDRESS = "xpath=//input[@placeholder=\"Search Address\"]";
	static final String LEAD_COUNTRY = "xpath=//input[@name='country']";
	static final String LEAD_STREET = "xpath=//textarea[@name='street']";
	static final String LEAD_CITY = "xpath=//input[@name='city']";
	static final String LEAD_STATE_PROVINCE = "xpath=//input[@name='province']";
	static final String LEAD_ZIP_POSTAL_CODE = "xpath=//input[@name='postalCode']";
	static final String LEAD_COMPANY = "xpath=//input[@name='Company']";
	static final String LEAD_COMPANY_TIN = "xpath=//input[@name='Company_TIN__c']";
	static final String LEAD_COMPANY_TRADE_NAME = "xpath=//input[@name='Company_Trade_Name__c']";
	static final String LEAD_INDUSTRY = "xpath=//*[text()='Industry']//following::div[3]/input";
	static final String LEAD_COMPANY_SIZE = "xpath=//*[text()='Company Size']//following::div[3]/input";
	static final String LEAD_SUB_INDUSTRY = "xpath=//*[text()='Sub-Industry']//following::div[3]/input";
	static final String LEAD_BUSINESS_TYPE = "xpath=//*[text()='Business Type']//following::div[3]/input";
	static final String LEAD_BUSINESS_REGISTRATION_TYPE = "xpath=//*[text()='Business Registration Type']//following::div[3]/input";
	static final String LEAD_BUSINESS_REGISTRATION_NUMBER = "xpath=//input[@name='Business_Registration_Number__c']";
	static final String LEAD_OTHER_BUSINESS_REGISTRATION_TYPE = "xpath=//input[@name='Other_Business_Registration_Type__c']";
	static final String LEAD_WEBSITE = "xpath=//input[@name=\"Website\"]";
	static final String LEAD_LINE_OF_BUSINESS = "xpath=//*[text()='LOB(Line of Business)']//following::div[3]/input";
	static final String LEAD_ACCOUNT_CLASS = "xpath=//*[text()='Account Class']//following::div[3]/input";
	static final String LEAD_EVENT_TRADE_SHOW_REFERRAL_NAME = "xpath=//input[@name='Event_Trade_Show_Referral_Name__c']";
	static final String LEAD_CANCEL_BUTTON = "xpath=//button[@name='CancelEdit']";
	static final String LEAD_SAVE_NEW_BUTTON = "xpath=//button[@name='SaveAndNew']";
	static final String LEAD_SAVE_BUTTON = "xpath=//button[@name='SaveEdit']";
	static final String LEAD_QUALIFIED_STAGE="xpath=//span[@class='ahead slds-path__stage']/following-sibling::span[text()='Qualified']";
	static final String LEAD_MARK_AS_CURRENT_STATUS="xpath=//span[text()='Mark as Current Status']";
	static final String LEAD_DETAIL_TAB="xpath=//a[@id='detailTab__item']";
	static final String LEAD_CREDIT_SECTION="xpath=//span[.='Personal Information']";
	static final String LEAD_CREDIT_LABEL="xpath=(//span[text()='Credit Check']/parent::label/span)[1]";
	static final String LEAD_EDIT_CREDIT_ICON="xpath=//button[.='Edit Credit Check']";
	static final String LEAD_CREDIT_CHECKBOX="xpath=//input[@name='Credit_Check__c']";
	static final String LEAD_CONVERTED_BUTTON="xpath=//ul[@class='slds-path__nav']//span[.='Converted']";
//	static final String LEAD_CONVERT_BUTTON="xpath=//button[contains(@class,'runtime_sales_leadConvertModalFooter')][2]";
	static final String LEAD_CONVERT_BUTTON="xpath=//button[contains(text(),'Convert')]";	
	//static final String LEAD_CONVERT_BUTTON="xpath=//button[contains(@class,'runtime_sales_leadConvertModalFooter')][2]|//button[@class='slds-button slds-button_brand']";
	static final String LEAD_SELECT_CONVERTED_STATUS="xpath=//span[.='Select Converted Status']";
	static final String LEAD_BANNER_ACCOUNT ="xpath=(//a[@class=' outputLookupLink slds-truncate outputLookupLink-0011s00001Gxw2KAAR-4:4986;a forceOutputLookup'])";
	static final String LEAD_BANNER_CLOSE="xpath=(//button[@class='slds-button slds-button--icon-inverse slds-modal__close uiButton--modal-closeBtn uiButton'])";
	static final String AssignUsingActiveAssignmentRule="xpath=//span[contains(.,'Assign')]//span[@class='slds-checkbox_faux']";
	
	
}
