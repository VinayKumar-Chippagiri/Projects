package com.pldt.locators;

public interface CartPageLocators 
{
	static final String SelectPriceList="xpath=//div[text()='Price List']//parent::div/button";
	static final String EnterpricePHPprice="xpath=//span[text()='Enterprise PHP Price List']";
	static final String ProductSearchBox="xpath=//div[@class='slds-col slds-no-flex slds-input-has-icon slds-input-has-icon_left cpq-searchbox']/input";
	static final String AddToCart="xpath=(//button[@class='slds-button slds-button_neutral cpq-add-button'])[1]";
	static final String RecurringCharges="xpath=(//span[@class='cpq-underline']/span)[1]";
	static final String EditPriceBtn="xpath=(//button[@title='Change Price'])[1]";
	static final String AdjustmentDropdown="xpath=//button[@id='cpq-custom-adjustment-view-button']";
	static final String SelectAmount="xpath=//a/span[text()='Amount']";
	static final String EnterAmount="xpath=//input[@class='slds-input ng-pristine ng-valid ng-empty ng-valid-step ng-touched']";
	static final String Apply="xpath=//button[@class='slds-button slds-button--brand']";
	static final String ViewRecord="xpath=//button[@title='View Record']";
	static final String DeviceConfigurationBtn="xpath=(//button[@title='Show Actions'])[2]"; //new
	static final String ConfigureDevice="xpath=((//button[@title='Show Actions'])/following-sibling::div/ul/li[3]/a)[2]";
	static final String DeviceArrow="xpath=(//button[@class='slds-button slds-button_icon-small'])[1]";
	static final String DeviceCapacity="xpath=(//select[@class='slds-select ng-pristine ng-empty ng-invalid ng-invalid-required ng-touched'])";
	static final String RecurringCharges2="xpath=(//span[@class='cpq-underline'])[1]/span/span";
	static final String RecurringTotal2="xpath=(//span[@class='cpq-underline'])[2]/span/span";
	static final String Menu="xpath=(//i[@class='icon icon-v-menu2'])[1]";
	static final String AddChildProduct="xpath=//div[@class=slds-lookup__menu slds-size--1-of-1]";
	static final String SearchChildProduct="xpath=//input[@class='slds-lookup__search-input slds-input ng-pristine ng-valid ng-empty ng-touched']";
	static final String AddChildProduct2="xpath=//div[@class=slds-lookup__menu slds-size--1-of-1]";
	static final String DetailIconMenu="xpath=//i[@class='icon icon-v-menu2']detailIconMenu_XPATH=//i[@class='icon icon-v-menu2']";
	static final String SearchDevice="(//input[@placeholder='Search' and @role='combobox'])[1]"; //new
	static final String SelectDeviceSuggestion="xpath=//ul[@class='slds-lookup__list']/li[2]";
	static final String ConfigureDeviceDrop="xpath=(//button[@class='slds-button slds-button_icon-border-filled cpq-item-actions-dropdown-button'])[2]";
	static final String DeletePlan="xpath=(//span[@class='slds-truncate cpq-action-item-label'])[4]";
	static final String ConfirmDelete="xpath=//button[text()='Delete']";
	static final String PaymentType="xpath=//select[@name='productconfig_field_0_0']";
	static final String PaymentType2="xpath//select[@name='productconfig_field_1_0']";
	static final String EnterSmartPricePricing="xpath=//span[text()='SMART Price List']";
	static final String EnterEnterprisePHPPricing="xpath=//span[text()='Enterprise PHP Price List']";
	static final String ConfigureDeviceDropDown="xpath=(//button[@class='slds-button slds-button_icon-border-filled cpq-item-actions-dropdown-button'])[2]";
	static final String ConfigureDevicePlan="xpath=(//span[@class='slds-truncate cpq-action-item-label'])[9]";
	static final String ConfigureDevicePlan2="xpath=(//span[@class='slds-truncate cpq-action-item-label'])[7]";
	static final String DevicePaymentType="xpath=//select[@name='productconfig_field_0_0']";
	static final String DevicePaymentType2="xpath=//select[@name='productconfig_field_1_0']";
	static final String DeviceCapacity3="xpath=//select[@name='productconfig_field_0_1']";
	static final String DeviceCapacity2="xpath=//select[@name='productconfig_field_1_1']";
	static final String DeviceColor="xpath=//select[@name='productconfig_field_0_2']";
	static final String DeviceColor2="xpath=//select[@name='productconfig_field_1_2']";
	static final String Close= "xpath=//button[@ng-click='importedScope.close()']"; //new
	static final String DeviceRecurringChareges="xpath=(//span[@class='cpq-underline'])[5]";
	static final String DeviceOneTimeCharges="xpath=(//span[@class='cpq-underline'])[7]";
	static final String PlanRecurringTotal="xpath(//span[@class='cpq-underline'])[2]";
	static final String PlanOneTimeTotal="xpath=(//span[@class='cpq-underline'])[4]";
	static final String DeviceRecurringTotal="xpath=(//span[@class='cpq-underline'])[6]";
	static final String DeviceOneTimeTotal="xpath=(//span[@class='cpq-underline'])[7]";
	static final String SearchDevice2="xpath=//span[text()='Devices']/../../../following-sibling::div//input";
	static final String PlanConfig="xpath=(//button[@title='Show Actions'])[1]";
	static final String UpdateAccount="xpath=((//button[@title='Show Actions'])/following-sibling::div/ul/li[7]/a)";
	static final String SearchBillAccount="xpath=(//p[normalize-space(text())='Billing Account']/following::input[1])";
	static final String BillAccountCheckBox ="xpath=(//span[@class='slds-radio'])[1]";
	static final String SearchServiceAccount ="xpath=(//p[normalize-space(text())='Site A Address / Delivery Address / Installation Address']/following::input[1])";
	static final String ServiceAccountCheckBox ="xpath=(//span[@class='slds-radio'])[2]";
	static final String Save ="xpath=//button[@title='Save']";

}
