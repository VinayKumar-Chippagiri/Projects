package com.pldt.locators;

import org.openqa.selenium.By;

import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public interface CasePageLocators {
	static final String Billingacc_search = "xpath=//span[text()='Billing Account']/following::input[1]";
	static final String Contactname_search = "xpath=//span[text()='Contact Name']/following::input[1]";
	static final String Consigneename_search = "xpath=//span[text()='Consignee Name']/following::input[1]";
	static final String Subject = "xpath=//span[text()='Subject']/following::input[@class=' input'][1]";
	static final String Line_of_business = "xpath=//span[text()='Line of Business']/following::a[1]";
	static final String Type_of_cust_req = "xpath=//span[text()='Type of Customer Request']/following::a[1]";
	static final String Type = "xpath=(//span[text()='Type']//following::a[1])[2]";
	static final String High_level_Trans_class = "xpath=//span[text()='High Level Transaction Classification']/following::a[1]";
	static final String Trans_type = "xpath=//span[text()='Transaction Type']/following::a[1]";
	static final String Trans_sub_type = "xpath=//span[text()='Transaction Sub Type']/following::a[1]";
	static final String Trans_reason = "xpath=//span[text()='Transaction Reason']/following::a[1]";
	static final String Case_origin = "xpath=//span[text()='Case Origin']/following::a[1]";
	static final String Status = "xpath=//label[text()='Status']/following::input[1]";
	static final String Rec_provider = "xpath=//span[text()='Recipient Provider']/following::a[1]";
	static final String Current_provider = "xpath=//span[text()='Current Provider']/following::a[1]";
	static final String MIN_portin = "xpath=//span[text()='MIN for Port In']/following::input[1]";
	static final String Save = "xpath=//button[@title='Save']";
	static final String Save_N_new = "xpath=//button[@title='Save & New']";
	static final String Cancel = "xpath=//button[@title='Cancel']";
	static final String newcase = "xpath=//div[.='New']";
	static final String SMARTSERREQ = "xpath=//*[text()='SMART Service Request']";
	static final String NEWCASE_NEXT = "xpath=//span[.='Next']";

	
	static final String Case_filter = "xpath=(//button[@title='Show quick filters'])[last()]";   //  Updated 7th Feb

	static final String Subject_inputBox = "xpath=(//label[text()='Subject']/following::input)[1]";
	static final String Apply_Btn = "xpath=(//button[@title='Apply'])[2]";
	static final String Apply_Btn2 = "xpath=//button[@title='Apply']";
	static final String CLOSE_FILTER = "xpath=//button[@title='Close Filters']";
	static final String caseInfo = "xpath=//span[text()='Case Information']";
	static final String caseOwner = "xpath=//span[text()='Case Owner']/following::span[@class='displayLabel']/slot";
	static final String casenumber = "xpath=//span[text()='Case Information']//following::span[text()='Case Number']/following::lightning-formatted-text[1]";
	static final String casenumber2 = "xpath=(//span[text()='Case Number']/following::lightning-formatted-text)[4]";
	static final String setupSearchBox = "//div[@class='uiInput uiAutocomplete uiInput--default']/input";
	static final String groupQueues = "xpath=//a[@class='scopesItem slds-nav-vertical__action']//span[text()='Groups and Queues']";
	static final String groupName = "//a[text()='EBG MNP Team']";
	static final String queueUserName = "xpath=//th[text()='Name']/following::tr[2]/th/a";
	static final String userLoginBtn = "xpath=(//input[@title='Login'])[1]";
	static final String frame = "xpath=//div[@class='content iframe-parent']//iframe";
	static final String QueuesSetUpFrame = "xpath=";
	static final String toastmsg = "xpath=//span[@class='toastMessage slds-text-heading--small forceActionsText']";
	static final String filterCase = "xpath=//button[@title='Select a List View']";
	static final String filterCaseSearch = "xpath=//input[@class='slds-input default input uiInput uiInputTextForAutocomplete uiInput--default uiInput--input']";
	static final String searchList = "xpath=//input[@placeholder='Search this list...']";
	static final String casecheckbox = "css=tbody label.slds-checkbox";
	static final String caseAcceptbtn = "xpath=//div[@title='Accept']";
	static final String eligibilityCheckBtn = "xpath=(//span[text()='Eligibility Check']/parent::div)[1]";
	static final String ThreeDotQuickActionTool = "xpath=(//i[@class='icon icon-v-menu2'])[1]";
	static final String caseTitle = "xpath=//div[@class='slds-align-middle fade-text']";
	static final String showMoreActions = "xpath=(//span[text()='Show more actions']/parent::button)[last()]";
	static final String uploadBulk = "xpath=(//span[text()='Upload Bulk File'])[last()]";
	static final String customObjects = "xpath=//a[text()='Custom objects']";
	static final String mnpPortabilityCheckBtn = "xpath=//a[text()='MNPPortabilityChecks']";
	static final String updateExistingRec = "xpath=//a[text()='Update existing records']";
	static final String matchBy = "xpath=(//select[@class='select uiInput uiInputSelect uiInput--default uiInput--select'])[1]";
	static final String salesforcecom = "xpath=(//option[text()='Salesforce.com ID']/parent::select)[1]";
	static final String csv = "xpath=//span[text()='CSV']";
	static final String chooseFile = "xpath=//input[@name='file']";
	static final String importFileNextButton = "xpath=//a[text()='Next']";
	static final String editMappingFieldNextButton = "xpath=//a[text()='Next']";
	static final String startImport = "xpath=//a[text()='Start Import']";
	static final String okButton = "xpath=//a[text()='OK']";
	static final String generateLOU = "xpath=(//span[text()='Generate LOU']/parent::div)[1]";
	static final String successTitle = "xpath=(//h1[@class='slds-page-header__title vlc-slds-page-header__title slds-truncate ng-binding'])[1]";
	static final String backToCaseBtn = "xpath=//p[text()='Back to Case']";
	static final String transactionDetails = "xpath=//a[text()='Transaction Details']";
	static final String transactionDetailsC = "xpath=//a[text()='Transaction Details']";
	static final String nextArrow = "xpath=//span[text()='Next']";
	static final String resolutionInProgress = "xpath=(//span[text()='Resolution In Progress'])[1]";
	static final String markStatusComplete = "xpath=//span[text()='Mark as Current Status']/..";
	static final String generateUSC = "xpath=(//span[text()='Generate USC']/parent::div)[1]";
	static final String doneBtn = "xpath=//p[text()='Done']";
	// bulk
	static final String transAssetBtn = "xpath=//a[text()='Transaction Assets']";
	static final String addNewRec = "xpath=//a[text()='Add new records']";
	static final String triggerCheckbox = "xpath=//input[@class='uiInput uiInputCheckbox uiInput--default uiInput--checkbox']";
	static final String caseLookupField = "xpath=(//select[@class='select uiInput uiInputSelect uiInput--default uiInput--select'])[3]";
	static final String editButton = "xpath=//button[@class='slds-button slds-button_brand' and text()='Edit']";
	static final String caseSectionNewcase = "xpath=//div[text()='Change Owner']/ancestor::ul/li/a/div[text()='New']";
	static final String availableDocuments = "xpath=//span[text()='Available']/following-sibling::div/ul/li[1]";
	static final String editButton1 = "xpath=//button[@class='slds-button slds-button_brand' and text()='Edit']";
	static final String PlanName = "xpath=//span[contains(text(),'Plan Name')]/parent::label/parent::div/input";
	static final String SelectPlanNextButton = "xpath=//p[text()='Next']";
	static final String Listview = "xpath=//button[@title='Select a List View']"; // updated
	static final String SearchInput = "xpath=//input[@placeholder='Search this list...']";
	static final String ViewRecord = "xpath=//button[@title='View Record']";

//*********************************************NEW CASE MODAL******************************************
	static final String SocialMediaRecordType ="xpath=//span[text()='Social Media Record Type']";
	static final String ICTInquiry = "xpath=//span[text()='ICT  Inquiry']";
	static final String ICTComplaint = "xpath=//span[text()='ICT Complaint']";
	static final String ICTServiceRequest = "xpath=//span[text()='ICT Service Request']";
	static final String PLDTComplaint ="xpath=//span[text()='PLDT Complaint']";
	static final String PLDTInquiry = "xpath=//span[text()='PLDT Inquiry']";
	static final String PLDTServiceRequest = "xpath=//span[text()='PLDT Service Request']";
	static final String SmartComplaint ="xpath=//span[text()='SMART Complaint']";
	static final String SmartInquiry = "xpath=//span[text()='SMART Inquiry']";
	static final String SmartServiceRequest ="xpath=//span[text()='SMART Service Request']";
	
//*****************************************************************************************************	
	static final String Accept = "xpath=//div[@title='Accept']";
	static String ChangeOwnerEdit = "xpath=//button[@title='Change Owner']";
	static String SearchUser = "xpath//input[@placeholder='Search Users...']";
	static String ChangeOwnerButton = "xpath//button[@name='change owner']";
}