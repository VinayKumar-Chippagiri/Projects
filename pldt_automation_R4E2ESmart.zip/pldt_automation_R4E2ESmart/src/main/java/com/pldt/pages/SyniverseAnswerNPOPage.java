package com.pldt.pages;

import java.util.Map;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SyniverseAnswerNPOPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	@FindBy(locator= "xpath=//td[text()='Reference ID:']/following::input[@name='value(sReferenceId)']")
	private QAFWebElement ReferenceID; 
	@FindBy(locator= "xpath=//td[text()='Owner ID:']/following::input[@name='value(sOwnerId)']")
	private QAFWebElement OwnerID; 
	@FindBy(locator= "xpath=//td[text()='BRN:']/following::input[@name='value(sRegistrationCode)']")
	private QAFWebElement BRN; 
	@FindBy(locator= "xpath=//td[text()='Porting Number:']/following::input[@name='value(sSubscriberNumber)']")
	private QAFWebElement PortingNumber;
	@FindBy(locator= "xpath=//input[@value='Search']")
	private QAFWebElement Search;
	@FindBy(locator= "xpath=//a[@class='CONTENT']")
	private QAFWebElement ReferenceIdLink;
	@FindBy(locator= "xpath=//input[@name='value(ApproveAll)']")
	private QAFWebElement ApproveAll;
	@FindBy(locator= "xpath=//input[@value='Approve']")
	private QAFWebElement Approve;
	@FindBy(locator= "xpath=//input[@value='Reject']")
	private QAFWebElement Reject;
	@FindBy(locator= "xpath=//select[@name='value(Reason1_0)']")
	private QAFExtendedWebElement Reason1;
	@FindBy(locator= "xpath=//select[@name='value(Reason2_0)']")
	private QAFExtendedWebElement Reason2;
	@FindBy(locator= "xpath=//select[@name='value(Reason3_0)']")
	private QAFExtendedWebElement Reason3;
	@FindBy(locator= "xpath=//input[@value='Send']")
	private QAFExtendedWebElement Send;
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	public QAFWebElement getReferenceID() {
		return ReferenceID;
	}
	public QAFWebElement getOwnerID() {
		return OwnerID;
	}
	public QAFWebElement getBRN() {
		return BRN;
	}
	public QAFWebElement getPortingNumber() {
		return PortingNumber;
	}
	public QAFWebElement getSearch() {
		return Search;
	}
	
	public QAFWebElement getReferenceIdLink() {
		return ReferenceIdLink;
	}
	public QAFWebElement getApproveAll() {
		return ApproveAll;
	}
	public QAFWebElement getApprove() {
		return Approve;
	}
	public QAFWebElement getReject() {
		return Reject;
	}
	
	public QAFExtendedWebElement getReason1() {
		return Reason1;
	}
	public QAFExtendedWebElement getReason2() {
		return Reason2;
	}
	public QAFExtendedWebElement getReason3() {
		return Reason3;
	}
	public QAFExtendedWebElement getSend() {
		return Send;
	}
	public void NPO(Map<String, String> data)
	{
		getPortingNumber().sendKeys(data.get("Porting Number"));
		getSearch().click();
		getReferenceIdLink().click();
		String NPO = data.get("NPO");
		if(NPO.equalsIgnoreCase("Clearence"))
		{
			getApproveAll().click();
		}
		else
		{
			getReject().click();
			//Mobile Number Mentioned Incorrect
			util.selectBy(getReason1(), data.get("Reason1"));
			util.selectBy(getReason2(), data.get("Reason2"));
			util.selectBy(getReason3(), data.get("Reason3"));
		}
		getSend().click();
		
	}
	
}
