package com.pldt.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.core.internal.resources.Project;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.logging.NeedsLocalLogs;

import com.common.utilities.ProjectBeans;
import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.microsoft.schemas.office.visio.x2012.main.PagesDocument;
import com.pldt.elements.Button;
import com.pldt.lib.PageLib;
import com.pldt.locators.QuotePageLocators;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.report.Report;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;
import com.qmetry.qaf.automation.util.Reporter;

public class QuotePage extends WebDriverBaseTestPage<WebDriverTestPage> implements QuotePageLocators {
	WebUtilities util = new WebUtilities();
	String deviceSalesNumber = null;
	String QuoteName = null;
	TestDataBean bean = new TestDataBean();
	DateUtil date = new DateUtil();

	@FindBy(locator = Menu)
	private QAFWebElement menu;
	@FindBy(locator = CreateBillingAccount)
	private QAFWebElement createBillingAccount;
	@FindBy(locator = CreateServiceAccount)
	private QAFWebElement createServiceAccount;
	@FindBy(locator = ServiceAccountName)
	private QAFWebElement serviceAccountName;
	@FindBy(locator = BillingAccountName)
	private QAFWebElement billingAccountName;
	@FindBy(locator = Country)
	private QAFWebElement country;
	@FindBy(locator = Street)
	private QAFWebElement street;
	@FindBy(locator = City)
	private QAFWebElement city;
	@FindBy(locator = State)
	private QAFWebElement state;
	@FindBy(locator = ZipCode)
	private QAFWebElement zipCode;
	@FindBy(locator = Save)
	private QAFWebElement save;
	@FindBy(locator = LOB)
	private QAFWebElement lOB;
	@FindBy(locator = AccountTypeCode)
	private QAFWebElement accountTypeCode;
	@FindBy(locator = NotifyEmailID)
	private QAFWebElement notifyEmailID;
	@FindBy(locator = NotifyMobileNo)
	private QAFWebElement notifyMobileNo;
	@FindBy(locator = BillingAddress)
	private QAFWebElement billingAddress;
	@FindBy(locator = BillingCity)
	private QAFWebElement billingCity;
	@FindBy(locator = Barangay)
	private QAFWebElement barangay;
	@FindBy(locator = BillingZipCode)
	private QAFWebElement billingZipCode;
	@FindBy(locator = Configure)
	private QAFWebElement configure;
	@FindBy(locator = Edit_Quote_Validity)
	private QAFWebElement editQuoteValidity;
	@FindBy(locator = Quote_Validity)
	private QAFWebElement quoteValidity;
	@FindBy(locator = Authorized_Signatory)
	private QAFWebElement authorizedSignatory;
	@FindBy(locator = Bill_Recipient)
	private QAFWebElement billRecipient;
	@FindBy(locator = Delivery_Recipient)
	private QAFWebElement deliveryRecipient;
	@FindBy(locator = CAP_Contact)
	private QAFWebElement capContact;
	@FindBy(locator = Edit_Delivery_Date)
	private QAFWebElement editDeliveryDate;
	@FindBy(locator = Delivery_Date)
	private QAFWebElement deliveryDate;
	@FindBy(locator = Quote_Save)
	private QAFWebElement quoteSave;
	@FindBy(locator = Validate_Cart)
	private QAFWebElement validateCart;
	@FindBy(locator = Go_To_Quote)
	private QAFWebElement goToQuote;
	@FindBy(locator = Credit_Check)
	private QAFWebElement creditCheck;
	@FindBy(locator = Credit_Check_Next_Button)
	private QAFWebElement creditCheckNextButton;
	@FindBy(locator = Edit_Credit_Approval_Status)
	private QAFWebElement editCreditApprovalStatus;
	@FindBy(locator = Credit_Approval_Status)
	private QAFWebElement creditApprovalStatus;
	@FindBy(locator = Credit_Approval_Condition)
	private QAFWebElement creditApprovalCondition;
	@FindBy(locator = Credit_Remarks)
	private QAFWebElement creditRemarks;
	@FindBy(locator = Quote_Search_Page)
	private QAFWebElement quoteSearchPage;
	@FindBy(locator = QuickFilter)
	private QAFWebElement quickFilter;
	@FindBy(locator = QuoteNameSearch)
	private QAFWebElement quoteNameSearch;
	@FindBy(locator = Related)
	private QAFWebElement related;
	@FindBy(locator = QLI_Related)
	private QAFWebElement QLIRelated;
	@FindBy(locator = Quote_Line_Items)
	private QAFWebElement quoteLineItems;
	@FindBy(locator = Quote_Line_Account_Details)
	private QAFWebElement quoteLineAccountDetails;
	@FindBy(locator = Device_Reservation)
	private QAFWebElement deviceReservation;
	@FindBy(locator = Device_Reservation_Next_Button)
	private QAFWebElement deviceReservationNextButton;
	@FindBy(locator = Accepted)
	private QAFWebElement accepted;
	@FindBy(locator = Mark_Status_As_Complete)
	private QAFWebElement markStatusAsComplete;
	@FindBy(locator = Mark_As_Current_Status)
	private QAFWebElement markAsCurrentStatus;
	@FindBy(locator = Create_Contract)
	private QAFWebElement createContract;
	@FindBy(locator = Contract_Next_Button)
	private QAFWebElement contractNextButton;
	@FindBy(locator = Orders)
	private QAFWebElement orders;
	@FindBy(locator = Listview)
	private QAFWebElement listview;
	@FindBy(locator = Smart_Credit_Team_Pending_Items)
	private QAFWebElement smartCreditTeamPendingItems;
	@FindBy(locator = Credit_Check_Status_Next_Button)
	private QAFWebElement creditCheckStatusNextButton;
	@FindBy(locator = Assign_PortIn_MIN)
	private QAFWebElement assignPortInMIN;
	@FindBy(locator = Assign)
	private QAFWebElement assign;
	@FindBy(locator = Back_To_Quote)
	private QAFWebElement backToQuote;
	@FindBy(locator = Upload)
	private QAFWebElement upload;
	@FindBy(locator = Done)
	private QAFWebElement done;
	// added by vidya
	@FindBy(locator = "//span[.='Offers']")
	private QAFWebElement offersButton;
	@FindBy(locator = "//button[.='Modify Products']")
	private QAFWebElement modifyProducts;
	@FindBy(locator = "//input[@placeholder='Enter Product Name']")
	private QAFWebElement productNameSearchBox;
	@FindBy(locator = "//label[contains(@for,'lgt-dt-header-factory')]//span[@class='slds-checkbox_faux']")
	private QAFWebElement productCheckbox;
	@FindBy(locator = "//button[@title='Close this window']")
	private QAFWebElement errorWindowCloseBtn;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getMenu() {
		return menu;
	}

	public QAFWebElement getCreateBillingAccount() {
		return createBillingAccount;
	}

	public QAFWebElement getCreateServiceAccount() {
		return createServiceAccount;
	}

	public QAFWebElement getServiceAccountName() {
		return serviceAccountName;
	}

	public QAFWebElement getBillingAccountName() {
		return billingAccountName;
	}

	public QAFWebElement getCountry() {
		return country;
	}

	public QAFWebElement getStreet() {
		return street;
	}

	public QAFWebElement getCity() {
		return city;
	}

	public QAFWebElement getState() {
		return state;
	}

	public QAFWebElement getZipCode() {
		return zipCode;
	}

	public QAFWebElement getSave() {
		return save;
	}

	public QAFWebElement getlOB() {
		return lOB;
	}

	public QAFWebElement getAccountTypeCode() {
		return accountTypeCode;
	}

	public QAFWebElement getNotifyEmailID() {
		return notifyEmailID;
	}

	public QAFWebElement getNotifyMobileNo() {
		return notifyMobileNo;
	}

	public QAFWebElement getBillingAddress() {
		return billingAddress;
	}

	public QAFWebElement getBillingCity() {
		return billingCity;
	}

	public QAFWebElement getBarangay() {
		return barangay;
	}

	public QAFWebElement getBillingZipCode() {
		return billingZipCode;
	}

	public QAFWebElement getConfigure() {
		return configure;
	}

	public QAFWebElement getEditQuoteValidity() {
		return editQuoteValidity;
	}

	public QAFWebElement getQuoteValidity() {
		return quoteValidity;
	}

	public QAFWebElement getAuthorizedSignatory() {
		return authorizedSignatory;
	}

	public QAFWebElement getDeliveryRecipient() {
		return deliveryRecipient;
	}

	public QAFWebElement getCapContact() {
		return capContact;
	}

	public QAFWebElement getBillRecipient() {
		return billRecipient;
	}

	public QAFWebElement getEditDeliveryDate() {
		return editDeliveryDate;
	}

	public QAFWebElement getDeliveryDate() {
		return deliveryDate;
	}

	public QAFWebElement getQuoteSave() {
		return quoteSave;
	}

	public QAFWebElement getValidateCart() {
		return validateCart;
	}

	public QAFWebElement getGoToQuote() {
		return goToQuote;
	}

	public QAFWebElement getCreditCheck() {
		return creditCheck;
	}

	public QAFWebElement getCreditCheckNextButton() {
		return creditCheckNextButton;
	}

	public QAFWebElement getEditCreditApprovalStatus() {
		return editCreditApprovalStatus;
	}

	public QAFWebElement getCreditApprovalStatus() {
		return creditApprovalStatus;
	}

	public QAFWebElement getCreditApprovalCondition() {
		return creditApprovalCondition;
	}

	public QAFWebElement getCreditRemarks() {
		return creditRemarks;
	}

	public QAFWebElement getQuoteSearchPage() {
		return quoteSearchPage;
	}

	public QAFWebElement getQuickFilter() {
		return quickFilter;
	}

	public QAFWebElement getQuoteNameSearch() {
		return quoteNameSearch;
	}

	public QAFWebElement getRelated() {
		return related;
	}

	public QAFWebElement getQLIRelated() {
		return QLIRelated;
	}

	public QAFWebElement getQuoteLineItems() {
		return quoteLineItems;
	}

	public QAFWebElement getQuoteLineAccountDetails() {
		return quoteLineAccountDetails;
	}

	public QAFWebElement getDeviceReservation() {
		return deviceReservation;
	}

	public QAFWebElement getDeviceReservationNextButton() {
		return deviceReservationNextButton;
	}

	public QAFWebElement getAccepted() {
		return accepted;
	}

	public QAFWebElement getMarkStatusAsComplete() {
		return markStatusAsComplete;
	}

	public QAFWebElement getMarkAsCurrentStatus() {
		return markAsCurrentStatus;
	}

	public QAFWebElement getCreateContract() {
		return createContract;
	}

	public QAFWebElement getContractNextButton() {
		return contractNextButton;
	}

	public QAFWebElement getOrders() {
		return orders;
	}

	public QAFWebElement getListview() {
		return listview;
	}

	public QAFWebElement getSmartCreditTeamPendingItems() {
		return smartCreditTeamPendingItems;
	}

	public QAFWebElement getCreditCheckStatusNextButton() {
		return creditCheckStatusNextButton;
	}

	public QAFWebElement getAssignPortInMIN() {
		return assignPortInMIN;
	}

	public QAFWebElement getAssign() {
		return assign;
	}

	public QAFWebElement getBackToQuote() {
		return backToQuote;
	}

	public QAFWebElement getUpload() {
		return upload;
	}

	public QAFWebElement getDone() {
		return done;
	}

	public void billing_InputAccountInfo() {
		util.type("CRM Account Number");
		util.type("Account Name");
		util.select("Account Currency");
		util.select("Parent Account Record Type");
		util.select("LoB (Line of Business)");
		util.select("Status");
		util.type("Parent Account");
		util.type("Case Number");
		Reporter.logWithScreenShot(
				"Successfully Entered Billing account information for the New Lead: Enterprise Extension ",
				MessageTypes.Pass);
	}

	public void billing_InputCustomerProfileInfo() {
		util.type("Company Trade Name");
		util.type("Company TIN");
		util.select("Industry");
		util.type("Personal TIN");
		util.select("Industry Sub Type");
		util.select("Credit Class");
		util.select("Bill Frequency");
		util.select("Tax Exemption");
		util.select("Bill Dispatch Method");
		util.select("Tax Exemption Rules");
		util.select("Bill Cycle");
		util.select("Tax Profile");
		util.click("eSOA Enrollment");
		util.type("eSOA Notification Email ID");
		util.select("Contact");
		Reporter.logWithScreenShot(
				"Successfully Entered Billing customer profile information for the New Lead: Enterprise Extension ",
				MessageTypes.Pass);
	}

	public void billing_InputSMARTBillingInfo() {
		util.select("Account Type Code");
		util.type("Credit Limit");
		util.select("Account Payment Type");
		util.select("THS Rating");
		util.select("Subscription");
		util.select("VIP Code");
		util.select("Service Provider");
		util.type("Assignee/ CI First Name");
		util.type("Assignee/ CI Middle Name");
		util.type("Assignee/ CI Last Name");
		Reporter.logWithScreenShot(
				"Successfully Entered Billing SMART Billing information for the New Lead: Enterprise Extension ",
				MessageTypes.Pass);
	}

	public void billing_InputPLDTBillingInfo() {
		util.type("Corporate Individual");
		util.type("For the Account Of");
		util.select("For the Account Of - Biz Act");
		Reporter.logWithScreenShot(
				"Successfully Entered Billing PLDT Billing information for the New Lead: Enterprise Extension ",
				MessageTypes.Pass);
	}

	public void billing_InputContactPreferences() {
		util.click("Email Notification");
		util.click("SMS Notification");
		util.click("Payment reminder callout");
		util.type("Notify Email ID");
		util.type("Notify Mobile No");
		Reporter.logWithScreenShot(
				"Successfully Entered Billing contact preference for the New Lead: Enterprise Extension ",
				MessageTypes.Pass);
	}

	public void billing_BillingAddressInfo() {
		util.type("Billing Address Line 1");
		util.type("Billing Address Line 2");
		util.type("Billing Address Line 3");
		util.select("Billing Country");
		util.select("Billing State/Province");
		util.select("Billing City");
		util.select("BARANGAY");
		util.select("Billing Zip/Postal Code");
		util.type("Billing City BackEnd");
		util.type("BARANGAY_BackEnd");
		util.type("Billing Zip/Postal Code BackEnd");
		Reporter.logWithScreenShot("Successfully Entered Billing Address info for the New Lead: Enterprise Extension ",
				MessageTypes.Pass);
	}

	public void billing_InputSMARTIntegrationUpdates() {
		util.select("FDC Collection Status");
		util.select("SFDC THS Status");
		Reporter.logWithScreenShot(
				"Successfully Entered Billing SMART address info for the New Lead: Enterprise Extension ",
				MessageTypes.Pass);
	}

	public void billing_InputLegacyInfoRef() {
		util.type("Legacy CSP Parent Account Number");
		util.type("Legacy CSP Parent Account Type Code");
		util.type("Legacy CSP Parent Account Name");
		util.type("Legacy CSP Parent Account ID");
		QAFExtendedWebElement saveBtn = new QAFExtendedWebElement("xpath=//button[@title='Save']");
		saveBtn.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Reporter.logWithScreenShot("Successfully Entered Billing Legacy Info for the New Lead: Enterprise Extension ",
				MessageTypes.Pass);
	}

	public void createBillingAccount() {
		billing_InputAccountInfo();
		billing_InputCustomerProfileInfo();
		billing_InputSMARTBillingInfo();
		billing_InputPLDTBillingInfo();
		billing_InputContactPreferences();
		billing_BillingAddressInfo();
		billing_InputSMARTIntegrationUpdates();
		billing_InputLegacyInfoRef();
	}

	public void createServiceAccount() {
	}

	public void UpdateQuotationValidityPeriod(String QuotationValidity) {
		util.scrollTillVisible(getEditQuoteValidity());
		getEditQuoteValidity().click();
		getQuoteValidity().sendKeys(QuotationValidity);
	}

	public void UpdateDeviceReservationInformation(String Delivery_Date) {
		getDeliveryDate().sendKeys(Delivery_Date);
		getQuoteSave().click();
	}

//	Created by Vinay to Validate Cart
	public void ValidateCart() {
		util.waitForQuotePage();
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Validate Cart");
		util.waitForVlocityOmniScript();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.scrollIntoElement(By.xpath("//div[@id='GoToQuote']"));
		Reporter.logWithScreenShot("Cart is Validated", MessageTypes.Info);
		util.clickUsingJs(By.xpath("//div[@id='GoToQuote']"));
		util.waitForQuotePage();
	}

//	Created by Vinay to perform CreditCheck
	public void CreditCheck() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Credit Check");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		Reporter.logWithScreenShot("Clicked on Next button");
		util.scrollTillVisible(By.xpath("//p[text()='Next']/parent::div"));
//		util.clickUsingJs(By.xpath("//p[text()='Next']/parent::div"));
		util.vlocityNextButton();
		try {
			util.clickUsingJs(driver.findElement(By.xpath("//div[@id='CreditCheckRequiredSMART_nextBtn']/p")));
		} catch (Exception e) {
		}
		util.waitForQuotePage();
	}

//	Created by Vinay to update quote validity,delivery date,contact details
	public void updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(Map<String, String> data) {
		util.waitFor(By.xpath("//span[.='Quotation Validity Period (Days)']"), 30, true);
		util.scrollIntoElement(By.xpath("//span[.='Quotation Validity Period (Days)']"));
		util.clickUsingJs(By.xpath("//button[@title='Edit Quotation Validity Period (Days)']"));
		util.waitFor(
				By.xpath("//span[text()='Quotation Validity Period (Days)']/parent::label/following-sibling::input"),
				10, true);
		util.enterText(
				driver.findElement(By.xpath(
						"//span[text()='Quotation Validity Period (Days)']/parent::label/following-sibling::input")),
				data.get("QuotationValidity"));
		util.clickUsingActions(By.xpath("//div[@class='active']//span[.='Quotation Validity Period (Days)']"));
		updateContactDetails(data);
		util.scrollIntoElement(By.xpath("(//span[.='Device Reservation Information'])[1]"));
		util.scrollIntoElement(By.xpath("//span[text()='Delivery Date']/parent::label/following-sibling::div/input"));
		util.enterText(
				driver.findElement(
						By.xpath("//span[text()='Delivery Date']/parent::label/following-sibling::div/input")),
				data.get("DeliveryDate"));
		util.clickUsingActions(By.xpath("//span[text()='Delivery Date']/parent::label"));
		update_EBIT();
		util.clickUsingJs(By.xpath("//button[@title='Save']"));
		util.waitFor(By.xpath("//span[text()='Delivery Date']/parent::label/following-sibling::div/input"), 40, false);
	}

	public void update_EBIT() {
		util.scrollIntoElement(By.xpath("(//h3[.='Internal Approvals'])[1]"));
		QAFWebElement input = new QAFExtendedWebElement(
				By.xpath("//span[text()='EBIT']/parent::label/following-sibling::input"));
		util.waitFor(By.xpath("//span[text()='EBIT']/parent::label/following-sibling::input"), 30, true);
		util.enterText(input, "40");
		util.clickUsingActions(By.xpath("//span[text()='EBIT']/parent::label"));
		util.clickUsingJs(By.xpath(
				"//button[contains(@class,'slds-button slds-button--neutral uiButton--brand uiButton forceActionButton')]"));
	}

	public void updateQuoteValidatyPeriod(Map<String, String> data) {
		util.waitFor(By.xpath("//span[.='Quotation Validity Period (Days)']"), 20, true);
		util.scrollIntoElement(By.xpath("//span[.='Quotation Validity Period (Days)']"));
		util.clickUsingJs(By.xpath("//button[@title='Edit Quotation Validity Period (Days)']"));
		util.waitFor(
				By.xpath("//span[text()='Quotation Validity Period (Days)']/parent::label/following-sibling::input"),
				30, true);
		util.enterText(
				driver.findElement(By.xpath(
						"//span[text()='Quotation Validity Period (Days)']/parent::label/following-sibling::input")),
				data.get("QuotationValidity"));
		util.clickUsingActions(By.xpath("//div[@class='active']//span[.='Quotation Validity Period (Days)']"));
		util.clickUsingJs(By.xpath("//button[@title='Save']"));
		util.waitFor(By.xpath("//button[@title='Save']"), 25, false);
	}

	public void reload(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		if (driver.findElement(By.xpath("//div[@class='reloadButton']/button/span")).isEnabled()) {
			util.clickUsingJs(driver.findElement(By.xpath("//div[@class='reloadButton']/button/span")));
			util.waitForQuotePage();
			updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
		}
	}

	public void SearchQuote(String Quote) throws InterruptedException {
		Thread.sleep(2000);
		getListview().click();
		getSmartCreditTeamPendingItems().click();
		getQuoteSearchPage().sendKeys(Quote);
		getQuoteSearchPage().sendKeys(Keys.ENTER);
		QAFWebElement quote = new QAFExtendedWebElement("xpath=(//a[@title='" + Quote + "'])[1]");
		util.clickButton(quote);
		Thread.sleep(3000);
	}

//	Created by Vinay to perform SynchronizingAccount
	public void SynchronizingAccount(String Plan, String RMUser) {
		util.clickUsingJs(getRelated());
		util.clickUsingJs(getQuoteLineItems());
		QAFWebElement plan = new QAFExtendedWebElement("xpath=(//a[@title='" + Plan + "'])[1]");
		util.clickButton(plan);
		getQLIRelated().click();
		getQuoteLineAccountDetails().click();
		util.waitFor(10);
		ProjectBeans.setQLIURL(driver.getCurrentUrl());
		int count = 1;
		Boolean synced = false;
		LocalTime time = LocalTime.now();
		System.out.println(time);
		Reporter.logWithScreenShot("Current Time " + time + "When Synchronize Starts", MessageTypes.Info);
		while (count <= 20) {
			util.waitFor(30);
			util.refreshPage();
			waitForPageToLoad();
			util.waitFor(By.xpath("(//span[.='CSP Account Sync Status']/following::tbody/tr/td[4]/span/span)[last()]"),
					30, true);
			Reporter.logWithScreenShot("CSP Account Sync Status of QLI Items ");
			if (driver
					.findElement(By
							.xpath("(//span[.='CSP Account Sync Status']/following::tbody/tr/td[4]/span/span)[last()]"))
					.getText().equalsIgnoreCase("Synced")) {
				synced = true;
				break;
			}
			System.out.println(driver
					.findElement(By
							.xpath("(//span[.='CSP Account Sync Status']/following::tbody/tr/td[4]/span/span)[last()]"))
					.getText());
			count++;
		}
		LocalTime endtime = LocalTime.now();
		System.out.println(endtime);
		Reporter.logWithScreenShot("Current Time " + endtime + "When CSP get Synced", MessageTypes.Info);
//		if (!synced) {
//			PageLib p = new PageLib();
//			p.getLoginpage().logoutCurrentUser();
//			driver.get(ProjectBeans.getQLIURL());
//			util.clickUsingJs(By.xpath("//a[contains(text(),'QLIA-')]"));
//			util.clickUsingJs(By.xpath("//button[@title='Edit CSP Account Sync Status']"));
//			System.out.println();
//			util.waitFor(10);
//			driver.findElement(By.xpath("(//label[.='CSP Account Sync Status']/following::div/button)[1]")).click();
//			// util.clickUsingJs(By.xpath("//label[text()='CSP Account Sync
//			// Status']/following::div[1]//button/span"));
//			util.clickUsingJs(By.xpath("//div/lightning-base-combobox-item[@data-value='Synced']"));
//			driver.findElement(By.xpath("//label[.='Error Message']/following::div/textarea")).clear();
//			util.clickUsingJs(By.xpath("//lightning-button//button[.='Save']"));
//			util.waitFor(By.xpath("//lightning-button//button[.='Save']"), 10, false);
//			util.waitFor(5);
//			driver.findElement(By.xpath(
//					"//span[.='CSP Account Sync Status']/following::lightning-formatted-text[normalize-space()='Synced']"))
//					.verifyVisible();
//			p.getHomepage().switchToAnyUser(RMUser);
//		}
		driver.get(ProjectBeans.getQuoteURL());
	}

	// Created by Vinay to Perform DeviceReservation
	public void DeviceReservation(Map<String, String> data) {
		String path = System.getProperty("user.dir") + "\\resources\\testdata\\Dummy.txt";
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Device Reservation");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//section[@id='Step3']//h1[contains(text(),'Device Availability')]"), 30, true);
		Reporter.logWithScreenShot("Verified Device Availability");
		util.vlocityNextButton();
		util.waitFor(5);
		util.AttachFrame();
		if (data.get("Delivery Mode").contains("Yes")) {
			Reporter.logWithScreenShot("Delivery Mode is Selected ");
			util.clickUsingJs(By.xpath(
					"//span[contains(text(),'RM delivery')]/ancestor::label/span[contains(@class,'slds-checkbox--faux')]"));
			util.waitFor(By.xpath("(//input[@type='file'])[last()]"), 10, true);
			QAFWebElement uploadFileBtn = new QAFExtendedWebElement(By.xpath("(//input[@type='file'])[last()]"));
			uploadFileBtn.sendKeys(path);
			util.waitFor(5);
			util.waitFor(By.xpath("(//ul/li/span[contains(@class,'binding')])"), 10, true);
		}
		util.vlocityNextButton();
		util.AttachFrame();
		if (util.isElementDisplayed(By.xpath("(//div//ng-form[@id='reservationStatusTxt']/div/p/p[1])[last()]"))) {
			deviceSalesNumber = util
					.getTextFromPage(By.xpath("(//div//ng-form[@id='reservationStatusTxt']/div/p/p[1])[last()]"))
					.split(" ")[4];
			Reporter.logWithScreenShot("Device Reservation is Successful");
		} else if (util.isElementDisplayed(By.xpath(
				"(//section[@id='DeviceAllocationUnsuccesful']//h1[contains(text(),'Device Reservation Unsuccessful')])[last()]"))) {
			deviceSalesNumber = util
					.getTextFromPage(By.xpath("(//section[@id='DeviceAllocationUnsuccesful']//ng-form//h1[2])[last()]"))
					.split(" ")[9];
			Reporter.logWithScreenShot("Device Reservation is Unsuccessful");
		}
		Reporter.log(deviceSalesNumber);
		util.vlocityNextButton();
		util.waitForQuotePage();
	}

//	Created by Vinay to Perform numberReservationCheck
	public void numberReservationCheck(Map<String, String> data) {
		System.out.println("Click on Number Reservation..");
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Number Reservation");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("(//*[contains(@class,'cards-container')])[1]//a[contains(.,'Search Numbers')]"), 30,
				true);
		Reporter.logWithScreenShot("Clicked on Search Numbers");
		util.clickUsingJs(By.xpath("(//*[contains(@class,'cards-container')])[1]//a[contains(.,'Search Numbers')]"));
		util.waitFor(8);
		util.AttachFrame();
		if (util.isElementDisplayed(By.xpath("(//h1[contains(text(),'Bulk Reservation Options')])[1]"))) {
			util.waitFor(By.xpath("//span[text()='Reserve any N available numbers']"), 5, true);
			util.refreshSwitchToFrame();
			util.AttachFrame();
			Reporter.logWithScreenShot("Choosen as Reserve any N avaialable numbers");
			util.clickUsingJs(By.xpath("//span[text()='Reserve any N available numbers']"));
			util.AttachFrame();
			util.clickUsingJs(By.xpath("//p[text()='Next']"));
			util.waitFor(3);
			util.AttachFrame();
			util.waitFor(By.xpath("(//p[.='Reserve Numbers'])[1]"), 5, true);
			Reporter.logWithScreenShot("Choosen Reserved Numbers");
			util.clickUsingJs(By.xpath("(//p[.='Reserve Numbers'])[1]"));
			util.waitFor(10);
			util.vlocityNextButton();
		} else {
			util.waitFor(By.xpath("//span[text()='Number/Pattern Search']"), 5, true);
			util.refreshSwitchToFrame();
			util.AttachFrame();
			Reporter.logWithScreenShot("Choosen Number/Pattern search");
			util.clickUsingJs(By.xpath("//span[text()='Number/Pattern Search']"));
			util.AttachFrame();
			util.clickUsingJs(By.xpath("//p[text()='Next']"));
			util.AttachFrame();
			if (!data.get("FreshMIN").contains("SKIP")) {
				util.enterText(By.xpath("//span[text()='Enter Number/Pattern']/following::input[@id='EnterNumber']"),
						data.get("FreshMIN"));
			}
			util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")), "Regular");
			util.clickUsingJs(By.xpath("(//p[.='Search MIN'])[1]"));
			util.clickUsingJs(By.xpath("(//th/button)[1]"));
			util.clickUsingJs(By.xpath("//div[@id='StepMINSearchNo_nextBtn']"));
			util.AttachFrame();
			util.clickUsingJs(By.xpath("(//p[text()='Next'])[3]"));
			util.AttachFrame();
			util.waitFor(By.xpath("//span[.='Number Reservation is successful.']"), 10, true);
			if (util.isElementDisplayed(By.xpath("(//span[.='Number Reservation is successful.'])[last()]"))) {
				util.AttachFrame();
				Reporter.logWithScreenShot("Number Reservation is Successful");
				util.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
			} else {
				for (int i = 0; i < 4; i++) {
					if (util.isElementDisplayed(By.xpath("(//span[.='Number Reservation is successful.'])[last()]"))) {
						util.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
						break;
					}
					util.AttachFrame();
					util.vlocityPreviousButton();
					util.AttachFrame();
					util.vlocityPreviousButton();
					util.AttachFrame();
					util.waitFor(By.xpath("//select[@id='NumberTypeMin']"), 60, true);
					util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")), "Regular");
					driver.findElement(By.xpath("(//p[.='Search MIN'])[1]")).click();
					driver.findElement(By.xpath("(//th/button)[1]")).click();
					driver.findElement(By.xpath("//div[@id='StepMINSearchNo_nextBtn']")).click();
					driver.findElement(By.xpath("(//p[text()='Next'])[3]")).click();
				}
			}
		}
		util.waitFor(By.xpath("//*[text()[contains(.,'View Quote')]]"), 5, true);
		util.refreshSwitchToFrame();
		util.clickUsingJs(By.xpath("//*[text()[contains(.,'View Quote')]]"));
		util.waitForQuotePage();
	}

	// Created by Vinay to Change the Status to accepted
	// if notification contains device it will update device reservation number and
	// change Status to accepted.
	public void ChangeStatusToAccepted(Map<String, String> data) {
		String notification = util.ChangeStatus("Accepted");
		Reporter.logWithScreenShot("Quote Status Changed to Accepted");
		if (notification.contains("device")) {
			PageLib p = new PageLib();
			p.getLoginpage().logoutCurrentUser();
			driver.get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			util.scrollIntoElement(By.xpath("(//span[.='Device Reservation Information'])[1]"));
			util.clickUsingJs(By.xpath("//button[@title='Edit Reservation Sales Number']//lightning-primitive-icon"));
			util.waitFor(By.xpath("//span[text()='Reservation Sales Number']/parent::label/following-sibling::input"),
					15, true);
			util.enterText(By.xpath("//span[text()='Reservation Sales Number']/parent::label/following-sibling::input"),
					deviceSalesNumber);
			util.clickUsingActions(By.xpath("//label[.='Reservation Sales Number']"));
			util.enterText(By.xpath("//span[text()='Reservation Status']/parent::label/following-sibling::input"),
					"Reserved");
			util.clickUsingActions(By.xpath("//label[.='Reservation Status']"));
			util.clickUsingJs(By.xpath("//button[@title='Save']"));
			util.waitFor(By.xpath("//span[text()='Reservation Status']/parent::label/following-sibling::input"), 10,
					false);
			p.getHomepage().switchToAnyUser("Jay Vinn Abaday");
			driver.get(ProjectBeans.getQuoteURL());
			util.ChangeStatus("Accepted");
		}
	}

//	Created by Vinay to change Status to Presented and Customer Approved
	public void changeStatusToApproved() {
		QAFWebElement approved = new QAFExtendedWebElement(By.xpath("//span[.='Customer Approved']"));
		Reporter.logWithScreenShot(util.ChangeStatus("Presented"));
		Reporter.logWithScreenShot(util.ChangeStatus("Customer Approved"));
	}

	public void changeQuoteStatustoAccepted() {
		util.ChangeStatus("Accepted");
	}

//	Created by Vinay to Create Contract in both environments
//	public void CreateContract() {
//		util.clickOnActionToolBarButton("QuoteActionToolbar", "Create Contract");
//		util.waitForVlocityOmniScript();
//		//if(util.getEnvironment().equalsIgnoreCase("R32SIT")) {
//			util.refreshSwitchToFrame();
//			util.AttachFrame();
//			util.vlocityNextButton();
//		//}		
//		util.waitForContractPage();
//		ProjectBeans.setContractURL(driver.getCurrentUrl());
//	}

//	Created by Vinay to Create Contract in both environments
	public void CreateContract() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Create Contract");
		util.waitForVlocityOmniScript();
		util.waitFor(10);
//		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.vlocityNextButton();
		util.waitForContractPage();
		ProjectBeans.setContractURL(driver.getCurrentUrl());
	}

//	Created by Vinay to Change Status From Negotiating to Signed
	public void ChangeTheStatusToSigned() {
		Reporter.logWithScreenShot(util.ChangeStatus("Negotiating"));
		util.waitFor(5);
		Reporter.logWithScreenShot(util.ChangeStatus("Awaiting Signature"));
		util.waitFor(5);
		Reporter.logWithScreenShot(util.ChangeStatus("Signed"));
		util.waitFor(5);
	}

	public ArrayList<String> VerifyOrders() {
		util.clickUsingJs(getRelated());
		util.clickUsingJs(getOrders());
		return util.refreshOrders(90, 11);
	}

	// File Upload
	public void AssignPortIN() {
		util.switchToFrame(By.xpath("(//span[text()='Assign PortIn MIN']/parent::div)[1]"));
		util.clickButton(getUpload());
		try {
			Robot rb = new Robot();
			StringSelection str = new StringSelection(
					"C:\\Users\\NIMPARAB\\OneDrive - Capgemini\\Desktop\\BULK\\BulkFile.csv");
			util.waitFor(2);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_V);
			rb.keyRelease(KeyEvent.VK_CONTROL);
			rb.keyRelease(KeyEvent.VK_V);
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception e) {
		}
		util.waitForClickable(By.xpath("//div[contains(@class,'modal-container')]//span[text()='Done']"), 5);
		new Button().click("Done");
		util.waitTillLoaderDissapear();
		getAssign().click();
		util.waitFor(By.xpath("//span[text()='Close'][@class='btnLabel']"), 5, true);
	}

//	created by Vinay to AddProducts in NR32SIT
	public void ClickAddProducts() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Add Products");
		util.waitForCartPage();
		util.refreshSwitchToFrame();
	}

// Created by Vinay to perform numberAvailabilityCheck
	public void numberAvailabilityCheck() {

		util.clickOnActionToolBarButton("QuoteActionToolbar", "Number Availability Check");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("(//*[contains(@class,'cards-container')])[1]//a[contains(.,'Search Numbers')]"), 30,
				true);
		util.clickUsingJs(By.xpath("(//*[contains(@class,'cards-container')])[1]//a[contains(.,'Search Numbers')]"));
		util.AttachFrame();
		util.waitFor(By.xpath("//span[text()='Number/Pattern Search']"), 5, true);
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//span[text()='Number/Pattern Search']"));
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//div[@id='ChooseOption_nextBtn']/p"));
		util.AttachFrame();
		util.waitFor(By.xpath("//select[@id='NumberTypeMin']"), 10, true);
		util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")), "Regular");
		util.clickUsingJs(By.xpath("(//p[.='Search MIN'])[1]"));
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//div[@id='StepMINSearchNo_nextBtn']/p"));
		util.waitFor(By.xpath("//*[text()[contains(.,'View Quote')]]"), 5, true);
		util.refreshSwitchToFrame();
		util.clickUsingJs(By.xpath("//*[text()[contains(.,'View Quote')]]"));
		util.waitForQuotePage();
	}

// Created by Vinay to perform deviceAvailabilityCheck
	public void deviceAvailabilityCheck() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Device Availability Check");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		try {
			util.AttachFrame();
			util.waitFor(By.xpath("//button[@id='InventoryDetails_nextBtn']"), 30, true);
			Reporter.logWithScreenShot("Clicked on Next button");
			util.clickUsingJs(By.xpath("//button[@id='InventoryDetails_nextBtn']"));
		} catch (Exception e) {
			util.AttachFrame();
			Reporter.logWithScreenShot("Clicked on Next button");
			util.clickUsingJs(By.xpath("(//button[@id='CheckMATDeviceCode_nextBtn'])[1]"));
			util.waitFor(By.xpath("(//button[@id='CheckMATDeviceCode_nextBtn'])[1]"), 10, false);
		}
		util.waitForQuotePage();
		util.waitForPageToLoad();
	}

	public void updateAuthorizeSigonatory(String AuthorizeSigonatory) {
		if (AuthorizeSigonatory.equalsIgnoreCase("Random")) {
			AuthorizeSigonatory = pageProps.getPropertyValue("Lead.fullName");
		}
		QAFWebElement as = new QAFExtendedWebElement(
				By.xpath("//span[text()='Authorized Signatory']/parent::label/following-sibling::div//input"));
		util.enterTextUsingJs(as, AuthorizeSigonatory);
		int check = AuthorizeSigonatory.length();
		while (check > 0) {
			as.sendKeys(Keys.BACK_SPACE);
			try {
				util.waitFor(By.xpath(
						"//span[.='Authorized Signatory']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ AuthorizeSigonatory + "']"),
						1, true);
				util.clickUsingJs(driver.findElement(By.xpath(
						"//span[.='Authorized Signatory']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ AuthorizeSigonatory + "']")));
				break;
			} catch (Exception e) {
			}
			check--;
		}
	}

	public void updateCapContact(String CapContact) {
		if (CapContact.equalsIgnoreCase("Random")) {
			CapContact = pageProps.getPropertyValue("Lead.fullName");
		}
		QAFWebElement cc = new QAFExtendedWebElement(
				By.xpath("//span[text()='CAP Contact']/parent::label/following-sibling::div//input"));
		util.enterTextUsingJs(cc, CapContact);
		int check = CapContact.length();
		while (check > 0) {
			cc.sendKeys(Keys.BACK_SPACE);
			try {
				util.waitFor(By.xpath(
						"//span[.='CAP Contact']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ CapContact + "']"),
						1, true);
				util.clickUsingJs(driver.findElement(By.xpath(
						"//span[.='CAP Contact']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ CapContact + "']")));
				break;
			} catch (Exception e) {
			}
			check--;
		}
	}

	public void updateBillRecipient(String BillRecipient) {
		if (BillRecipient.equalsIgnoreCase("Random")) {
			BillRecipient = pageProps.getPropertyValue("contact.BillRecipient");
		}
		QAFWebElement br = new QAFExtendedWebElement(
				By.xpath("//span[text()='Bill Recipient']/parent::label/following-sibling::div//input"));
		util.enterTextUsingJs(br, BillRecipient);
		int check = BillRecipient.length();
		while (check > 0) {
			br.sendKeys(Keys.BACK_SPACE);
			try {
				util.waitFor(By.xpath(
						"//span[.='Bill Recipient']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ BillRecipient + "']"),
						1, true);
				util.clickUsingJs(driver.findElement(By.xpath(
						"//span[.='Bill Recipient']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ BillRecipient + "']")));
				break;
			} catch (Exception e) {
			}
			check--;
		}
	}

	public void updateDeliveryRecipient(String DeliveryRecipient) {
		if (DeliveryRecipient.equalsIgnoreCase("Random")) {
			DeliveryRecipient = pageProps.getPropertyValue("contact.DeliveryRecipient");
		}
		QAFWebElement dr = new QAFExtendedWebElement(
				By.xpath("//span[text()='Delivery Recipient']/parent::label/following-sibling::div//input"));
		util.enterTextUsingJs(dr, DeliveryRecipient);
		int check = DeliveryRecipient.length();
		while (check > 0) {
			dr.sendKeys(Keys.BACK_SPACE);
			try {
				util.waitFor(By.xpath(
						"//span[.='Delivery Recipient']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ DeliveryRecipient + "']"),
						1, true);
				util.clickUsingJs(driver.findElement(By.xpath(
						"//span[.='Delivery Recipient']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ DeliveryRecipient + "']")));
				break;
			} catch (Exception e) {
			}
			check--;
		}
	}

	public void updateContactDetails(Map<String, String> data) {
		updateAuthorizeSigonatory(data.get("Authorized Signatory"));
		updateBillRecipient(data.get("Bill Recipient"));
		updateCapContact(data.get("CAP Contact"));
		updateDeliveryRecipient(data.get("Delivery Recipient"));
	}

//	Created by Vinay to Update Credit Information
	public void UpdateCreditInformation(String CreditApprovalStatus, String CreditApprovalCondition,
			String CreditRemark) {
		util.scrollIntoElement(By.xpath("(//h3//span[.='Credit Information'])[last()]"));
		util.clickUsingJs(By.xpath("//span[text()='Edit Credit Approval Status']"));
		util.clickUsingJs(By.xpath(
				"//span[contains(@id,'label')][text()='Credit Approval Status']/following::div[1]//a[@role='button']"));
		util.clickUsingJs(By.xpath("//li/a[text()='Approved']"));
		util.clickUsingJs(By.xpath(
				"//span[contains(@id,'label')][text()='Credit Approval Condition']/following::div[1]//a[@role='button']"));
		util.clickUsingJs(By.xpath("//li/a[text()='Bill Above']"));
		util.enterText(
				driver.findElement(
						By.xpath("(//span[text()='Credit Remarks']/following::textarea[@role='textbox'])[3]")),
				CreditRemark);
		util.clickUsingActions(By.xpath("//span[text()='Credit Remarks']/parent::label"));
		Reporter.logWithScreenShot("Credit information is updated", MessageTypes.Info);
		util.clickUsingJs(By.xpath("//button[@title='Save']/span"));
		util.waitFor(By.xpath("//button[@title='Save']/span"), 40, false);
	}

	public void ClickConfigure() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Configure");
		util.waitForCartPage();
		util.refreshSwitchToFrame();
	}

//	Created by Vinay to Click on Modify products and Configure as we required
	public void ModifyProducts(String product) {
		util.waitForQuotePage();
		util.waitFor(10);
		if (util.isElementDisplayed(By.xpath("(//span[.='Offers'])[last()]"))) {
			util.scrollIntoElement(By.xpath("(//span[.='Offers'])[last()]"));
			util.clickUsingJs(By.xpath("(//span[.='Offers'])[last()]"));
			util.waitFor(By.xpath("//button[.='Modify Products']"), 20, true);
//			util.clickUsingJs(By.xpath("//label[contains(@for,'lgt-dt-header-factory')]//span[@class='slds-checkbox_faux']"));
			util.clickUsingJs(By.xpath("//lightning-base-formatted-text[.='" + product
					+ "']/ancestor::tr//span[@class='slds-checkbox_faux']"));
			util.clickUsingJs(By.xpath("//button[.='Modify Products']"));
			util.waitForWorkingCartPage();

		} else {
			ClickConfigure();
		}
	}

//	 Created by Vinay to Submit EBIT value and Click on Submit for EBIT Approval action.
	public void submitEBITForApproval(Map<String, String> data) {
		QuoteName = driver.findElement(By.xpath("((//h1//div[.='Quote'])[last()]/following::div/span)[1]")).getText();
		util.scrollIntoElement(By.xpath("(//h3[.='Internal Approvals'])[1]"));
		util.clickUsingJs(By.xpath("//span[text()='EBIT']/parent::div/following-sibling::div/button"));
		QAFWebElement input = new QAFExtendedWebElement(
				By.xpath("//span[text()='EBIT']/parent::label/following-sibling::input"));
		util.waitFor(By.xpath("//span[text()='EBIT']/parent::label/following-sibling::input"), 30, true);
		util.enterText(input, "30");
		util.clickUsingActions(By.xpath("//span[text()='EBIT']/parent::label"));
		util.clickUsingJs(By.xpath(
				"//button[contains(@class,'slds-button slds-button--neutral uiButton--brand uiButton forceActionButton')]"));
		util.waitFor(By.xpath(
				"//button[contains(@class,'slds-button slds-button--neutral uiButton--brand uiButton forceActionButton')]"),
				30, false);
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Submit for EBIT Approval");
		util.waitForQuotePage();
		util.refreshPage();
		util.waitFor(By.xpath("//span[normalize-space()='Status']/following::div/span[.='Internal Approval']"), 20,
				true);
	}

//	Created by Vinay to approve EBIT request by Approver
	public void approveEBIT(Map<String, String> data) {
		HomePage hp = new HomePage();
		LoginPage lp = new LoginPage();
		hp.clickOnViewAll();
		// String QuoteName =
		// driver.findElementByXPath("((//h1//div[.='Quote'])[last()]/following::div/span)[1]").getText();
		util.clickUsingJs(By.xpath("//a[@title='" + QuoteName + "']"));
		util.waitForApprovalRequestPage();
		String appover = "";
		int levelsofApproval = 0;
		Boolean isApproved = false;
		while (!isApproved) {
			if (levelsofApproval >= 0) {
				util.clickUsingJs(By.xpath("//a/div[@title='Approve']"));
				util.waitFor(By.xpath("//h2[.='Approve Quote']"), 5, true);
				util.enterText(By.xpath("//span[.='Comments']/following::textarea"), QuoteName + " is Accepted");
				util.clickUsingJs(By.xpath("//button/span[.='Approve']"));
				util.waitFor(By.xpath("//button/span[.='Approve']"), 5, false);
				util.waitFor(By.xpath("//div[contains(text(),'Process Instance Step')]/following-sibling::div"), 10,
						true);
			}
			if (driver.findElement(By.xpath("//div[contains(text(),'Process Instance Step')]/following-sibling::div"))
					.getAttribute("title").equalsIgnoreCase("Approved")) {
				levelsofApproval++;
				lp.logoutCurrentUser();
				isApproved = true;
				break;
			} else {
				util.clickUsingJs(By.xpath("(//span[.='Quote Name']/following::div[1]/span//a)[last()]"));
				;
				util.clickUsingJs(getRelated());
				util.clickUsingJs(By.xpath("//span[@title='Approval History']"));
				util.waitFor(By.xpath("(//td/span[.='Pending'])[last()]"), 20, true);
				if (util.isElementDisplayed(By.xpath("(//td/span[.='Pending'])[last()]"))) {
					try {
						appover = driver
								.findElement(By.xpath("(//td/span[.='Pending'])[last()]/following::td[1]/span/a"))
								.getText();
					} catch (Exception e) {
					}
				}
				lp.logoutCurrentUser();
				hp.switchToAnyUser(appover);
				hp.clickOnViewAll();
				util.clickUsingJs(By.xpath("//a[@title='" + QuoteName + "']"));
				util.waitForApprovalRequestPage();
				levelsofApproval++;
			}
		}
	}

	// done by vidya
	public void RetentionUpdateContactDetails(Map<String, String> data) {
		updateAuthorizeSigonatory(data.get("Authorized Signatory"));
		updateBillRecipient(data.get("Bill Recipient"));
		updateDeliveryRecipient(data.get("Delivery Recipient"));
		Reporter.logWithScreenShot("Updated Contacts..");
	}

	// created by waseem scroll and click on quotation validity
	public void UpdateQuotationValidity(String QuotationValidity) {
		util.scrollTillVisible(editQuoteValidity);
		getEditQuoteValidity().click();
		getQuoteValidity().sendKeys(QuotationValidity);
		Reporter.logWithScreenShot("Updated Quotation Validity Period..");
	}

	// created by waseem
	public void deviceAvailability() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Device Availability Check");
		util.waitFor(By.xpath("//title[text()='vlocity_cmt__OmniScriptUniversalPage | Salesforce']"), 10, true);
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//title[text()='vlocity_cmt__OmniScriptUniversalPage | Salesforce']"), 30, true);
		String deviceStatus = driver.findElement(By.xpath("(//tr[@class='ng-scope']//td[last()])[2]")).getText();
		if (deviceStatus.equalsIgnoreCase("AVAILABLE")) {
			QAFExtendedWebElement nextbtn = new QAFExtendedWebElement("//button[@id='InventoryDetails_nextBtn']");
			util.waitFor(nextbtn, 10, true);
			Reporter.logWithScreenShot("Performing Device Availability Check..");
			nextbtn.click();
			util.waitForQuotePage();
			util.waitForPageToLoad();
		} else {
			Reporter.logWithScreenShot("Device Status: " + deviceStatus, MessageTypes.Fail);
		}
	}

	// created by waseem
	public void DeviceReservationPerform() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Device Reservation");
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//section[@id='Step3']//h1[contains(text(),'Device Availability')]"), 30, true);
		List<WebElement> config = driver.findElements(By.xpath("//*[contains(text(),'Next')]"));
		util.waitFor(By.xpath("//*[contains(text(),'Next')]"), 30, true);
		for (int i = 0; i < config.size(); i++) {
			if (config.get(i).isDisplayed()) {
				config.get(i).click();
				break;
			}
		}
		List<WebElement> config1 = driver.findElements(By.xpath("//*[contains(text(),'Next')]"));
		util.waitFor(By.xpath("//*[contains(text(),'Next')]"), 30, true);
		for (int i = 0; i < config1.size(); i++) {
			if (config1.get(i).isDisplayed()) {
				config1.get(i).click();
				break;
			}
		}
		List<WebElement> config2 = driver.findElements(By.xpath("//*[contains(text(),'Next')]"));
		util.waitFor(By.xpath("//*[contains(text(),'Next')]"), 30, true);
		for (int i = 0; i < config2.size(); i++) {
			if (config2.get(i).isDisplayed()) {
				config2.get(i).click();
				break;
			}
		}
		util.waitForQuotePage();
	}

	public void ChangeStatusToAccepted() {
		util.ChangeStatus(getAccepted(), getMarkAsCurrentStatus());
		try {
			Thread.sleep(5000);
		} catch (Exception e) { // Commented to test loadingPage
		}
	}

	public void changeStatusToApproved1() {
		QAFWebElement approved = new QAFExtendedWebElement(By.xpath("(//a[@title='Customer Approved'])"));
		util.ChangeStatus(approved, getMarkAsCurrentStatus());
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}
	}

	public void changeStatusToInternalApproval() {
		util.ChangeStatus("Internal Approval");
		Reporter.logWithScreenShot("Quote status Changed to Internal Approval", MessageTypes.Info);
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}
	}

	// Created by Vinay for Converting Quote to PDF
	public void QuotetoPDF() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Quote to PDF");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//h1[contains(text(),'Generate Document')]"), 20, true);
		driver.switchTo().frame(0);
		QAFWebElement generate = new QAFExtendedWebElement("xpath=//button[span[text()='Generate Document']]");
		util.waitAndClickUsingJavaScript(generate, "Generate");
		util.waitFor(By.xpath("//h2[text()='Successfully generated PDF attachment.']"), 30, true);
		util.clickUsingJs(By.xpath("//button[contains(@class,'download')]"));
		util.waitFor(10);
		Reporter.logWithScreenShot("Successfully Downloaded the PDF File");
		util.AttachFrame();
		util.vlocityNextButton();
		util.waitForQuotePage();
	}

	// created by Vidya
	public void modifyProductsbyduplicates(Map<String, String> data) {
		util.waitForQuotePage();
		ProjectBeans.setQuoteURL(driver.getCurrentUrl());
//		deleteQLI();
		util.waitFor(offersButton, 30, true);
		util.clickUsingJs(offersButton);
		if (errorWindowCloseBtn.isPresent()) {
			errorWindowCloseBtn.click();
		}
		int numberOfRefresh = 0;
		QAFWebElement productCheckbox2 = new QAFExtendedWebElement(
				By.xpath("(//span[@class='slds-checkbox_faux'])[2]"));
		if (errorWindowCloseBtn.isPresent()) {
			errorWindowCloseBtn.click();
		}
		while ((!productCheckbox2.isPresent()) && (numberOfRefresh++ < 30)) {
			util.refreshPage();
			util.waitForQuotePage();
			util.waitFor(offersButton, 30, true);
			util.clickUsingJs(offersButton);
			util.waitFor(1);
		}
		if (data.get("AddDeviceOrNot").equalsIgnoreCase("Yes")) {
			util.waitFor(productNameSearchBox, 30, true);
			productNameSearchBox.sendKeys(data.get("Plan"));
			util.clickUsingJs(productCheckbox2);
			util.clickUsingJs(modifyProducts);
			util.waitForCartPage();
		}
	}

	// created by Nimesh
	public void deleteQLI() {
		driver.get(ProjectBeans.getQuoteURL());
		util.waitFor(5);
		driver.findElement(By.xpath("//span[text()='Related']")).click();
		util.waitFor(3);
		driver.findElement(By.xpath("//span[@title='Quote Line Items']")).click();
		int numberOfRefresh = 0;
		QAFWebElement numberofQLI = new QAFExtendedWebElement(By.xpath("(//span[text()='Show Actions'])[4]"));
		while ((!numberofQLI.isPresent()) && (numberOfRefresh++ < 70)) {
			util.refreshPage();
			util.waitFor(By.xpath("//title[text()='Quote Line Items | Salesforce']"), 5, true);
		}
		util.waitFor(3);
		Reporter.logWithScreenShot("Quote Line Items");
		String QLIShowActionButton = "//span[text()='Show Actions']";
		List<WebElement> listofelements = driver.findElements(By.xpath(QLIShowActionButton));
		int Size = listofelements.size();
		if (Size > 1) {
			for (int i = 2; i <= Size; i++) {
				util.waitFor(By.xpath("(//span[text()='Show Actions'])[2]"), 10, true);
				util.clickUsingJs(By.xpath("(//span[text()='Show Actions'])[2]"));
				util.waitFor(By.xpath("//a[@title='Delete']"), 10, true);
				util.clickUsingJs(By.xpath("//a[@title='Delete']"));
				util.waitFor(By.xpath("//button[@title='Delete']"), 10, true);
				util.clickUsingJs(By.xpath("//button[@title='Delete']"));
				util.waitForGenericToastMessage();
				util.refreshPage();
			}
		}
		driver.get(ProjectBeans.getQuoteURL());
	}

	public void createQuoteSMARTR4EndtoEnd(Map<String, String> data) {
		bean.fillRandomData();
		util.clickOnActionToolBarButton("AccountActionToolbar", "Create Quote");
		util.waitForVlocityOmniScript();
		util.AttachFrame();
		util.clickUsingJs(By.xpath("(//span[text()='SMART_Quote'])"));
		util.vlocityNextButton();
		util.waitFor(By.xpath("//input[@id='QuoteName']"), 10, true);
		String quotename = bean.getFirstName();
		driver.findElement(By.xpath("//input[@id='QuoteName']")).sendKeys(quotename);
		pageProps.setProperty("Quote_name", quotename);
//        util.waitFor(3);
		util.enterText(By.xpath("//input[@id='OpportunityCloseDate']"), date.getDate(365, "MM-dd-yyyy"));
		util.clickUsingJs(By.xpath("//input[@id='PriceList']"));
		util.waitFor(By.xpath("//input[@id='PriceList']/following::ul/li[contains(text(),'SMART Price List')]"), 20,
				true);
		util.clickUsingJs(By.xpath("//input[@id='PriceList']/following::ul/li[contains(text(),'SMART Price List')]"));
//        driver.findElement(By.xpath("//input[@id='MINPort']")).sendKeys(data.get("MIN for Port In"));
		util.selectBy(
				driver.findElement(
						By.xpath("//span[text()='Current Provider']/following::select[@id='CurrentProvider']")),
				data.get("CurrentProvider"));
		Reporter.logWithScreenShot("Quote details");
		util.vlocityNextButton();
		util.waitForQuotePage();
	}

	String planname;

	// created by Vidya for Bulk Scenario
	public void workingCartForBulk(Map<String, String> data) {
		AddressAssignmentPage addressPage = new AddressAssignmentPage();
		util.waitForQuotePage();
		ProjectBeans.setQuoteURL(driver.getCurrentUrl());
		util.waitFor(offersButton, 30, true);
		util.clickUsingJs(offersButton);
		if (errorWindowCloseBtn.isPresent()) {
			errorWindowCloseBtn.click();
		}
		int numberOfRefresh = 0;
		String BulkQuantity = data.get("BulkQuantity");
		QAFWebElement productCheckbox2 = new QAFExtendedWebElement(
				By.xpath("(//tr/td[1]//span[@class='slds-checkbox_faux'])[" + BulkQuantity + "]"));
		if (errorWindowCloseBtn.isPresent()) {
			errorWindowCloseBtn.click();
		}
		while ((!productCheckbox2.isPresent()) && (numberOfRefresh++ < 40)) {
			util.refreshPage();
			util.waitForQuotePage();
			util.waitFor(offersButton, 30, true);
			util.clickUsingJs(offersButton);
			util.waitFor(2);
		}
		Reporter.logWithScreenShot("Clicked on Offers button in quote page");
		String Plannames = "(//th//span[@class='slds-grid slds-no-space slds-grid_align-spread'])/div/lightning-base-formatted-text";
		List<WebElement> listofplans = driver.findElements(By.xpath(Plannames));
		int size = listofplans.size();
		for (int i = 1; i <= size; i++) {
			util.waitForQuotePage();
			util.waitFor(offersButton, 30, true);
			util.clickUsingJs(offersButton);
			util.waitFor(5);
			planname = driver.findElement(By.xpath(
					"((//th//span[@class='slds-grid slds-no-space slds-grid_align-spread'])/div/lightning-base-formatted-text)["
							+ i + "]"))
					.getText();
			if (data.get("AddDeviceOrNot").equalsIgnoreCase("Yes") || data.get("AddonsCheck").equalsIgnoreCase("Yes")) {
				util.waitFor(productNameSearchBox, 30, true);
				productNameSearchBox.sendKeys(planname);
				util.clickUsingJs(By.xpath("(//tr/td[1]//span[@class='slds-checkbox_faux'])[1]"));
				util.clickUsingJs(modifyProducts);
				util.waitForCartPage();
			} else if (planname.contains("BYOD") || planname.contains("Bro")
					|| data.get("ServiceAccAddCheck").equalsIgnoreCase("Yes")) {
				util.waitFor(productNameSearchBox, 30, true);
				productNameSearchBox.sendKeys(planname);
				util.clickUsingJs(By.xpath("(//tr/td[1]//span[@class='slds-checkbox_faux'])[1]"));
				util.clickUsingJs(modifyProducts);
				util.waitForCartPage();
			}

			CartPage cartpage = new CartPage();
			if (data.get("AddDeviceOrNot").equalsIgnoreCase("Yes")) {
				Reporter.logWithScreenShot("Configuring " + planname);
				cartpage.AddDevice_To_Product_And_Configure(planname, data.get("DeviceName"), data.get("DeviceCapcity"),
						data.get("DeviceColor"));
				if (planname.contains("5G") && data.get("AddonsCheck").equalsIgnoreCase("Yes")) {
					Reporter.logWithScreenShot("Adding addons to this :" + planname);
					cartpage.addAddonsto5GPlans(data.get("Addons"), data);
					Reporter.logWithScreenShot("Added" + data.get("Addons") + " to the " + planname);
					util.waitFor(5);
				}
				UpdateAccounts(planname);
				addressPage.AssignServiceAccount(data.get("ServiceAccountName"));
				cartpage.SaveWorkingCart();
				Reporter.logWithScreenShot("Clicked on Save Working Cart");
				cartpage.WorkingCartConfigure();
				Reporter.log("Cart Configuration done for " + planname);
			} else if (planname.contains("BYOD") || planname.contains("Bro")
					|| data.get("ServiceAccAddCheck").equalsIgnoreCase("Yes")) {
				/// ******************** need to add service ac code/// ******************************
				UpdateAccounts(planname);
				addressPage.AssignServiceAccount(data.get("ServiceAccountName"));
				util.AttachFrame();
				QAFWebElement save = new QAFExtendedWebElement("xpath=//button[contains(text(),'Save Working Cart')]");
				save.click();
				util.waitFor(20);
				Reporter.log("Clicked on Save Working Cart button");
//                cartpage.WorkingCartConfigure();
//                Reporter.log("Cart Configuration done for " + planname);
			}
		}
	}

//	Created by Vinay to click on  particular Update Accounts when there is more than one plan
	public void UpdateAccounts(String planname) {
		// getPlanConfig().click();
		// util.refreshSwitchToFrame();
		// util.AttachFrame();
		util.waitFor(5);
		String product = planname;
		String planxpath = "//button[contains(@title,'" + planname + "')]";
		String actions = planxpath + "/following::button[@title='Show Actions']";
		String updateAccount = "(//button[contains(@title,'" + planname
				+ "')]/following::button[@title='Show Actions']/following::a[normalize-space()='Update Account'])[1]";
		util.AttachFrame();
		util.scrollIntoElement(By.xpath(actions));
		util.waitFor(5);
		util.clickUsingJs(By.xpath(actions));
		util.waitFor(5);
		util.clickUsingJs(By.xpath(updateAccount));
//		getUpdateAccount().click();
		driver.switchTo().defaultContent();
		util.waitForAddressAssignmentPage();
	}

	/**
	 * CreatingContract method used to click on Create contract button from
	 * QuoteActionToolbar if Pending Account Sync is displayed it retry for 5 times
	 * and wait for 5 mins
	 * 
	 * @author Waseem
	 * @return No return value.
	 */
	public void CreatingContract() {
		int numberOfPendingSync = 0;
		do {
			if (numberOfPendingSync > 0) {
				util.vlocityNextButton();
			}
			util.waitFor(60);
			util.clickOnActionToolBarButton("QuoteActionToolbar", "Create Contract");
			util.waitForVlocityOmniScript();
			Reporter.logWithScreenShot("Clicked on Create Contract");
			util.implicitlyWait(15);
			util.implicitlyWait(By.xpath("(//div[.='Contract'])[last()]"));
			util.AttachFrame();
			QAFWebElement Activecontracttxt = new QAFExtendedWebElement(
					"xpath=//p[contains(text(),'Kindly check previous Active contract associated with this quote. To create a new, make previous contract as Cancelled/Terminated.')]");
			if (Activecontracttxt.isPresent()) {
				QAFWebElement cancelbtn = new QAFExtendedWebElement("xpath=//div[contains(text(),'Cancel')]");
				QAFWebElement Okbtn = new QAFExtendedWebElement("xpath=//button[@id='alert-ok-button']");
				QAFWebElement Relatedlink = new QAFExtendedWebElement("xpath=//a[@title='Related']");
				QAFWebElement contractlink = new QAFExtendedWebElement(
						"xpath=(//span[@title='Contracts']//parent::a)[1]");
				QAFWebElement contractnumlink = new QAFExtendedWebElement("xpath=(//tbody//tr//th//a)[last()]");
				cancelbtn.click();
				util.waitFor(10);
				util.AttachFrame();
				Okbtn.click();
				util.waitFor(20);
				Relatedlink.click();
				util.waitFor(10);
				contractlink.click();
				util.waitFor(10);
				contractnumlink.click();
				util.waitFor(10);
				break;
			}
		} while (util.isElementDisplayed(By.xpath("//p/div[contains(text(),'Please try')]"))
				&& numberOfPendingSync++ < 5);
	}
}
