package com.pldt.pages;

import java.util.Map;

import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SyniverseNPOPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	@FindBy(locator = "xpath=//input[@value='CORPORATE']")
	private QAFWebElement CorporateCheckBox;
	@FindBy(locator = "xpath=//input[@value='PERSONAL']")
	private QAFWebElement PersonalCheckBox;
	@FindBy(locator = "xpath=//input[contains(@name,'value(OwnerName)')]")
	private QAFWebElement PersonalOwnerName;
	@FindBy(locator = "xpath=//input[@name='value(OwnerId)']")
	private QAFWebElement PersonalOwnerID;
	@FindBy(locator = "xpath=//input[contains(@name,'value(PersonSignDate)')]")
	private QAFWebElement PersonalApplicationDate;
	@FindBy(locator = "xpath=//input[contains(@name,'value(SingleSubscriberNumber)')]")
	private QAFWebElement PersonalPortingNumber;
	@FindBy(locator = "xpath=//input[contains(@name,'CompanyName')]")
	private QAFWebElement NPOCorporateCompanyName;
	@FindBy(locator = "xpath=//input[contains(@name,'RegistrationCode')]")
	private QAFWebElement NPOCorporateBRN;
	@FindBy(locator = "xpath=//input[contains(@name,'AccountNumber')]")
	private QAFWebElement NPOCorporateBillingAccount;
	@FindBy(locator = "xpath=//input[contains(@name,'CompanySignDate')]")
	private QAFWebElement NPOCorporateApplicationDate;
	@FindBy(locator = "xpath=//select[contains(@name,'DonorTelco')]")
	private QAFExtendedWebElement DonorTelcoDropdown;
	@FindBy(locator = "xpath=//input[contains(@name,'UndertakingAck')]")
	private QAFWebElement UndertakingAcknowledgementCheckbox;
	@FindBy(locator = "xpath=//select[contains(@name,'preServiceType')]")
	private QAFExtendedWebElement CustomerTypeDropdown;
	@FindBy(locator = "xpath=//select[contains(@name,'preRouteNum')]")
	private QAFWebElement RouteNumberDropdown;
	@FindBy(locator = "xpath=//input[@name='value(OwnerId1)']")
	private QAFWebElement OwnerIDInput;
	@FindBy(locator = "xpath=//input[@name='value(MultipleSubscriberNumber)']")
	private QAFWebElement PortingNumberInput;
	@FindBy(locator = "xpath=//input[@value='Submit']")
	private QAFWebElement SubmitButton;
	@FindBy(locator = "xpath=//input[@value='Verify DP']")
	private QAFWebElement VerifyDPButton;
	@FindBy(locator = "xpath=//input[contains(@name,'sReferenceId')]")
	private QAFWebElement DISCONNECTReferenceID;
	@FindBy(locator = "xpath=//input[contains(@name,'sOwnerId')]")
	private QAFWebElement DISCONNECTOwnerID;
	@FindBy(locator = "xpath=//input[contains(@name,'sRegistrationCode')]")
	private QAFWebElement DISCONNECTBRN;
	@FindBy(locator = "xpath=//input[contains(@name,'sSubscriberNumber')]")
	private QAFWebElement DISCONNECTPortingNumber;
	@FindBy(locator = "xpath=//input[contains(@name,'FromSubDate')]")
	private QAFWebElement DISCONNECTFromDate;
	@FindBy(locator = "xpath=//input[contains(@name,'ToSubDate')]")
	private QAFWebElement DISCONNECTToDate;
	@FindBy(locator = "xpath=//select[@name='value(SortBy)']")
	private QAFWebElement DISCONNECTSortByDropdown;
	@FindBy(locator = "xpath=//input[@value='Search']")
	private QAFWebElement DISCONNECTSerachButton;
	@FindBy(locator = "xpath=//input[@name='value(AddButton)']")
	private QAFWebElement AddButton;
	@FindBy(locator = "xpath=//input[@name='value(method1)']")
	private QAFWebElement ConfirmButton;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getCorporateCheckBox() {
		return CorporateCheckBox;
	}

	public QAFWebElement getNPOCorporateCompanyName() {
		return NPOCorporateCompanyName;
	}

	public QAFWebElement getNPOCorporateBRN() {
		return NPOCorporateBRN;
	}

	public QAFWebElement getNPOCorporateBillingAccount() {
		return NPOCorporateBillingAccount;
	}

	public QAFWebElement getNPOCorporateApplicationDate() {
		return NPOCorporateApplicationDate;
	}

	public QAFExtendedWebElement getDonorTelcoDropdown() {
		return DonorTelcoDropdown;
	}

	public QAFWebElement getUndertakingAcknowledgementCheckbox() {
		return UndertakingAcknowledgementCheckbox;
	}

	public QAFExtendedWebElement getCustomerTypeDropdown() {
		return CustomerTypeDropdown;
	}

	public QAFWebElement getRouteNumberDropdown() {
		return RouteNumberDropdown;
	}

	public QAFWebElement getPortingNumberInput() {
		return PortingNumberInput;
	}

	public QAFWebElement getSubmitButton() {
		return SubmitButton;
	}

	public QAFWebElement getVerifyDPButton() {
		return VerifyDPButton;
	}

	public QAFWebElement getDISCONNECTReferenceID() {
		return DISCONNECTReferenceID;
	}

	public QAFWebElement getDISCONNECTOwnerID() {
		return DISCONNECTOwnerID;
	}

	public QAFWebElement getDISCONNECTBRN() {
		return DISCONNECTBRN;
	}

	public QAFWebElement getDISCONNECTPortingNumber() {
		return DISCONNECTPortingNumber;
	}

	public QAFWebElement getDISCONNECTFromDate() {
		return DISCONNECTFromDate;
	}

	public QAFWebElement getDISCONNECTToDate() {
		return DISCONNECTToDate;
	}

	public QAFWebElement getDISCONNECTSortByDropdown() {
		return DISCONNECTSortByDropdown;
	}

	public QAFWebElement getDISCONNECTSerachButton() {
		return DISCONNECTSerachButton;
	}

	public QAFWebElement getOwnerIDInput() {
		return OwnerIDInput;
	}

	public QAFWebElement getADDButton() {
		return AddButton;
	}

	public QAFWebElement getConfirmButton() {
		return ConfirmButton;
	}

	public QAFWebElement getPersonalCheckBox() {
		return PersonalCheckBox;
	}

	public QAFWebElement getPersonalOwnerID() {
		return PersonalOwnerID;
	}

	public QAFWebElement getPersonalApplicationDate() {
		return PersonalApplicationDate;
	}

	public QAFWebElement getPersonalPortingNumber() {
		return PersonalPortingNumber;
	}

	public QAFWebElement getPersonalOwnerName() {
		return PersonalOwnerName;
	}

	// Created by Waseem to create NPO
	public void CreateNPO(Map<String, String> data) {
		if (data.get("TestCase").equalsIgnoreCase("SyniverseSingle")) {
			getPersonalCheckBox().click();
			getPersonalOwnerName().sendKeys(data.get("OwnerName"));
			getPersonalOwnerID().sendKeys(data.get("OwnerId"));
			getPersonalApplicationDate().clear();
			getPersonalApplicationDate().sendKeys(data.get("ApplicationDate"));
			util.selectBy(getDonorTelcoDropdown(), data.get("DonorTelco"));
			util.selectBy(getCustomerTypeDropdown(), data.get("CustomerType"));
			getPersonalPortingNumber().sendKeys(data.get("PortingNumber"));
		} else {
			getCorporateCheckBox().click();
			getNPOCorporateCompanyName().sendKeys(data.get("CompanyName"));
			getNPOCorporateBRN().sendKeys(data.get("BRN").toString());
			getNPOCorporateApplicationDate().clear();
			getNPOCorporateApplicationDate().sendKeys(data.get("ApplicationDate"));
			util.selectBy(getDonorTelcoDropdown(), data.get("DonorTelco"));
			util.selectBy(getCustomerTypeDropdown(), data.get("CustomerType"));
			getOwnerIDInput().sendKeys(data.get("OwnerId"));
			getPortingNumberInput().sendKeys(data.get("PortingNumber"));
			getADDButton().click();
			QAFExtendedWebElement element = new QAFExtendedWebElement(
					By.xpath("//select[@name='value(preSubscriberNumber)']//option[@value='2220008765']"));
			// element.assertPresent(null).
		}
	}

	// Created by Waseem
	public void ClickOnNPOSave() {
		getSubmitButton().click();
	}

	public void ClickOnNPOConfirmationPageConfirmButton() {
		getConfirmButton().click();
		driver.findElement(By.xpath("//a[@class='CONTENT']")).click();
	}
}
