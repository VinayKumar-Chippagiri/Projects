package com.pldt.pages;

import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.pldt.elements.Button;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class NewOpportunityModel extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	static final String NewOpportunity = "xpath=//span[text()='New']";
	static final String Existing = "xpath=//span[text()='Existing']";
	private static By AccountName = By.xpath("//label[text()='Account Name']/following::div[1]//input[@placeholder='Search Accounts...']");
	private static By PriceList = By.xpath("//label[text()='Price List']/following::div[1]//input[@placeholder='Search Price Lists...']");
	
	//static final String AccountName="xpath=//label[text()='Account Name']/following::div[1]//input[@placeholder='Search Accounts...']";
//	static final String PriceList ="xpath=//label[text()='Price List']/following::div[1]//input[@placeholder='Search Price Lists...']";
	static final String NewOpportunityNextButton= "xpath=//span[text()='Next']";
	static final String Save ="xpath=//button[text()='Save']";
	@FindBy(locator = NewOpportunity)
	private QAFWebElement newOpportunity;
	@FindBy(locator = Existing)
	private QAFWebElement existing;
//	@FindBy(locator = AccountName)
//	private QAFWebElement accountName;
//	@FindBy(locator = PriceList)
//	private QAFWebElement priceList;
	@FindBy(locator = NewOpportunityNextButton)
	private QAFWebElement newOpportunityNextButton;
	@FindBy (locator =Save)
	private QAFWebElement save;
	public QAFWebElement getNewOpportunity() {
		return newOpportunity;
	}

	public QAFWebElement getExisting() {
		return existing;
	}

//	public QAFWebElement getAccountName() {
//		return accountName;
//	}
//
//	public QAFWebElement getPriceList() {
//		return priceList;
//	}

	public QAFWebElement getNewOpportunityNextButton() {
		return newOpportunityNextButton;
	}
	public QAFWebElement getSave() {
		return save;
	}
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	public void SelectRecordType(String RecordType) {
		util.waitFor(2);
		driver.findElement(By.xpath("//span[text()='"+RecordType+"']")).click();
		new Button().click("Next");
		Reporter.log("Selected Record Type as "+RecordType+"..");
	}
	public void createNewOpportunity(String accountName, String priceList) {
		util.type("Opportunity Name");
		util.selectAndClickCaseSuggestedValue(AccountName, accountName); /// need to change
		util.select("Contracting Party");
		util.select("Opportunity Type");
		util.select("Dropped Reason");
		util.select("Other Dropped reasons");
		util.select("Contract Type");
		util.type("Close Date");
		util.select("Stage");
		util.select("Lost Reason");
		util.type("Other Lost reasons");
		util.type("MIN for Port In");
		util.select("Current Provider");
		util.type("Probability (%)");
		util.select("Opportunity Currency");
		util.type("Number Of Contracted Months");
		util.type("Amount");
		util.selectAndClickCaseSuggestedValue(PriceList, priceList);  // need to change
		util.select("ETS Status");
		util.select("ETS Status - Detail Design");
		util.select("ESS Status");
		util.select("ECND Status - Site Survey");
		util.select("ECND Status - Detail Design");
		util.select("Solcon Status");
		util.select("Solcon Head Status");
		util.typeIntoTextArea("ETS Remarks");
		util.typeIntoTextArea("ETS Detail Design Remarks");
		util.typeIntoTextArea("ESS Remarks");
		util.typeIntoTextArea("ECND Detail Design Remarks");
		util.typeIntoTextArea("Solcon Remarks");
		util.typeIntoTextArea("Solcon Head Remarks");
		util.clickCheckbox("Budget Confirmed");
		util.clickCheckbox("Discovery Completed");
		util.clickCheckbox("ROI Analysis Completed");
		util.type("Order Number");
		util.typeIntoTextArea("Description");
		util.type("Next Step");
		util.typeIntoTextArea("Order Number");
		getSave().click();
	}
}
