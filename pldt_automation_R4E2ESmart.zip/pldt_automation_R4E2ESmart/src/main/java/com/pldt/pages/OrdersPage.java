package com.pldt.pages;

import java.util.ArrayList;

import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.StringMatcher;
import com.pldt.lib.PageLib;

public class OrdersPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	public static By related = By.xpath("//span[text()='Related']");
	private static By ordersHeaderLink = By.xpath("//span[@title='Orders']");

	public ArrayList<String> VerifyOrders(int refreshattempts,int noofOrders) {
		util.clickUsingJs(related);
		util.clickUsingJs(ordersHeaderLink);
		return util.refreshOrders(refreshattempts, noofOrders);

	}

	public ArrayList<String> goToCaseOrdersSearchPage(String caseURL, String transactionType) {
		String orderSearchPage = caseURL.replaceFirst("/view", "/related/Orders__r/view");
		driver.get(orderSearchPage);
		if (transactionType.contains("SIM Replacement")) {
			return util.refreshOrders(90, 2);
		} else {
			return util.refreshOrders(90, 1);
		}
	}

	public ArrayList<String> verifyOrdersFromCasePage(String caseURL, String transactionType) {
		return goToCaseOrdersSearchPage(caseURL, transactionType);
	}

	public void goToCaseOrdersSearchPage(String caseURL) {
		String orderSearchPage = caseURL.replaceFirst("/view", "/related/Orders__r/view");
		driver.get(orderSearchPage);
	}

	public ArrayList<String> verifyOrderFromCasePage(String caseURL, int ordercount) {
		String orderSearchPage = caseURL.replaceFirst("/view", "/related/Orders__r/view");
		driver.get(orderSearchPage);
		return util.refreshOrders(50, ordercount);
	}

	public void verifyOrdersFromCasePage(String caseURL) {
		goToCaseOrdersSearchPage(caseURL);
	}
	
	//created  by Vidya
	public void verifyOrderIsActivated(int refreshAttempts) {
		int count = 0;
		QAFExtendedWebElement status = new QAFExtendedWebElement(
				By.xpath("//span[@title='Status']//following::tr//td[3]//span//span"));
		String orderStatus = status.getText();
		while (orderStatus.equalsIgnoreCase("Open")) {
			if (count == refreshAttempts) {
				break;
			}
			util.refreshPage();
			util.waitForPageToLoad();
			orderStatus = status.getText();
			count++;
		}
		Reporter.logWithScreenShot("Order status..");
		status.assertText(StringMatcher.exact("Activated"), "Order Status");
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}
	
}
