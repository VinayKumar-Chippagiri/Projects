package com.pldt.pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.common.utilities.WebUtilities;

import com.pldt.lib.PageLib;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class CaseListPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	static String billingAccountNumber = null;
	// public static By quickfilter = By.xpath("(//button[@title='Show quick
	// filters'])");
	static String caseListPage = null;
	public static By quickfilter = By.xpath("(//button[@title='Show quick filters'])[last()]");
	public static By newButton = By.xpath("(//div[contains(@class,'slds-col slds-no')]//a[@title='New'])[last()]");
	private static By consigneeName = By
			.xpath("(//span[text()='Consignee Name']/following::input[@placeholder='Search Contacts...'])");
	private static By billingAccountName = By
			.xpath("//span[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");
	private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	private static By moveDocumentArrow = By.xpath("//span[text()='Move selection to Chosen']");
	private static By save = By.xpath("//button[@title='Save']");
	public static By subjectInput = By.xpath("(//label[text()='Subject']/following::input[1])[last()]");
	public static By QuoteNameInput = By.xpath("(//label[text()='Quote Name']/following::input[1])[last()]");
	static final String caseSectionNewcase = "xpath=//div[text()='Change Owner']/ancestor::ul/li/a/div[text()='New']";
	static final String Listview = "xpath=//button[@title='Select a List View']";
	static final String filterCaseSearch = "xpath=//input[@class='slds-input default input uiInput uiInputTextForAutocomplete uiInput--default uiInput--input']";
	static final String SearchInput = "xpath=//input[@placeholder='Search this list...']";
	private static By transactionType = By.xpath("(//span[.='Transaction Type']/following::input)[1]");
	private static By transactionSubType = By.xpath("(//span[.='Transaction Sub Type']/following::input)[1]");
	private static By transactionReason = By.xpath("(//span[.='Transaction Reason']/following::input)[1]");
	QAFExtendedWebElement QuickFiltersCaseRecordType = new QAFExtendedWebElement(By.xpath("//input[@name='Case-RecordType.Name']"));
	QAFExtendedWebElement QuickFilterstransactionTypeInput = new QAFExtendedWebElement(By.xpath("//input[@name='Case-Case_Transaction_Type__r.Name']"));
	QAFExtendedWebElement QuickFilterstransactionSubTypeInput = new QAFExtendedWebElement(By.xpath("//input[@name='Case-Case_Transaction_Sub_Type__r.Name']"));
	QAFExtendedWebElement QuickFiltersStatusOpenChk = new QAFExtendedWebElement(By.xpath("(//input[@name='Case-Status' and @value='Open']//following::span)[1]"));
	QAFExtendedWebElement QuickFiltersOwnerInput = new QAFExtendedWebElement(By.xpath("//input[@name='Case-Owner.Name']"));
	QAFExtendedWebElement QuickFiltersApplybtn = new QAFExtendedWebElement(By.xpath("//button[@title='Apply']"));
	QAFExtendedWebElement QuickFiltersSubject = new QAFExtendedWebElement(By.xpath("//input[@name='Case-Subject']"));
	
	
	@FindBy(locator = caseSectionNewcase)
	private QAFWebElement CaseSectionNewcase;
	@FindBy(locator = Listview)
	private QAFWebElement listview;
	@FindBy(locator = filterCaseSearch)
	private QAFWebElement FilterCaseSearchBox;
	@FindBy(locator = SearchInput)
	private QAFWebElement searchInput;

	public QAFWebElement getCaseSectionNewcase() {
		return CaseSectionNewcase;
	}

	public QAFWebElement getListview() {
		return listview;
	}

	public QAFWebElement getFilterCaseSearchBox() {
		return FilterCaseSearchBox;
	}

	public QAFWebElement getSearchInput() {
		return searchInput;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public void cleanUpCase(String Subject, String RMUser) {
		caseListPage = driver.getCurrentUrl();
		String subject = "(//a[@title='" + Subject + "'])";
		if (util.isElementDisplayed(By.xpath(subject))) {
//			 pages.getLoginpage().logoutCurrentUser();
			new LoginPage().logoutCurrentUser();
			driver.get(caseListPage);
			String showActions = "(//a[@title='" + Subject + "']/following::td/span/div/a[@role='button'])[1]";
			util.clickUsingJs(By.xpath("//a[@title='Delete']"));
			util.waitFor(By.xpath("//span[normalize-space()='Delete']"), 10, true);
			util.clickUsingJs(By.xpath("//span[normalize-space()='Delete']"));
			util.waitForGenericToastMessage();
//			 pages.getHomepage().switchToAnyUser(RMUser);
			new HomePage().switchToAnyUser(RMUser);
			driver.get(caseListPage);
		} else {
			util.clickUsingJs(newButton);
		}
	}

	public void createNewCaseFromAsset(Map<String, String> data) {
		util.clickUsingJs(newButton);
		util.clickUsingJs(By.xpath("//*[text()='SMART Service Request']"));
		util.clickUsingJs(By.xpath("//span[.='Next']"));
		if (data.get("Transaction Type").contains("SIM Replacement")) {
			util.selectAndClickCaseSuggestedValue(consigneeName, data.get("Consignee Name"));
		}
		util.selectAndClickCaseSuggestedValue(billingAccountName, pageProps.getString("billingAccountNumber"));
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.selectAndClickCaseSuggestedValue(transactionType, data.get("Transaction Type"));
		util.selectAndClickCaseSuggestedValue(transactionSubType, data.get("Transaction SubType"));
		util.selectAndClickCaseSuggestedValue(transactionReason, data.get("Transaction Reason"));
		util.select("Case Origin");
//		click_availableDocuments();
//		click_moveAvailableDocuments();
		Reporter.logWithScreenShot(util.clickUsingJs(save).toString());
		Reporter.logWithScreenShot(util.waitForGenericToastMessage());
		if (util.isElementDisplayed(By.xpath("//*[@data-aura-class='forceToastMessage']"))) {
			Reporter.log("Entered mandatory fields and case got created..");
			Reporter.logWithScreenShot("", MessageTypes.Pass);
		} else {
			Reporter.log("Not Entered Mandatory Fields ,So Case is not Created");
			Reporter.logWithScreenShot("", MessageTypes.Fail);
		}
	}

	public void click_availableDocuments() {
		util.scrollIntoElement(availableDocuments);
		util.moveToElement(availableDocuments);
		util.clickUsingActions(availableDocuments);
	}

	public void click_moveAvailableDocuments() {
		util.clickUsingJs(moveDocumentArrow);
	}

	public void selectCase(String subjectValue) {
		util.clickUsingJs(quickfilter);
		util.waitFor(subjectInput, 5, true);
		util.clickUsingJs(subjectInput);
		util.enterTextUsingJs(subjectInput, subjectValue);
		util.enterKey();
		String Cat = "//a[text()=" + "'" + subjectValue + "'" + "]";
		util.openLink(By.xpath(Cat));
		Reporter.log("Opened created case by filtering case name..");
		util.waitForCasePage();
	}

	public void clickNewCaseButton() {
		getCaseSectionNewcase().click();
		Reporter.log("Clicked on New button..");
	}

	public void acceptCase(String CaseID) {
		getListview().click();
		util.waitFor(2);
		// driver.findElement(By.xpath("//input[@class='slds-input default input uiInput
		// uiInputTextForAutocomplete uiInput--default
		// uiInput--input']")).sendKeys("SMART Enterprise Support");
		getFilterCaseSearchBox().sendKeys("SMART Enterprise Support");
		util.waitFor(5);
		driver.findElement(By.xpath("//mark[text()='SMART Enterprise Support']")).click();
		util.waitTillLoaderDissapear();
		getSearchInput().click();
		util.waitFor(3);
		util.refreshPage();
		util.typeDataTo(getSearchInput(), CaseID);
		// getSearchInput().sendKeys(Subject);
		util.waitTillLoaderDissapear();
		// getSearchInput().sendKeys(Subject);
		util.waitFor(3);
		getSearchInput().sendKeys(Keys.ENTER);
		util.waitFor(8);
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		util.waitFor(3);
		util.waitFor(By.xpath("(//a[@title='" + CaseID + "'])[1]"), 20, true);
		util.waitFor(By.xpath("(//span[@class='slds-checkbox--faux'])[2]"), 10, true);
		driver.findElement(By.xpath("(//span[@class='slds-checkbox--faux'])[2]")).click();
		driver.findElement(By.xpath("//div[@title='Accept']")).click();
		util.waitForGenericToastMessage();
		util.waitFor(3);
		getListview().click();
		util.waitFor(2);
		getFilterCaseSearchBox().sendKeys("My Cases");
		util.waitFor(2);
		driver.findElement(By.xpath("//mark[text()='My Cases']")).click();
		util.waitTillLoaderDissapear();
		util.waitFor(3);
		util.typeDataTo(getSearchInput(), CaseID);
		// getSearchInput().sendKeys(Subject);
		util.waitTillLoaderDissapear();
		// getSearchInput().sendKeys(Subject);
		util.waitFor(3);
		getSearchInput().sendKeys(Keys.ENTER);
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		util.waitFor(3);
		String Case = "//a[text()='" + CaseID + "']";
		util.clickUsingJs(By.xpath(Case));
	}
	
	public String FilterCaseOnAsset(String subjectValue) {
		util.clickUsingJs(quickfilter);
		util.waitFor(subjectInput, 5, true);
		util.clickUsingJs(subjectInput);
		util.enterTextUsingJs(subjectInput, subjectValue);
		util.enterKey();
		QAFExtendedWebElement CloseFiltersBtn = new QAFExtendedWebElement(By.xpath("//button[@title='Close Filters']"));
		CloseFiltersBtn.click();
		String CaseID = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a")).getText();
		return CaseID;	
	}
	
	public String FilterCaseOnAccount(Map<String, String> data) {
		util.clickUsingJs(quickfilter);
		util.waitFor(5);
		if(QuickFiltersCaseRecordType.isPresent() && QuickFiltersCaseRecordType.isDisplayed()) {
		QuickFiltersCaseRecordType.sendKeys(data.get("Record_Type"));
		util.waitFor(2);
		}
		if(QuickFilterstransactionTypeInput.isPresent() && QuickFilterstransactionTypeInput.isDisplayed()) {
		QuickFilterstransactionTypeInput.sendKeys(data.get("Transaction Type"));
		util.waitFor(2);
		}
		if(QuickFilterstransactionSubTypeInput.isPresent() && QuickFilterstransactionSubTypeInput.isDisplayed()) {
		QuickFilterstransactionSubTypeInput.sendKeys(data.get("Transaction Sub Type"));
		util.waitFor(2);
		}
		QuickFiltersStatusOpenChk.click();
		util.waitFor(2);
		if(QuickFiltersSubject.isPresent()&&QuickFiltersSubject.isDisplayed()) {
		QuickFiltersSubject.sendKeys(data.get("Subject"));
		util.waitFor(2);
		}
		QuickFiltersOwnerInput.sendKeys(ConfigurationManager.getBundle().getPropertyValue("Owner"));
		util.waitFor(2);
		QuickFiltersApplybtn.click();
		util.waitFor(5);
		QAFExtendedWebElement CloseFiltersBtn = new QAFExtendedWebElement(By.xpath("//button[@title='Close Filters']"));
		CloseFiltersBtn.click();
		util.waitFor(4);
		util.refreshPage();
		util.waitFor(15);
		String CaseID = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a")).getText();
		return CaseID;	
	}
	
	public String FilterQuote(String subjectValue) {
		util.clickUsingJs(quickfilter);
		util.waitFor(QuoteNameInput, 5, true);
		util.clickUsingJs(QuoteNameInput);
		util.enterTextUsingJs(QuoteNameInput, subjectValue);
		util.enterKey();
		QAFExtendedWebElement CloseFiltersBtn = new QAFExtendedWebElement(By.xpath("//button[@title='Close Filters']"));
		CloseFiltersBtn.click();
		String QuoteName = new QAFExtendedWebElement(By.xpath("(//tbody//tr/th//a)[last()]")).getText();
		return QuoteName;	
	}
}
