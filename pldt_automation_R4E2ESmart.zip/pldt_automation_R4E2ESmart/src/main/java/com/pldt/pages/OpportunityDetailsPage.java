package com.pldt.pages;

import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class OpportunityDetailsPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	WebUtilities util=new WebUtilities();
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	public void ClickConfigure()
	{ 
		util.clickOnActionToolBarButton("OpportunityActionToolbar", "Configure");
		util.waitForCartPage();
		util.refreshSwitchToFrame();
	}
	public void DeviceAvailability() 
	{
		//Thread.sleep(5000);
		//util.switchToActionFrame();
	//	getDeviceAvailabilityCheck().click();
		//Thread.sleep(3000);
		//util.switchToActionFrame();
		util.clickOnActionToolBarButton("OpportunityActionToolbar", "Device Availability check"); //Nimesh
		//util.switchtoFrameAndClick(By.xpath("(//span[text()='Device Availability check'])[1]"));
		util.waitForVlocityOmniScript();
		util.switchtoFrameAndClick(By.xpath("//button[@id='InventoryDetails_nextBtn']"));
	//	util.clickUsingJs(deviceAvailabilityNextBtn);
	}
	public void CreateQuote() 
	{
		util.clickOnActionToolBarButton("OpportunityActionToolbar", "Create Quote");
//		util.switchtoFrameAndClick(By.xpath("(//span[text()='Create Quote'])[1]"));
		util.waitForQuotePage();
	//	util.clickOnQuickActionButton("create quote", By.xpath("//div[.='Quote']"), true);
		//getcreateQuotebtn().click();
	}
	public void changestatustoEstablishNeed() {
		QAFWebElement establishNeed = new QAFExtendedWebElement(
				By.xpath("//span[@class='ahead slds-path__stage']/following-sibling::span[text()='Establish Need']"));
		QAFWebElement markStatus = new QAFExtendedWebElement(By.xpath("//span[text()='Mark as Current Stage']"));
		util.ChangeStatus(establishNeed, markStatus);
		System.out.println("Changed Status to Establish Need...");
	}
}
