package com.pldt.pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.elements.Button;
import com.pldt.lib.PageLib;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class QuoteDetailsPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	String deviceSalesNumber = null;
	static final String QuoteName = "xpath=//span[text()='Quote Name']/parent::label/following-sibling::input";
	static final String OpportunityName = "xpath=//span[text()='Opportunity Name']/parent::label/following-sibling::div";
	static final String QuoteCurrency = "xpath=//span[text()='Quote Currency']/parent::span/following-sibling::div";
	static final String SimFirstDelivery = "xpath=//span[text()='Sim First Delivery']/parent::label/following-sibling::input";
	static final String ExpirationDate = "xpath=//span[text()='Expiration Date']/parent::label/following-sibling::div";
	static final String Status = "xpath=//span[text()='Status']/parent::span/following-sibling::div";
	static final String Description = "xpath=//span[text()='Description']/parent::label/following-sibling::textarea";
	static final String SyncedOrder = "xpath=//span[text()='Synced Order']/parent::label/following-sibling::div";
	static final String RFSDate = "xpath=//span[text()='RFS Date']/parent::label/following-sibling::div";
	static final String FutureActivationDate = "xpath=//span[text()='Future Activation Date']/parent::label/following-sibling::div";
	static final String SpecialBuildCost = "xpath=//span[text()='Special Build Cost']/parent::label/following-sibling::input";
	static final String Edit_Quote_Validity = "xpath=//button[@title='Edit Quotation Validity Period (Days)']";
	static final String Quote_Validity = "xpath=//span[text()='Quotation Validity Period (Days)']/parent::label/following-sibling::input";
	static final String Authorized_Signatory = "xpath=//span[text()='Authorized Signatory']/parent::label/following-sibling::div//input";
	static final String Bill_Recipient = "xpath=//span[text()='Bill Recipient']/parent::label/following-sibling::div//input";
	static final String Delivery_Recipient = "xpath=//span[text()='Delivery Recipient']/parent::label/following-sibling::div//input";
	static final String CAP_Contact = "xpath=//span[text()='CAP Contact']/parent::label/following-sibling::div//input";
	static final String Quote_Save = "xpath=//button[@title='Save']";
	static final String NonSmartSBRApprovalStatus = "xpath=//span[text()='Non-SMART SBR Approval Status']/parent::span/following-sibling::div";
	static final String NonSmartSBRApprovalCheck = "xpath=//span[text()='Non-SMART SBR Approval Check']/parent::label/following-sibling::input";
	static final String SmartSBRApprovalStatus = "xpath=//span[text()='SMART SBR Approval Status']/parent::span/following-sibling::div";
	static final String EBIT = "xpath=//span[text()='EBIT']/parent::label/following-sibling::input";
	static final String Tax = "xpath=//span[text()='Tax']/parent::label/following-sibling::input";
	static final String CaseID = "xpath=//span[text()='CaseId']/parent::label/following-sibling::div";
	static final String ContactName = "xpath=//span[text()='Contact Name']/parent::label/following-sibling::div";
	static final String Email = "xpath=//span[text()='Email']/parent::label/following-sibling::input";
	static final String Phone = "xpath=//span[text()='Phone']/parent::label/following-sibling::input";
	static final String Fax = "xpath=//span[text()='Fax']/parent::label/following-sibling::input";
	static final String CreditCheck = "xpath=//span[text()='Credit Check']/parent::span/following-sibling::div";
	static final String Edit_Credit_Approval_Status = "xpath=//button[@title='Edit Credit Approval Status']";
	static final String Credit_Approval_Status = "xpath=//span[text()='Credit Approval Status']/parent::span/following-sibling::div//a";
	static final String Credit_Approval_Condition = "xpath=//span[text()='Credit Approval Condition']/parent::span/following-sibling::div//a";
	static final String Credit_Remarks = "xpath=//span[text()='Credit Remarks']/parent::label/following-sibling::textarea";
	static final String AdvancePaymentInMonths = "xpath=//span[text()='Advance Payment in Months']/parent::label/following-sibling::input";
	static final String CreditApprovedBy = "xpath=//span[text()='Credit Approved By']/parent::label/following-sibling::div";
	static final String CreditApprovedDate = "xpath=//span[text()='Credit Approved Date']/parent::label/following-sibling::div";
	static final String SecurityDepositInMonths = "xpath=//span[text()='Security Deposit in Months']/parent::label/following-sibling::input";
	static final String ReservationSalesNumber = "xpath=//span[text()='Reservation Sales Number']/parent::label/following-sibling::input";
	static final String ReservationStatus = "xpath=//span[text()='Reservation Status']/parent::label/following-sibling::input";
	static final String ExpiryDate = "xpath=//span[text()='Expiry Date']/parent::label/following-sibling::div";
	static final String Edit_Delivery_Date = "xpath=//button[@title='Edit Delivery Date']";
	static final String Delivery_Date = "xpath=//span[text()='Delivery Date']/parent::label/following-sibling::div/input";
	static final String ETSStatus = "xpath=//span[text()='ETS Status']/parent::span/following-sibling::div";
	static final String ETSRemarks = "xpath=//span[text()='ETS Remarks']/parent::label/following-sibling::textarea";
	static final String ESSRemarks = "xpath=//span[text()='ESS Status']/parent::span/following-sibling::div";
	static final String ENCDStatusSiteSurvey = "xpath=//span[text()='ECND Status - Site Survey']/parent::span/following-sibling::div";
	static final String ENCDStatusDetailDesign = "xpath=//span[text()='ECND Status - Detail Design']/parent::span/following-sibling::div";
	static final String ENCDDetailDesignRemark = "xpath=//span[text()='ECND Detail Design Remarks']/parent::label/following-sibling::textarea";
	static final String SolconStatus = "xpath=//span[text()='Solcon Status']/parent::span/following-sibling::div";
	static final String SolconRemarks = "xpath=//span[text()='Solcon Remarks']/parent::label/following-sibling::textarea";
	static final String SolconHeadStatus = "xpath=//span[text()='Solcon Head Status']/parent::span/following-sibling::div";
	static final String SolconHeadRemarks = "xpath=//span[text()='Solcon Head Remarks']/parent::label/following-sibling::textarea";
	static final String Accepted = "xpath=//span[text()='Accepted']";
	static final String Mark_As_Current_Status = "xpath=//span[text()='Mark as Current Status']";
	static final String Related = "xpath=//span[text()='Related']";
	static final String Quote_Line_Items = "xpath=//span[@title='Quote Line Items']";
	static final String QLI_Related = "xpath=(//span[text()='Related'])[2]";
	static final String Quote_Line_Account_Details = "xpath=//span[@title='QLI Account Detail']";
	static final String Orders = "xpath=//span[@title='Orders']";
	static final String Upload = "xpath=(//span[text()='Upload Files'])[2]";
	static final String Assign = "xpath=//span[text()='Assign']";
	static final String Close = "xpath=//span[text()='Close'][@class='btnLabel']";
	@FindBy(locator = Accepted)
	private QAFWebElement accepted;
	@FindBy(locator = Mark_As_Current_Status)
	private QAFWebElement markAsCurrentStatus;
	@FindBy(locator = Related)
	private QAFWebElement related;
	@FindBy(locator = Quote_Line_Items)
	private QAFWebElement quoteLineItems;
	@FindBy(locator = QLI_Related)
	private QAFWebElement QLIRelated;
	@FindBy(locator = Quote_Line_Account_Details)
	private QAFWebElement quoteLineAccountDetails;
	@FindBy(locator = Orders)
	private QAFWebElement orders;
	@FindBy(locator = Upload)
	private QAFWebElement upload;
	@FindBy(locator = Assign)
	private QAFWebElement assign;
	@FindBy(locator = Close)
	private QAFWebElement close;
	// added by vidya
	@FindBy(locator = "//span[.='Offers']")
	private QAFWebElement offersButton;
	@FindBy(locator = "//button[.='Modify Products']")
	private QAFWebElement modifyProducts;
	@FindBy(locator = "//input[@placeholder='Enter Product Name']")
	private QAFWebElement productNameSearchBox;
	@FindBy(locator = "//label[contains(@for,'lgt-dt-header-factory')]//span[@class='slds-checkbox_faux']")
	private QAFWebElement productCheckbox;
	@FindBy(locator = "//button[@title='Close this window']")
	private QAFWebElement errorWindowCloseBtn;

	public QAFWebElement getAccepted() {
		return accepted;
	}

	public QAFWebElement getMarkAsCurrentStatus() {
		return markAsCurrentStatus;
	}

	public QAFWebElement getRelated() {
		return related;
	}

	public QAFWebElement getQuoteLineItems() {
		return quoteLineItems;
	}

	public QAFWebElement getQLIRelated() {
		return QLIRelated;
	}

	public QAFWebElement getQuoteLineAccountDetails() {
		return quoteLineAccountDetails;
	}

	public QAFWebElement getOrders() {
		return orders;
	}

	public QAFWebElement getUpload() {
		return upload;
	}

	public QAFWebElement getAssign() {
		return assign;
	}

	public QAFWebElement getClose() {
		return close;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public void updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(Map<String, String> data) {
		util.waitFor(By.xpath("//span[.='Quotation Validity Period (Days)']"), 30, true);
		util.scrollIntoElement(By.xpath("//span[.='Quotation Validity Period (Days)']"));
		util.clickUsingJs(By.xpath("//button[@title='Edit Quotation Validity Period (Days)']"));
		util.enterText(
				driver.findElement(By.xpath(
						"//span[text()='Quotation Validity Period (Days)']/parent::label/following-sibling::input")),
				data.get("QuotationValidity"));
		util.clickUsingActions(By.xpath("//div[@class='active']//span[.='Quotation Validity Period (Days)']"));
//		if (data.get("EBro") != null || data.get("ES") != null
//				|| data.get("EE Hotline") != null && !data.get("EBro").equalsIgnoreCase("SKIP")
//				|| !data.get("ES").equalsIgnoreCase("SKIP") || !data.get("EE Hotline").equalsIgnoreCase("SKIP")) {
//			if (data.get("Transaction Type").equalsIgnoreCase("Upgrade / plan upgrade")) {
//				QAFWebElement QuoteCreatedbyContactCenter_Checkbox = new QAFExtendedWebElement(By.xpath(
//						"(//label[@class=\\\"label inputLabel uiLabel-left form-element__label uiLabel\\\"]/span[text()='Quote Created by Contact Center']/following::input)[1]"));
//				util.clickUsingJs(QuoteCreatedbyContactCenter_Checkbox);
//			}
//		}
		updateContactDetails(data);
		util.scrollIntoElement(By.xpath("(//span[.='Device Reservation Information'])[1]"));
		util.scrollIntoElement(By.xpath("//span[text()='Delivery Date']/parent::label/following-sibling::div/input"));
		util.enterText(
				driver.findElement(
						By.xpath("//span[text()='Delivery Date']/parent::label/following-sibling::div/input")),
				data.get("DeliveryDate"));
		util.clickUsingActions(By.xpath("//span[text()='Delivery Date']/parent::label"));
		update_EBIT();
		util.clickUsingJs(By.xpath("//button[@title='Save']"));
		util.waitFor(By.xpath("//span[text()='Delivery Date']/parent::label/following-sibling::div/input"), 10, false);
		util.waitFor(3); // new
		try {
			reload(data);
		} catch (Exception e) {
		}
	}

	public void update_EBIT() {
		util.scrollIntoElement(By.xpath("(//h3[.='Internal Approvals'])[1]"));
		// util.clickUsingJs(By.xpath("//span[text()='EBIT']/parent::div/following-sibling::div/button"));
		QAFWebElement input = new QAFExtendedWebElement(
				By.xpath("//span[text()='EBIT']/parent::label/following-sibling::input"));
		util.waitFor(By.xpath("//span[text()='EBIT']/parent::label/following-sibling::input"), 30, true);
		util.enterText(input, "40");
		util.clickUsingActions(By.xpath("//span[text()='EBIT']/parent::label"));
		util.clickUsingJs(By.xpath(
				"//button[contains(@class,'slds-button slds-button--neutral uiButton--brand uiButton forceActionButton')]"));
	}

	public void reload(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		if (driver.findElement(By.xpath("//div[@class='reloadButton']/button/span")).isEnabled()) {
			util.clickUsingJs(driver.findElement(By.xpath("//div[@class='reloadButton']/button/span")));
			util.waitForQuotePage();
			updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
		}
	}

	public void updateContactDetails(Map<String, String> data) {
		updateAuthorizeSigonatory(data.get("Authorized Signatory"));
//		updateBillRecipient(data.get("Bill Recipient"));
		updateCapContact(data.get("CAP Contact"));
		updateDeliveryRecipient(data.get("Delivery Recipient"));
	}

	public void updateAuthorizeSigonatory(String AuthorizeSigonatory) {
		if (AuthorizeSigonatory.equalsIgnoreCase("Random")) {
			AuthorizeSigonatory = pageProps.getPropertyValue("Authorized.Signatory");
		}
		QAFWebElement as = new QAFExtendedWebElement(
				By.xpath("//span[text()='Authorized Signatory']/parent::label/following-sibling::div//input"));
		util.enterTextUsingJs(as, AuthorizeSigonatory);
		int check = AuthorizeSigonatory.length();
		while (check > 0) {
			as.sendKeys(Keys.BACK_SPACE);
			try {
				util.waitFor(By.xpath(
						"//span[.='Authorized Signatory']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ AuthorizeSigonatory + "']"),
						1, true);
				util.clickUsingJs(driver.findElement(By.xpath(
						"//span[.='Authorized Signatory']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ AuthorizeSigonatory + "']")));
				break;
			} catch (Exception e) {
			}
			check--;
		}
	}

	public void updateCapContact(String CapContact) {
		QAFWebElement cc = new QAFExtendedWebElement(
				By.xpath("//span[text()='CAP Contact']/parent::label/following-sibling::div//input"));
		util.enterTextUsingJs(cc, CapContact);
		int check = CapContact.length();
		while (check > 0) {
			cc.sendKeys(Keys.BACK_SPACE);
			try {
				util.waitFor(By.xpath(
						"//span[.='CAP Contact']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ CapContact + "']"),
						1, true);
				util.clickUsingJs(driver.findElement(By.xpath(
						"//span[.='CAP Contact']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ CapContact + "']")));
				break;
			} catch (Exception e) {
			}
			check--;
		}
	}

	public void updateBillRecipient(String BillRecipient) {
		if (BillRecipient.equalsIgnoreCase("Random")) {
			BillRecipient = pageProps.getPropertyValue("Bill.Recipient");
		}
		QAFWebElement br = new QAFExtendedWebElement(
				By.xpath("//span[text()='Bill Recipient']/parent::label/following-sibling::div//input"));
		util.enterTextUsingJs(br, BillRecipient);
		int check = BillRecipient.length();
		while (check > 0) {
			br.sendKeys(Keys.BACK_SPACE);
			try {
				util.waitFor(By.xpath(
						"//span[.='Bill Recipient']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ BillRecipient + "']"),
						1, true);
				util.clickUsingJs(driver.findElement(By.xpath(
						"//span[.='Bill Recipient']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ BillRecipient + "']")));
				break;
			} catch (Exception e) {
			}
			check--;
		}
	}

	public void updateDeliveryRecipient(String DeliveryRecipient) {
		if (DeliveryRecipient.equalsIgnoreCase("Random")) {
			DeliveryRecipient = pageProps.getPropertyValue("Delivery.Recipient");
		}
		QAFWebElement dr = new QAFExtendedWebElement(
				By.xpath("//span[text()='Delivery Recipient']/parent::label/following-sibling::div//input"));
		util.enterTextUsingJs(dr, DeliveryRecipient);
		int check = DeliveryRecipient.length();
		while (check > 0) {
			dr.sendKeys(Keys.BACK_SPACE);
			try {
				util.waitFor(By.xpath(
						"//span[.='Delivery Recipient']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ DeliveryRecipient + "']"),
						1, true);
				util.clickUsingJs(driver.findElement(By.xpath(
						"//span[.='Delivery Recipient']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
								+ DeliveryRecipient + "']")));
				break;
			} catch (Exception e) {
			}
			check--;
		}
	}

	public void ValidateCart() {
		util.waitForQuotePage();
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Validate Cart");
		// util.waitFor(By.xpath("vlocity_cmt__OmniScriptUniversalPage | Salesforce"),
		// 20, true);
		util.waitForVlocityOmniScript();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//div[@id='GoToQuote']"));
		util.waitForQuotePage();
	}

	public void UpdateCreditInformation(String CreditApprovalStatus, String CreditApprovalCondition,
			String CreditRemark) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)", "");
		//util.scrollDown();
		//util.scrollIntoElement(By.xpath("(//h3//span[.='Totals'])[last()]"));
		util.clickUsingJs(By.xpath("//span[text()='Edit Credit Approval Status']"));
		util.clickUsingJs(By.xpath(
				"//span[contains(@id,'label')][text()='Credit Approval Status']/following::div[1]//a[@role='button']"));
		util.clickUsingJs(By.xpath("//li/a[text()='Approved']"));
		util.clickUsingJs(By.xpath(
				"//span[contains(@id,'label')][text()='Credit Approval Condition']/following::div[1]//a[@role='button']"));
		util.clickUsingJs(By.xpath("//li/a[text()='Bill Above']"));
		util.enterText(
				driver.findElement(
						By.xpath("(//span[text()='Credit Remarks']/following::textarea[@role='textbox'])[3]")),
				CreditRemark);
		util.clickUsingActions(By.xpath("//span[text()='Credit Remarks']/parent::label"));
		util.clickUsingJs(By.xpath("//button[@title='Save']/span"));
		util.waitFor(By.xpath("//button[@title='Save']/span"), 10, false);
	}

	public void ChangeStatusToAccepted() {
		util.ChangeStatus(getAccepted(), getMarkAsCurrentStatus());
		try {
			Thread.sleep(5000);
		} catch (Exception e) { // Commented to test loadingPage
		}
//		getAccepted().click();
//		getMarkStatusAsComplete().click();
	}

	public void changeStatusToApproved1() {
		QAFWebElement approved = new QAFExtendedWebElement(By.xpath("(//a[@title='Customer Approved'])"));
		util.ChangeStatus(approved, getMarkAsCurrentStatus());
		try {
			Thread.sleep(5000);
		} catch (Exception e) {
		}
//		getAccepted().click();
//		getMarkStatusAsComplete().click();
	}

	public void CreateContract() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Create Contract");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.vlocityNextButton();
		util.waitForContractPage();
		ProjectBeans.setContractURL(driver.getCurrentUrl());
	}

	// File Upload
	public void AssignPortIN() {
		// util.switchToActionFrame();
		// getAssignPortInMIN().click();
		util.switchToFrame(By.xpath("(//span[text()='Assign PortIn MIN']/parent::div)[1]"));
		// driver.switchTo().defaultContent();
		util.clickButton(getUpload());
		try {
			// Thread.sleep(3000); //Commented to test loadingPage
			Robot rb = new Robot();
			// copying File path to Clipboard
			String projectPath = System.getProperty("user.dir");
			StringSelection str = new StringSelection((projectPath + "\\resources\\testdata\\BulkFile.csv"));
			util.waitFor(2);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
			// press Contol+V for pasting
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_V);
			// release Contol+V for pasting
			rb.keyRelease(KeyEvent.VK_CONTROL);
			rb.keyRelease(KeyEvent.VK_V);
			// for pressing and releasing Enter
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception e) {
		}
		util.waitForClickable(By.xpath("//div[contains(@class,'modal-container')]//span[text()='Done']"), 5);
		new Button().click("Done");
		util.waitTillLoaderDissapear();
		util.waitFor(3);
		getAssign().click();
		util.waitFor(By.xpath("//span[text()='Close'][@class='btnLabel']"), 5, true);
		getClose().click();
	}

	public void SynchronizingAccount(String Plan, String RMUser) {
		util.clickUsingJs(getRelated());
		util.clickUsingJs(getQuoteLineItems());
		QAFWebElement plan = new QAFExtendedWebElement("xpath=(//a[@title='" + Plan + "'])[1]");
		util.clickButton(plan);
		getQLIRelated().click();
		getQuoteLineAccountDetails().click();
		ProjectBeans.setQLIURL(driver.getCurrentUrl());
		int count = 120;
		Boolean synced = false;
		while (count <= 5) {
			util.refreshPage();
			waitForPageToLoad();
			util.waitFor(By.xpath("//span[.='CSP Account Sync Status']/following::tbody/tr/td[4]/span/span"), 30, true);
			if (driver.findElement(By.xpath("//span[.='CSP Account Sync Status']/following::tbody/tr/td[4]/span/span"))
					.getText().equalsIgnoreCase("Synced")) {
				synced = true;
				break;
			}
			System.out.println(driver
					.findElement(By.xpath("//span[.='CSP Account Sync Status']/following::tbody/tr/td[4]/span/span"))
					.getText());
			count++;
		}
		if (!synced) {
			PageLib p = new PageLib();
			p.getLoginpage().logoutCurrentUser();
			driver.get(ProjectBeans.getQLIURL());
			util.clickUsingJs(By.xpath("//a[contains(text(),'QLIA-')]"));
			util.clickUsingJs(By.xpath("//button[@title='Edit CSP Account Sync Status']"));
			System.out.println();
			util.waitFor(5);
//			driver.findElement(By.xpath("(//label[.='CSP Account Sync Status']/following::div/button)[1]")).click();
			util.clickUsingActions(By.xpath("(//label[.='CSP Account Sync Status']/following::div/button)[1]"));
//			util.clickUsingJs(By.xpath("//label[text()='CSP Account Sync Status']/following::div[1]//button/span"));
			util.clickUsingJs(By.xpath("(//div/lightning-base-combobox-item[@data-value='Synced'])[1]"));
			driver.findElement(By.xpath("//label[.='Error Message']/following::div/textarea")).clear();
			util.clickUsingJs(By.xpath("//lightning-button//button[.='Save']"));
			util.waitFor(By.xpath("//lightning-button//button[.='Save']"), 10, false);
			driver.findElement(By.xpath(
					"//span[.='CSP Account Sync Status']/following::lightning-formatted-text[normalize-space()='Synced']"))
					.verifyVisible();
			p.getHomepage().switchToAnyUser(RMUser);
		}
		driver.get(ProjectBeans.getQuoteURL());
	}

	public void ClickConfigure() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Configure");
		util.waitForCartPage();
		util.refreshSwitchToFrame();
	}

	public void CreditCheck() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Credit Check");
//			util.waitFor(By.xpath("vlocity_cmt__OmniScriptUniversalPage | Salesforce"), 10, true);
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.scrollTillVisible(By.xpath("//p[text()='Next']/parent::div"));
		util.clickUsingJs(By.xpath("//p[text()='Next']/parent::div"));
		// util.scrollTillVisible(By.xpath("//p[text()='Next']/parent::div"));
		// util.clickUsingJs(By.xpath("//p[text()='Next']/parent::div"));
		util.vlocityNextButton();
		try {
			util.clickUsingJs(driver.findElement(By.xpath("//div[@id='CreditCheckRequiredSMART_nextBtn']/p")));
		} catch (Exception e) {
		}
		util.waitForQuotePage();
	}

	public void DeviceReservation() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Device Reservation");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//section[@id='Step3']//h1[contains(text(),'Device Availability')]"), 30, true);
		util.vlocityNextButton();
		util.AttachFrame();
		util.vlocityNextButton();
		util.AttachFrame();
		if (util.isElementDisplayed(By.xpath("(//div//ng-form[@id='reservationStatusTxt']/div/p/p[1])[last()]"))) {
			deviceSalesNumber = util
					.getTextFromPage(By.xpath("(//div//ng-form[@id='reservationStatusTxt']/div/p/p[1])[last()]"))
					.split(" ")[4];
		} else if (util.isElementDisplayed(By.xpath(
				"(//section[@id='DeviceAllocationUnsuccesful']//h1[contains(text(),'Device Reservation Unsuccessful')])[last()]"))) {
			deviceSalesNumber = util
					.getTextFromPage(By.xpath("(//section[@id='DeviceAllocationUnsuccesful']//ng-form//h1[2])[last()]"))
					.split(" ")[9];
		}
		Reporter.log(deviceSalesNumber);
		util.vlocityNextButton();
		util.waitForQuotePage();
	}

	public ArrayList<String> VerifyOrders() {
		util.clickUsingJs(getRelated());
		util.clickUsingJs(getOrders());
		return util.refreshOrders(10, 2);
	}

	// Created by Vinay for Converting Quote to PDF
	public void QuotetoPDF() {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Quote to PDF");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//h1[contains(text(),'Generate Document')]"), 20, true);
		driver.switchTo().frame(0);
		QAFWebElement generate = new QAFExtendedWebElement("xpath=//button[span[text()='Generate Document']]");
		util.waitAndClickUsingJavaScript(generate, "Generate");
		util.waitFor(By.xpath("//h2[text()='Successfully generated PDF attachment.']"), 30, true);
		util.clickUsingJs(By.xpath("//button[contains(@class,'download')]"));
		util.waitFor(10);
		util.AttachFrame();
		util.vlocityNextButton();
		util.waitForQuotePage();
	}

	// created by Vidya
	public void modifyProductsbyduplicates(Map<String, String> data) {
		util.waitForQuotePage();
		ProjectBeans.setQuoteURL(driver.getCurrentUrl());
		//deleteQLI();
		util.waitFor(offersButton, 30, true);
		util.clickUsingJs(offersButton);
		if (errorWindowCloseBtn.isPresent()) {
			errorWindowCloseBtn.click();
		}
		int numberOfRefresh = 0;
		QAFWebElement productCheckbox2 = new QAFExtendedWebElement(
				By.xpath("(//span[@class='slds-checkbox_faux'])[2]"));
		try {
			if (errorWindowCloseBtn.isPresent()) {
				errorWindowCloseBtn.click();
			}
			while ((!productCheckbox2.isPresent()) && (numberOfRefresh++ < 45)) {
				util.refreshPage();
				util.waitForQuotePage();
				util.waitFor(offersButton, 30, true);
				util.clickUsingJs(offersButton);
				util.waitFor(2);
			}
		} catch (Exception e) {
		}
		if (data.get("AddDeviceOrNot").equalsIgnoreCase("Yes")) {
			util.waitFor(productNameSearchBox, 30, true);
			productNameSearchBox.sendKeys(data.get("Plan"));
			util.clickUsingJs(productCheckbox2);
			util.clickUsingJs(modifyProducts);
			util.waitForCartPage();
		}
	}

	// created by Nimesh
	public void deleteQLI() {
		driver.get(ProjectBeans.getQuoteURL());
		util.waitFor(5);
		driver.findElement(By.xpath("//span[text()='Related']")).click();
		util.waitFor(3);
		driver.findElement(By.xpath("//span[@title='Quote Line Items']")).click();
		int numberOfRefresh = 0;
		QAFWebElement numberofQLI = new QAFExtendedWebElement(By.xpath("(//span[text()='Show Actions'])[4]"));

		while ((!numberofQLI.isPresent()) && (numberOfRefresh++ < 90)) {
			util.refreshPage();
			util.waitFor(By.xpath("//title[text()='Quote Line Items | Salesforce']"), 5, true);

		}
		String QLIShowActionButton = "//span[text()='Show Actions']";
		List<WebElement> listofelements = driver.findElements(By.xpath(QLIShowActionButton));
		int Size = listofelements.size();
		if (Size > 1) {
			for (int i = 2; i <= Size; i++) {
				util.waitFor(By.xpath("(//span[text()='Show Actions'])[2]"), 10, true);
				util.clickUsingJs(By.xpath("(//span[text()='Show Actions'])[2]"));
				util.waitFor(By.xpath("//a[@title='Delete']"), 10, true);
				util.clickUsingJs(By.xpath("//a[@title='Delete']"));
				util.waitFor(By.xpath("//button[@title='Delete']"), 10, true);
				util.clickUsingJs(By.xpath("//button[@title='Delete']"));
				util.waitForGenericToastMessage();
				util.refreshPage();

			}
		}
		driver.get(ProjectBeans.getQuoteURL());
	}
}
