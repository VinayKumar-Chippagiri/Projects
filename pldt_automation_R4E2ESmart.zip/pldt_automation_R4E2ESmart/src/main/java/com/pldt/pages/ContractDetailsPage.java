package com.pldt.pages;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class ContractDetailsPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	WebUtilities util = new WebUtilities();
	static final String Negotiating="xpath=//span[text()='Negotiating']";
	static final String Mark_Status_As_Complete="xpath=(//span[text()='Mark Status as Complete'])[2]";
	static final String Awaiting_Signature="xpath=//span[text()='Awaiting Signature']";
	static final String Details="xpath=(//span[text()='Details'])";
	static final String Generate="xpath=//span[text()='Generate']/ancestor::button";
	static final String Template_Select="xpath=//select[@id='template-select']";
	static final String Qoute="xpath=(//span[text()='Quote']/parent::*/following-sibling::div//a)[1]";
	@FindBy(locator = Negotiating)
	private QAFWebElement negotiating;
	@FindBy(locator = Mark_Status_As_Complete)
	private QAFWebElement markStatusAsComplete;
	@FindBy(locator = Awaiting_Signature)
	private QAFWebElement awaiting_Signature;
	@FindBy(locator = Details)
	private QAFWebElement details;
	@FindBy(locator = Generate)
	private QAFWebElement generate;
	@FindBy(locator = Template_Select)
	private QAFWebElement TemplateSelect;
	@FindBy(locator = Qoute)
	private QAFWebElement qoute;
	public QAFWebElement getNegotiating() {
		return negotiating;
	}
	public QAFWebElement getMarkStatusAsComplete() {
		return markStatusAsComplete;
	}
	public QAFWebElement getAwaiting_Signature() {
		return awaiting_Signature;
	}
	public QAFWebElement getDetails() {
		return details;
	}
	public QAFWebElement getGenerate() {
		return generate;
	}
	public QAFWebElement getTemplateSelect() {
		return TemplateSelect;
	}
	public QAFWebElement getQoute() {
		return qoute;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	public void ChangeTheStatusToAwaitingSignature() {
		//	QAFWebElement MarkCurrentStatus =new QAFExtendedWebElement(By.xpath("//span[text()='Mark as Current Status']"));
			getNegotiating().click();
			getMarkStatusAsComplete().click();
			//MarkCurrentStatus.click();
			getAwaiting_Signature().click();
			
		}

		public void GenerateContractDocument(String Template) {
			getDetails().click();
			//util.switchToActionFrame();
			util.clickButton(getGenerate());
			//util.switchToActionFrame();
			getTemplateSelect().click();
			QAFWebElement template = new QAFExtendedWebElement("xpath=(//option[text()='" + Template + "'])");
			util.clickButton(template);
		}

		public void GoToQuote() {
			getDetails().click();
			util.clickButton(getQoute());
		}
		
		public void ChangeTheStatusToSigned() {
			util.ChangeStatus("Negotiating");
		//	util.ChangeStatus("Awaiting Signature");
			util.ChangeStatus("Signed");
		}

}
