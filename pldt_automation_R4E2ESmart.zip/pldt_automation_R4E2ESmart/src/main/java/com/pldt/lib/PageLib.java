package com.pldt.lib;

import com.pldt.aftersalesactions.AfterSales;
import com.pldt.pages.AccountDetailsPage;
import com.pldt.pages.AccountListPage;
import com.pldt.pages.AccountPage;
import com.pldt.pages.AddressAssignmentPage;
import com.pldt.pages.AssetDetailsPage;
import com.pldt.pages.AssetPage;
import com.pldt.pages.AssetsListPage;
import com.pldt.pages.BillingAndServiceAccount;
import com.pldt.pages.CartPage;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.pages.CaseListPage;
import com.pldt.pages.CasePage;
import com.pldt.pages.ContactPage;
import com.pldt.pages.ContractPage;
import com.pldt.pages.HomePage;
import com.pldt.pages.LeadPage;
import com.pldt.pages.LoginPage;
import com.pldt.pages.OpportunityPage;
import com.pldt.pages.QuotePage;
import com.pldt.pages.SyniverseLoginPage;
import com.pldt.pages.VlocityPage;
import com.pldt.pages.*;

public class PageLib {
	private LoginPage loginpage;
	private HomePage homepage;
	private LeadPage leadpage;
	private QuotePage quotepage;
	private CasePage casepage;
	private AccountPage accountpage;
	private AssetPage assetpage;
	private OpportunityPage opportunitypage;
	private CartPage cartpage;
	private VlocityPage vlocitypage;
	private AddressAssignmentPage addressassignmentpage;
	private ContractPage contractPage;
	private ContactPage contactPage;
	private BillingAndServiceAccount billingAndServiceAccount;
	private SyniverseLoginPage syniverseLogin;
	private AfterSales afterSales;
	private OrdersPage ordersPage;
	private AccountListPage accountListPage;
	private AccountDetailsPage accountDetailsPage;
	private AssetsListPage assetsListPage;
	private AssetDetailsPage assetDetailsPage;
	private CaseListPage caseListPage;
	private CaseDetailsPage caseDetailsPage;
	private NewCaseModal newCaseModal;
	private QuoteDetailsPage quoteDetailsPage;
	private OpportunityListPage opportunityListPage;
	private NewOpportunityModel newOpportunityModel;
	private OpportunityDetailsPage opportunityDetailsPage;
	// private QAFExtendedWebDriver driver;
	private SyniverseHomePage syniverseHomePage;
	private SyniverseNPOPage syniverseNPOPage;
	private QuoteListPage quoteListPage;
	private SyniverseDisconnectPage syniverseDisconnectPage;
	// private QAFExtendedWebDriver driver;

	public PageLib() {
		// this.driver=driver;
		loginpage = new LoginPage();
		homepage = new HomePage();
		leadpage = new LeadPage();
		quotepage = new QuotePage();
		casepage = new CasePage();
		accountpage = new AccountPage();
		assetpage = new AssetPage();
		opportunitypage = new OpportunityPage();
		cartpage = new CartPage();
		vlocitypage = new VlocityPage();
		addressassignmentpage = new AddressAssignmentPage();
		contractPage = new ContractPage();
		contactPage = new ContactPage();
		billingAndServiceAccount = new BillingAndServiceAccount();
		syniverseLogin = new SyniverseLoginPage();
		afterSales = new AfterSales();
		ordersPage = new OrdersPage();
		accountListPage = new AccountListPage();
		accountDetailsPage = new AccountDetailsPage();
		assetsListPage = new AssetsListPage();
		assetDetailsPage = new AssetDetailsPage();
		caseListPage = new CaseListPage();
		caseDetailsPage = new CaseDetailsPage();
		newCaseModal = new NewCaseModal();
		quoteDetailsPage = new QuoteDetailsPage();
		opportunityListPage = new OpportunityListPage();
		newOpportunityModel = new NewOpportunityModel();
		opportunityDetailsPage = new OpportunityDetailsPage();
		syniverseHomePage = new SyniverseHomePage();
		syniverseNPOPage = new SyniverseNPOPage();
		quoteListPage = new QuoteListPage();
		syniverseDisconnectPage = new SyniverseDisconnectPage();
	}

	public CaseDetailsPage getCaseDetailsPage() {
		return caseDetailsPage;
	}

	public CaseListPage getCaseListPage() {
		return caseListPage;
	}

	public AssetDetailsPage getAssetDetailsPage() {
		return assetDetailsPage;
	}

	public AssetsListPage getAssetsListPage() {
		return assetsListPage;
	}

	public AccountDetailsPage getAccountDetailsPage() {
		return accountDetailsPage;
	}

	public AccountListPage getAccountListPage() {
		return accountListPage;
	}

	public VlocityPage getVlocitypage() {
		return vlocitypage;
	}

	public LoginPage getLoginpage() {
		return loginpage;
	}

	public HomePage getHomepage() {
		return homepage;
	}

	public LeadPage getLeadpage() {
		return leadpage;
	}

	public QuotePage getQuotepage() {
		return quotepage;
	}

	public CasePage getCasepage() {
		return casepage;
	}

	public AccountPage getAccountpage() {
		return accountpage;
	}

	public AssetPage getAssetpage() {
		return assetpage;
	}

	public OpportunityPage getOpportunitypage() {
		return opportunitypage;
	}

	public CartPage getCartpage() {
		return cartpage;
	}

	public AddressAssignmentPage getAddressassignmentpage() {
		return addressassignmentpage;
	}

	public ContractPage getContractpage() {
		return contractPage;
	}

	public ContactPage getContactpage() {
		return contactPage;
	}

	public BillingAndServiceAccount getBillingAndServiceAccount() {
		return billingAndServiceAccount;
	}

	public SyniverseLoginPage getSyniverseLogin() {
		return syniverseLogin;
	}

	public AfterSales getAfterSales() {
		return afterSales;
	}

	public QuoteListPage getQuoteListPage() {
		return quoteListPage;
	}

	public OrdersPage getOrdersPage() {
		return ordersPage;
	}

	public NewCaseModal getNewCaseModal() {
		return newCaseModal;
	}

	public QuoteDetailsPage getQuoteDetailsPage() {
		return quoteDetailsPage;
	}

	public OpportunityListPage getOpportunityListPage() {
		return opportunityListPage;
	}

	public NewOpportunityModel getNewOpportunityModel() {
		return newOpportunityModel;
	}

	public OpportunityDetailsPage getOpportunityDetailsPage() {
		return opportunityDetailsPage;
	}

	public SyniverseHomePage getSyniverseHomePage() {
		return syniverseHomePage;
	}

	public SyniverseNPOPage getSyniverseNPOPage() {
		return syniverseNPOPage;
	}

	public SyniverseDisconnectPage getSyniverseDisconnectPage() {
		return syniverseDisconnectPage;
	}
}
