package saucelabs;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;


public class SaucelabsTest {
	saucecommon.Utilities sauce = new saucecommon.Utilities();
	WebDriver driver = null;
  
	
  @Test(description="Login Functionality",priority=1)
  public void Login() {
	  sauce.login();
	  System.out.println("User is logged in with given Credentials");
  }
  
  @Test(description = "Opening the Menu",priority=2)
  public void OpenMenu() {
	  sauce.openMenu();
	  System.out.println("Opened the Menu and Clicked on About Link");  
  }
  
  @Test(description="Validating the Url",priority=3)
  public void ValidateUrl() {
	 sauce.validatingUrl();
	 System.out.println("Validating the Sauce Labs Site");
  }
  
  @Test(description="Clicking on browser back button and Validating the products page",priority=4)
  public void NavigatebackAndValidate() {
	 sauce.navigatingback();
	 System.out.println("Click on browser back button");
	 sauce.validateProductspage();
	 System.out.println("Validating the Products Page");
  }
  
  @Test(description="Selecting the Highest price",priority=5)
  public void SelectinghighestPrice() {
	 sauce.selectinghighestPrice();
	 System.out.println("Selecting Highest Price value");
  }
  
  @Test(description="Clicking on Cart viewer button",priority=6)
  public void ClickonCart() {
	  sauce.clickOnCart();
	  System.out.println("user clicked on cart viewer");
  }
  
  @Test(description="Validating the Cart Page",priority=7)
  public void ValidateCartPage() {
	sauce.validateCartPage();
	System.out.println("validating the Cart page");
  }
  
  @Test(description="Clicking on CheckOut",priority=8)
  public void CheckOut() {
	sauce.CheckOut();
	System.out.println("User Clicked on CheckOut Button");
  }
  
  @Test(description="Validating Your Information Page",priority=9)
  public void YourInformation() {
	sauce.YourInformation();
	System.out.println("Validating the your Information Page");
  }
  
  @Test(description="Populating the Details",priority=10)
  public void populateDetais() {
	  sauce.Populatingdetails();
	  System.out.println("Populated the Details and Clicked on Continue button");
  }
  
  @Test(description="Validating the Checkout Overview Page", priority=11)
  public void validateOverview() {
	  sauce.ValidateOverview();
	  System.out.println("Validating the Checkout Overview Page");
	  sauce.Priceformat();
	  System.out.println("Total Prices is in the Given format");
  }
  @BeforeTest(description="Launching the browser")
  public void Launch() {
	  sauce.browserType("Chrome");
	  System.out.println("Chrome browser is Launched");
	  
  }

  @AfterTest(description="Closing the browser")
  public void afterTest() {
	sauce.closingthebrowser();
	System.out.println("Closing the Browser");  
  }

}
