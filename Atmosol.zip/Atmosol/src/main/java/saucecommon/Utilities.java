package saucecommon;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;

public class Utilities {
	
	static WebDriver driver =null;
	
	public static void browserType(String browser) {
		switch (browser) {
		case "Chrome":
			 WebDriverManager.chromedriver().setup();
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--remote-allow-origins=*","--start-maximized");
				 driver = new ChromeDriver(options);	
				 driver.get("https://www.saucedemo.com/");
		}
	}
	
	public void login() {
		WebElement Username = driver.findElement(By.xpath("(//div/input[@placeholder='Username'])"));
		Username.sendKeys("standard_user");
		WebElement Password = driver.findElement(By.xpath("(//div/input[@placeholder='Password'])"));
		Password.sendKeys("secret_sauce");
		waitFor(2);
		WebElement loginbutton = driver.findElement(By.xpath("(//div//input[@name='login-button'])"));
		loginbutton.click();
	}
	
	public void waitFor(int i) {
		try {
			Thread.sleep(i*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void openMenu() {
		waitFor(5);
//		driver.switchTo().alert().accept();
		WebElement OpenMenu = driver.findElement(By.xpath("(//div//button[text()='Open Menu'])"));
		OpenMenu.click();
		WebElement About = driver.findElement(By.xpath("(//div//nav/a[text()='About'])"));
		About.click();
		waitFor(5);
	}
	
	public void validatingUrl() {
		String CurrentUrl = driver.getCurrentUrl();
		Assert.assertEquals("https://saucelabs.com/", CurrentUrl);
	}
	
	public void navigatingback() {
		driver.navigate().back();
		waitFor(5);
	}
	
	public void validateProductspage() {
		waitFor(10);
		WebElement Products = driver.findElement(By.xpath("(//div[@class='header_secondary_container']//span)[1]"));
		String products= Products.getText();
		Assert.assertEquals("Products", products);
	}

	public void selectinghighestPrice() {
		List<WebElement> Price = driver.findElements(By.xpath("(//div[@class='inventory_item_price'])"));
		Price.forEach(v->v.getText());
		System.out.println(Price);
		WebElement AddtoCart = driver.findElement(By.xpath("(//div//button[@name='add-to-cart-sauce-labs-fleece-jacket'])"));
		AddtoCart.click();
	}
	
	public void clickOnCart() {
		WebElement Cart = driver.findElement(By.xpath("(//div[@id='shopping_cart_container']//a[@class='shopping_cart_link'])"));
		Cart.click();
	}
	
	public void validateCartPage() {
		WebElement YourCart = driver.findElement(By.xpath("(//div[@class='header_secondary_container']//span)"));
		String CartPage = YourCart.getText();
		Assert.assertEquals("Your Cart", CartPage);
	}
	
	public void CheckOut() {
		WebElement checkOut = driver.findElement(By.xpath("(//button[@name='checkout'])"));
		checkOut.click();
	}
	
	public void YourInformation() {
		WebElement YourInformation = driver.findElement(By.xpath("(//div[@class='header_secondary_container']//span)"));
		String Information = YourInformation.getText();
		Assert.assertEquals("Checkout: Your Information", Information);
	}
	
	public void Populatingdetails() {
		WebElement FirstName = driver.findElement(By.xpath("(//div//input[@name='firstName'])"));
		FirstName.sendKeys("Vinay Kumar");
		WebElement LastName = driver.findElement(By.xpath("(//div//input[@name='lastName'])"));
		LastName.sendKeys("Chippagiri");
		WebElement ZipCode = driver.findElement(By.xpath("(//div//input[@name='postalCode'])"));
		ZipCode.sendKeys("518501");
		WebElement Continue = driver.findElement(By.xpath("//input[@id='continue']"));
		Continue.click();
	}
	
	public void ValidateOverview() {
		WebElement ValidateOverview = driver.findElement(By.xpath("(//div[@class='header_secondary_container']//span)"));
		String Overview = ValidateOverview.getText();
		Assert.assertEquals("Checkout: Overview", Overview);
	}
	
	public void Priceformat() {
		WebElement priceFormat = driver.findElement(By.xpath("(//div[@class='inventory_item_price'])"));
		String Price= priceFormat.getText();
		System.out.println(Price);
		System.out.println("Total Price is shown in given Format");
	}
	
	public void closingthebrowser() {
		waitFor(3);
		driver.close();
	}
}
