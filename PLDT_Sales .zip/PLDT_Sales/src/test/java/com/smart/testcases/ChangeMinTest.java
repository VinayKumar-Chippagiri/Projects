package com.smart.testcases;

import java.util.ArrayList;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.smart.common.CaseCreation;
import com.smart.common.Login;

import base.TestBase;

import junit.framework.Assert;
import pageAction.CommonSteps;
import pageAction.CreateOrderAction;
import utilities.ExcelManager;

public class ChangeMinTest extends TestBase {
	static String billingAccountNumber = null;
	static TestBase tb = new TestBase();
	static CreateOrderAction coa = new CreateOrderAction();
	public static By appLauncher = By.xpath("//*[@aria-label=\"App\"]/one-app-launcher-header/button/div");
	public static By appSearch = By.xpath("//input[@placeholder=\"Search apps and items...\"]");
	public static By filter = By.xpath("(//*[text()='Select List View'])/parent::*");
	public static By searchList = By.xpath("//input[@placeholder='Search this list...']");
	public static By showAll = By.xpath("//ul/following-sibling::div/a[contains(text(),'Show All')]");
	public static By asset = By.xpath("//ul/li//force-hoverable-link//slot//*[contains(text(),'Assets')]");
	public static By quickfilter = By.xpath("(//button[@title='Show quick filters'])");
	public static By assetinput = By.xpath("(//label[text()='Asset Name']/following::input)[1]");
	public static By details = By.xpath("//span[text()='Details']");
	public static By billAccountNumber = By
			.xpath("//span[text()='CRM Billing Account Number']/parent::div/following-sibling::div/span/span");
	public static By related = By.xpath("//span[text()='Related']");
	public static By cases = By.xpath("(//div/h2/a/span[text()='Cases'])[1]");
	public static By newButton = By.xpath("//div[text()='Change Owner']/ancestor::ul/li/a/div[text()='New']");
	public static By subjectInput = By.xpath("(//label[text()='Subject']/following::input)[1]");
	// Case page
	public static By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	public static By resolutionInProg = By
			.xpath("//span[text()='Resolution In Progress'][@class='title slds-path__title']");
	public static By markCurrentStatus = By.xpath("//span[text()='Mark as Current Status']");
	public static By dropDown = By.xpath("(//i[@class='icon icon-v-menu2'])[1]");
	public static By reserverNumber = By.xpath("(//span[text()='Reserve Numbers']/parent::div)[1]");
	public static By validateCart = By.xpath("(//span[text()='Validate Cart'])[1]");
	public static By markasCurrentstatus = By.xpath(
			"//button[@type='button'][@class='slds-button slds-button--brand slds-path__mark-complete stepAction active uiButton']");
	// Transaction details verification
	public static By assetID = By.xpath("//span[.='Asset ID']/following::div[1]");
	public static By MINNumber = By.xpath("//span[.='MIN Number']/following::div[1]");
	public static By transactionStatus = By.xpath("//span[.='Transaction Status']/following::div[1]");
	public static By mininput = By.xpath("(//label[text()='MIN']/following::input[@name='Asset-MIN__c'])");
	public static String caseLink = null;
	public static String quoteLink = null;
	public static String orderLink = null;
	public static String masterOrderOrchestrationLink = null;

	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public static void changeMIN(Hashtable<String, String> data) {
		Login.asAdmin();
		Login.switchToRelationshipManager();
		goToAccounts();
		searchAndSelectAccount(data.get("accountName"));
		goToAccountAssets();
		selectAsset(data.get("MINNumber"), data.get("assetName"));
		getBillAccountNumber();
		goToCreateCase();
		createNewCase(data.get("accountName"), data.get("contactName"), billingAccountNumber, data.get("subject"),
				data.get("description"), data.get("lineOfBusiness"), data.get("typeOfCustomerRequest"),
				data.get("type"), data.get("highLevelTransactionClassification"), data.get("transactionType"),
				data.get("transactionSubType"), data.get("transactionReason"), data.get("product"),
				data.get("priority"), data.get("caseOrigin"), data.get("status"), data.get("transactionDescription"),
				data.get("numberOfLinesServices"), data.get("caseCancellationReason"), data.get("minForPortIn"),
				data.get("currentProvider"), data.get("recipientProvider"), data.get("otherOneTimeFee"),
				data.get("waiverOfMoveFee"), data.get("adjustmentAmount"), data.get("transactionEntry"),
				data.get("requestedCreditLimit"), data.get("period"), data.get("preferredBillingCurrency"),
				data.get("deliveryAddress"), data.get("preferredAddOn"),
				data.get("requiredAssetAndContractInformation"), data.get("invoiceNumber"), data.get("webEmail"),
				data.get("technicalInformation"), data.get("billingAccountName"));
		selectCase(data.get("subject"));
		verifyTransactionDetails(data.get("assetName"));
		markCaseStatus();
		reserveNumber();
		updateQuoteValidationPeriod();
		validateCart();
		changeQuoteStatustoAccepted();
		verifyOrderDetails();
		goToOrchestration();
		verifyOrchestrationStatus();
		ReferenceData();
	}

	public static void createNewCase(String accountNameValue, String contactNameValue, String billingAccountValue,
			String subjectValue, String descriptionValue, String lineOfBusinessValue, String typeOfCustomerRequestValue,
			String typeValue, String highLevelTransactionClassificationValue, String transactionTypeValue,
			String transactionSubTypeValue, String transactionReasonValue, String productValue, String priorityValue,
			String caseOriginValue, String statusValue, String transactionDescriptionValue,
			String numberOfLinesServicesValue, String caseCancellationReasonValue, String minForPortInValue,
			String currentProviderValue, String recipientProviderValue, String otherOneTimeFeeValue,
			String waiverOfMoveFeeValue, String adjustmentAmountValue, String transactionEntryValue,
			String requestedCreditLimitValue, String periodValue, String preferredBillingCurrencyValue,
			String deliveryAddressValue, String preferredAddOnValue, String requiredAssetAndContractInformationValue,
			String invoiceNumberValue, String webEmailValue, String technicalInformationValue,
			String billingAccountName) {
		CaseCreation.enter_billingAccount(billingAccountValue);
		CaseCreation.enter_subject(subjectValue);
		CaseCreation.select_lineOfBusiness(lineOfBusinessValue);
		CaseCreation.select_typeOfCustomerRequest(typeOfCustomerRequestValue);
		CaseCreation.select_type(typeValue);
		CaseCreation.select_highLevelTransactionClassification(highLevelTransactionClassificationValue);
		CaseCreation.select_transactionType(transactionTypeValue);
		CaseCreation.select_transactionSubType(transactionSubTypeValue);
		CaseCreation.click_availableDocuments();
		CaseCreation.click_moveAvailableDocuments();
		CaseCreation.click_save();
		String casenotifi = CommonSteps.getIDFromNotificationText();
		TestBase.test.log(LogStatus.INFO, "CaseID: "+casenotifi);
		System.out.println(casenotifi);
	}

	public static void goToAccounts() {
		try {
			tb.clickUsingJs(appLauncher);
			tb.clickUsingJs(appSearch);
			tb.typeDataTo(appSearch, "Accounts");
			tb.clickDropdownValue("Accounts");
			TestBase.test.log(LogStatus.PASS, "Navigated to Account search page");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Navigated to Account search page");
		}
	}

	public static void searchAndSelectAccount(String acountNameValue) {
		try { 
			tb.clickUsingJs(filter);
			tb.clickDropdownValue("All Accounts - Business Accounts");
			tb.typeDataTo(searchList, acountNameValue);
			tb.waitFor(By.xpath("//table[1]"), 5, true);
			tb.enterKey();
			String path = "//a[text()=" + "'" + acountNameValue + "'" + "]";
			System.out.println(path);
			tb.clickUsingJs(By.xpath(path));
			TestBase.test.log(LogStatus.PASS, "Specific Acount is selected");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Specific Acount is selected");
		}
	}

	public static void goToAccountAssets() {
		try {
			
			tb.clickOnElementUsingActions(showAll);
			tb.clickUsingJs(asset);
			TestBase.test.log(LogStatus.PASS, "Clicked on Assets in Account Page");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked on Assets in Account Page");
		}
	}

	public static void selectAsset(String minValue, String assetNameValue) {
		try {
			tb.clickUsingJs(quickfilter);
			tb.clickUsingJs(assetinput);
			tb.typeDataTo(assetinput, assetNameValue);
			tb.clickUsingJs(mininput);
			tb.typeDataTo(mininput, minValue);
			tb.enterKey();
			String pat = "//a[text()=" + "'" + assetNameValue + "'" + "]";
			tb.clickUsingJs(By.xpath(pat));
			TestBase.test.log(LogStatus.PASS, "Searched for an Specific Asset");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Searched for an Specific Asset");
		}
	}

	public static void getBillAccountNumber() {
		try {
			tb.clickUsingJs(details);
			billingAccountNumber = TestBase.driver.findElement(billAccountNumber).getText();
			System.out.println(billingAccountNumber);
			tb.clickUsingJs(related);
			TestBase.test.log(LogStatus.PASS, "Copyied Billing Account Number");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Copyied Billing Account Number");
		}
	}

	public static void goToCreateCase() {
		try {
			tb.clickUsingJs(cases);
			tb.clickUsingJs(newButton);
			tb.clickUsingJs(By.xpath("//*[text()='SMART Service Request']"));
			tb.clickUsingJs(By.xpath("//span[.='Next']"));
			TestBase.test.log(LogStatus.PASS, "Created new Case");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Created new Case");
		}
	}

	public static void selectCase(String subjectValue) {
		try {
			tb.clickUsingJs(quickfilter);
			tb.clickUsingJs(subjectInput);
			tb.typeDataTo(subjectInput, subjectValue);
			tb.enterKey();
			String Cat = "//a[text()=" + "'" + subjectValue + "'" + "]";
			CommonSteps.openLink(By.xpath(Cat));
			TestBase.test.log(LogStatus.PASS, "Case is selected");
			CommonSteps.waitForCasePage();
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Case is selected");
		}
	}

	public static boolean verifyTransactionDetails(String assetValue) {
		caseLink = TestBase.driver.getCurrentUrl();
		tb.clickUsingJs(transactionDetails);
		System.out.println(tb.getTextFromPage(assetID));
		System.out.println(tb.getTextFromPage(MINNumber));
		System.out.println(tb.getTextFromPage(transactionStatus));
		ArrayList<Boolean> check = new ArrayList<>();
		if (tb.isElementDisplayed(assetID) && tb.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		check.add(tb.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			TestBase.test.log(LogStatus.FAIL, "Transaction details are not populated correctly");
			return false;
		}
		TestBase.test.log(LogStatus.PASS, "Transaction details are verified");
		return true;
	}

	public static void markCaseStatus() {
		try {
			CommonSteps.markCaseStatus(resolutionInProg);
			tb.clickUsingJs(markCurrentStatus);
			tb.waitFor(8);
			tb.refreshPage();
			TestBase.test.log(LogStatus.PASS, "Changed the case Status to Resolution in Progress");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Changed the case Status to Resolution in Progress");
		}
	}

	public static void reserveNumber() {
		try {
			System.out.println("Click on Number Reservation..");
			CommonSteps.switchToActionFrame();
			CommonSteps.clickOnVlocityActionbutton(dropDown, reserverNumber);
			CommonSteps.refreshSwitchToFrame();
			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty("NumberPatternSearch_XPATH")));
			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty("nextButton_XPATH")));
			tb.ExplicitWait("SearchMIN_XPATH");
			tb.select("NumberType_XPATH", "Regular");
			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty("SearchMIN_XPATH")));
			tb.clickUsingJs(By.xpath("(//th/button)[1]"));
			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty("NumberAvailabilityNextBtn_XPATH")));
			tb.clickUsingJs(By.xpath("(//p[text()='Next'])[3]"));
			tb.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
			tb.waitFor(By.xpath("//span[text()='QuoteActionToolbar']"), 10, true);
			TestBase.test.log(LogStatus.PASS, "Number Reservation is done");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Number Reservation is done");
		}
	}

	public static void updateQuoteValidationPeriod() {
		try {
			tb.refreshPage();
			quoteLink = TestBase.driver.getCurrentUrl();
			tb.ExplicitWait("QuoteNumber_XPATH");
			tb.ThreadWait(1000);
			tb.scroll(300, 400);
			tb.waitFor(By.xpath(TestBase.OR.getProperty("ScrollTillContract_XPATH")), 20, true);
			tb.Scroll("ScrollTillContract_XPATH");
			tb.jsClick("EditQuoteValidityPeriod_XPATH");
			tb.ThreadWait(1000);
			tb.type("InputQuoteday_XPATH", "30");
			tb.ThreadWait(1000);
			tb.Scroll("InputQuoteday_XPATH");
			System.out.println("clickOnSAVE");
			tb.retryClick("save_XPATH");
			tb.ExplicitWait("QuoteNumber_XPATH");
			tb.ThreadWait(2000);
			TestBase.test.log(LogStatus.PASS, "Updated Quote Validation Period");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Updated Quote Validation Period");
		}
	}

	public static void validateCart() {
		try {

			CommonSteps.switchToActionFrame();
			CommonSteps.clickOnVlocityActionbutton(dropDown, validateCart);
			CommonSteps.refreshSwitchToFrame();

			tb.waitFor(By.xpath("//p[text()='Go to Quote']"), 10, true);
			tb.clickUsingJs(By.xpath("//p[text()='Go to Quote']"));
			CommonSteps.waitForQuotePage();
			TestBase.test.log(LogStatus.PASS, "Validated Cart");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Validated Cart");
		}
	}

	public static void changeQuoteStatustoAccepted() {
		try {
			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty("AcceptedStage_XPATH")));
			tb.clickUsingJs(markasCurrentstatus);
			tb.waitFor(5);
			System.out.println("Move Quote to Accepted status...");
			System.out.println("\n=====================\n");
			TestBase.test.log(LogStatus.PASS, "Changed the quote status to Accepted");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Changed the quote status to Accepted");
		}
	}

	public static void verifyOrderDetails() {
		try {
			String OrderNumber = null;
			OrderNumber = coa.clickOnOrdersTitle();
			coa.clickOnOrderLink(OrderNumber);
			TestBase.test.log(LogStatus.PASS, "Order details are verified");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Order details are verified");
		}
	}

	public static void goToOrchestration() {
		try {
			orderLink = TestBase.driver.getCurrentUrl();
			coa.clickOnViewDecomposition();
			coa.clickOnViewOrchestrationPlan();
			CommonSteps.switchWindow();
			Thread.sleep(4000);
			TestBase.test.log(LogStatus.PASS, "Opened Orchestration Plan");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Opened Orchestration Plan");
		}
	}

	public static void verifyOrchestrationStatus() {
		masterOrderOrchestrationLink = TestBase.driver.getCurrentUrl();
		CommonSteps.waitForOrchestrationPage();
		CommonSteps.refreshSwitchToFrame();
		CommonSteps.verifyOSPhase("uSPS Activation");
		CommonSteps.verifyOSPhase("uSPS Confirmation");
		CommonSteps.verifyOSPhase("Billing Activation");
		CommonSteps.verifyOSPhase("Kenan Confirmation");
	}

	public static void ReferenceData() {
		TestBase.test.log(LogStatus.INFO, "Case Link -> ", "<a " + "href=" + caseLink + ">" + "caseLink" + "</a>");
		TestBase.test.log(LogStatus.INFO, "Quote Link -> ", "<a " + "href=" + quoteLink + ">" + "quoteLink" + "</a>");
		TestBase.test.log(LogStatus.INFO, "Order Link -> ", "<a " + "href=" + orderLink + ">" + "orderLink" + "</a>");
		TestBase.test.log(LogStatus.INFO, "Master Order OrchestrationLink -> ",
				"<a " + "href=" + masterOrderOrchestrationLink + ">" + "masterOrderOrchestrationLink" + "</a>");
	}
}
