package com.smart.testcases;

import java.util.Hashtable;

import org.testng.SkipException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.smart.common.Login;

import base.TestBase;
import pages.ContactPage;
import utilities.ExcelManager;
import utilities.Excel_DP;
import utilities.RunMode;

public class CreateContactTest extends TestBase {
	TestBase tb = new TestBase();


	@SuppressWarnings("static-access")
	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public void NewCreateContact(Hashtable<String, String> data) {

		String Salutation = data.get("Salutation");
		String firstName = data.get("firstName");
		String middleName = data.get("middleName");
		String lastName = data.get("lastName");
		String Suffix = data.get("Suffix");
		String Account = data.get("Account");
		String Role = data.get("Role");
		String Phone = data.get("Phone");
		String Mobile = data.get("Mobile");
		String Email = data.get("Email");


    //  Login.asAdmin();
		//SoftAssert softAssert = new SoftAssert();
		if (Role.contains("Authorized Signatory")) {
			Login.switchToCreditAnalyst();

		} else {
			Login.switchToRelationshipManager();

		}
		tb.driver.get(
				"https://pldtoneenterprise--r32sit.lightning.force.com/lightning/o/Contact/list?filterName=Recent");
		ContactPage.clickOnNewContactButton();
		ContactPage.fillContactForm(Salutation, firstName, middleName, lastName, Suffix, Account, Role, Phone, Mobile,
				Email);
		Login.logOutCurrentUser();
		//Login.logOutAsAdmin();
		//softAssert.assertAll();
	}
}
