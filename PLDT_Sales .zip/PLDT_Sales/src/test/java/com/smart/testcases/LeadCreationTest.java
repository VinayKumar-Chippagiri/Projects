package com.smart.testcases;

import java.util.Hashtable;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.smart.common.Login;

import base.TestBase;
import pageAction.LeadCreationAction;
import testcases.HomePageTest;
import testcases.LeadConversionTest;
import pageAction.CommonSteps;
import utilities.ExcelManager;
import utilities.Excel_DP;
import utilities.RunMode;

public class LeadCreationTest extends TestBase {
	LeadCreationAction leadCreationAction = new LeadCreationAction();
	TestBase tb = new TestBase();
	HomePageTest hpt = new HomePageTest();
	LeadConversionTest leadConversionTest = new LeadConversionTest();
	public static String company;
	public static boolean firstLogin = false;

	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public void NewLeadCreate(Hashtable<String, String> data) {
		try {
			System.out.println(data.get("salutation"));
			Login.asAdmin();
			Login.switchToRelationshipManager();
			leadCreationAction.clickOnAppLauncher();
			leadCreationAction.enterValueOnAppSearch();
			leadCreationAction.clickOnNewLeadButton();
			leadCreationAction.selectNewLeadType();
			CommonSteps.click_on_Next();
			leadCreationAction.fillTheLeadForm(data.get("salutation"),data.get("firstName"),data.get("middleName"),data.get("lastName"),data.get("suffix"),data.get("title"),data.get("leadRole"),data.get("leadStatus"),data.get("notQualifiedReason"),data.get("leadSource"),data.get("other"),data.get("description"),data.get("leadType"),data.get("annualRevenue"),data.get("productInterest"),data.get("leadProductOfInterest"),data.get("rfsDate"),data.get("rtsReasons"),data.get("callBackDate"),data.get("minForPortIn"),data.get("currentProvider"),data.get("offerPackage"),data.get("phone"),data.get("mobile"),data.get("birthdate"),data.get("email"),data.get("address"),data.get("country"),data.get("street"),data.get("city"),data.get("state"),data.get("zipCode"),data.get("company"),data.get("companyTradeName"),data.get("companySize"),data.get("businessType"),data.get("businessRegistrationType"),data.get("companyTin"),data.get("industry"),data.get("subIndustry"),data.get("businessRegistrationNumber"),data.get("otherBusinessRegistrationType"),data.get("website"),data.get("deadlineOfSubmission"),data.get("lob"),data.get("event"),data.get("accountClass"));
			leadCreationAction.markLeadStatusAsQualified();
			tb.waitFor(5);
			Login.logOutCurrentUser();
			Login.switchToCreditAnalyst();
			leadCreationAction.clickOnAppLauncher();
			leadCreationAction.enterValueOnAppSearch();
			tb.waitFor(5);
			leadCreationAction.searchAndOpenLeadProfile(data.get("firstName"), data.get("middleName"), data.get("lastName"), data.get("suffix"));
			leadCreationAction.validateCreditCheck();
			leadCreationAction.convertLead();
			Login.logOutCurrentUser();
			tb.waitFor(2);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
