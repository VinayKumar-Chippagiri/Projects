package com.smart.testcases;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Hashtable;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.smart.common.CaseCreation;
import com.smart.common.Login;
import pages.FeaturesPage;
import pages.Retention;
import utilities.ExcelManager;

public class FeatureTest extends FeaturesPage {

	Retention rt = new Retention();
	FeaturesPage fp = new FeaturesPage();

	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public void features(Hashtable<String, String> data) throws Exception {

		Login.asAdmin();
		
		  Login.switchToRelationshipManager();
//		  com.smart.common.CommonSteps.switchAndOpenAccount(data.get("accountName"),"Business Account"); 
		//  rt.pathForCaseCreationRetention(data.get("accountName"),data.get("Min Num"), data.get("AssetID"));
		  goToAccounts();
		  searchAndSelectAccount(data.get("accountName"));
		  goToAccountAssets();
		  selectAsset(data.get("Min Num"), data.get("AssetID"));
		  goToCreateCase();
		  CaseCreation.createCaseFeature(data.get("billingAccount"),
		  data.get("billingAccountName"), data.get("subject"), data.get("type"),
		  data.get("caseOrigin"), data.get("highLevelTransactionClassification"),
		  data.get("transactionType")); Login.logOutCurrentUser();
		  Login.switchToAnyUser("Marjorie Legion"); 
		  fp.acceptCase(data.get("subject"));
		  
		 		
		String caseOrigin = data.get("caseOrigin");
		if (caseOrigin.equalsIgnoreCase("Bulk")) {		
			fp.setCaseID(null);
			ExcelManager.UpdateCaseIDInCSVFile(data.get("location"), fp.getCaseID());
			fp.bulk(data.get("location"));
		} else {
			fp.caseModification(data.get("remarkValue"), data.get("FeaturesAvailable"));
		}
		fp.verifyTransactionAsset();
		fp.featureAction(data.get("transactionType"));
		fp.verifyOrder();
		fp.selectMaster();

	}
}
