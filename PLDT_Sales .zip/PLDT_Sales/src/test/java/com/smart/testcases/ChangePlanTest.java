package com.smart.testcases;

import java.util.Hashtable;

import org.testng.annotations.Test;

import com.smart.common.CaseCreation;
import com.smart.common.Login;


import pageAction.CommonSteps;
import pageAction.OpportunityCreationAction;
import pages.ChangePlan;
import pages.Retention;
import utilities.ExcelManager;

public class ChangePlanTest extends ChangePlan {

	ChangePlan chplan = new ChangePlan();
	Retention rt = new Retention();
	OpportunityCreationTest oppCreatTest = new OpportunityCreationTest();
	OpportunityCreationAction oppcrtaction = new OpportunityCreationAction();

	String QuoteURL = null;

	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public void changeplan(Hashtable<String, String> data) {

		try {
			Login.asAdmin();
			Login.switchToRelationshipManager();
			CommonSteps.switchAndOpenAccount(data.get("accountName"), "Business Account");
			rt.pathForCaseCreationRetention(data.get("accountName"), data.get("Min Num"), data.get("AssetID"));
			CaseCreation.createCaseRetention(data.get("billingAccount"), data.get("billingAccountName"),
					data.get("subject"), data.get("type"), data.get("highLevelTransactionClassification"),
					data.get("transactionType"), data.get("transactionSubType"));
			rt.findNewlyCreatedCase(data.get("subject"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		// step 2 : we will modify case

		try {
			chplan.caseModificationChangePlan(data.get("remarkValue"), data.get("OfferMigrationType"));
			chplan.changePlan(data.get("Plan"));
		} catch (Exception e) {
			e.printStackTrace();
		}


//		// step 4 Device Validity
		try {
			rt.validateCart();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// step5 update necessary details in Quote page
		try {
			rt.rtnUpdateQuoteValidationPeriod();
			rt.updateContact(data.get("Authorized Signatory"), data.get("Bill Recipient"),
					data.get("Delivery Recipient"));
			chplan.EBIT(data.get("EBIT"));
			rt.QuoteDeliveryDate(data.get("Delivery Date"));

		} catch (Exception e) {
			e.printStackTrace();
		}

		// in case reload require
		try {
			boolean flag = rt.reload();
			if (flag) {
				rt.clickOnReload();
				rt.rtnUpdateQuoteValidationPeriod();
				rt.updateContact(data.get("Authorized Signatory"), data.get("Bill Recipient"),
						data.get("Delivery Recipient"));
				chplan.EBIT(data.get("EBIT"));
				rt.QuoteDeliveryDate(data.get("Delivery Date"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		// step6 credit check using credit analyst

		String type = data.get("ChangePlan");
		if (type.equalsIgnoreCase("Upgrade")) {

			try {
				QuoteURL = rt.getQuoteURL();
				Login.logOutCurrentUser();
				Login.switchToCreditAnalyst();
				rt.navigateURL(QuoteURL);
				rt.creditcheck(data.get("Credit Check NewStatus"), data.get("Credit Check Condition"),
						data.get("Credit Check Remark"));
				Login.logOutCurrentUser();
				Login.switchToRelationshipManager();
				rt.navigateURL(QuoteURL);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		// step 7 ChangeStatustoCustomerApproved
		try {
			rt.ChangeStatustoCustomerApproved();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// step8 ChangeStatustoAccepted
		try {
			rt.ChangeStatustoAccepted();
		} catch (Exception e) {
			e.printStackTrace();
		}

		// step9 create contract
		try {
			rt.CreateContract();
			rt.order();
			rt.masterOrderStatus();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
