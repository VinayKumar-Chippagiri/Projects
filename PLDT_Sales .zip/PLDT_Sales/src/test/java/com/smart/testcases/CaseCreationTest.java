package com.smart.testcases;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.smart.common.CaseCreation;
import com.smart.common.Login;

import base.TestBase;
import pageAction.CommonSteps;
import utilities.ExcelManager;

public class CaseCreationTest extends TestBase {
	TestBase tb = new TestBase();

	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public void newCaseCreation(Hashtable<String, String> data) {
		Login.asAdmin();
		Login.switchToRelationshipManager();
		tb.driver.get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/o/Case/list?filterName=Recent");
		tb.clickOn(By.xpath("//div[.='New']"));
		tb.clickOn(By.xpath("//*[text()='SMART Service Request']"));
		tb.clickOn(By.xpath("//span[.='Next']"));
		CaseCreation.createCase(data.get("accountName"), data.get("contactName"), data.get("billingAccount"),data.get("consigneeName"),
				data.get("subject"), data.get("description"), data.get("lineOfBusiness"),
				data.get("typeOfCustomerRequest"), data.get("type"), data.get("highLevelTransactionClassification"),
				data.get("transactionType"), data.get("transactionSubType"), data.get("transactionReason"),
				data.get("product"), data.get("priority"), data.get("caseOrigin"), data.get("status"),
				data.get("transactionDescription"), data.get("numberOfLinesServices"),
				data.get("caseCancellationReason"), data.get("minForPortIn"), data.get("currentProvider"),
				data.get("recipientProvider"), data.get("otherOneTimeFee"), data.get("waiverOfMoveFee"),
				data.get("adjustmentAmount"), data.get("transactionEntry"), data.get("requestedCreditLimit"),
				data.get("period"), data.get("preferredBillingCurrency"), data.get("deliveryAddress"),
				data.get("preferredAddOn"), data.get("requiredAssetAndContractInformation"), data.get("invoiceNumber"),
				data.get("webEmail"), data.get("technicalInformation"));
		CommonSteps.waitTillLoaderDissapear();
		System.out.println(CommonSteps.getIDFromNotificationText());
	}
}
