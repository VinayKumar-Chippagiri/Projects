package com.smart.testcases;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.relevantcodes.extentreports.LogStatus;
import com.smart.common.CaseCreation;
import com.smart.common.Login;

import base.ProjectBeans;
import base.TestBase;
import junit.framework.Assert;
import pageAction.CommonSteps;
import pageAction.CreateOrderAction;
import utilities.ExcelManager;

public class PD_TD_RES_Test extends TestBase {
	static String billingAccountNumber = null;
	static String caseURL = null;
	static String caseID = null;
	static TestBase tb = new TestBase();
	static CreateOrderAction coa = new CreateOrderAction();
	private static By appLauncher = By.xpath("//*[@aria-label=\"App\"]/one-app-launcher-header/button/div");
	private static By appSearch = By.xpath("//input[@placeholder=\"Search apps and items...\"]");
	private static By filter = By.xpath("(//*[text()='Select List View'])/parent::*");
	private static By searchList = By.xpath("//input[@placeholder='Search this list...']");
	private static By showAll = By.xpath("//ul/following-sibling::div/a[contains(text(),'Show All')]");
	private static By asset = By.xpath("//ul/li//force-hoverable-link//slot//*[contains(text(),'Assets')]");
	private static By quickfilter = By.xpath("(//button[@title='Show quick filters'])");
	private static By assetinput = By.xpath("(//label[text()='Asset Name']/following::input)[1]");
	private static By details = By.xpath("//span[text()='Details']");
	private static By billAccountNumber = By
			.xpath("//span[text()='CRM Billing Account Number']/parent::div/following-sibling::div/span/span");
	private static By related = By.xpath("//span[text()='Related']");
	private static By cases = By.xpath("(//div/h2/a/span[text()='Cases'])[1]");// correction needed
	private static By newButton = By.xpath("//div[text()='Change Owner']/ancestor::ul/li/a/div[text()='New']");/// correction
	private static By subjectInput = By.xpath("(//label[text()='Subject']/following::input)[1]");
	// Case page
	private static By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	private static By editButton = By.xpath("//button[text()='Edit'][@class='slds-button slds-button_brand']");
	private static By highLevelDisconnection = By.xpath(
			"(//label[text()='High Level Disconnection Reason']/following::input[@name='High_Level_Disconnection_Reason__c'])");
	private static By saveRecord = By.xpath("//button[@class='slds-button slds-button_brand'][@type='submit']");
	private static By resolutionInProg = By
			.xpath("//span[text()='Resolution In Progress'][@class='title slds-path__title']");
	private static By markCurrentStatus = By.xpath("//span[text()='Mark as Current Status']");
	private static By transactionAsset = By.xpath("(//span[text()='Transaction Asset'])[1]/following-sibling::span");
	private static By relatedSection = By.xpath("(//flexipage-record-home-scrollable-column)[3]");
	private static By dropDown = By.xpath("(//i[@class='icon icon-v-menu2'])[1]");
	private static By disconnect = By.xpath("(//span[text()='Disconnect'])[1]");
	private static By suspend = By.xpath("(//span[text()='Suspend'])[1]");
	private static By doneButton = By.xpath("//p[.='Done']");
	// Transaction details verification
	private static By assetID = By.xpath("//span[.='Asset ID']/following::div[1]");
	private static By MINNumber = By.xpath("//span[.='MIN Number']/following::div[1]");
	private static By mininput = By.xpath("(//label[text()='MIN']/following::input[@name='Asset-MIN__c'])");
	private static By applyButton = By.xpath("//button[@class='slds-button slds-button_brand'][text()='Apply']");
	private static By resume = By.xpath("(//span[text()='Resume'])[1]");
	private static By servicereq = By.xpath("//input[@class='slds-input slds-combobox__input']");
	private static String caseLink = null;
	// private static String quoteLink=null;
	private static String orderLink = null;
	private static String masterOrderOrchestrationLink = null;


	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public static void pd_td_Resume(Hashtable<String, String> data) throws FilloException, FileNotFoundException, IOException {

		Login.asAdmin();
		Login.switchToRelationshipManager();
		tb.driver.navigate().to("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Asset/02i1s000005M8zeAAC/view");
		//goToAccounts();
		//searchAndSelectAccount(data.get("accountName"));
		//goToAccountAssets();
		//selectAsset(data.get("MINNumber"), data.get("assetName"));
		getBillAccountNumber();
		goToCreateCase();
		createNewCase(data.get("accountName"), data.get("contactName"), billingAccountNumber, data.get("subject"),
				data.get("description"), data.get("lineOfBusiness"), data.get("typeOfCustomerRequest"),
				data.get("type"), data.get("highLevelTransactionClassification"), data.get("transactionType"),
				data.get("transactionSubType"), data.get("transactionReason"), data.get("product"),
				data.get("priority"), data.get("caseOrigin"), data.get("status"), data.get("transactionDescription"),
				data.get("numberOfLinesServices"), data.get("caseCancellationReason"), data.get("minForPortIn"),
				data.get("currentProvider"), data.get("recipientProvider"), data.get("otherOneTimeFee"),
				data.get("waiverOfMoveFee"), data.get("adjustmentAmount"), data.get("transactionEntry"),
				data.get("requestedCreditLimit"), data.get("period"), data.get("preferredBillingCurrency"),
				data.get("deliveryAddress"), data.get("preferredAddOn"),
				data.get("requiredAssetAndContractInformation"), data.get("invoiceNumber"), data.get("webEmail"),
				data.get("technicalInformation"), data.get("billingAccountName"));
		selectCase(data.get("subject"));
		loginAsEFSAMOfficer();
		if(!data.get("caseOrigin").equalsIgnoreCase("bulk"))
		{
			verifyTransactionDetails(data.get("assetName"), data.get("transactionReasonOrRequest"),
					data.get("transactionType"));
		}
		
		if(data.get("caseOrigin").equalsIgnoreCase("bulk"))
		{   
			ExcelManager.updateCSV(ProjectBeans.getCaseID());
			CommonSteps.bulkUpload(caseURL);
		}
		markCaseStatus();
		verifyTransactionAsset();
		transactionAction(data.get("transactionType"));
		verifyOrderDetails();
		selectSubOrder();
		goToOrchestration();
		verifyOrchestrationStatus();
		ReferenceData();
	}

	public static void createNewCase(String accountNameValue, String contactNameValue, String billingAccountValue,
			String subjectValue, String descriptionValue, String lineOfBusinessValue, String typeOfCustomerRequestValue,
			String typeValue, String highLevelTransactionClassificationValue, String transactionTypeValue,
			String transactionSubTypeValue, String transactionReasonValue, String productValue, String priorityValue,
			String caseOriginValue, String statusValue, String transactionDescriptionValue,
			String numberOfLinesServicesValue, String caseCancellationReasonValue, String minForPortInValue,
			String currentProviderValue, String recipientProviderValue, String otherOneTimeFeeValue,
			String waiverOfMoveFeeValue, String adjustmentAmountValue, String transactionEntryValue,
			String requestedCreditLimitValue, String periodValue, String preferredBillingCurrencyValue,
			String deliveryAddressValue, String preferredAddOnValue, String requiredAssetAndContractInformationValue,
			String invoiceNumberValue, String webEmailValue, String technicalInformationValue,
			String billingAccountName) {
		CaseCreation.enter_billingAccount(billingAccountValue);
		CaseCreation.enter_subject(subjectValue);
		CaseCreation.select_lineOfBusiness(lineOfBusinessValue);
		CaseCreation.select_typeOfCustomerRequest(typeOfCustomerRequestValue);
		CaseCreation.select_type(typeValue);
		if (caseOriginValue.equalsIgnoreCase("Bulk")) {
			CaseCreation.select_caseOrigin(caseOriginValue);
		}
		CaseCreation.select_highLevelTransactionClassification(highLevelTransactionClassificationValue);
		CaseCreation.select_transactionType(transactionTypeValue);
		if (!transactionTypeValue.contains("Reconnection")) {
			CaseCreation.select_transactionSubType(transactionSubTypeValue);
		}
		CaseCreation.click_availableDocuments();
		CaseCreation.click_moveAvailableDocuments();
		CaseCreation.click_save();
		caseID = CommonSteps.getIDFromNotificationText();
		ProjectBeans.setCaseID(caseID);
		System.out.println(caseID);
	}

	private static void goToAccounts() {
		try {
			tb.clickUsingJs(appLauncher);
			tb.clickUsingJs(appSearch);
			tb.typeDataTo(appSearch, "Accounts");
			tb.enterKey();
			TestBase.test.log(LogStatus.PASS, "Navigated to Account search page");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Navigated to Account search page");
		}
	}

	private static void searchAndSelectAccount(String acountNameValue) {
		try {
			tb.clickUsingJs(filter);
			tb.clickDropdownValue("All Accounts - Business Accounts");
			tb.typeDataTo(searchList, acountNameValue);
			tb.enterKey();
			String path = "//a[text()=" + "'" + acountNameValue + "'" + "]";
			System.out.println(path);
			tb.clickUsingJs(By.xpath(path));
			TestBase.test.log(LogStatus.PASS, "Specific Acount is selected");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Specific Acount is selected");
		}
	}

	private static void goToAccountAssets() {
		try {
			tb.clickOnElementUsingActions(showAll);
			tb.clickUsingJs(asset);
			TestBase.test.log(LogStatus.PASS, "Clicked on Assets in Account Page");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked on Assets in Account Page");
		}
	}

	private static void selectAsset(String minValue, String assetNameValue) {
		try {
			tb.clickUsingJs(quickfilter);
			tb.clickUsingJs(assetinput);
			tb.enterData(assetinput, assetNameValue);
			tb.clickUsingJs(mininput);
			tb.enterData(mininput, minValue);
			tb.enterKey();
			String pat = "//a[text()=" + "'" + assetNameValue + "'" + "]";
			tb.clickUsingJs(By.xpath(pat));
			TestBase.test.log(LogStatus.PASS, "Searched for an Specific Asset");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Searched for an Specific Asset");
		}
	}

	private static void getBillAccountNumber() {
		try {
			tb.clickUsingJs(details);
			billingAccountNumber = TestBase.driver.findElement(billAccountNumber).getText();
			System.out.println(billingAccountNumber);
			tb.clickUsingJs(related);
			// tb.clickUsingJs(cases);
			TestBase.test.log(LogStatus.PASS, "Copyied Billing Account Number");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Copyied Billing Account Number");
		}
	}

	public static void goToCreateCase() {
		try {
			tb.clickUsingJs(cases);
			tb.clickUsingJs(newButton);
			tb.clickUsingJs(By.xpath("//*[text()='SMART Service Request']"));
			tb.clickUsingJs(By.xpath("//span[.='Next']"));
			TestBase.test.log(LogStatus.PASS, "Created new Case");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Created new Case");
		}
	}

	private static void selectCase(String subjectValue) {
		try {
			tb.clickUsingJs(quickfilter);
			tb.clickUsingJs(subjectInput);
			tb.enterData(subjectInput, subjectValue);
			tb.enterKey();
			String Cat = "//a[text()=" + "'" + subjectValue + "'" + "]";
			CommonSteps.openLink(By.xpath(Cat));
			caseURL = TestBase.driver.getCurrentUrl();
			TestBase.test.log(LogStatus.PASS, "Case is selected");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Case is selected");
		}
	}

	private static boolean verifyTransactionDetails(String assetValue, String transactionReasonValue,
			String transactiontype) {
		caseLink = TestBase.driver.getCurrentUrl();
		tb.clickUsingJs(transactionDetails);
		tb.clickUsingJs(editButton);
		if (transactiontype.contains("Reconnection")) {
			tb.clickUsingJs(servicereq);
		} else {
			tb.clickUsingJs(highLevelDisconnection);
		}
		tb.clickDropdownValue(transactionReasonValue);
		tb.clickUsingJs(saveRecord);
		ArrayList<Boolean> check = new ArrayList<>();
		if (tb.isElementDisplayed(assetID) && tb.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		check.add(tb.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			TestBase.test.log(LogStatus.FAIL, "Transaction details are not populated correctly");
			return false;
		}
		TestBase.test.log(LogStatus.PASS, "Transaction details are verified");
		return true;
	}
	
	
	

	private static void loginAsEFSAMOfficer() {
		Login.logOutCurrentUser();
		Login.switchToAnyUser("Edgar, Jr. Antonio");
		tb.navigateURL(caseURL);
	}

	private static void markCaseStatus() {
		try {
			CommonSteps.markCaseStatus(resolutionInProg);
			tb.clickUsingJs(markCurrentStatus);
			tb.waitFor(5);
			tb.refreshPage();
			CommonSteps.waitForCasePage();
			TestBase.test.log(LogStatus.PASS, "Changed the case Status to Resolution in Progress");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Changed the case Status to Resolution in Progress");
		}
	}

	private static void verifyTransactionAsset() {
		js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scroll(0,2500)", TestBase.driver.findElement(relatedSection));
		if (!tb.getTextFromPage(transactionAsset).equals("(0)")) {
			System.out.println("pass");
		}
	}

	private static void transactionAction(String transactionType) {
		try {
			System.out.println("Click on Disconnection..");
			tb.refreshPage();
			CommonSteps.switchToActionFrame();
			tb.clickUsingJs(dropDown);
			if (transactionType.contains("Termination")) {
				tb.clickUsingJs(disconnect);
			} else {
				if (transactionType.contains("Reconnection")) {
					tb.clickUsingJs(resume);
				} else {
					if (transactionType.contains("Temporary"))
						tb.clickUsingJs(suspend);
				}
			}
			tb.waitFor(5);
			tb.refreshPage();
			CommonSteps.refreshSwitchToFrame();
			tb.clickUsingJs(doneButton);
			CommonSteps.waitForCasePage();
			TestBase.test.log(LogStatus.PASS, "Disconnection is done");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Disconnection is done");
		}
	}

	private static void verifyOrderDetails() {
		try {
			CommonSteps.goToCaseOrdersSearchPage(caseURL);
			CommonSteps.refreshOrders(60, 2);
			TestBase.test.log(LogStatus.PASS, "Order details are verified");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Order details are verified");
		}
	}

	private static void selectSubOrder() {
		try {
			CommonSteps.goToCaseOrdersSearchPage(caseURL);
			tb.clickUsingJs(quickfilter);
			tb.enterValueUsingJs(By.xpath("//input[@name='Order-TotalAmount-min']"), "1");
			tb.enterValueUsingJs(By.xpath("//input[@name='Order-TotalAmount-max']"), "");
			tb.clickUsingJs(applyButton);
			tb.waitFor(By.xpath("//td[4]/span/span[text()='PHP 0.000']"), 5, false);
			tb.clickUsingJs(By.xpath("//th/span/a"));
			TestBase.test.log(LogStatus.PASS, "Sub order is selected");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Sub order is selected");
		}
	}

	private static void goToOrchestration() {
		try {
			orderLink = TestBase.driver.getCurrentUrl();
			coa.clickOnViewDecomposition();
			coa.clickOnViewOrchestrationPlan();
			CommonSteps.switchWindow();
			Thread.sleep(4000);
			TestBase.test.log(LogStatus.PASS, "Opened Orchestration Plan");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Opened Orchestration Plan");
		}
	}

	private static void verifyOrchestrationStatus() {
		masterOrderOrchestrationLink = TestBase.driver.getCurrentUrl();
		CommonSteps.waitForOrchestrationPage();
		CommonSteps.refreshSwitchToFrame();
		CommonSteps.verifyOSPhase("uSPS Activation");
		CommonSteps.verifyOSPhase("uSPS Confirmation");
		CommonSteps.verifyOSPhase("Billing Activation");
		CommonSteps.verifyOSPhase("Kenan Confirmation");
	}

	private static void ReferenceData() {
		TestBase.test.log(LogStatus.INFO, "Case Link -> ", "<a " + "href=" + caseLink + ">" + "caseLink" + "</a>");
		TestBase.test.log(LogStatus.INFO, "Order Link -> ", "<a " + "href=" + orderLink + ">" + "orderLink" + "</a>");
		TestBase.test.log(LogStatus.INFO, "Master Order OrchestrationLink -> ",
				"<a " + "href=" + masterOrderOrchestrationLink + ">" + "masterOrderOrchestrationLink" + "</a>");
	}
}
