package com.smart.testcases;

import java.util.Hashtable;

import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.smart.testcases.LeadCreationTest;

import base.TestBase;
import testcases.CreateContractTest;
import testcases.CreateOrderTest;
import testcases.OpportunityTest;
import utilities.ExcelManager;
import utilities.Excel_DP;
import utilities.RunMode;

public class OpportunityToOrderTest extends TestBase {
	QuoteTest quoteTest = new QuoteTest();
	CreateContractTest createContractTest = new CreateContractTest();
	CreateOrderTest createOrderTest = new CreateOrderTest();
	OpportunityCreationTest OpportunityCreationTest = new OpportunityCreationTest();

	// Test To Create Opportunity,Adding product into the Cart, Quote and Contract
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public void opportunityToOrder(Hashtable<String, String> data) {
		String contractTemplate = data.get("contractTemplate");
		String type = data.get("type");
		SoftAssert softAssert = new SoftAssert();
		if (LeadCreationTest.firstLogin == true) {
		}
		try {
			OpportunityCreationTest.opportunityTest(data);
			if (OpportunityCreationTest.flag == true) {
				OpportunityCreationTest.addProductToCart(data);
				quoteTest.newQuoteTest(data);
				createContractTest.createContractTest(contractTemplate, type);
				// tb.navigateURL(opptyURL);
				// Thread.sleep(10000);
				// James: CreateOrder
				// add code here for OM
				createOrderTest.createOrderTest();
				// James : Validate ETS Solution Design
				// OpportunityCreationAction.ETSSolutionDesignNeeded(ETSSolutionDesign);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		softAssert.assertAll();
	}
	/*
	 * @Test(dependsOnMethods = "opportunityToOrder") public void testMethod() {
	 * System.out.println("Hi James"); }
	 */
}
