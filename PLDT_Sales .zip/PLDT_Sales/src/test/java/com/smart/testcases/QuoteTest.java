package com.smart.testcases;

import java.util.Date;
import java.util.Hashtable;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;
import com.smart.common.Login;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.CreateContractAction;
import pageAction.LeadConversionAction;
import pageAction.QuotePageAction;
import pages.Retention;
import testcases.CreateBilllingandServiceAccountsTest;
import testcases.CreateOrderTest;
import testcases.HomePageTest;
import testcases.LoginAsUser;
import testcases.OpportunityTest;
import utilities.ExcelManager;
import utilities.Excel_DP;
import utilities.RunMode;

public class QuoteTest extends TestBase {
	QuotePageAction quotePageAction = new QuotePageAction();
	TestBase tb = new TestBase();
	HomePageTest hpt = new HomePageTest();
	LeadConversionAction leadConversionAction = new LeadConversionAction();
	CreateBilllingandServiceAccountsTest createOtherAccountsTest = new CreateBilllingandServiceAccountsTest();
	String quoteNo = null;
	String quoteName = null;
	String runStatus = "FAIL";
	public static String opportunityURL = null;
	public static String quoteURL = "https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Quote/0Q01s00000069VkCAI/view";

	// Create Quote, Credit Check, MoveStageTo Accepted
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public void newQuoteTest(Hashtable<String, String> data) {

		String QuoteURL = data.get("QuoteURL");
		String ContractingParty = data.get("ContractingParty");
		String queueName = data.get("queueName");
		String type = data.get("type");
		String creditCondition = data.get("creditCondition");
		String Product = data.get("Product");
		String NumberType = data.get("NumberType");
		String parent = data.get("parent");
		String billingAccName = data.get("billingAccName");
		String lob = data.get("lob");
		String currency = data.get("currency");
		String industry = data.get("industry");
		String industrySubType = data.get("industrySubType");
		String accountTypeCode = data.get("accountTypeCode");
		String accountOf = data.get("accountOf");
		String AccountOfBizAct = data.get("AccountOfBizAct");
		String CIFirstName = data.get("CIFirstName");
		String CIMidName = data.get("CIMidName");
		String CILastName = data.get("CILastName");
		String creditLimit = data.get("creditLimit");
		String thsStatus = data.get("thsStatus");
		String thsRating = data.get("thsRating");
		String subscription = data.get("subscription");
		String serviceProvider = data.get("serviceProvider");
		String notifyMailId = data.get("notifyMailId");
		String creditClass = data.get("creditClass");
		String notifyMobileNo = data.get("notifyMobileNo");
		String phone = data.get("phone");
		String accountPaymentType = data.get("accountPaymentType");
		String customerGroup = data.get("customerGroup");
		String taxExemption = data.get("taxExemption");
		String taxProfile = data.get("taxProfile");
		String billFrequency = data.get("billFrequency");
		String VIPCode = data.get("VIPCode");
		String BillDispatchMethod = data.get("BillDispatchMethod");
		String BillCycle = data.get("BillCycle");	
		String AddrLine1 = data.get("AddrLine1");
		String AddrLine2 = data.get("AddrLine2");
		String AddrLine3 = data.get("AddrLine3");
		String Country = data.get("BillingCountry");
		String City = data.get("BillingCity");
		String Barangay = data.get("Barangay");
		String StateProvince = data.get("StateProvince");
		String ZipPostal = data.get("ZipPostal");
		String SeviceAccountName = data.get("SeviceAccountName");
		String AuthorizeSigonatory = data.get("AuthorizeSigonatory");
		String BillRecipient = data.get("BillRecipient");
		String DeliveryRecipient = data.get("DeliveryRecipient");



		  Login.asAdmin(); 
		  Login.switchToRelationshipManager();
		  driver.get(quoteURL);


		Date d = new Date();
		String date = d.toString().replace(":", "").replace(" ", "").substring(0, 12);
		billingAccName = billingAccName ;
		SeviceAccountName = SeviceAccountName ;
		
		try {
			

			// Ankita-Device Availability Check

			  try {

				  
				 
				  driver.get(quoteURL);
				 // DeviceAvailabilityCheck();
				  TestBase.test.log(LogStatus.PASS, "Performed Device Availability Check");}
			  catch (SkipException e)
			  {
				  Assert.fail();
					TestBase.test.log(LogStatus.FAIL, "Performed Device Availability Check");
			  System.out.println("Skipped : Device Availability Check");
			  }

			// James - Number Availability Check

			  try {
				  driver.get(quoteURL);
				// numberAvailabilityCheck(NumberType);
				 TestBase.test.log(LogStatus.PASS, "Performed Number Availability Check");}
			  catch (SkipException e)
			  {Assert.fail();
				TestBase.test.log(LogStatus.FAIL, "Performed Number Availability Check");
			  System.out.println("Skipped : Number Availability Check");
			  }




		  try {
				  // Ankita : Create Billing Account from Quote
			  driver.get(quoteURL);
//			  createOtherAccountsTest.createNewBillingAccount(parent, billingAccName, lob,
//			  currency, industry, industrySubType, accountTypeCode, accountOf,
//			  AccountOfBizAct, CIFirstName, CIMidName, CILastName, creditLimit, thsStatus,
//			  thsRating, subscription, serviceProvider, notifyMailId, creditClass,
//			  notifyMobileNo, phone, accountPaymentType, customerGroup, taxExemption,
//			  taxProfile, billFrequency, VIPCode, BillDispatchMethod, BillCycle, AddrLine1,
//			  AddrLine2, AddrLine3, Country, City, Barangay, StateProvince, ZipPostal);
			  TestBase.test.log(LogStatus.PASS, "Created NewBilling Account");}
			  catch (Exception e) {
				  Assert.fail();
					TestBase.test.log(LogStatus.FAIL, "Created NewBilling Account");
			  System.out.println("Skipped : Create New Billing Account"); }

			  try {
		     
		      tb.driver.navigate().to(quoteURL);
//			  createOtherAccountsTest.createNewServiceAccount(parent, SeviceAccountName,
//			  parent, AddrLine1, City, StateProvince, ZipPostal, Country, lob, phone);
//			  TestBase.test.log(LogStatus.PASS, "Created NewService Account");
		      }

		  catch (Exception e) {
				  Assert.fail();
					TestBase.test.log(LogStatus.FAIL, "Created NewService Account");
			  System.out.println("Skipped : Create New Service Account");
			  }

			  // Ankita :Populate Quote Validity

		  try 
			  {
				 
			  
			 
			  tb.driver.navigate().to(quoteURL);
			  updateQuoteValidatyPeriod_DeliveryDate_ConatctDetails(AuthorizeSigonatory,
			  BillRecipient, AuthorizeSigonatory, DeliveryRecipient);
			  
			  TestBase.test.log(LogStatus.PASS, "updated QuoteValidaty Period, DeliveryDate and ConatctDetails");
			  }
			  catch (Exception e)
			  {
				  e.printStackTrace();
				  Assert.fail();
				TestBase.test.log(LogStatus.FAIL, "updated QuoteValidaty Period, DeliveryDate and ConatctDetails");
				  System.out.println("Skipped : Update Quote Validity, Delivery Date and Contact Details" ); }
			  try {
				 
				  tb.driver.navigate().to(quoteURL);
				 updateAccounts(billingAccName,SeviceAccountName);
				  
			  TestBase.test.log(LogStatus.PASS, "Updated Billing and Service Accounts");} catch
			  (Exception e) {Assert.fail();
				TestBase.test.log(LogStatus.FAIL, "Updated Billing and service Accounts"); System.out.println("Skipped : Update Accounts"); }
			  
			  try {
				  tb.driver.navigate().to(quoteURL);
				  validateCart();
				 // creditCheck();
				  }
			    catch (Exception e) {

			    }


			//Amit ; Check if Solution design is required
//			if (ContractingParty.contains("PLDT")|| Product.contains("A2P")|| Product.contains("M2M")||Product.contains("Digital")) {
				//Perform Solution Design
//				try {

					//performSolutionDesigning(quoteName, ContractingParty,queueName,type);

//				} catch (Exception e) {

//					System.out.println("Skipped : Solution Designing");
//				}
//			}

//			String cc = quotePageAction.getCreditCheckValue();
//			System.out.println(quoteName + " | " + quoteNo + " | " + cc);

			// Leonyl - credit check required
//			if (cc.contentEquals("Required")) {
//				try {
//
//					performCreditCheck(quoteName, quoteNo, queueName, ContractingParty, creditCondition, type);
//
//					TestBase.test.log(LogStatus.PASS, "Performed Credit Check Value");
//					}
//				catch (Exception e) 
//				{
//						e.printStackTrace();
//						Assert.fail();
//						TestBase.test.log(LogStatus.FAIL, "Performed Credit Check Value");
//					System.out.println("Skipped : Credit Check");
//				}
//			}
			try {
				 tb.driver.navigate().to(quoteURL);
				//quotePageAction.performEbitApproval();
				
			}

		  catch (Exception e) {

			e.printStackTrace();
		    }

//			//Ankita : Move Quote to CustomerApproved
			try {

				tb.driver.navigate().to(quoteURL);
				//MoveQuoteToCustomerApproved(type);
				tb.takeScreenshot();
				TestBase.test.log(LogStatus.PASS, "Quote Status Moved to Customer Approved");
				}
			catch (Exception e)
			{
					e.printStackTrace();
					Assert.fail();
					TestBase.test.log(LogStatus.FAIL, "Quote Status Moved to Customer Approved");
				System.out.println("Skipped : Custmore Approved");
			}
			try {
				// Ankita : Device Reservation Check
				tb.driver.navigate().to(quoteURL);
				 //deviceReservation();
			//DeviceReservationCheck();
//				tb.takeScreenshot();
//				tb.driver.get(QuoteURL);
				TestBase.test.log(LogStatus.PASS, "Performed Device Reservation Check");} catch (Exception e) {
					Assert.fail();
					TestBase.test.log(LogStatus.FAIL, "Performed Device Reservation Check");
				System.out.println("Skipped : Device Reservation Check");
			}
			// James : Number Reservation Check
			try {
				 //numberReservation(NumberType);
				tb.driver.get(quoteURL);
				
				// numberReservationz(NumberType);
				tb.takeScreenshot();
				
				TestBase.test.log(LogStatus.PASS, "Performed Number Reservation Check");} catch (Exception e) {
					Assert.fail();
					TestBase.test.log(LogStatus.FAIL, "Performed Number Reservation Check");
				System.out.println("Skipped : Number Reservation Check");
			}
			try {
				// Ankita : Move Quote To Accepted
				tb.driver.get(quoteURL);
				//MoveQuoteToAccepted();
				createContract();
				CreateOrderTest CreateOrderTest = new CreateOrderTest();
				CreateOrderTest.createOrderTest();
				tb.takeScreenshot();
				TestBase.test.log(LogStatus.PASS, "Quote Status Moved To Accepted");} catch (Exception e) {
					Assert.fail();
					TestBase.test.log(LogStatus.FAIL, "Quote Status Moved To Accepted");
				System.out.println("Skipped : Move Quote To Accepted");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			tb.test.log(LogStatus.valueOf(runStatus), runStatus);
		}
	}

	private void deviceReservation() {
		
		CommonSteps.switchToActionFrame();
		CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "DeviceReservation_XPATH");
		CommonSteps.refreshSwitchToFrame();
		tb.clickUsingJs(By.xpath("//div[@id=\"Step3_nextBtn\"]"));
		tb.clickUsingJs(By.xpath("//div[@id='Step6_nextBtn']"));
		tb.clickUsingJs(By.xpath("(//p[text()='Next'])[3]"));
		CommonSteps.waitForQuotePage();
		
	}

	private void creditCheck() {
	try {   tb.refreshPage();
			CommonSteps.switchToActionFrame();
			CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "creditCheckButton_XPATH");
			
			CommonSteps.refreshSwitchToFrame();

			tb.clickUsingJs(By.xpath(tb.OR.getProperty("ccStatusNextButton_XPATH")));
			try {
				tb.waitFor(By.xpath("//div[@id='CreditCheckRequiredSMART_nextBtn']"), 20, true);
				CommonSteps.refreshSwitchToFrame();
				tb.clickUsingJs(By.xpath("//div[@id='CreditCheckRequiredSMART_nextBtn']"));

				CommonSteps.waitForQuotePage();
			} catch (Exception e) {
				tb.switchBacktoMain();
			}
			
			Login.logOutCurrentUser();
			Login.switchToCreditAnalyst();
			tb.driver.get(quoteURL);
			tb.driver.navigate().refresh();
			tb.ExplicitWait("QuoteNumber_XPATH");
			tb.scrollIntoElement(By.xpath("(//span[text()='Credit Information'])"));
			tb.clickUsingJs(By.xpath("//span[text()='Edit Credit Approval Status']"));
			tb.clickOnElementUsingActions(By.xpath("(//span[text()='Credit Approval Status']/following::div[1])[2]"));
			tb.clickUsingJs(By.xpath("//li/a[text()='Approved']"));
			tb.clickUsingJs(By.xpath("(//div/a[text()='--None--'])"));
			tb.clickUsingJs(By.xpath("//li/a[text()='Bill Above']"));
			tb.enterData(By.xpath("(//span[text()='Credit Remarks']/following::textarea[@role='textbox'])[3]"), "testingcredit");
			tb.retryClick("save_XPATH");
			tb.waitFor(5);
			Login.logOutCurrentUser();
			Login.switchToRelationshipManager();
			tb.waitFor(3);
			TestBase.test.log(LogStatus.PASS, "Performed Credit Check");} catch (Exception e) {
				Assert.fail();
				TestBase.test.log(LogStatus.FAIL, "Performed Credit Check");
		}
	}

	private void validateCart() {
		try {tb.refreshPage();
			CommonSteps.switchToActionFrame();
			CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "validateCart_XPATH");
			tb.takeScreenshot();
			CommonSteps.refreshSwitchToFrame();
			tb.clickUsingJs(By.xpath("//p[text()='Go to Quote']"));
		   CommonSteps.waitForQuotePage();
			TestBase.test.log(LogStatus.PASS, "Performed Validate Cart");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Validate Cart");
		}
	}

	private void numberReservationz(String NumberType) {
		System.out.println("Click on Number Reservation..");

		try {
			System.out.println("Click on Number Reservation..");
			CommonSteps.switchToActionFrame();
			CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "NumberReservation_XPATH");
			CommonSteps.refreshSwitchToFrame();
			tb.clickUsingJs(By.xpath("//a[contains(.,'Search Numbers')]"));
			CommonSteps.refreshSwitchToFrame();
			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty("NumberPatternSearch_XPATH")));
			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty("nextButton_XPATH")));
			tb.ExplicitWait("SearchMIN_XPATH");
			tb.select("NumberType_XPATH", "Regular");
			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty("SearchMIN_XPATH")));
			tb.clickUsingJs(By.xpath("(//th/button)[1]"));
			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty("NumberAvailabilityNextBtn_XPATH")));
			tb.clickUsingJs(By.xpath("(//p[text()='Next'])[3]"));
			tb.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
			tb.waitFor(By.xpath("//span[text()='QuoteActionToolbar']"), 10, true);
			TestBase.test.log(LogStatus.PASS, "Number Reservation is done");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Number Reservation is done");
		}

	}

	public void createQuote(String QuoteURL, String ContractingParty, String Product) {
		if (OpportunityCreationTest.flag == false) {

			try {
				Login.asAdmin();
				Login.switchToRelationshipManager();
				/*
				 * quotePageAction.clickOnAppLauncher();
				 * quotePageAction.enterValueOnAppSearch();
				 * quotePageAction.searchAndOpenQuote(quoteName);
				 */
				/*
				 * driver.navigate().to(
				 * "https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Opportunity/0061s000006yBZsAAM/view"
				 * );
				 */
				//quotePageAction.CreateQuote();


				TestBase.test.log(LogStatus.PASS, "Clicked On Create Quote");
			} catch (Throwable e) {
				Assert.fail();
				TestBase.test.log(LogStatus.FAIL, "Clicked On Create Quote");
			}
		} else {
			// Ankita- create Quote form Opportunity

			// CommonSteps.clickOnDetail();
			tb.ThreadWait(2000);
			tb.takeScreenshot();
			quotePageAction.CreateQuote();

			System.out.println("Quote Created..");
		}
		// driver.navigate().to(opportunityURL);


//		Excel_DP.excel.setCellData("quoteURL", "quoteURL", 2,  quoteURL);
//		Excel_DP.excel.setCellData("quoteURL", "Product", 2, Product );
//
//		Login.asAdmin();
//		Login.asRelationshipManager();
		this.quoteName = quotePageAction.getQuoteName();
		quoteNo = quotePageAction.getQuoteNumber();
		this.quoteURL = tb.driver.getCurrentUrl();
		System.out.println("\n=====================\n");
	}

	// credit check test method
	@SuppressWarnings("static-access")
	public void performCreditCheck(String quoteName, String quoteNo, String queueName, String ContractingParty,
			String creditCondition, String type) {
//		if (!(RunMode.isTestRunnable("performCreditCheck"))) {
//			throw new SkipException(
//					"Skipping the test " + "performCreditCheck".toUpperCase() + "as the Run mode is NO");
//		}
		try {
			quotePageAction.clickOnCreditCheck();
			tb.ThreadWait(2000);
			tb.driver.navigate().refresh();
			tb.ThreadWait(2000);
			quotePageAction.clickOnNext();
			tb.ThreadWait(3000);
			tb.takeScreenshot();
			System.out.println("Perform Credit check: " + quoteNo);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		loginCA_SearchQuote(ContractingParty, quoteName, "All Quotes", "Credit ");
		try {
			editCreditInformation("Approved", creditCondition, "1", "1");
			Thread.sleep(2000);
			// LEONYL: below steps have been removed in R3
			// tb.driver.navigate().refresh();
			// tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Credit
			// check for Quote :')]")));
			// quotePageAction.creditCheckForQuote(quoteNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// logout Credit Analyst
		tb.takeScreenshot();
		LoginAsUser.logout();
		// lnb : re-login as RM
		try {
			// EE RM user
			if (type.contentEquals("EE")) {
				ContractingParty = "EE " + ContractingParty;
			}
			LoginAsUser.loginAsUser(ContractingParty);
			Thread.sleep(4000);
			tb.driver.get(quoteURL);
			tb.driver.navigate().refresh();
			tb.ExplicitWait("QuoteNumber_XPATH");
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	// Edit Credit Information on Quote details
	public void editCreditInformation(String status, String condition, String advPayInMos, String secDepinMos) {
		System.out.println("Edit Credit Information...");
		try {
			tb.ExplicitWait("QuoteNumber_XPATH");
			tb.Scroll("quoteCreditCheck_XPATH");
			tb.jsClick("EDITCreditApprovalCondition_XPATH");
			tb.ThreadWait(2000);
			// only for credit check
			if (!status.isEmpty()) {
				quotePageAction.editCreditApprovalStatus(status);
			}
			quotePageAction.editCreditApprovalCondition(condition);
			quotePageAction.editAdvancePaymentInMonths(advPayInMos);
			quotePageAction.editSecurityDepositInMonths(secDepinMos);
			quotePageAction.editCreditRemart("Credit Check Done");
			tb.takeScreenshot();
			Thread.sleep(2000);
			quotePageAction.saveEditedQuoteDetails();
			tb.waitElementtoBecomeInvisble("footer_XPATH");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Login as Credit Analyst and search for quote
	@SuppressWarnings("static-access")
	public void loginCA_SearchQuote(String contractingParty, String quoteName, String queueName, String user) {
		try {
			Login.logOutCurrentUser();
			Login.switchToCreditAnalyst();
			/*
			 * LoginAsUser.logout(); System.out.println(user + contractingParty);
			 * LoginAsUser.loginAsUser(user + contractingParty); Thread.sleep(1000);
			 * tb.driver.navigate().refresh(); // LoginAsUser.homepagefeature("Quotes");
			 */			hpt.featureURL("Quote");
			quotePageAction.selectQuotesListView(queueName);
			Thread.sleep(1000);
			quotePageAction.searchQuote(quoteName);
			tb.takeScreenshot();
			Thread.sleep(2000);
			quotePageAction.clickQuoteRecord(quoteName);
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	// Ankita
	public void DeviceAvailabilityCheck() {

		quotePageAction.DeviceAvailabilityChceck(quoteName, runStatus);
	}

	// Ankita
	public void DeviceReservationCheck() {
//		if (!(RunMode.isTestRunnable("DeviceReservationCheck"))) {
//			throw new SkipException(
//					"Skipping the test " + "DeviceReservationCheck".toUpperCase() + "as the Run mode is NO");
//		}
		quotePageAction.DeviceReservation(quoteName, runStatus);
	}

	// Ankita
	public void MoveQuoteToCustomerApproved(String type) {
//		if (!(RunMode.isTestRunnable("MoveQuoteToCustomerApproved"))) {
//			throw new SkipException(
//					"Skipping the test " + "MoveQuoteToCustomerApproved".toUpperCase() + "as the Run mode is NO");
//		}
		// additional stages needed only for Business
		if (type.contentEquals("Business")) {
			//quotePageAction.ChangeStatustoPresented();
			tb.refreshPage();
			quotePageAction.ChangeStatustoCustomerApproved();
		}
	}

	public void MoveQuoteToAccepted() {
//		if (!(RunMode.isTestRunnable("MoveQuoteToAccepted"))) {
//			throw new SkipException(
//					"Skipping the test " + "MoveQuoteToAccepted".toUpperCase() + "as the Run mode is NO");
//		}
		quotePageAction.ChangeStatustoAccepted();
		tb.takeScreenshot();
	}

	// Amit: To perform Solution designing
//	public void performSolutionDesigning(String OpportunityName, String ContractingParty, String queueName,
//			String type) {
////		if (!(RunMode.isTestRunnable("performSolutionDesigning"))) {
////			throw new SkipException(
////					"Skipping the test " + "performSolutionDesigning".toUpperCase() + "as the Run mode is NO");
////		}
//		// Click on Lock Cart
//		try {
//			boolean flag;
//			do {
//				try {
//					quotePageAction.ClickOnTriggerSD();
//					tb.ThreadWait(2000);
//					tb.driver.navigate().refresh();
//					tb.ThreadWait(2000);
//					quotePageAction.clickOnNext();
//					tb.ThreadWait(3000);
//					tb.driver.switchTo().parentFrame();
//					tb.ThreadWait(1000);
//					tb.switchToFrame("Frame_XPATH");
//					tb.ThreadWait(1000);
//					tb.click("Menue_XPATH");
//					tb.ExplicitWait("SolutionDesign_XPATH");
//				} catch (Exception e) {
//					tb.refreshPage();
//					e.printStackTrace();
//				}
//				flag = tb.isElementDisplayed("SolutionDesign_XPATH");
//			} while (!flag);
//			tb.driver.switchTo().parentFrame();
//			// Check if Solution Design button enabled
//			if (flag) {
//				loginCA_SearchQuote(ContractingParty, quoteName, "All Quotes", "ETS ");
//				String etsStatus = "";
//				// Click on Solution Design
//				do {
//					try {
//						// Select the Completed status
//						quotePageAction.clickONSolutionDesign();
//						quotePageAction.selectETSStatus("Completed");
//						tb.driver.navigate().refresh();
//						tb.ThreadWait(2000);
//						tb.Scroll("CreditInformation_XPATH");
//						etsStatus = quotePageAction.etsStatusVerify();
//						System.out.println("etsStatus : " + etsStatus);
//					} catch (Exception e) {
//						tb.navigateURL(quoteURL);
//						e.printStackTrace();
//					}
//				} while (!etsStatus.equalsIgnoreCase("Completed"));
//				// Verify if the ETS Status is 'Completed'
//				if (etsStatus.equalsIgnoreCase("Completed")) {
//					System.out.println("Pass");
//					tb.test.log(LogStatus.PASS, etsStatus);
//				} else {
//					tb.test.log(LogStatus.FAIL, etsStatus);
//				}
//				// lnb : re-login as RM
//				try {
//					tb.takeScreenshot();
//					LoginAsUser.logout();
//					// EE RM user
//					if (type.contentEquals("EE")) {
//						ContractingParty = "EE " + ContractingParty;
//					}
//					LoginAsUser.loginAsUser(ContractingParty);
//					Thread.sleep(4000);
//					tb.driver.get(quoteURL);
//					tb.driver.navigate().refresh();
//					tb.ExplicitWait("QuoteNumber_XPATH");
//				} catch (Throwable e) {
//					e.printStackTrace();
//				}
//			}
//		} catch (Exception e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//	}

	// James - NumberAvailabilityCheck
	public void numberAvailabilityCheck(String NumberType) {
         tb.refreshPage();
		CommonSteps.switchToActionFrame();
		CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "NumberAvailabilityCheck_XPATH");
		CommonSteps.refreshSwitchToFrame();
		tb.clickUsingJs(By.xpath("//a[contains(.,'Search Numbers')]"));
		CommonSteps.refreshSwitchToFrame();
		tb.clickUsingJs(By.xpath("//*[contains(text(),'Pattern Search')]"));
		tb.clickUsingJs(By.xpath("(//*[text()='Next'])[1]"));
		tb.selectByValue(By.xpath("//select[@id='NumberTypeMin']"), "Regular");
		tb.clickUsingJs(By.xpath("//p[.='Search MIN']"));
		tb.clickUsingJs(By.xpath("(//*[text()='Next'])[2]"));
		CommonSteps.refreshSwitchToFrame();
		tb.clickUsingJs(By.xpath("//*[text()[contains(.,'View Quote')]]"));
		CommonSteps.waitForQuotePage();
		

	}

	// James - NumberReservation
	public void numberReservation(String NumberType) {
		if (!(RunMode.isTestRunnable("NumberReservation"))) {
			throw new SkipException("Skipping the test " + "NumberReservation".toUpperCase() + "as the Run mode is NO");
		}
		quotePageAction.numberReservation(quoteName, runStatus, NumberType);
	}

	public void updateQuoteValidatyPeriod_DeliveryDate_ConatctDetails(String AuthorizeSigonatory, String BillRecipient,
			String CapContact, String DeliveryRecipient) {

		quotePageAction.updateQuoteValidatyPeriod_DeliveryDate_ConatctDetails(AuthorizeSigonatory, BillRecipient,
				CapContact, DeliveryRecipient);
	}

	public void updateAccounts(String BiilingAccountName, String ServiceAccountName) {
//		if (!(RunMode.isTestRunnable("updateAccounts"))) {
//			throw new SkipException("Skipping the test " + "updateAccounts".toUpperCase() + "as the Run mode is NO");
//		}
		quotePageAction.updateAccounts(BiilingAccountName, ServiceAccountName);
	}

	public void createContract() {
		if (!(RunMode.isTestRunnable("createContractTest"))) {
			throw new SkipException(
					"Skipping the test " + "createContractTest".toUpperCase() + "as the Run mode is NO");
		}
		SoftAssert softAssert = new SoftAssert();
		try {
			CreateContractAction createContractAction = new CreateContractAction();
			createContractAction.createContractFromQuote();
			System.out.println(" Contract Created....");
			tb.ExplicitWait("NegotiatingStage_XPATH");
			// CommonSteps.clickOnDetail();
			Thread.sleep(3000);
			tb.takeScreenshot();
//			createContractAction.editContract(startDate, contractMonth);
//			leadCreationAction.clickOnsaveBtn();
			// createContractAction.GenerateDocument(contractTemplate);
			tb.ExplicitWait("NegotiatingStage_XPATH");
			tb.takeScreenshot();
			createContractAction.MoveStageToNegociation();
			createContractAction.MoveStageToAwaitingSingnature();
			createContractAction.MoveStageToSigned();
//			createContractAction.MoveStageToActivated();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
