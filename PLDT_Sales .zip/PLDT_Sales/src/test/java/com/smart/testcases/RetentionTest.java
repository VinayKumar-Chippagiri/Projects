package com.smart.testcases;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.smart.common.CaseCreation;


import pageAction.CommonSteps;
import pageAction.OpportunityCreationAction;

import com.smart.common.Login;

import pages.Retention;
import utilities.ExcelManager;

public class RetentionTest extends Retention {

	Retention rt = new Retention();
	OpportunityCreationTest oppCreatTest = new OpportunityCreationTest();
	OpportunityCreationAction oppcrtaction = new OpportunityCreationAction();

	String QuoteURL = null;
	
	//TS00420190000551

	@Test(dataProviderClass = ExcelManager.class, dataProvider = "testdata")
	public void Retention(Hashtable<String, String> data) throws InterruptedException {

		// step 1: login and create case
		try {
			Login.asAdmin();
			Login.switchToRelationshipManager();
			CommonSteps.switchAndOpenAccount(data.get("accountName"), "Business Account");
			goToAccountAssets();
			selectAsset(data.get("Min Num"), data.get("AssetID"));
			rt.pathForCaseCreationRetention(data.get("accountName"), data.get("Min Num"), data.get("AssetID"));
			CaseCreation.createCaseRetention(data.get("billingAccount"), data.get("billingAccountName"),
					data.get("subject"), data.get("type"), data.get("highLevelTransactionClassification"),
					data.get("transactionType"), data.get("transactionSubType"));
			rt.findNewlyCreatedCase(data.get("subject"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		// step 2 : we will modify case
		try {
			rt.caseModification(data.get("remarkValue"));
			rt.retentionAction(data.get("Plan"),data.get("Retention"));
		} catch (Exception e) {
			e.printStackTrace();
		}

		// step 3 add device
		try {
			
			rt.addDevice(data.get("DeviceName"),data.get("transactionSubType"));
			oppcrtaction.selectDeviceCapacity(data.get("DeviceCapacity"));
			Thread.sleep(2000);
			oppcrtaction.selectColor(data.get("DeviceColor"));
			Thread.sleep(2000);
			rt.viewRecord();
		} catch (Exception e) {
			e.printStackTrace();
		}

		// step 4 Device Validity
		try {			
			rt.validateCart();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		// step5 update necessary details in Quote page
		try {

			rt.rtnUpdateQuoteValidationPeriod();
			rt.updateContact(data.get("Authorized Signatory"), data.get("Bill Recipient"),
					data.get("Delivery Recipient"));
			rt.QuoteDeliveryDate(data.get("Delivery Date"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// in case reload require
				try {
					boolean flag = rt.reload();
					if (flag) {
						rt.clickOnReload();
						rt.rtnUpdateQuoteValidationPeriod();
						rt.updateContact(data.get("Authorized Signatory"), data.get("Bill Recipient"),
								data.get("Delivery Recipient"));
						rt.QuoteDeliveryDate(data.get("Delivery Date"));
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
		
		
		// step6 credit check using credit analyst
		
		
		String type = data.get("Retention");
		Thread.sleep(5000);
		if (!type.equalsIgnoreCase("Downgrade")) {
			
			try {
				QuoteURL = rt.getQuoteURL();
				Login.logOutCurrentUser();
				Login.switchToCreditAnalyst();
				rt.navigateURL(QuoteURL);
				rt.creditcheck(data.get("Credit Check NewStatus"), data.get("Credit Check Condition"),
						data.get("Credit Check Remark"));
				Login.logOutCurrentUser();
				Login.switchToRelationshipManager();
				rt.navigateURL(QuoteURL);

			} catch (Exception e) {
				e.printStackTrace();
			}			
		}
				
		// step 7 device availability
		try {
			rt.DeviceAvalibility();
			rt.ChangeStatustoCustomerApproved();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// step8 device reservation
		try {
			rt.DeviceReservation();
			rt.ChangeStatustoAccepted();
		} catch (Exception e) {
			e.printStackTrace();
		}
				
		// step9 create contract
		try {
			rt.CreateContract();
			//rt.navigateURL("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Contract/8001s000000PWaXAAW/view");
			rt.order();
			rt.selectMaster();
			//rt.masterOrderStatus();
			rt.selectSubOrder();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}
