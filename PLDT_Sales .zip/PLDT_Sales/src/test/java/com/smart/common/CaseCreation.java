package com.smart.common;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import base.TestBase;

public class CaseCreation {
	// By Pranay
	static TestBase tb = new TestBase();
	private static By accountName = By.xpath("(//input[@placeholder='Search Accounts...'])[1]");
	private static By contactName = By.xpath("//input[@placeholder='Search Contacts...']");
	private static By billingAccount = By.xpath("(//input[@placeholder='Search Accounts...'])[2]");
	private static By consigneeName = By
			.xpath("(//span[text()='Consignee Name']/following::input[@placeholder='Search Contacts...'])");
	private static By subject = By.xpath("//label/span[text()='Subject']/parent::label/following-sibling::*");
	private static By description = By.xpath("//label/span[text()='Description']/parent::label/following-sibling::*");
	private static By lineOfBusiness = By
			.xpath("//span[text()='Line of Business']/parent::span/following-sibling::div/div//a");
	private static By typeOfCustomerRequest = By
			.xpath("//span[text()='Type of Customer Request']/parent::span/following-sibling::div/div//a");
	private static By type = By.xpath("//span[text()='Type']/parent::span/following-sibling::div/div//a");
	private static By highLevelTransactionClassification = By
			.xpath("//span[text()='High Level Transaction Classification']/parent::span/following-sibling::div/div//a");
	private static By transactionType = By
			.xpath("//span[text()='Transaction Type']/parent::span/following-sibling::div/div//a");
	private static By transactionSubType = By
			.xpath("//span[text()='Transaction Sub Type']/parent::span/following-sibling::div/div//a");
	private static By transactionReason = By
			.xpath("//span[text()='Transaction Reason']/parent::span/following-sibling::div/div//a");
	private static By product = By.xpath("//span[text()='Product']/parent::span/following-sibling::div/div//a");
	private static By manualDeactivation = By
			.xpath("//label/span[text()='Manual Deactivation']/parent::label/following-sibling::*");
	private static By priority = By.xpath("//label/span[text()='Priority']/parent::label/following-sibling::*");
	private static By caseOrigin = By.xpath("//span[text()='Case Origin']/parent::span/following-sibling::div/div//a");
	private static By status = By.xpath("//label/span[text()='Status']/parent::label/following-sibling::*");
	private static By transactionDescription = By
			.xpath("//label/span[text()='Transaction Description']/parent::label/following-sibling::*");
	private static By numberOfLinesServices = By
			.xpath("//label/span[text()='Number of lines/services']/parent::label/following-sibling::*");
	private static By caseCancellationReason = By
			.xpath("//label/span[text()='Case Cancellation Reason']/parent::label/following-sibling::*");
	private static By minForPortIn = By
			.xpath("//label/span[text()='MIN for Port In']/parent::label/following-sibling::*");
	private static By currentProvider = By
			.xpath("//label/span[text()='Current Provider']/parent::label/following-sibling::*");
	private static By recipientProvider = By
			.xpath("//label/span[text()='Recipient Provider']/parent::label/following-sibling::*");
	private static By otherOneTimeFee = By
			.xpath("//label/span[text()='Other One time Fee']/parent::label/following-sibling::*");
	private static By waiverOfMoveFee = By
			.xpath("//label/span[text()='Waiver of Move fee']/parent::label/following-sibling::*");
	private static By adjustmentAmount = By
			.xpath("//label/span[text()='Adjustment Amount']/parent::label/following-sibling::*");
	private static By transactionEntry = By
			.xpath("//label/span[text()='Transaction Entry']/parent::label/following-sibling::*");
	private static By requestedCreditLimit = By
			.xpath("//label/span[text()='Requested Credit Limit']/parent::label/following-sibling::*");
	private static By period = By.xpath("//label/span[text()='Period']/parent::label/following-sibling::*");
	private static By preferredBillingCurrency = By
			.xpath("//label/span[text()='Preferred Billing Currency']/parent::label/following-sibling::*");
	private static By deliveryAddress = By
			.xpath("//label/span[text()='Delivery Address']/parent::label/following-sibling::*");
	private static By preferredAddOn = By
			.xpath("//label/span[text()='Preferred Add-on']/parent::label/following-sibling::*");
	private static By requiredAssetAndContractInformation = By
			.xpath("//label/span[text()='Required Asset and Contract Information']/parent::label/following-sibling::*");
	private static By invoiceNumber = By
			.xpath("//label/span[text()='Invoice Number']/parent::label/following-sibling::*");
	private static By webEmail = By.xpath("//label/span[text()='Web Email']/parent::label/following-sibling::*");
	private static By technicalInformation = By
			.xpath("//label/span[text()='Technical Information']/parent::label/following-sibling::*");
	private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	private static By cancel = By.xpath("//label/span[text()='cancel']/parent::label/following-sibling::*");
	private static By saveAndNew = By.xpath("//label/span[text()='save and new']/parent::label/following-sibling::*");
	private static By save = By.xpath("//button[@title='Save']");
	private static By moveDocumentArrow = By.xpath("//span[text()='Move selection to Chosen']");
	private static By caseClose = By.xpath("//span[text()='Close this window']/parent::button");

	public static void enter_accountName(String accountNameValue) {
		tb.enterData(accountName, accountNameValue);
		tb.driver.findElement(accountName).sendKeys(Keys.BACK_SPACE);
		tb.clickUsingJs(By.xpath("(//ul//li//*[@title='" + accountNameValue + "'])[1]"));
	}

	public static void enter_contactName(String contactNameValue) {
		tb.enterData(contactName, contactNameValue);
	}

	public static void enter_billingAccount(String billingAccountValue) {
		tb.enterData(billingAccount, billingAccountValue);
		tb.clickOn(By.xpath("//span[contains(text(),'in Accounts')]"));
		tb.waitFor(2);
		tb.clickUsingJs(By.xpath("//*[text()='Account Name']/ancestor::table/tbody/tr/td/a"));
	}

	public static void enter_billingAccount(String accountNum, String billingAccountname) {
		tb.enterData(billingAccount, accountNum);
		tb.clickOn(By.xpath("//span[contains(text(),'in Accounts')]"));
		tb.jsClink_LinkText(billingAccountname);
	}

	public static void enter_consigneeName(String consigneeNameValue) {
//		tb.enterData(consigneeName, consigneeNameValue);
//		//tb.enterKey();
//		tb.clickOn(By.xpath("//span[contains(text(),'in Contacts')]"));
//		tb.waitFor(2);
//		tb.clickUsingJs(By.xpath("(//*[@title='Name']/ancestor::table/tbody/tr/td/a)[1]"));
		tb.typeDataTo(consigneeName, consigneeNameValue);
		tb.driver.findElement(consigneeName).sendKeys(Keys.BACK_SPACE);
		tb.clickUsingJs(By.xpath("(//ul//li//*[@title='" + consigneeNameValue + "'])[1]"));
	}

	public static void enter_subject(String subjectValue) {
		tb.enterData(subject, subjectValue);
	}

	public static void enter_description(String descriptionValue) {
		tb.enterData(description, descriptionValue);
	}

	public static void select_lineOfBusiness(String lineOfBusinessValue) {
		tb.clickUsingJs(lineOfBusiness);
		tb.clickUsingJs(By.xpath("(//a[text()=" + "'" + lineOfBusinessValue + "'" + "])[2]"));
	}

	public static void select_typeOfCustomerRequest(String typeOfCustomerRequestValue) {
		tb.clickUsingJs(typeOfCustomerRequest);
		tb.clickUsingJs(By.xpath("(//a[text()=" + "'" + typeOfCustomerRequestValue + "'" + "])[2]"));
	}

	public static void select_type(String typeValue) {
		tb.clickUsingJs(type);
		tb.clickUsingJs(By.xpath("(//a[text()=" + "'" + typeValue + "'" + "])[1]"));
	}

	public static void select_highLevelTransactionClassification(String highLevelTransactionClassificationValue) {
		tb.clickUsingJs(highLevelTransactionClassification);
		tb.clickUsingJs(By.xpath("(//a[text()=" + "'" + highLevelTransactionClassificationValue + "'" + "])[1]"));
	}

	public static void select_transactionType(String transactionTypeValue) {
		tb.clickUsingJs(transactionType);
		tb.clickUsingJs(By.xpath("(//a[text()=" + "'" + transactionTypeValue + "'" + "])[1]"));
	}

	public static void select_transactionSubType(String transactionSubTypeValue) {
		tb.clickUsingJs(transactionSubType);
		tb.clickUsingJs(By.xpath("(//a[text()=" + "'" + transactionSubTypeValue + "'" + "])[1]"));
	}

	public static void select_transactionReason(String transactionReasonValue) {
		tb.clickUsingJs(transactionReason);
		tb.jsClink_LinkText(transactionReasonValue);
	}

	public static void select_product(String productValue) {
		tb.clickUsingJs(product);
		tb.jsClink_LinkText(productValue);
	}

	public static void click_manualDeactivation() {
		tb.clickUsingJs(manualDeactivation);
	}

	public static void select_priority(String priorityValue) {
		tb.clickUsingJs(priority);
		tb.jsClink_LinkText(priorityValue);
	}

	public static void select_caseOrigin(String caseOriginValue) {
		tb.clickUsingJs(caseOrigin);
		tb.jsClink_LinkText(caseOriginValue);
	}

	public static void select_status(String statusValue) {
		tb.clickUsingJs(status);
		tb.jsClink_LinkText(statusValue);
	}

	public static void enter_transactionDescription(String transactionDescriptionValue) {
		tb.enterData(transactionDescription, transactionDescriptionValue);
	}

	public static void enter_numberOfLinesServices(String numberOfLinesServicesValue) {
		tb.enterData(numberOfLinesServices, numberOfLinesServicesValue);
	}

	public static void enter_caseCancellationReason(String caseCancellationReasonValue) {
		tb.enterData(caseCancellationReason, caseCancellationReasonValue);
	}

	public static void enter_minForPortIn(String minForPortInValue) {
		tb.enterData(minForPortIn, minForPortInValue);
	}

	public static void select_currentProvider(String currentProviderValue) {
		tb.clickUsingJs(currentProvider);
		tb.jsClink_LinkText(currentProviderValue);
	}

	public static void select_recipientProvider(String recipientProviderValue) {
		tb.clickUsingJs(recipientProvider);
		tb.jsClink_LinkText(recipientProviderValue);
	}

	public static void enter_otherOneTimeFee(String otherOneTimeFeeValue) {
		tb.enterData(otherOneTimeFee, otherOneTimeFeeValue);
	}

	public static void enter_waiverOfMoveFee(String waiverOfMoveFeeValue) {
		tb.enterData(waiverOfMoveFee, waiverOfMoveFeeValue);
	}

	public static void enter_adjustmentAmount(String adjustmentAmountValue) {
		tb.enterData(adjustmentAmount, adjustmentAmountValue);
	}

	public static void select_transactionEntry(String transactionEntryValue) {
		tb.clickUsingJs(transactionEntry);
		tb.jsClink_LinkText(transactionEntryValue);
	}

	public static void enter_requestedCreditLimit(String requestedCreditLimitValue) {
		tb.enterData(requestedCreditLimit, requestedCreditLimitValue);
	}

	public static void enter_period(String periodValue) {
		tb.enterData(period, periodValue);
	}

	public static void enter_preferredBillingCurrency(String preferredBillingCurrencyValue) {
		tb.enterData(preferredBillingCurrency, preferredBillingCurrencyValue);
	}

	public static void enter_deliveryAddress(String deliveryAddressValue) {
		tb.enterData(deliveryAddress, deliveryAddressValue);
	}

	public static void enter_preferredAddOn(String preferredAddOnValue) {
		tb.enterData(preferredAddOn, preferredAddOnValue);
	}

	public static void enter_requiredAssetAndContractInformation(String requiredAssetAndContractInformationValue) {
		tb.enterData(requiredAssetAndContractInformation, requiredAssetAndContractInformationValue);
	}

	public static void enter_invoiceNumber(String invoiceNumberValue) {
		tb.enterData(invoiceNumber, invoiceNumberValue);
	}

	public static void enter_webEmail(String webEmailValue) {
		tb.enterData(webEmail, webEmailValue);
	}

	public static void enter_technicalInformation(String technicalInformationValue) {
		tb.enterData(technicalInformation, technicalInformationValue);
	}

	public static void click_availableDocuments() {
		tb.scrollIntoElement(availableDocuments);
		tb.moveToElement(availableDocuments);
		tb.clickOnElementUsingActions(availableDocuments);
	}

	public static void click_moveAvailableDocuments() {
		tb.clickUsingJs(moveDocumentArrow);
	}

	public static void click_cancel() {
		tb.clickUsingJs(cancel);
	}

	public static void click_saveAndNew() {
		tb.clickUsingJs(saveAndNew);
	}

	public static void click_save() {
		tb.clickUsingJs(save);
	}

	public static void createCase(String accountNameValue, String contactNameValue, String billingAccountValue,
			String consigneeNameValue, String subjectValue, String descriptionValue, String lineOfBusinessValue,
			String typeOfCustomerRequestValue, String typeValue, String highLevelTransactionClassificationValue,
			String transactionTypeValue, String transactionSubTypeValue, String transactionReasonValue,
			String productValue, String priorityValue, String caseOriginValue, String statusValue,
			String transactionDescriptionValue, String numberOfLinesServicesValue, String caseCancellationReasonValue,
			String minForPortInValue, String currentProviderValue, String recipientProviderValue,
			String otherOneTimeFeeValue, String waiverOfMoveFeeValue, String adjustmentAmountValue,
			String transactionEntryValue, String requestedCreditLimitValue, String periodValue,
			String preferredBillingCurrencyValue, String deliveryAddressValue, String preferredAddOnValue,
			String requiredAssetAndContractInformationValue, String invoiceNumberValue, String webEmailValue,
			String technicalInformationValue) {
		CaseCreation.enter_accountName(accountNameValue);
		// CaseCreation.enter_contactName(contactNameValue);
		// CaseCreation.enter_billingAccount(billingAccountValue);
		CaseCreation.enter_consigneeName(consigneeNameValue);
		CaseCreation.enter_subject(subjectValue);
		// CaseCreation.enter_description(descriptionValue);
		CaseCreation.select_lineOfBusiness(lineOfBusinessValue);
		CaseCreation.select_typeOfCustomerRequest(typeOfCustomerRequestValue);
		CaseCreation.select_type(typeValue);
		CaseCreation.select_highLevelTransactionClassification(highLevelTransactionClassificationValue);
		CaseCreation.select_transactionType(transactionTypeValue);
		CaseCreation.select_transactionSubType(transactionSubTypeValue);
		// CaseCreation.select_transactionReason(transactionReasonValue);
		// CaseCreation.select_product(productValue);
		// CaseCreation.click_manualDeactivation();
		// CaseCreation.select_priority(priorityValue);
		// CaseCreation.select_caseOrigin(caseOriginValue);
		// CaseCreation.select_status(statusValue);
		// CaseCreation.enter_transactionDescription(transactionDescriptionValue);
		// CaseCreation.enter_numberOfLinesServices(numberOfLinesServicesValue);
		// CaseCreation.enter_caseCancellationReason(caseCancellationReasonValue);
		// CaseCreation.enter_minForPortIn(minForPortInValue);
		// CaseCreation.select_currentProvider(currentProviderValue);
		// CaseCreation.select_recipientProvider(recipientProviderValue);
		// CaseCreation.enter_otherOneTimeFee(otherOneTimeFeeValue);
		// CaseCreation.enter_waiverOfMoveFee(waiverOfMoveFeeValue);
		// CaseCreation.enter_adjustmentAmount(adjustmentAmountValue);
		// CaseCreation.select_transactionEntry(transactionEntryValue);
		// CaseCreation.enter_requestedCreditLimit(requestedCreditLimitValue);
		// CaseCreation.enter_period(periodValue);
		// CaseCreation.enter_preferredBillingCurrency(preferredBillingCurrencyValue);
		// CaseCreation.enter_deliveryAddress(deliveryAddressValue);
		// CaseCreation.enter_preferredAddOn(preferredAddOnValue);
		// CaseCreation.enter_requiredAssetAndContractInformation(requiredAssetAndContractInformationValue);
		// CaseCreation.enter_invoiceNumber(invoiceNumberValue);
		// CaseCreation.enter_webEmail(webEmailValue);
		// CaseCreation.enter_technicalInformation(technicalInformationValue);
		CaseCreation.click_availableDocuments();
		CaseCreation.click_moveAvailableDocuments();
		// CaseCreation.click_cancel();
		// CaseCreation.click_saveAndNew();
		CaseCreation.click_save();
	}

	public static void createCaseRetention(String billingac, String billingAcName, String subjectValue,
			String typeValue, String highLevelTransactionClassificationValue, String transactionTypeValue,
			String transactionSubTypeValue) throws InterruptedException {
		// CaseCreation.enter_accountName(accountNameValue);
		// CaseCreation.enter_billingAccount(billingac, billingAcName);
		CaseCreation.enter_billingAccount(billingac);
		CaseCreation.enter_subject(subjectValue);
		CaseCreation.select_type(typeValue);
		CaseCreation.select_highLevelTransactionClassification(highLevelTransactionClassificationValue);
		CaseCreation.select_transactionType(transactionTypeValue);
		CaseCreation.select_transactionSubType(transactionSubTypeValue);
		CaseCreation.click_availableDocuments();
		CaseCreation.click_moveAvailableDocuments();
		Thread.sleep(2000);
		CaseCreation.click_save();
		Thread.sleep(2000);
		if (tb.isElementPresent(caseClose))
			tb.clickUsingJs(caseClose);
	}

	public static void createCaseFeature(String billingac, String billingAcName, String subjectValue, String typeValue,
			String caseOriginValue, String highLevelTransactionClassificationValue, String transactionTypeValue)
			throws InterruptedException {
		CaseCreation.enter_billingAccount(billingac, billingAcName);
		CaseCreation.enter_subject(subjectValue);
		CaseCreation.select_type(typeValue);
		if (caseOriginValue.equalsIgnoreCase("Bulk")) {
			CaseCreation.select_caseOrigin(caseOriginValue);
		}
		CaseCreation.select_highLevelTransactionClassification(highLevelTransactionClassificationValue);
		CaseCreation.select_transactionType(transactionTypeValue);
		CaseCreation.click_save();
		Thread.sleep(3000);
		if (tb.isElementPresent(caseClose)) {
			tb.clickUsingJs(caseClose);
		}
	}
}
