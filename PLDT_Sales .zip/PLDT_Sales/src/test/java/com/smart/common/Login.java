package com.smart.common;

import java.net.MalformedURLException;

import java.net.URL;
import java.util.List;

import org.apache.poi.hssf.record.ObjRecord;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByCssSelector;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import base.TestBase;
import pageAction.CommonSteps;
import utilities.ExcelReader;

public class Login extends TestBase {
	static TestBase tb = new TestBase();
	static URL uri = null;
	static String name = null;
	static String email = null;
	static String profile = null;
	static String viewFilter = null;
	public static ExcelReader excel = new ExcelReader(
			System.getProperty("user.dir") + "\\src\\test\\resources\\excelFiles\\logintest.xlsx");
	private static By userName = By.xpath("//input[@id='username']");
	private static By passWord = By.xpath("//input[@id='password']");
	private static By login = By.xpath("//input[@id='Login']");
	private static By tableRows = By.xpath("//table/tbody/tr");

	public static void asAdmin() {
		try {
			tb.enterValueUsingJs(userName, excel.getCellData("AdminLogin", 1, 2));
			tb.enterValueUsingJs(passWord, excel.getCellData("AdminLogin", 2, 2));
			tb.clickUsingJs(login);
			Log.info("Logged in as Admin");
			TestBase.test.log(LogStatus.PASS, "Logged in as Admin");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Logged in as Admin");
		}
	}

	public static void asRelationshipManager() {
		setCredentials(excel.getCellData("UserLogin", 0, 2), excel.getCellData("UserLogin", 1, 2),
				excel.getCellData("UserLogin", 3, 2));
		Log.info("Logged in as Relationship Manager");
	}

	public static void asCreditAnalyst() {
		setCredentials(excel.getCellData("UserLogin", 0, 3), excel.getCellData("UserLogin", 1, 3),
				excel.getCellData("UserLogin", 3, 3));
		Log.info("Logged in as Credit Analyst");
	}

	public static void setCredentials(String name, String email, String viewfilter) {
		goToUsersPage();
		tb.waitFor(By.xpath(OR.getProperty("userTableFrame_XPATH")), 30, true);
		tb.switchToFrame("userTableFrame_XPATH");
		selectViewFilter(viewfilter);
		clickAlphabetFilter(name.toLowerCase().charAt(0));
		boolean hasNextPage = false;
		if (!isEmailExistInTable(email)) {
			try {
				hasNextPage = TestBase.driver.findElement(By.cssSelector(".hasMotif > .bNext .next > a")).isEnabled();
				while (hasNextPage) {
					TestBase.driver.findElement(By.cssSelector(".hasMotif > .bNext .next > a")).click();
					tb.switchToFrame("userTableFrame_XPATH");
					if (isEmailExistInTable(email)) {
						break;
					}
				}
			} catch (Exception e) {
			}
		}
	}

	private static boolean isEmailExistInTable(String email) {
		List<WebElement> rows = TestBase.driver.findElements(tableRows);
		for (int i = 1; i < rows.size(); i++) {
			List<WebElement> cols = rows.get(i).findElements(By.tagName("td"));
			if (cols.get(2).getText().equals(email)) {
				List<WebElement> firstColumn = cols.get(0).findElements(By.tagName("a"));
				firstColumn.get(1).click();
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				return true;
			}
		}
		return false;
	}

	private static void clickAlphabetFilter(Character alphabet) {
		String alpha = "(//div[@class=\"rolodex\"]/a/span)[" + (alphabet - 96) + "]";
		tb.waitForClickable(By.xpath(alpha), 60);
		tb.clickOn(By.xpath(alpha));
		TestBase.driver.navigate().refresh();
		tb.switchToFrame("userTableFrame_XPATH");
	}

	private static void selectViewFilter(String viewfilter) {
		tb.select("viewFilter_XPATH", viewfilter);
	}



	public static void logOut()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();",
				TestBase.driver.findElement(By.xpath("//*[contains(text(),'Log out')]")));
		Log.info("User has been Logged out");
		tb.waitFor(1);
	}
	public static void logOutUser() {
		try {
			tb.jsClick("user_XPATH");
			tb.jsClick("logout_XPATH");
		} catch (Exception e) {
		}
		tb.waitFor(2);
		try {
			if (tb.isElementPresent(By.xpath("//input[@id='Login']"))) {
				Login.asAdmin();
			}
			String sessionEndPopup = "//lightning-formatted-text[text()='Your session has ended']";
			if (tb.isElementPresent(By.xpath(sessionEndPopup))) {
				if (tb.isElementDisplayed(By.xpath(sessionEndPopup + "//following::div[2]/button[2]"))
						&& tb.isElementDisplayed(By.xpath(sessionEndPopup + "//following::div[2]/button"))) {
					tb.clickUsingJs(By.xpath(
							"//lightning-formatted-text[text()='Your session has ended']//following::div[2]/button[2]"));
				}
			}
		} catch (Exception e) {
		}
		Log.info("User has been Logged out");
	}

	public static void logOutAsAdmin() {
		tb.navigateURL("https://pldtoneenterprise--r32sit.lightning.force.com/secur/logout.jsp");

	}

	public static void goToUsersPage() {
		try {
			uri = new URL(TestBase.driver.getCurrentUrl());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		tb.navigateURL("https://" + uri.getHost() + "/lightning/setup/ManageUsers/home");
	}

	public static void switchToRelationshipManager() {
		try {
			CommonSteps.switchAndOpen(excel.getCellData("switchlogin", 0, 2).trim(), "User");
			tb.clickUsingJs(By.xpath("(//div[.='User Detail'])[1]"));
			tb.switchToFrame(By.xpath("//*[@id=\"setupComponent\"]/div[2]/div/div/force-aloha-page/div/iframe"));
			tb.waitForClickable(By.xpath("(//input[@title='Login'])[1]"), 30);
			tb.clickUsingJs(By.xpath("(//input[@title='Login'])[1]"));
			tb.waitFor(5);
			Log.info("Logged in as Relationship Manager");
			TestBase.test.log(LogStatus.PASS, "Logged in as Relationship Manager");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Logged in as Relationship Manager");
		}
	}

	public static void switchToCreditAnalyst() {
		try {
			CommonSteps.switchAndOpen(excel.getCellData("switchlogin", 0, 3).trim(), "User");
			tb.clickUsingJs(By.xpath("(//div[.='User Detail'])[1]"));
			tb.switchToFrame(By.xpath("//*[@id=\"setupComponent\"]/div[2]/div/div/force-aloha-page/div/iframe"));
			tb.waitForClickable(By.xpath("(//input[@title='Login'])[1]"), 30);
			tb.clickUsingJs(By.xpath("(//input[@title='Login'])[1]"));
			// tb.switchBacktoMain();
			tb.waitFor(5);
			Log.info("Logged in as Credit Analyst");
			TestBase.test.log(LogStatus.PASS, "Logged in as Credit Analyst");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Logged in as Credit Analyst");
		}
	}

	public static void switchToAnyUser(String userName) {
		try {
			CommonSteps.switchAndOpen(userName.trim(), "User");
			tb.clickUsingJs(By.xpath("(//div[.='User Detail'])[1]"));
			tb.switchToFrame(By.xpath("//*[@id=\"setupComponent\"]/div[2]/div/div/force-aloha-page/div/iframe"));
			tb.waitForClickable(By.xpath("(//input[@title='Login'])[1]"), 30);
			tb.clickUsingJs(By.xpath("(//input[@title='Login'])[1]"));
			// tb.switchBacktoMain();
			tb.waitFor(5);
			Log.info("Logged in as " + userName);
			TestBase.test.log(LogStatus.PASS, "Logged in as " + userName);
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Logged in as " + userName);
		}
	}

	public static void logOutCurrentUser() {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click();",
					TestBase.driver.findElement(By.xpath("//*[contains(text(),'Log out')]")));
			Log.info("User has been Logged out");
			tb.waitFor(1);
			try {
				if (TestBase.driver.findElement(By.xpath("(//span[.='Home'])[1]")).isDisplayed()) {
				}
			} catch (Exception e) {
				tb.navigateURL("https://test.salesforce.com");
				Login.asAdmin();
			}
			goToHomePage();
			TestBase.test.log(LogStatus.PASS, "User has been Logged out");
		}
		catch(Exception e)
		{   Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "User has been Logged out");
		}

	}

	public static void goToHomePage() {
		try {
			uri = new URL(TestBase.driver.getCurrentUrl());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		tb.navigateURL("https://" + uri.getHost() + "/lightning/page/home");
	}
}
