package testcasesEE;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.LeadConversionAction;
import pageAction.LeadCreationAction;
import testcases.HomePageTest;
import testcases.LoginAsUser;
import utilities.Excel_DP;
import utilities.RunMode;

public class LeadCreationEETest {


	LeadCreationAction 	leadCreationAction=new 	LeadCreationAction();
	LeadConversionAction leadConvertionAction=new LeadConversionAction();
	CommonSteps CS=new CommonSteps();
	TestBase tb = new TestBase ();
	HomePageTest hpt = new HomePageTest();

	int rowNum = 1;

	boolean firstLogin = true;
	boolean changeloging = true;
	String previousLOB = "";
	
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void leadCreateToConvertEE(String firstName,String lastName, String leadStatus,
			String leadSource, String productInterest, String phone, String mobile, String email, 
			String street,String city, String state,String postal,String country, String company, String birthDate, String companySize, String businessType,
			String industry, String subIndustry,String lob,String accountClass, String referralName, String maidenName, String personalTIN, String role, String assignQueue, 
			String user) {

		String methodName = "leadCreateToConvertEE";
		
		if(!(RunMode.isTestRunnable(methodName))){
			throw new SkipException("Skipping the test " + methodName.toUpperCase() + "as the Run mode is NO");
		}

		SoftAssert softAssert =new SoftAssert();

		try {
			if(!lob.equalsIgnoreCase(previousLOB)) {
				LoginAsUser.logout();
				LoginAsUser.loginAsUser(user);
				tb.driver.navigate().refresh();
				Thread.sleep(2000);

			}
			LoginAsUser.homepagefeature("Leads");
			//tb.driver.navigate().refresh();
			Thread.sleep(2000);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			String queueName=null;
			Thread.sleep(2000);

			leadCreationAction.click_on_NewBtn();
			Thread.sleep(2000);
			CS.click_on_Next();
			//TestBase.takeScreenshot();
			//Required Field: Mother's Maiden Name,Personal TIN, Lead Role, Title, First Name, LOB, Account Class
			leadCreationAction.firstName(firstName);
			leadCreationAction.titleandRole(role);
			leadCreationRequiredDataEE(lastName, leadStatus, leadSource, productInterest, phone, mobile, email, street, city, state, postal, country, company, birthDate);
			//TestBase.takeScreenshot();
			leadCreationAction.motherMaidenName(maidenName);
			leadCreationAction.personalTIN(personalTIN);
			leadCreationAction.lob(lob);
			leadCreationAction.accountClass(accountClass);

			if(leadSource.equalsIgnoreCase("Employee Referral")||leadSource.equalsIgnoreCase("Event")||leadSource.equalsIgnoreCase("External Referral")||leadSource.equalsIgnoreCase("Trade Show"))
			{
				leadCreationAction.referralName(referralName.trim());
			}

			//TestBase.takeScreenshot();
			leadCreationAction.clickOnsaveBtn();

			try { 
				if(tb.element("errorOnLeadPage_XPATH").isDisplayed()) {
					tb.takeScreenshot();
					String ErrorMSG=null;
					try {
						ErrorMSG = tb.element("errorMSG_XPATH").getText();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					rowNum=rowNum+1;
					TestBase.test.log(LogStatus.FAIL, ErrorMSG);
					//Excel_DP.excel.setCellData("lead_AssignmentToQueue", "Error", rowNum, ErrorMSG);
					leadCreationAction.clickOnCancel();
					softAssert.assertTrue(false, ErrorMSG);
				}

			} catch (Exception e) {
				
				e.printStackTrace();
				Thread.sleep(1000);
				//tb.driver.navigate().refresh(); 
				//Thread.sleep(2000);
				leadCreationAction.markLeadStatusAsQualified();
				Thread.sleep(1000);		
				tb.driver.navigate().refresh();
				CS.clickOnDetail();
				Thread.sleep(1000);
				JavascriptExecutor js = (JavascriptExecutor) tb.driver;
				js.executeScript("arguments[0].scrollIntoView();", tb.driver.findElement(By.xpath("(//span[text()='Lead Information'])")));
				Thread.sleep(1000);
				tb.takeScreenshot();
				
				//convert if Lead Role <> "Authorized Signatory"
				if(!role.equals("Authorized Signatory")) {
					System.out.println("RM TO CONVERT...");
					js.executeScript("arguments[0].scrollIntoView();", tb.driver.findElement(By.xpath("//p[text()='Company']")));
					leadConvertionAction.convertLead();
					Thread.sleep(2000);
					tb.takeScreenshot();
				}
				
				rowNum = rowNum+1;
				System.out.println("rowNum: "+rowNum);

				try {
					queueName=leadCreationAction.getQueueOrOwnerName();
					System.out.println("Lead Owner :"+queueName);

				} 

				catch (Exception e1) {
					queueName="NULL";
//					Excel_DP.excel.setCellData(methodName, "Assigned to", rowNum,queueName);	
				}
				Excel_DP.excel.setCellData(methodName, "Assigned to", rowNum, queueName);


				/*if(assignQueue.toString().trim().equalsIgnoreCase(queueName)) {
					tb.test.log(LogStatus.INFO, "Assigned :"+queueName+ " Given :"+assignQueue+" Queue Matched");
				}
				else
				{
					tb.test.log(LogStatus.INFO, "Assigned "+queueName+" Given "+assignQueue+" Queue did not match");
				}	*/

			}
		} catch (Throwable e) {
			rowNum = rowNum+1;
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/*
		 * try { hpt.homepage_test(); } catch (Throwable e) { // TODO Auto-generated
		 * catch block e.printStackTrace(); }
		 */
		previousLOB = lob;
		firstLogin = false;
		softAssert.assertAll();
	}

	public void leadCreationRequiredDataEE(String lastName,String leadStatus,String leadSource, String productInterest,String phone,String mobile,String email, 
			String street, String city, String state,String postal,String country,String company, String birthDate ) {

		leadCreationAction.lastName(lastName);
		//TestBase.takeScreenshot();
		//leadCreationAction.leadStatus(leadStatus.trim());
		leadCreationAction.leadSource(leadSource.trim());
		leadCreationAction.productInterest(productInterest.trim());
		//TestBase.takeScreenshot();
		leadCreationAction.phone(phone.trim());
		leadCreationAction.mobile(mobile.trim());
		leadCreationAction.email(email.trim());
		
		leadCreationAction.birthDate(birthDate);//Birthdate
		leadCreationAction.company(company);//Company
		
		//TestBase.takeScreenshot();
		leadCreationAction.street(street);
		leadCreationAction.city(city.trim());
		leadCreationAction.state(state.trim());
		leadCreationAction.postal(postal.trim());
		leadCreationAction.country(country.trim());
		leadCreationAction.company(company.trim());

	}

}
