package testcasesEE;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import base.TestBase;
import pageAction.QuotePageAction;
import testcases.LoginAsUser;
import testcases.QuoteTest;
import testcases.Setup;

public class QuoteEETest extends Setup {

	QuotePageAction quotePageAction=new QuotePageAction();
	QuoteTest QT = new QuoteTest();
	TestBase tb= new TestBase();

	@Test
	public void quoteEETest() {
		
		try {
			
			LoginAsUser.loginAsUser("Admin");
			Thread.sleep(20000);
		
			tb.driver.get("https://pldtoneenterprise--r2xuat.lightning.force.com/one/one.app#eyJjb21wb25lbnREZWYiOiJvbmU6YWxvaGFQYWdlIiwiYXR0cmlidXRlcyI6eyJhZGRyZXNzIjoiaHR0cHM6Ly9wbGR0b25lZW50ZXJwcmlzZS0tcjJ4dWF0LmxpZ2h0bmluZy5mb3JjZS5jb20vYXBleC92bG9jaXR5X2NtdF9fT21uaVNjcmlwdFVuaXZlcnNhbFBhZ2U%2FaWQ9MDA2MXMwMDAwMDVTZUdOJmxheW91dD1uZXdwb3J0Iy9PbW5pU2NyaXB0VHlwZS9TTUFSVC9PbW5pU2NyaXB0U3ViVHlwZS9TNEludmVudG9yeUNoZWNrL09tbmlTY3JpcHRMYW5nL0VuZ2xpc2gvQ29udGV4dElkLzAwNjFzMDAwMDA1U2VHTi9QcmVmaWxsRGF0YVJhcHRvckJ1bmRsZS8vdHJ1ZSJ9LCJzdGF0ZSI6e319");
			Thread.sleep(25000);
			
			tb.driver.switchTo().frame(0);
			
			FileWriter wr = new FileWriter(System.getProperty("user.dir") + "\\src\\test\\resources\\result.csv", true);
			BufferedWriter bw = new BufferedWriter(wr);
			
			List<WebElement> devices = tb.driver.findElements(By.xpath("//table/tbody/tr/td[1]"));
			List<WebElement> status = tb.driver.findElements(By.xpath("//table/tbody/tr/td[5]"));
			
			int rows = devices.size();
			
			//validate status and write to CSV
			for(int i=0; i<rows; i++) {
				System.out.println(devices.get(i).getText() + "|" + status.get(i).getText());
				
				bw.write(devices.get(i).getText());
				bw.write("|");
				bw.write(status.get(i).getText());
				bw.write("|");
				
				if (!status.get(i).getText().contentEquals("AVAILABLE")) {
					System.out.println(devices.get(i).getText() + "|" + status.get(i).getText() + "|FAILED");
					bw.write("FAILED");
				} else {
					System.out.println(devices.get(i).getText() + "|" + status.get(i).getText() + "|PASSED");
					bw.write("PASSED");
				}
				
				bw.newLine();
			}
			
			bw.close();
			
		} catch (Throwable e) {
			e.printStackTrace();
		}

		
	}
}
