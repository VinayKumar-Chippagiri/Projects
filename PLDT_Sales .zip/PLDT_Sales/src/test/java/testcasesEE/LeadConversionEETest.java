package testcasesEE;

import org.testng.annotations.Test;

import base.TestBase;
import pageAction.CommonSteps;
import testcases.LeadConversionTest;
import utilities.Excel_DP;
public class LeadConversionEETest {

	LeadConversionTest leadConvertionTest =new LeadConversionTest();
	CommonSteps leadStatusObj=new CommonSteps();
	TestBase tb=new TestBase();
	String previousLOB=null;
	
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void leadConversionEE(String queuename, String leadname,String lob, String checkOppty ) {

		leadConvertionTest.leadConversionTest(queuename, leadname, lob, checkOppty);
	}

}
