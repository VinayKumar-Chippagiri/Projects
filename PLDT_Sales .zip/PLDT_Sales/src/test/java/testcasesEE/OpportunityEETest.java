package testcasesEE;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.LeadCreationAction;
import pageAction.OpportunityCreationAction;
import testcases.CreateContractTest;
import testcases.LoginAsUser;
import testcases.OpportunityTest;
import testcases.QuoteTest;
import utilities.Excel_DP;
import utilities.RunMode;

public class OpportunityEETest {

	OpportunityCreationAction OpportunityCreationAction = new OpportunityCreationAction();
	LeadCreationAction leadCreationAction = new LeadCreationAction();
	TestBase tb = new TestBase();
	QuoteTest qt=new QuoteTest();
	CreateContractTest createContractTest=new CreateContractTest();
	OpportunityTest opportunityTest = new OpportunityTest();
	int rownum = 1;
	String previousLOB = null;
	static boolean flag=false;
	
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void opptyEERequiredData(String OpportunityName, String ContractingParty, String OpportunintyType,
			String closeDate, String stage, String opportunintyCurrency, String NumberofContractMonth,
			String AccountName, String Product, String Price,String DeviceName, String DeviceCapcity, String DeviceColor,String SecondDevice,String vasName, String accessoriesName,String Addons,String DiscountOnPlanMSF,String DiscountOnDevive, String
			OrderQuantity,String vanityNoType, String queueName,String creditCondition, String startDate, String contractMonths, String contractTemplate,String ETSSolutionDesignString, String contractTerm, String speed, String PaymentMethod,String PlanName, String PaymentFrequency, String NumberType ) {
		
		String methodName = "opptyEERequiredData";

		if (!(RunMode.isTestRunnable(methodName))) {
			throw new SkipException("Skipping the test " + methodName.toUpperCase() + "as the Run mode is NO");
		}

		SoftAssert softAssert = new SoftAssert();
		
		//generate unique Opportunity name using timestamp
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
		String timeStamp  = dateFormat.format(new Date());
		OpportunityName = OpportunityName + timeStamp; 
		
		try {
			if (!ContractingParty.equalsIgnoreCase(previousLOB)) {
				LoginAsUser.logout();
				LoginAsUser.loginAsUser("EE " + ContractingParty);
				Thread.sleep(4000);
				tb.driver.navigate().refresh();
			}
			LoginAsUser.homepagefeature("Opportunities");

			Thread.sleep(2000);
			// tb.driver.navigate().refresh();
		} catch (Throwable e) {
			e.printStackTrace();
		}

		try {
			OpportunityCreationAction.click_on_new();
			OpportunityCreationAction.Enter_OpportunityName(OpportunityName);
			OpportunityCreationAction.Enter_AccountName(AccountName);
			OpportunityCreationAction.EnterContractingParty(ContractingParty);
			OpportunityCreationAction.OpportunintyType(OpportunintyType);
			OpportunityCreationAction.Enter_CloseDate(closeDate);
			OpportunityCreationAction.stage(stage);
			OpportunityCreationAction.opportunintyCurrency(opportunintyCurrency);
			OpportunityCreationAction.NumberofContractMonth(NumberofContractMonth);

			tb.takeScreenshot();
			Thread.sleep(1000);

			OpportunityCreationAction.clickonSave();
			tb.waitElementtoBecomeInvisble("save_XPATH");
			
			try {
				if (tb.element("errorOnLeadPage_XPATH").isDisplayed()) {
					tb.takeScreenshot();
					String ErrorMSG = tb.element("errorMSG_XPATH").getText();
					TestBase.test.log(LogStatus.FAIL, ErrorMSG);
					OpportunityCreationAction.clickOnCancel();
					rownum = rownum + 1;
					softAssert.assertTrue(false, ErrorMSG);
					// Excel_DP.excel.setCellData("createOpportunityWithRequireddata", "Error",
					// rownum, tb.element("errorMSG_XPATH").getText());
				}
			} catch (Exception e) {
				tb.driver.navigate().refresh();
				CommonSteps.clickOnDetail();
				Thread.sleep(10000);
				tb.takeScreenshot();

				opportunityTest.addProductToCart(ContractingParty,Product,DeviceName, DeviceCapcity,DeviceColor, SecondDevice,vasName, accessoriesName,Addons,DiscountOnPlanMSF,DiscountOnDevive, vanityNoType, OrderQuantity, 
						ETSSolutionDesignString,contractTerm,  speed,  PaymentMethod, PlanName,  PaymentFrequency, NumberType);


				tb.takeScreenshot();
				Thread.sleep(10000);
				CommonSteps.clickOnDetail();

				Thread.sleep(10000);
				tb.takeScreenshot();


				String opptyURL = tb.driver.getCurrentUrl(); 
				flag=true;
				//qt.quoteTest("",ContractingParty, queueName, "Business", creditCondition,Product, NumberType);

				
				//createContractTest.createContractTest(startDate, contractMonths, contractTemplate);

			}

		} catch (Exception e) {
			e.printStackTrace();
			rownum = rownum + 1;
		}

		tb.takeScreenshot();
		
		previousLOB = "EE " + ContractingParty;
		softAssert.assertAll();

	}

}
