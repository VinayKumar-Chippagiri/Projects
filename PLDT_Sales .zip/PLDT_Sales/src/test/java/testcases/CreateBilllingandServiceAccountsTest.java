package testcases;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.CreateBillingandServiceAccountsAction;
import utilities.Excel_DP;
import utilities.RunMode;

public class CreateBilllingandServiceAccountsTest {

	CreateBillingandServiceAccountsAction createBillingandServiceAccountsAction = new CreateBillingandServiceAccountsAction();
	TestBase tb = new TestBase();
	int rownum = 1;
	String previousLOB = null;

	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata",enabled = false)
	public void createNewBillingAccount(String parent, String name, String lob, String currency,
			String industry,String industrySubType, String accountTypeCode, String accountOf, String AccountOfBizAct, String CIFirstName,
			String CIMidName, String CILastName,String creditLimit, String thsStatus, String thsRating, String subscription,
			String serviceProvider,String notifyMailId, String creditClass, String notifyMobileNo, String phone, String accountPaymentType,
			String customerGroup, String taxExemption, String taxProfile, String billFrequency, String VIPCode, String BillDispatchMethod,
			String BillCycle, String BillingAddrLine1, String BillingAddrLine2, String BillingAddrLine3, String BillingCountry, String BillingCity,
			String Barangay, String BillingStateProvince, String BillingZipPostal) {

		String methodName = "createNewBillingAccount";


		SoftAssert softAssert = new SoftAssert();

		/*
		 * try { if (!lob.equalsIgnoreCase(previousLOB)) { LoginAsUser.logout();
		 * LoginAsUser.loginAsUser(lob); Thread.sleep(4000);
		 * tb.driver.navigate().refresh(); }
		 * //LoginAsUser.homepagefeature("Accounts"); tb.driver.get(
		 * "https://pldtoneenterprise--r2xuat.lightning.force.com/lightning/r/Account/0011s00000abi8LAAQ/view"
		 * ); tb.ThreadWait(5000);
		 *
		 * } catch (Throwable e) { e.printStackTrace(); }
		 */

		try {

			// search and view parent account
			//searchAndViewAccount(parent);
			//			tb.refreshPage();



			// create new Billing or Billing Aggregator
			createBillingandServiceAccountsAction.clickNewBilling();
			//tb.ExplicitWait("newBilling_AccountName_XPATH");

			if (!name.isEmpty()) {
				//createBillingandServiceAccountsAction.deleteAccountName();
				createBillingandServiceAccountsAction.enterAccountName(name);
			}

			createBillingandServiceAccountsAction.selectLOB(lob);
			createBillingandServiceAccountsAction.selectCurrency(currency);
			createBillingandServiceAccountsAction.enterIndustry(industry);
			createBillingandServiceAccountsAction.enterIndustrySubType(industrySubType);
			createBillingandServiceAccountsAction.selectBillFrequency(billFrequency);
			createBillingandServiceAccountsAction.enterBillDispatchMethod(BillDispatchMethod);
			createBillingandServiceAccountsAction.enterBillCycle(BillCycle);
			//createBillingandServiceAccountsAction.selectCreditClass(creditClass);
			createBillingandServiceAccountsAction.selectTaxExemption(taxExemption);
			createBillingandServiceAccountsAction.enterTaxProfile(taxProfile);
			createBillingandServiceAccountsAction.selectAccountPaymentType(accountPaymentType);
			createBillingandServiceAccountsAction.enterAccountTypeCode(accountTypeCode);
			//createBillingandServiceAccountsAction.enterServiceProvider(serviceProvider);
			//createBillingandServiceAccountsAction.enterTHSStatus(thsStatus);
			createBillingandServiceAccountsAction.enterTHSRating(thsRating);
			createBillingandServiceAccountsAction.enterSubscription(subscription);
			tb.ThreadWait(2000);
			createBillingandServiceAccountsAction.enterVIPCode(VIPCode);
			createBillingandServiceAccountsAction.enterForTheAccountOf(accountOf);

			createBillingandServiceAccountsAction.enterAccountOfBizAccount(AccountOfBizAct);
			createBillingandServiceAccountsAction.enterAssigneeCIFirstName(CIFirstName);
			createBillingandServiceAccountsAction.enterAssigneeCIMiddleName(CIMidName);
			createBillingandServiceAccountsAction.enterAssigneeCILastName(CILastName);
			//createBillingandServiceAccountsAction.enterCreditLimit(creditLimit);
			tb.ThreadWait(2000);
			createBillingandServiceAccountsAction.enterNotifyMailId(notifyMailId);
			createBillingandServiceAccountsAction.enterNotifyMobile(notifyMobileNo);
			//createBillingandServiceAccountsAction.enterPhone(phone);
			createBillingandServiceAccountsAction.enterBillingAddrLine1(BillingAddrLine1);
			createBillingandServiceAccountsAction.enterBillingAddrLine2(BillingAddrLine2);
			//createBillingandServiceAccountsAction.enterBillingAddrLine3(BillingAddrLine3);
			//createBillingandServiceAccountsAction.enterBillingCountry(BillingCountry);
			createBillingandServiceAccountsAction.enterBillingCity(BillingCity);
			createBillingandServiceAccountsAction.enterBarangay(Barangay);
			//createBillingandServiceAccountsAction.enterBillingStateProvince(BillingStateProvince);
			createBillingandServiceAccountsAction.enterBillingBillingZipPostal(BillingZipPostal.replace(".0", ""));

			tb.takeScreenshot();
			createBillingandServiceAccountsAction.clickSave();

             CommonSteps.waitForAccountPage();


			/*
			 * createBillingandServiceAccountsAction.enterStreet(street);
			 * createBillingandServiceAccountsAction.enterCity(city);
			 * createBillingandServiceAccountsAction.enterStateProvince(province);
			 * createBillingandServiceAccountsAction.enterZipCode(zip);
			 * createBillingandServiceAccountsAction.enterCountry(country);
			 */

//
//			try { // check for errors
//				System.out.println("inside try for errors...");
//				if (tb.element("errorOnLeadPage_XPATH").isDisplayed()) {
//					tb.takeScreenshot();
//					String ErrorMSG = null;
//
//					try {
//						ErrorMSG = tb.element("errorOnLeadPage_XPATH").getText();
//
//					} catch (Exception e) {
//						//						e.printStackTrace();
//					}
//					System.out.println(ErrorMSG);
//					tb.test.log(LogStatus.FAIL, ErrorMSG);
//					Excel_DP.excel.setCellData(methodName, "Error", rownum, ErrorMSG);
//					createBillingandServiceAccountsAction.clickCancel();
//					rownum = rownum + 1;
//
//					softAssert.assertTrue(false, ErrorMSG);
//					softAssert.assertAll();
//				}
//			} catch (Exception e) {
//				//				tb.wait.until(ExpectedConditions.titleContains(parent));
//				tb.takeScreenshot();
//				rownum = rownum + 1;
//				tb.WaitTillPresenseofElement("detailBtn_XPATH");
//				tb.navigateURL(com.smart.testcases.QuoteTest4.quoteURL);
//				tb.ExplicitWait("QuoteNumber_XPATH");
//
//				System.out.println("\n=====================\n");
//
//			}

		} catch (Exception e1) {
			e1.printStackTrace();
		}


		previousLOB = lob;
		softAssert.assertAll();
	}

	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void createNewBillingAggrAccount(String testCaseNo, String parent, String name, String lob, String currency,
			String street, String city, String province, String zip, String country, String user) {

		String methodName = "createNewBillingAggrAccount";

		if (!(RunMode.isTestRunnable(methodName))) {
			throw new SkipException("Skipping the test " + methodName.toUpperCase() + "as the Run mode is NO");
		}

		SoftAssert softAssert = new SoftAssert();

		try {
			if (!lob.equalsIgnoreCase(previousLOB)) {
				LoginAsUser.logout();
				LoginAsUser.loginAsUser(lob);
				Thread.sleep(4000);
				tb.driver.navigate().refresh();
			}
			LoginAsUser.homepagefeature("Accounts");
		} catch (Throwable e) {
			e.printStackTrace();
		}

		try {

			// search and view parent account
			searchAndViewAccount(parent);
			//			tb.refreshPage();

			// create new Billing or Billing Aggregator
			createBillingandServiceAccountsAction.clickNewBillingAgg();
			tb.wait.until(ExpectedConditions.titleContains("New Billing Aggregator"));

			if (!name.isEmpty()) {
				createBillingandServiceAccountsAction.deleteAccountName();
				createBillingandServiceAccountsAction.enterAccountName(name);
			}

			createBillingandServiceAccountsAction.selectLOB(lob);
			//			createBillingandServiceAccountsAction.selectCurrency(currency);
			createBillingandServiceAccountsAction.enterStreet(street);
			createBillingandServiceAccountsAction.enterCity(city);
			createBillingandServiceAccountsAction.enterStateProvince(province);
			createBillingandServiceAccountsAction.enterZipCode(zip);
			//createBillingandServiceAccountsAction.enterCountry(country);
			createBillingandServiceAccountsAction.clickSave();

			try { // check for errors
				System.out.println("inside try for errors...");
				if (tb.element("errorOnLeadPage_XPATH").isDisplayed()) {
					tb.takeScreenshot();
					String ErrorMSG = null;

					try {
						ErrorMSG = tb.element("errorMSG_XPATH").getText();

					} catch (Exception e) {
						//						e.printStackTrace();
					}

					tb.test.log(LogStatus.FAIL, ErrorMSG);
					Excel_DP.excel.setCellData(methodName, "Error", rownum, ErrorMSG);
					createBillingandServiceAccountsAction.clickCancel();
					rownum = rownum + 1;

					softAssert.assertTrue(false, ErrorMSG);
				}
			} catch (Exception e) {
				//				tb.wait.until(ExpectedConditions.titleContains(parent));
				tb.takeScreenshot();
				rownum = rownum + 1;

			}

		} catch (Exception e1) {
			e1.printStackTrace();
		}

		previousLOB = lob;
		softAssert.assertAll();
	}

	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void createNewServiceAccount(String parent, String name,String contact,String street, String city,
			String province, String zip, String country, String lob, String phone) {

		String methodName = "createNewServiceAccount";

	

		SoftAssert softAssert = new SoftAssert();

		/*
		 * try { if (!lob.equalsIgnoreCase(previousLOB)) { LoginAsUser.logout();
		 * LoginAsUser.loginAsUser(lob); Thread.sleep(4000);
		 * tb.driver.navigate().refresh(); }
		 * //LoginAsUser.homepagefeature("Accounts"); tb.navigateURL(
		 * "https://pldtoneenterprise--r2xuat.lightning.force.com/lightning/r/Account/0011s00000abi8LAAQ/view"
		 * ); tb.ThreadWait(5000); } catch (Throwable e) { e.printStackTrace(); }
		 */

		try {

			// search and view parent account
			//searchAndViewAccount(parent);
			//			tb.refreshPage();

			// create new Billing or Billing Aggregator

			createBillingandServiceAccountsAction.clickNewService();
			tb.ExplicitWait("newBilling_AccountName_XPATH");

			if (!name.isEmpty()) {
				//createBillingandServiceAccountsAction.deleteAccountName();
				createBillingandServiceAccountsAction.enterAccountName(name);
			}
			//createBillingandServiceAccountsAction.selectLOB(lob);

			//createBillingandServiceAccountsAction.selectServiceBillingAccount(billingAccount);
			//createBillingandServiceAccountsAction.enterServiceAccountNumber(accountNumber);
			//createBillingandServiceAccountsAction.selectServiceContact(contact);
			//createBillingandServiceAccountsAction.selectServiceStatus(status);
			//createBillingandServiceAccountsAction.enterServiceRecipientName(deliveryRecipientName);
			//createBillingandServiceAccountsAction.enterServiceRecipientNo(deliveryRecipientNo);

			createBillingandServiceAccountsAction.enterStreet(street);
			createBillingandServiceAccountsAction.enterCity(city);
			createBillingandServiceAccountsAction.enterStateProvince(province);
			createBillingandServiceAccountsAction.enterZipCode(zip.replace(".0", ""));
			createBillingandServiceAccountsAction.enterCountry(country);
			
			tb.takeScreenshot();
			createBillingandServiceAccountsAction.clickSave();
			CommonSteps.waitForAccountPage();
			
//			try { // check for errors
//				System.out.println("inside try for errors...");
//				if (tb.element("errorOnLeadPage_XPATH").isDisplayed()) {
//					tb.takeScreenshot();
//					String ErrorMSG = null;
//
//					try {
//						ErrorMSG = tb.element("errorOnLeadPage_XPATH").getText();
//
//					} catch (Exception e) {
//						//						e.printStackTrace();
//					}
//					System.out.println(ErrorMSG);
//
//					tb.test.log(LogStatus.FAIL, ErrorMSG);
//					Excel_DP.excel.setCellData(methodName, "Error", rownum, ErrorMSG);
//					createBillingandServiceAccountsAction.clickCancel();
//					rownum = rownum + 1;
//
//					//softAssert.assertTrue(false, ErrorMSG);
//				}
//				tb.ThreadWait(1000);
//
//
//			} catch (Exception e) {
//				//				tb.wait.until(ExpectedConditions.titleContains(parent));
//
//				/*
//				 * createBillingandServiceAccountsAction.enterAccountNameToSearch(name);
//				 * tb.ThreadWait(1000); createBillingandServiceAccountsAction.clickAccountNameLink(name);
//				 */
//				// createBillingandServiceAccountsAction.editServicePhoneNumber(phone);
//				//createBillingandServiceAccountsAction.clickSaveOnDetailsTab(); tb.ThreadWait(1000);
//				//tb.takeScreenshot(); rownum = rownum + 1;
//
//
//				tb.WaitTillPresenseofElement("detailBtn_XPATH");
//				tb.takeScreenshot();
//				tb.navigateURL(com.smart.testcases.QuoteTest4.quoteURL);
//				tb.ExplicitWait("QuoteNumber_XPATH");
//
//				System.out.println("\n=====================\n");
//
//			}

		} catch (Exception e1) {
			e1.printStackTrace();
		}

		previousLOB = lob;
		//softAssert.assertAll();
	}

	// reusable methods
	public void searchAndViewAccount(String searchText) throws InterruptedException {
		System.out.println("Search and View Account details: " + searchText);

		createBillingandServiceAccountsAction.selectAllAccountsListView();
		createBillingandServiceAccountsAction.enterAccountNameToSearch(searchText);
		Thread.sleep(2000);
		createBillingandServiceAccountsAction.clickRefresh();
		createBillingandServiceAccountsAction.clickAccountNameLink(searchText);
		Thread.sleep(2000);

	}

}
