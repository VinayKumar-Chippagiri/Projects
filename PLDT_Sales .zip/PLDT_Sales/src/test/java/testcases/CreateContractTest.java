package testcases;

import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.CreateContractAction;
import pageAction.LeadConversionAction;
import pageAction.LeadCreationAction;
import pageAction.QuotePageAction;
import utilities.Excel_DP;
import utilities.RunMode;

public class CreateContractTest extends Setup
{
	LeadConversionAction leadConvertionAction=new LeadConversionAction();
	LeadCreationAction 	leadCreationAction=new 	LeadCreationAction();
	CreateContractAction createContractAction=new CreateContractAction();
	
	TestBase tb = new TestBase ();
	String previousLOB = "";

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void createContractTest (String contractTemplate,String type) {

		if(!(RunMode.isTestRunnable("createContractTest"))){

			throw new SkipException("Skipping the test "+"createContractTest".toUpperCase()+ "as the Run mode is NO");
		}
		     SoftAssert softAssert =new SoftAssert();
		try {

			createContractAction.createContractFromQuote();
			System.out.println(" Contract Created....");
			tb.ExplicitWait("NegotiatingStage_XPATH");
			//CommonSteps.clickOnDetail();
			Thread.sleep(3000);
			tb.takeScreenshot();
//			createContractAction.editContract(startDate, contractMonth);
//			leadCreationAction.clickOnsaveBtn();
			//createContractAction.GenerateDocument(contractTemplate);
			
			tb.ExplicitWait("NegotiatingStage_XPATH");
			tb.takeScreenshot();			
			
			createContractAction.MoveStageToNegociation();
			if(type.equalsIgnoreCase("Business")) {
			createContractAction.MoveStageToAwaitingSingnature();
			}
			createContractAction.MoveStageToSigned();
//			createContractAction.MoveStageToActivated();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


	@SuppressWarnings("static-access")
	@Test(enabled=false)
	public void createContractTest_Quote() {

		/*
		 * if(!(RunMode.isTestRunnable("createContractTest_Quote"))){
		 * 
		 * throw new
		 * SkipException("Skipping the test "+"createContractTest_Quote".toUpperCase()+
		 * "as the Run mode is NO"); }
		 */

		//SoftAssert softAssert =new SoftAssert();

		try {
			if(!"SMART".equalsIgnoreCase(previousLOB)) {
				LoginAsUser.logout();
				LoginAsUser.loginAsUser("SMART");
				Thread.sleep(4000);
				tb.driver.navigate().refresh();
			}
			LoginAsUser.homepagefeature("Quotes");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			leadConvertionAction.selectList();
			//leadConvertionAction.enterQueueName("All Quotes");
			Thread.sleep(2000);

			createContractAction.SelectAllQuotes();
			leadConvertionAction.searchLead("QuoteSearch_XPATH","New Opty");
			Thread.sleep(2000);
			leadConvertionAction.ClickOnLeadRecord();
			Thread.sleep(2000);
			tb.driver.switchTo().frame(0);
			createContractAction.createContractFromQuote();
			Thread.sleep(4000);
			createContractAction.editContract("11/30/2020", "12");
			leadCreationAction.clickOnsaveBtn();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
