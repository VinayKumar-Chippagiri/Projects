package testcases;

import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CreateAccountAction;
import utilities.Excel_DP;
import utilities.RunMode;

public class CreateAccountTest{
	
	CreateAccountAction createAccountAction =new CreateAccountAction();
	TestBase tb=new TestBase();
	int rownum=1;
	String previousLOB=null;
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void createAccountWithRequiredData(String accountName, String accountClass,String industry, String industrySubType, String AccountCurrency, String companyTin,String companySize, String Businesstype, String BusinessRigsType, String BusinessRigsNumber, String lob ) {
		 if(!(RunMode.isTestRunnable("createAccountWithRequiredData"))){
				
				throw new SkipException("Skipping the test "+"createAccountWithRequiredData".toUpperCase()+ "as the Run mode is NO");
			}
		 SoftAssert softAssert =new SoftAssert();
		 
		 try {
				if(!lob.equalsIgnoreCase(previousLOB)) {
					LoginAsUser.logout();
					LoginAsUser.loginAsUser(lob);
					Thread.sleep(4000);
					tb.driver.navigate().refresh();
				}
				LoginAsUser.homepagefeature("Accounts");
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		try {
			createAccountAction.click_on_new();
			createAccountAction.click_on_Next();
			createAccountAction.accountName(accountName);
			//createAccountAction.parentAccount();
			createAccountAction.accountClass(accountClass);
			createAccountAction.industry(industry);
			createAccountAction.industrySubType(industrySubType);
			createAccountAction.AccountCurrency(AccountCurrency);
			createAccountAction.companyTin(companyTin);
			createAccountAction.companySize(companySize);
			createAccountAction.Businesstype(Businesstype);
			createAccountAction.BusinessRigsType(BusinessRigsType);
			createAccountAction.BusinessRigsNumber(BusinessRigsNumber);
			createAccountAction.clickonSave();
			 try {
					if(tb.element("errorOnLeadPage_XPATH").isDisplayed()) {
						tb.takeScreenshot();
						 String ErrorMSG=null;
						try {
							ErrorMSG = tb.element("errorMSG_XPATH").getText();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 TestBase.test.log(LogStatus.FAIL, ErrorMSG);
						 Excel_DP.excel.setCellData("createAccountWithRequiredData", "Error", rownum, ErrorMSG);
						 createAccountAction.clickOnCancel();
						 rownum=rownum+1;
						 
						 softAssert.assertTrue(false, ErrorMSG);
						
					 }
				} catch (Exception e) {
					tb.takeScreenshot();
					 rownum=rownum+1;
					 
					
				}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
			previousLOB=lob;
		softAssert.assertAll();
	}
	}


