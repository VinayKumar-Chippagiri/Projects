package testcases;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import base.TestBase;


public class Setup {
	
	TestBase cm=new TestBase();
@BeforeSuite(alwaysRun = true)
public void setup() {
	
System.out.println("inside the test");
	cm.setUp();
	
}
@AfterSuite	
public void teardown() {
	cm.tearDown();
	System.out.println("outside the test");
	
}
}
