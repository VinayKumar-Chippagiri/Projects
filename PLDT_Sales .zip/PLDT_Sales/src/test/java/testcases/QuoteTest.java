package testcases;

import java.util.Date;

import org.testng.SkipException;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.LeadConversionAction;
import pageAction.QuotePageAction;
import utilities.Excel_DP;
import utilities.RunMode;

public class QuoteTest extends Setup{

	QuotePageAction quotePageAction = new QuotePageAction();
	TestBase tb = new TestBase();
	HomePageTest hpt = new HomePageTest();
	LeadConversionAction leadConversionAction=new LeadConversionAction();
	CreateBilllingandServiceAccountsTest createOtherAccountsTest = new CreateBilllingandServiceAccountsTest();


	String quoteNo = "";
	String quoteName = "";
	String runStatus = "FAIL";
	static String quoteURL = null;

	// Create Quote, Credit Check, MoveStageTo Accepted
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void quoteTest(String QuoteURL, String ContractingParty, String queueName, String type, String creditCondition, String Product, String NumberType, String parent, String billingAccName, String lob, String currency,
			String industry,String industrySubType, String accountTypeCode, String accountOf, String AccountOfBizAct, String CIFirstName,
			String CIMidName, String CILastName,String creditLimit, String thsStatus, String thsRating, String subscription,
			String serviceProvider,String notifyMailId, String creditClass, String notifyMobileNo, String phone, String accountPaymentType,
			String customerGroup, String taxExemption, String taxProfile, String billFrequency, String VIPCode, String BillDispatchMethod,
			String BillCycle, String AddrLine1, String AddrLine2, String AddrLine3, String Country, String City,
			String Barangay, String StateProvince, String ZipPostal, String SeviceAccountName,String AuthorizeSigonatory, String BillRecipient,String DeliveryRecipient) {


		if (!(RunMode.isTestRunnable("quoteTest"))) {

			throw new SkipException(
					"Skipping the test " + "quoteTest".toUpperCase() + "as the Run mode is NO");
		}

		Date d= new Date();
		String date=d.toString().replace(":","").replace(" ", "").substring(0, 12);
		billingAccName=billingAccName+date;
		//SeviceAccountName=SeviceAccountName+date;
		SeviceAccountName="Service";


		try {

			//Ankita-Create Quote
			createQuote(QuoteURL, ContractingParty, Product);

			// Ankita-Device Availability Check
			try {

				DeviceAvailabilityCheck();

			} catch (SkipException e) {

				System.out.println("Skipped : Device Availability Check");
			}

			// James - Number Availability Check
			try {

				numberAvailabilityCheck(NumberType);

			} catch (SkipException e) {
				System.out.println("Skipped : Number Availability Check");
			}

			try {
				//Ankita : Create Billing Account from Quote
				createOtherAccountsTest.createNewBillingAccount(parent, billingAccName, lob, currency,  industry,
						industrySubType, accountTypeCode, accountOf, AccountOfBizAct, CIFirstName, CIMidName, CILastName, creditLimit, thsStatus, thsRating,
						subscription, serviceProvider, notifyMailId, creditClass, notifyMobileNo, phone, accountPaymentType,customerGroup,
						taxExemption, taxProfile, billFrequency, VIPCode, BillDispatchMethod, BillCycle, AddrLine1, AddrLine2, AddrLine3,
						Country, City, Barangay, StateProvince, ZipPostal);

			} catch (Exception e) {

				System.out.println("Skipped : Create New Billing Account");

			}

			try {

				createOtherAccountsTest.createNewServiceAccount(parent, SeviceAccountName, parent, AddrLine1, City, StateProvince, ZipPostal, Country, lob, phone);

			} catch (Exception e) {

				System.out.println("Skipped : Create New Service Account");

			}

			//Ankita :  Populate Quote Validity
			try {

				updateQuoteValidatyPeriod_DeliveryDate_ConatctDetails(AuthorizeSigonatory, BillRecipient, AuthorizeSigonatory, DeliveryRecipient);


			} catch (Exception e) {

				System.out.println("Skipped : Update Quote Validity, Delivery Date and Contact Details");
			}


			try {

				updateAccounts(billingAccName,SeviceAccountName);


			} catch (Exception e) {

				System.out.println("Skipped : Update Accounts");
			}

			//Amit ; Check if Solution design is required
			if (ContractingParty.contains("PLDT")|| Product.contains("A2P")|| Product.contains("M2M")||Product.contains("Digital")) {
				//Perform Solution Design
				try {

					performSolutionDesigning(quoteName, ContractingParty,queueName,type);

				} catch (Exception e) {

					System.out.println("Skipped : Solution Designing");
				}
			}

			//String cc = quotePageAction.getCreditCheckValue();
			//System.out.println(quoteName + " | " + quoteNo + " | " + cc);

			//Leonyl - credit check required
			//if (cc.contentEquals("Required")) {
				try {

					performCreditCheck(quoteName, quoteNo, queueName, ContractingParty, creditCondition,type);

				} catch (Exception e) {

					System.out.println("Skipped : Credit Check");
				}
			//}


			//Ankita : Move Quote to CustomerApproved
			try {
				MoveQuoteToCustomerApproved(type);
			} catch (Exception e) {

				System.out.println("Skipped : Custmore Approved");
			}
			try {
				//Ankita : Device Reservation Check
				DeviceReservationCheck();

			} catch (Exception e) {
				System.out.println("Skipped : Device Reservation Check");

			}

			//James : Number Reservation Check
			try {
				numberReservation(NumberType);

			} catch (Exception e) {

				e.printStackTrace();
				System.out.println("Skipped : Number Reservation Check");

			}
			try {
				//Ankita : Move Quote To Accepted
				MoveQuoteToAccepted();
			} catch (Exception e) {

				System.out.println("Skipped : Move Quote To Accepted");
			}


		}catch(	Exception e) {
			e.printStackTrace();
		}finally {
			tb.test.log(LogStatus.valueOf(runStatus), runStatus);
		}

	}
	public void createQuote(String QuoteURL, String ContractingParty, String Product ) {

		if(OpportunityTest.flag==false) {

			try {
				LoginAsUser.loginAsUser(ContractingParty);
				tb.ThreadWait(1000);
				tb.navigateURL(QuoteURL);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			// Ankita- create Quote form Opportunity

			//CommonSteps.clickOnDetail();
			tb.ThreadWait(2000);
			tb.takeScreenshot();
			quotePageAction.CreateQuote();

			System.out.println("Quote Created..");
		}

		//quote details
		quoteURL = tb.driver.getCurrentUrl();
		Excel_DP.excel.setCellData("quoteURL", "quoteURL", 2,  quoteURL);
		Excel_DP.excel.setCellData("quoteURL", "Product", 2, Product );
		quoteName = quotePageAction.getQuoteName();
		quoteNo = quotePageAction.getQuoteNumber();

		System.out.println("\n=====================\n");

	}
	// credit check test method
	@SuppressWarnings("static-access")
	public void performCreditCheck(String quoteName, String quoteNo, String queueName, String ContractingParty, String creditCondition, String type) {

		if (!(RunMode.isTestRunnable("performCreditCheck"))) {

			throw new SkipException(
					"Skipping the test " + "performCreditCheck".toUpperCase() + "as the Run mode is NO");
		}

		try {
			quotePageAction.clickOnCreditCheck();
			tb.ThreadWait(2000);

			tb.driver.navigate().refresh();
			tb.ThreadWait(2000);

			quotePageAction.clickOnNext();

			tb.ThreadWait(3000);

			tb.takeScreenshot();

			System.out.println("Perform Credit check: " + quoteNo);

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}


		loginCA_SearchQuote(ContractingParty, quoteName, "All Quotes","Credit " );


		try {

			editCreditInformation("Approved", creditCondition, "1", "1");
			Thread.sleep(2000);

			//LEONYL: below steps have been removed in R3
			//			tb.driver.navigate().refresh();
			//			tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Credit check for Quote :')]")));
			//			quotePageAction.creditCheckForQuote(quoteNo);


		} catch (Exception e) {
			e.printStackTrace();
		}

		//logout Credit Analyst
		tb.takeScreenshot();
		LoginAsUser.logout();

		//lnb : re-login as RM
		try {
			// EE RM user
			if(type.contentEquals("EE")) {
				ContractingParty = "EE " + ContractingParty;
			}

			LoginAsUser.loginAsUser(ContractingParty);

			Thread.sleep(4000);
			tb.driver.get(quoteURL);

			tb.driver.navigate().refresh();
			tb.ExplicitWait("QuoteNumber_XPATH");

		} catch (Throwable e) {
			e.printStackTrace();
		}

	}

	// Edit Credit Information on Quote details
	public void editCreditInformation(String status, String condition, String advPayInMos, String secDepinMos) {
		System.out.println("Edit Credit Information...");

		try {

			tb.ExplicitWait("QuoteNumber_XPATH");

			tb.Scroll("quoteCreditCheck_XPATH");

			tb.jsClick("EDITCreditApprovalCondition_XPATH");
			tb.ThreadWait(2000);

			//only for credit check
			if (!status.isEmpty()) {
				quotePageAction.editCreditApprovalStatus(status);
			}

			quotePageAction.editCreditApprovalCondition(condition);
			quotePageAction.editAdvancePaymentInMonths(advPayInMos);
			quotePageAction.editSecurityDepositInMonths(secDepinMos);
			quotePageAction.editCreditRemart("Credit Check Done");


			tb.takeScreenshot();

			Thread.sleep(2000);
			quotePageAction.saveEditedQuoteDetails();
			tb.waitElementtoBecomeInvisble("footer_XPATH");

		} catch (InterruptedException e) {
			e.printStackTrace();

		}

	}

	// Login as Credit Analyst and search for quote
	@SuppressWarnings("static-access")
	public void loginCA_SearchQuote(String contractingParty, String quoteName, String queueName,String user) {
		try {
			LoginAsUser.logout();


			System.out.println(user + contractingParty);
			LoginAsUser.loginAsUser(user + contractingParty);

			Thread.sleep(1000);
			tb.driver.navigate().refresh()
			;
			//			LoginAsUser.homepagefeature("Quotes");
			hpt.featureURL("Quote");

			quotePageAction.selectQuotesListView(queueName);
			Thread.sleep(1000);
			quotePageAction.searchQuote(quoteName);

			tb.takeScreenshot();

			Thread.sleep(2000);
			quotePageAction.clickQuoteRecord(quoteName);

		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
	//Ankita
	public void DeviceAvailabilityCheck() {

		if (!(RunMode.isTestRunnable("DeviceAvailabilityCheck"))) {

			throw new SkipException(
					"Skipping the test " + "DeviceAvailabilityCheck".toUpperCase() + "as the Run mode is NO");
		}

		quotePageAction.DeviceAvailabilityChceck(quoteName, runStatus);

	}
	//Ankita
	public void DeviceReservationCheck() {



		if (!(RunMode.isTestRunnable("DeviceReservationCheck"))) {

			throw new SkipException(
					"Skipping the test " + "DeviceReservationCheck".toUpperCase() + "as the Run mode is NO");
		}

		quotePageAction.DeviceReservation(quoteName,runStatus);

	}
	//Ankita
	public void MoveQuoteToCustomerApproved(String type) {

		if (!(RunMode.isTestRunnable("MoveQuoteToCustomerApproved"))) {

			throw new SkipException(
					"Skipping the test " + "MoveQuoteToCustomerApproved".toUpperCase() + "as the Run mode is NO");
		}

		//additional stages needed only for Business
		if(type.contentEquals("Business")) {

			quotePageAction.ChangeStatustoPresented();
			quotePageAction.ChangeStatustoCustomerApproved();

		}

	}
	public void MoveQuoteToAccepted() {

		if (!(RunMode.isTestRunnable("MoveQuoteToAccepted"))) {

			throw new SkipException(
					"Skipping the test " + "MoveQuoteToAccepted".toUpperCase() + "as the Run mode is NO");
		}

		quotePageAction.ChangeStatustoAccepted();


		tb.takeScreenshot();

	}

	//Amit: To perform Solution designing
	public void performSolutionDesigning( String OpportunityName, String ContractingParty, String queueName,String type) {

		if (!(RunMode.isTestRunnable("performSolutionDesigning"))) {

			throw new SkipException(
					"Skipping the test " + "performSolutionDesigning".toUpperCase() + "as the Run mode is NO");
		}

		//Click on Lock Cart
		try {

			boolean flag;

			do {
				try {
				quotePageAction.ClickOnTriggerSD();
				tb.ThreadWait(2000);

				tb.driver.navigate().refresh();

				tb.ThreadWait(2000);
				quotePageAction.clickOnNext();
				tb.ThreadWait(3000);


					tb.driver.switchTo().parentFrame();
					tb.ThreadWait(1000);
					tb.switchToFrame("Frame_XPATH");

					tb.ThreadWait(1000);
					tb.click("Menue_XPATH");
					tb.ExplicitWait("SolutionDesign_XPATH");

				} catch (Exception e) {

					tb.refreshPage();
					e.printStackTrace();
				}

				flag=tb.isElementDisplayed("SolutionDesign_XPATH");
			}

			while(!flag);

			tb.driver.switchTo().parentFrame();

			//Check if Solution Design button enabled
			if(flag) {

				loginCA_SearchQuote(ContractingParty, quoteName, "All Quotes","ETS " );

				String etsStatus = "";

				//Click on Solution Design
				do {

					try {
						//Select the Completed status
						quotePageAction.clickONSolutionDesign();
						quotePageAction.selectETSStatus("Completed");

						tb.driver.navigate().refresh();
						tb.ThreadWait(2000);

						tb.Scroll("CreditInformation_XPATH");
						etsStatus = quotePageAction.etsStatusVerify();
						System.out.println("etsStatus : "+etsStatus);
					} catch (Exception e) {

						tb.navigateURL(quoteURL);
						e.printStackTrace();
					}

				}
				while(!etsStatus.equalsIgnoreCase("Completed"));


				//Verify if the ETS Status is 'Completed'
				if (etsStatus.equalsIgnoreCase("Completed")){
					System.out.println("Pass");
					tb.test.log(LogStatus.PASS, etsStatus );
				}

				else {

					tb.test.log(LogStatus.FAIL, etsStatus );
				}


				//lnb : re-login as RM
				try {

					tb.takeScreenshot();
					LoginAsUser.logout();
					// EE RM user
					if(type.contentEquals("EE")) {
						ContractingParty = "EE " + ContractingParty;
					}

					LoginAsUser.loginAsUser(ContractingParty);

					Thread.sleep(4000);
					tb.driver.get(quoteURL);

					tb.driver.navigate().refresh();
					tb.ExplicitWait("QuoteNumber_XPATH");

				} catch (Throwable e) {
					e.printStackTrace();
				}

			}

		}
		catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}


	//James - NumberAvailabilityCheck
	public void numberAvailabilityCheck(String NumberType) {

		if (!(RunMode.isTestRunnable("NumberAvailabilityCheck"))) {

			throw new SkipException(
					"Skipping the test " + "NumberAvailabilityCheck".toUpperCase() + "as the Run mode is NO");
		}

		quotePageAction.numberAvailabilityCheck(quoteName,runStatus, NumberType);



	}

	//James - NumberReservation
	public void numberReservation(String NumberType) {

		if (!(RunMode.isTestRunnable("NumberReservation"))) {

			throw new SkipException(
					"Skipping the test " + "NumberReservation".toUpperCase() + "as the Run mode is NO");
		}

		quotePageAction.numberReservation(quoteName,runStatus, NumberType);


	}

	public void updateQuoteValidatyPeriod_DeliveryDate_ConatctDetails(String AuthorizeSigonatory, String BillRecipient, String CapContact, String DeliveryRecipient) {

		if (!(RunMode.isTestRunnable("updateQuoteValidatyPeriod_DeliveryDate_ConatctDetails"))) {

			throw new SkipException(
					"Skipping the test " + "updateQuoteValidatyPeriod_DeliveryDate_ConatctDetails".toUpperCase() + "as the Run mode is NO");
		}

		quotePageAction.updateQuoteValidatyPeriod_DeliveryDate_ConatctDetails(AuthorizeSigonatory, BillRecipient, CapContact, DeliveryRecipient);


	}

	public void updateAccounts(String BiilingAccountName, String ServiceAccountName) {

		if (!(RunMode.isTestRunnable("updateAccounts"))) {

			throw new SkipException(
					"Skipping the test " + "updateAccounts".toUpperCase() + "as the Run mode is NO");
		}

		quotePageAction.updateAccounts(BiilingAccountName, ServiceAccountName);

	}
}

