package testcases;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.LeadCreationAction;
import utilities.Excel_DP;

public class WebToLead {

	TestBase tb=new TestBase();
	LeadCreationAction leadCreationAction= new LeadCreationAction();
	boolean flag = true;
	int Row = 2;

	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void WebToLlead(String first_name,String last_name, String Industry,String Sub_Industry ,String BusinessType, String CompanySiZe,  
			String city,String state, String country,String zip, String queue,String actual) {

		SoftAssert  softAssert= new SoftAssert();
		String leadOwner="";
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
		String timeStamp  = dateFormat.format(new Date());
		
		Date d= new Date();
		String date=d.toString().replace(":","").replace(" ", "").substring(0, 12);
		
		first_name = first_name + date; 

		try {
			TestBase.driver.get("C:\\Users\\arathore\\Downloads\\web-to-lead-r32sit (4).html");
			TestBase.driver.findElement(By.id("first_name")).sendKeys(first_name);
			tb.driver.findElement(By.id("last_name")).sendKeys(last_name.trim());
			//tb.driver.findElement(By.id("phone")).sendKeys(timeStamp);
			tb.driver.findElement(By.id("mobile")).sendKeys(timeStamp);;
			tb.driver.findElement(By.id("email")).sendKeys(timeStamp+"@gmail.com");
			//tb.driver.findElement(By.id("00N2x000006cCzg")).sendKeys("10/02/1992");
			tb.driver.findElement(By.id("company")).sendKeys("PLDT"+timeStamp);
			tb.select("industry", Industry);
			tb.select("00N2x000006cD07", Sub_Industry);
			tb.select("00N2x000006cCzj", BusinessType);
			tb.select("00N2x000006cCzl", CompanySiZe);
			tb.select("country_code", country);
			//tb.driver.findElement(By.name("00N2x000006cCzs")).sendKeys("Fixed");
			tb.driver.findElement(By.name("street")).sendKeys(timeStamp);
			tb.select("state_code", state);
			tb.driver.findElement(By.name("city")).sendKeys(city.trim());
			//tb.driver.findElement(By.name("state")).sendKeys(state.trim());
			//tb.driver.findElement(By.name("country")).sendKeys(country.trim());
			tb.driver.findElement(By.name("zip")).sendKeys(zip.toString());
			tb.driver.findElement(By.name("00N1s0000019tqS")).click();
			tb.driver.findElement(By.name("00N1s0000019tqU")).click();
			tb.select("00N2x000006c9iI", "Fixed");
			tb.select("lead_source", "Web");
			tb.select("recordType", "Business");
			tb.select("00N2x000006cCzr", "PLDT");

			tb.driver.findElement(By.name("submit")).click();
			Thread.sleep(5000);
			
			if(flag) {
				LoginAsUser.loginAsUser("Admin");
			}
			TestBase.driver.get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/o/Lead/list?filterName=00B2x000001NAZlEAO");
			tb.ThreadWait(2000);
			CommonSteps.GoToRecord("All Open Leads", "leadSearchInput_XPATH", first_name+" "+last_name);
			tb.ThreadWait(3000);
			
			boolean noitem = false;
			
			try {
				//noitem = tb.element("NoItemtoDisplay_XPATH").isDisplayed();
				noitem=false;
				
			} catch (Exception e) {
				
			}
				System.out.println(noitem);
				if (noitem==true) {
					System.out.println("Take screenshot");
					tb.takeScreenshot();
					String ErrorMSG = tb.element("NoItemtoDisplay_XPATH").getText();
					TestBase.test.log(LogStatus.FAIL, ErrorMSG);
					System.out.println(ErrorMSG);
					softAssert.assertTrue(false, ErrorMSG);
				}
				else {
					
					System.out.println("Click On Detail");
					CommonSteps.clickOnDetail();
					tb.ThreadWait(2000);
					leadOwner=leadCreationAction.leadOwner();
					System.out.println("Expected :"+queue);
					System.out.println("Actual :"+leadCreationAction.leadOwner());
					tb.takeScreenshot();

				}
				
               

		}catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		

		if(leadOwner.equalsIgnoreCase(queue)) {

			System.out.println("PASS");
			tb.test.log(LogStatus.PASS, "Expected :"+queue+" Actual :"+leadOwner);
			Excel_DP.excel.setCellData("WebToLlead", "Actual Queue", Row, leadOwner);
			

		}
		else {

			softAssert.assertEquals(leadOwner, queue);
			System.out.println("Fail");
			tb.test.log(LogStatus.FAIL, "Expected :"+queue+" Actual :"+leadOwner);
			Excel_DP.excel.setCellData("WebToLlead", "Actual Queue", Row, leadOwner);

		}

		
		Row = Row+1;
         flag=false;
         

		softAssert.assertAll();
	}

}


