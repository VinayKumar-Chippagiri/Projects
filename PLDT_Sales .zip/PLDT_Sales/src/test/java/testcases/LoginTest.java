package testcases;

import org.testng.SkipException;
import org.testng.annotations.Test;
import loginAndHomePageAction.LoginAction;
import utilities.RunMode;
import utilities.ScriptMetaData;

public class LoginTest {

	LoginAction loginAction=new LoginAction();
	@ScriptMetaData(productionReady=true)
	@Test()
	public void logintest() throws Throwable  {
		if(!(RunMode.isTestRunnable("logintest"))){

			throw new SkipException("Skipping the test "+"logintest".toUpperCase()+ "as the Run mode is NO");
		}
		try {

			int rows =RunMode.excel.getRowCount("LoginTest");
			int cols = RunMode.excel.getColumnCount("LoginTest");
			System.out.println(rows);
			System.out.println(cols);
			for (int rowNum = 2; rowNum <=rows; rowNum++) { // 2

				String username=RunMode.excel.getCellData("LoginTest", 0, rowNum);
				String Password=RunMode.excel.getCellData("LoginTest", 1, rowNum);
				String runmode=RunMode.excel.getCellData("LoginTest", 2, rowNum);
				runmode = runmode.trim();
				System.out.println(Password);
				System.out.println(username);
				System.out.println(runmode);
				if(runmode.equalsIgnoreCase("Y")) {
					loginAction.enter_username(username);
					loginAction.enter_password(Password);
					//TestBase.takeScreenshot();
					loginAction.click_on_login_Btn();
					loginAction.verify_login();
				}
				}} catch(Exception e) {

				}
		}



	}
