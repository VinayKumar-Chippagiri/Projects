package testcases;

import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.smart.common.Login;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.CreateOrderAction;
import utilities.RunMode;

public class CreateOrderTest  {

	CreateOrderAction createOrderAction = new CreateOrderAction();

	TestBase tb=new TestBase();
	String previousLOB=null;
	static String QuoteName="NewOpportunity";
	static String OrderNumber=null;
	@SuppressWarnings("static-access")
	@Test
	public void createOrderTest(){

	
		SoftAssert softAssert = new SoftAssert();


		try {


			CommonSteps.clickOnDetail();

		tb.takeScreenshot();
			createOrderAction.goToQuote();

			String OrderNumber = null;
			OrderNumber = createOrderAction.clickOnOrdersTitle();
			createOrderAction.clickOnOrderLink(OrderNumber);
			createOrderAction.clickOnViewDecomposition();
			createOrderAction.clickOnViewOrchestrationPlan();
			createOrderAction.switchToOrchestrationPlanWindow();
			createOrderAction.inventoryAllocatedPage();

		}catch (Exception e)
		{
			e.printStackTrace();
		}

	}

}
