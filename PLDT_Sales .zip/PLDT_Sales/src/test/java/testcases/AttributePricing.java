package testcases;

import java.io.FileWriter;
import java.io.IOException;


import org.testng.annotations.Test;

import com.opencsv.CSVWriter;
import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.LeadConversionAction;
import pageAction.OpportunityCreationAction;
import utilities.Excel_DP;

public class AttributePricing extends Setup {
	OpportunityCreationAction OpportunityCreationAction = new OpportunityCreationAction();
	LeadConversionAction leadConvertionAction = new LeadConversionAction();
	CommonSteps leadStatusObj = new CommonSteps();
	TestBase tb = new TestBase();
	String previousLOB = null;

	public CSVWriter csvWriter = null;

	String runStatus = "FAIL";
	
	public AttributePricing() {
		FileWriter Writer;
		try {

			Writer = new FileWriter("CSV//ProductTesing.csv", true);
			csvWriter = new CSVWriter(Writer);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	LogStatus runstatus=LogStatus.FAIL;
	
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void attributePricing(String planType, String deviceName, String paymentType, String capacity, String color,

		  String recurringCharges, String onetimecharges,String lob) {
          String recurringcharge = null;
          String  onetimecharge = null;
          String  planOneTimeTotal = null;
          String  RecurringTimeTotal = null;
          String deviceOneTimeTotal = null;
          String deviceRecurringTimeTotal = null;
          

          runstatus=LogStatus.FAIL;
          
		try {

			try {
				if (!lob.equalsIgnoreCase(previousLOB)) {
					LoginAsUser.logout();
					LoginAsUser.loginAsUser(lob);
//					tb.driver.get(
//							"https://pldtoneenterprise--r2xsit.lightning.force.com/one/one.app#eyJjb21wb25lbnREZWYiOiJvbmU6YWxvaGFQYWdlIiwiYXR0cmlidXRlcyI6eyJhZGRyZXNzIjoiaHR0cHM6Ly9wbGR0b25lZW50ZXJwcmlzZS0tcjJ4c2l0LmxpZ2h0bmluZy5mb3JjZS5jb20vYXBleC92bG9jaXR5X2NtdF9fSHlicmlkQ1BRP2lkPTAwNjBwMDAwMDA3cE5EQSJ9LCJzdGF0ZSI6e319");

					tb.driver.get(
							"https://pldtoneenterprise--r2xsit.lightning.force.com/one/one.app#eyJjb21wb25lbnREZWYiOiJvbmU6YWxvaGFQYWdlIiwiYXR0cmlidXRlcyI6eyJhZGRyZXNzIjoiaHR0cHM6Ly9wbGR0b25lZW50ZXJwcmlzZS0tcjJ4c2l0LmxpZ2h0bmluZy5mb3JjZS5jb20vYXBleC92bG9jaXR5X2NtdF9fSHlicmlkQ1BRP2lkPTAwNjBwMDAwMDA3cE5DUSJ9LCJzdGF0ZSI6e319");


					Thread.sleep(15000);
					tb.driver.switchTo().frame(0);
					OpportunityCreationAction.selectPriceList();
				}

			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			OpportunityCreationAction.searchProduct(planType);
			Thread.sleep(4000);
			OpportunityCreationAction.addToCart(planType);
			tb.ExplicitWait("ProductConfigurationBtn_XPATH");
			
			OpportunityCreationAction.AddChildDevice(deviceName, paymentType, capacity, color);

			 recurringcharge = OpportunityCreationAction.getDeviceRecurringCharges().replace("₱", "").replace(",", "").replace(".00", "");
			
			System.out.println(recurringcharge);
			System.out.println("recurringCharges :"+recurringCharges.replace(".0","") );
			if (recurringcharge.equalsIgnoreCase(recurringCharges.replace(".0","").trim().toString())) {

				System.out.println("recurring charges are correct");

				runstatus=LogStatus.PASS;
				tb.test.log(runstatus, "recurring charges are correct");

			} else {
				System.out.println("recurring charges are incorrect");
				tb.test.log(LogStatus.FAIL, "recurring charges are incorrect");
				
			}

			onetimecharge = OpportunityCreationAction.getDeviceOneTimeCharges().replace("₱", "").replace(",", "").replace(".00", "");
			System.out.println(onetimecharge);
            System.out.println("onetimecharges:"+onetimecharges.replace(".0", ""));
			if (onetimecharge.trim().toString().equalsIgnoreCase(onetimecharges.replace(".0", "").trim().toString())) {

				System.out.println("onetime charges are correct");

				runstatus=LogStatus.PASS;
				tb.test.log(runstatus, "onetime charges are correct");

			} else {
				System.out.println("onetime charges are incorrect");
				tb.test.log(LogStatus.FAIL, "onetime charges are incorrect");
				
			}

			
			  planOneTimeTotal= OpportunityCreationAction.getPlanOneTimetotalCharges().replace("₱","").replace(",", "").replace(".00", ""); 
			  RecurringTimeTotal=OpportunityCreationAction.getPlanRecurringCharges().replace("₱","").replace(",", "").replace(".00", ""); 
			  deviceOneTimeTotal=OpportunityCreationAction.getDeviceOneTimeCharges().replace("₱","").replace(",", "").replace(".00", "");
			  deviceRecurringTimeTotal=OpportunityCreationAction.getDeviceRecurringCharges( ).replace("₱", "").replace(",", "").replace(".00", "");
			 
		//Thread.sleep(1000);
		


			  } catch (Exception e) {
			e.printStackTrace();
			
		} 
		
		try {
			
			  String[] data1 = { planType, deviceName, paymentType, capacity, color,recurringCharges, recurringcharge, onetimecharges,onetimecharge,planOneTimeTotal,RecurringTimeTotal,deviceOneTimeTotal,
			  deviceRecurringTimeTotal };
			 
			csvWriter.writeNext(data1);
			csvWriter.flush();
		} catch (Exception e) {
			
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			
			tb.test.log(runstatus,runstatus.toString());
			
		}
		
		tb.takeScreenshot();
		//tb.Scroll("ProductConfigurationBtn_XPATH");
		OpportunityCreationAction.deletePlan();
	    //tb.ThreadWait(3000);
		
		previousLOB = lob;
		
		
	}
	
	public void name() throws Exception {
		
		csvWriter.close();
		
	}

}
