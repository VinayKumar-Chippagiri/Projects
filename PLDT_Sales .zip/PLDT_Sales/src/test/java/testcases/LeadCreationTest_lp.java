package testcases;

import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;
import com.smart.common.Login;

import base.TestBase;
import pageAction.LeadCreationAction;
import pageAction.CommonSteps;
import utilities.Excel_DP;
import utilities.RunMode;

public class LeadCreationTest_lp extends TestBase {


	LeadCreationAction 	leadCreationAction=new 	LeadCreationAction();
	TestBase tb = new TestBase ();
	HomePageTest hpt = new HomePageTest();
	LeadConversionTest leadConversionTest = new LeadConversionTest();



	@Test(dataProviderClass = Excel_DP.class,dataProvider = "newtestdata",enabled=false)
	public void leadCreation_WithAllFields(String salutation,String firstName,String midNAme,String lastName,String suffix,
			String title, String leadStatus,String leadCurrency,String stageDate,String stageTime,String notQualifiedReason,String leadSource,String other,String RTS, String productInterest,
			String rfsDate,String callBackDate,String phone,String mobile, String email,String agentCode, String birthDate, String website,
			String street,String city, String state,String postal,String country, String company, String companySize, String businessType,String businessRigsType,
			String companyTName,String companyTin,String industry,String subIndustry,String businessRigsNum,String otherBusinessType,String lob, String accountClass, String referralName) {

		if(!(RunMode.isTestRunnable("NewLeadCreate"))){

			throw new SkipException("Skipping the test "+"leadCreation_WithAllFields".toUpperCase()+ "as the Run mode is NO");
		}
		Login.asAdmin();


		try {

			Thread.sleep(3000);

			leadCreationAction.click_on_NewBtn();
			Thread.sleep(3000);
			tb.takeScreenshot();

			//Start Lead Information ******************************************
			leadCreationAction.select_salutation(salutation);
			leadCreationAction.firstName(firstName);
			leadCreationAction.midNmae(midNAme);
			System.out.println(lastName);
			tb.takeScreenshot();
			leadCreationAction.lastName(lastName);
			leadCreationAction.suffix(suffix);
			leadCreationAction.titleandRole();
			tb.takeScreenshot();

			JavascriptExecutor js = (JavascriptExecutor) TestBase.driver;
			js.executeScript("arguments[0].scrollIntoView();", tb.element("leadCurrency_XPATH"));
			Thread.sleep(1000);
			leadCreationAction.leadCurrency(leadCurrency);
			Thread.sleep(1000);
			leadCreationAction.leadStatus(leadStatus);
			Thread.sleep(1000);
			leadCreationAction.stageDate(stageDate);
			Thread.sleep(1000);
			//leadCreationAction.stageTime(stageTime);
			System.out.println("Time: "+stageTime.toString().trim());
			Thread.sleep(1000);
			leadCreationAction.notQualifiedReason(notQualifiedReason);
			Thread.sleep(1000);
			leadCreationAction.rfsDate(rfsDate);
			Thread.sleep(1000);
			leadCreationAction.callBackDate(callBackDate);
			Thread.sleep(1000);
			leadCreationAction.leadSource(leadSource);
			leadCreationAction.other(other);
			Thread.sleep(1000);
			leadCreationAction.productInterest(productInterest);
			Thread.sleep(1000);
			leadCreationAction.RTS(RTS);
			Thread.sleep(2000);

			//End Lead Information ******************************************
			tb.takeScreenshot();


			//Start Personal Information ******************************************

			leadCreationAction.phone(phone);
			Thread.sleep(2000);
			leadCreationAction.mobile(mobile);
			Thread.sleep(2000);
			leadCreationAction.email(email);
			Thread.sleep(2000);
			leadCreationAction.agentCode(agentCode);
			leadCreationAction.birthDate(birthDate);
			Thread.sleep(2000);
			leadCreationAction.website(website);
			Thread.sleep(1000);
			leadCreationAction.street(street);
			Thread.sleep(1000);
			leadCreationAction.city(city);
			Thread.sleep(1000);
			leadCreationAction.state(state);
			Thread.sleep(2000);
			leadCreationAction.postal(postal);
			Thread.sleep(1000);
			leadCreationAction.country(country);
			Thread.sleep(2000);

			//End Personal Information ******************************************
			tb.takeScreenshot();


			//Start Company Information ******************************************

			leadCreationAction.company(company);
			Thread.sleep(2000);
			leadCreationAction.companySize(companySize);
			Thread.sleep(1000);
			leadCreationAction.businessType(businessType);
			Thread.sleep(1000);
			leadCreationAction.companyTin(companyTin);
			Thread.sleep(1000);
			leadCreationAction.industry(industry);
			Thread.sleep(2000);
			leadCreationAction.subIndustry(subIndustry);
			Thread.sleep(1000);
			leadCreationAction.businessRigsType(businessRigsType);
			Thread.sleep(1000);
			leadCreationAction.businessRigsNum(businessRigsNum);
			Thread.sleep(2000);
			leadCreationAction.companyTName(companyTName);
			Thread.sleep(1000);
			leadCreationAction.otherBusinessType(otherBusinessType);
			Thread.sleep(2000);

			//End Company Information ******************************************
			tb.takeScreenshot();


			//Start Additional Information ******************************************

			leadCreationAction.lob(lob);
			Thread.sleep(1000);
			leadCreationAction.accountClass(accountClass);
			Thread.sleep(2000);
			//End Additional Information ******************************************

			leadCreationAction.referralName(referralName);
			Thread.sleep(1000);
			leadCreationAction.uncheckTheCheckBox();
			Thread.sleep(1000);
			tb.takeScreenshot();

			leadCreationAction.clickOnsaveBtn();

			Thread.sleep(3000);
			//leadStatusObj.clickOnDetail();
			Thread.sleep(2000);
			tb.takeScreenshot();
			//leadCreationAction.clickOnleads();
			Thread.sleep(3000);
		} catch (Exception e) {

			e.printStackTrace();
		}

		try {
			hpt.homepage_test();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


	int rowNum = 1;
	static String company;
	static boolean firstLogin = false;

	String previousLOB = "";
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata",enabled=false)
	public void leadCreationtToConvertion(String firstName,String lastName, String leadStatus,
			String leadSource, String productInterest, String phone, String mobile, String email,
			String street,String city, String state,String postal,String country, String company, String companySize, String businessType,
			String industry, String subIndustry,String lob,String accountClass, String referralName ,String queuename) {

		if(!(RunMode.isTestRunnable("leadCreationtToConvertion"))){
			throw new SkipException("Skipping the test "+"leadCreationtToConvertion".toUpperCase()+ "as the Run mode is NO");
		}

		SoftAssert softAssert =new SoftAssert();
		Date d = new Date();
		String SampleDate=d.toString().replace(":", "_").replace(" ", "_");
		lastName=lastName+SampleDate;
		company=company+SampleDate;
		this.company=company;

		try {
			if (!lob.equalsIgnoreCase(previousLOB)) {
				if(previousLOB!=null) {

					LoginAsUser.logout();
				}

				LoginAsUser.loginAsUser(lob);
			}


			LoginAsUser.homepagefeature("Leads");
			//tb.driver.navigate().refresh();
			Thread.sleep(2000);
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			String queueName=null;
			Thread.sleep(2000);

			leadCreationAction.click_on_NewBtn();
			Thread.sleep(2000);
			CommonSteps.click_on_Next();
			//TestBase.takeScreenshot();
			leadCreationAction.firstName(firstName);
			leadCreationAction.titleandRole();
			leadCreationRequiredData(lastName, leadStatus, leadSource, productInterest, phone, mobile, email, street, city, state, postal, country, company);
			//TestBase.takeScreenshot();
			leadCreationAction.companySize(companySize.trim());
			leadCreationAction.companyTin("4345456675323");
			leadCreationAction.businessType(businessType.trim());
			leadCreationAction.industry(industry.trim());
			leadCreationAction.subIndustry(subIndustry.trim());
			leadCreationAction.lob(lob);
			leadCreationAction.accountClass(accountClass);

			if(leadSource.equalsIgnoreCase("Employee Referral")||leadSource.equalsIgnoreCase("Event")||leadSource.equalsIgnoreCase("External Referral")||leadSource.equalsIgnoreCase("Trade Show"))
			{
				leadCreationAction.referralName(referralName.trim());
			}

			//TestBase.takeScreenshot();
			leadCreationAction.clickOnsaveBtn();



			try {
				if(tb.element("errorOnLeadPage_XPATH").isDisplayed()) {
					tb.takeScreenshot();
					String ErrorMSG=null;
					try {
						ErrorMSG = tb.element("errorMSG_XPATH").getText();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					rowNum=rowNum+1;
					TestBase.test.log(LogStatus.FAIL, ErrorMSG);
					//Excel_DP.excel.setCellData("lead_AssignmentToQueue", "Error", rowNum, ErrorMSG);
					leadCreationAction.clickOnCancel();
					softAssert.assertTrue(false, ErrorMSG);
				}

			} catch (Exception e) {

				e.printStackTrace();
				Thread.sleep(1000);
				//tb.driver.navigate().refresh();
				//Thread.sleep(2000);
				leadCreationAction.markLeadStatusAsQualified();
				Thread.sleep(1000);
				CommonSteps.clickOnDetail();
				Thread.sleep(1000);
				tb.Scroll("LeadInfo_XPATH");
				Thread.sleep(1000);
				tb.takeScreenshot();
				rowNum = rowNum+1;
				System.out.println("rowNum: "+rowNum);

				try {
					queueName=leadCreationAction.getQueueOrOwnerName();
					System.out.println("Lead Owner :"+queueName);

				}

				catch (Exception e1) {
					queueName="NULL";
					Excel_DP.excel.setCellData("lead_AssignmentToQueue", "Assigned to", rowNum,queueName);
				}
				Excel_DP.excel.setCellData("leadConversionTest", "LeadName", rowNum, firstName+" "+lastName);




				leadConversionTest.leadConversionTest(queuename, firstName+" "+lastName, lob, "Y");
			}
		} catch (Throwable e) {
			rowNum = rowNum+1;
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		/*
		 * try { hpt.homepage_test(); } catch (Throwable e) { // TODO Auto-generated
		 * catch block e.printStackTrace(); }
		 */
		previousLOB = lob;
		firstLogin = true;
		softAssert.assertAll();
	}

	public void leadCreationRequiredData(String lastName,String leadStatus,String leadSource, String productInterest,String phone,String mobile,String email,
			String street, String city, String state,String postal,String country,String company ) {

		leadCreationAction.lastName(lastName);
		//TestBase.takeScreenshot();
		//leadCreationAction.leadStatus(leadStatus.trim());
		leadCreationAction.leadSource(leadSource.trim());
		leadCreationAction.productInterest(productInterest.trim());
		//TestBase.takeScreenshot();
		leadCreationAction.phone(phone.trim());
		leadCreationAction.mobile(mobile.trim());
		leadCreationAction.email(email.trim());

		//TestBase.takeScreenshot();
		leadCreationAction.street(street);
		leadCreationAction.city(city.trim());
		leadCreationAction.state(state.trim());
		leadCreationAction.postal(postal.trim());
		leadCreationAction.country(country.trim());
		leadCreationAction.company(company.trim());

	}


	// added by waseem to create lead

	int rowNumber = 1;
	static String Company;
	static boolean firstlogin = false;



	String PreviousLOB = "";
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "newtestdata",enabled=true)
	public void NewLeadCreate(String saluation,String firstName,String lastName, String leadStatus,
	String leadSource, String productInterest, String phone, String mobile, String email,
	String street,String city, String state,String postal,String country, String company, String companySize, String businessType,
	String industry, String subIndustry,String lob,String accountClass, String referralName, String queueName ) {

		Login.asAdmin();

	if(!(RunMode.isTestRunnable("NewLeadCreate"))){
	throw new SkipException("Skipping the test "+"NewLeadCreate".toUpperCase()+ "as the Run mode is NO");
	}



	SoftAssert softAssert =new SoftAssert();
	Date d = new Date();
	String SampleDate=d.toString().replace(":", "_").replace(" ", "_");
	lastName=lastName+SampleDate;
	company=company+SampleDate;
	this.company=company;
	try {
	leadCreationAction.clickOnAppLauncher();
	leadCreationAction.enterValueOnAppSearch();

	leadCreationAction.clickOnNewLeadButton();
	leadCreationAction.selectNewLeadType();

	//*****************************************************************************************************

	leadCreationAction.click_on_NewBtn();
	Thread.sleep(2000);
	CommonSteps.click_on_Next();
	//TestBase.takeScreenshot();
	leadCreationAction.firstName(firstName);
	leadCreationAction.titleandRole();
	leadCreationRequiredData(lastName, leadStatus, leadSource, productInterest, phone, mobile, email, street, city, state, postal, country, company);
	//TestBase.takeScreenshot();
	leadCreationAction.companySize(companySize.trim());
	leadCreationAction.companyTin("4345456675323");
	leadCreationAction.businessType(businessType.trim());
	leadCreationAction.industry(industry.trim());
	leadCreationAction.subIndustry(subIndustry.trim());
	leadCreationAction.lob(lob);
	leadCreationAction.accountClass(accountClass);



	if(leadSource.equalsIgnoreCase("Employee Referral")||leadSource.equalsIgnoreCase("Event")||leadSource.equalsIgnoreCase("External Referral")||leadSource.equalsIgnoreCase("Trade Show"))
	{
	leadCreationAction.referralName(referralName.trim());
	}



	//TestBase.takeScreenshot();
	leadCreationAction.clickOnsaveBtn();





	try {
	if(tb.element("errorOnLeadPage_XPATH").isDisplayed()) {
	tb.takeScreenshot();
	String ErrorMSG=null;
	try {
	ErrorMSG = tb.element("errorMSG_XPATH").getText();
	} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	rowNum=rowNum+1;
	TestBase.test.log(LogStatus.FAIL, ErrorMSG);
	//Excel_DP.excel.setCellData("lead_AssignmentToQueue", "Error", rowNum, ErrorMSG);
	leadCreationAction.clickOnCancel();
	softAssert.assertTrue(false, ErrorMSG);
	}



	} catch (Exception e) {



	e.printStackTrace();
	Thread.sleep(1000);
	//tb.getdriver().navigate().refresh();
	//Thread.sleep(2000);
	leadCreationAction.markLeadStatusAsQualified();
	Thread.sleep(1000);
	CommonSteps.clickOnDetail();
	Thread.sleep(1000);
	tb.Scroll("LeadInfo_XPATH");
	Thread.sleep(1000);
	tb.takeScreenshot();
	rowNum = rowNum+1;
	System.out.println("rowNum: "+rowNum);



	try {
	queueName=leadCreationAction.getQueueOrOwnerName();
	System.out.println("Lead Owner :"+queueName);



	}



	catch (Exception e1) {
	queueName="NULL";
	Excel_DP.excel.setCellData("lead_AssignmentToQueue", "Assigned to", rowNum,queueName);
	}
	Excel_DP.excel.setCellData("leadConversionTest", "LeadName", rowNum, firstName+" "+lastName);






	leadConversionTest.leadConversionTest(queueName, firstName+" "+lastName, lob, "Y");
	}
	} catch (Throwable e) {
	rowNum = rowNum+1;
	// TODO Auto-generated catch block
	e.printStackTrace();
	}



	/*
	* try { hpt.homepage_test(); } catch (Throwable e) { // TODO Auto-generated
	* catch block e.printStackTrace(); }
	*/
	previousLOB = lob;
	firstLogin = true;
	softAssert.assertAll();
	}













}
