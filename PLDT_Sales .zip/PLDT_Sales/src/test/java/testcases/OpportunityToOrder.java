package testcases;

import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.smart.testcases.LeadCreationTest;

import utilities.Excel_DP;
import utilities.RunMode;

public class OpportunityToOrder {

	QuoteTest quoteTest=new QuoteTest();
	CreateContractTest createContractTest=new CreateContractTest();
	CreateOrderTest createOrderTest = new CreateOrderTest();
	OpportunityTest opportunityTest = new OpportunityTest();


	// Test To Create Opportunity,Adding product into the Cart, Quote and Contract
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void opportunityToOrder(String OpportunityName, String ContractingParty, String OpportunintyType,
			String closeDate, String stage, String opportunintyCurrency, String NumberofContractMonth,
			String AccountName, String Product, String Price,String DeviceName, String DeviceCapcity, String DeviceColor,String SecondDevice, String vasName, String accessoriesName,String Addons,String DiscountOnPlanMSF,String DiscountOnDevive,
			String OrderQuantity,String vanityNoType, String queueName,String creditCondition, String startDate, String contractMonths, String contractTemplate,
			String ETSSolutionDesign,String contractTerm, String speed, String PaymentMethod,String PlanName, String PaymentFrequency, String type, String NumberType, String parent, String name, String lob, String currency,
			 String industry,String industrySubType, String accountTypeCode, String accountOf, String AccountOfBizAct, String CIFirstName,
			String CIMidName, String CILastName,String creditLimit, String thsStatus, String thsRating, String subscription,
			String serviceProvider,String notifyMailId, String creditClass, String notifyMobileNo, String phone, String accountPaymentType,
			String customerGroup, String taxExemption, String taxProfile, String billFrequency, String VIPCode, String BillDispatchMethod,
			String BillCycle, String BillingAddrLine1, String BillingAddrLine2, String BillingAddrLine3, String BillingCountry, String BillingCity,
			String Barangay, String BillingStateProvince, String BillingZipPostal, String ServiceAccountName, String AuthorizeSigonatory, String BillRecipient,String DeliveryRecipient) {

		if (!(RunMode.isTestRunnable("opportunityToOrder"))) {

			throw new SkipException(
					"Skipping the test " + "opportunityToOrder".toUpperCase() + "as the Run mode is NO");
		}
		SoftAssert softAssert = new SoftAssert();

		if(LeadCreationTest.firstLogin==true) {

		AccountName=LeadCreationTest.company;
		}

		try {
			opportunityTest.opportunityTest(OpportunityName, ContractingParty, OpportunintyType, closeDate, stage, opportunintyCurrency, NumberofContractMonth, AccountName,type);
			if (OpportunityTest.flag==true) {
				opportunityTest.addProductToCart(ContractingParty,Product, DeviceName, DeviceCapcity,DeviceColor,SecondDevice,vasName, accessoriesName, Addons,DiscountOnPlanMSF,DiscountOnDevive,vanityNoType,OrderQuantity,ETSSolutionDesign, contractTerm,  speed,  PaymentMethod, PlanName,  PaymentFrequency, NumberType);

				quoteTest.quoteTest("",ContractingParty, queueName, type, creditCondition, Product, NumberType,parent, name, lob, currency, industry,
						industrySubType, accountTypeCode, accountOf, AccountOfBizAct, CIFirstName, CIMidName, CILastName, creditLimit, thsStatus, thsRating,
						subscription, serviceProvider, notifyMailId, creditClass, notifyMobileNo, phone, accountPaymentType, customerGroup,
						taxExemption, taxProfile, billFrequency, VIPCode, BillDispatchMethod, BillCycle, BillingAddrLine1, BillingAddrLine2, BillingAddrLine3,
						BillingCountry, BillingCity, Barangay, BillingStateProvince, BillingZipPostal, ServiceAccountName,AuthorizeSigonatory, BillRecipient, DeliveryRecipient);

				createContractTest.createContractTest(contractTemplate,type);

				//tb.navigateURL(opptyURL);

				//Thread.sleep(10000);


				//James: CreateOrder
				// add code here for OM
				createOrderTest.createOrderTest();

				// James : Validate ETS Solution Design
				//OpportunityCreationAction.ETSSolutionDesignNeeded(ETSSolutionDesign);
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}


		softAssert.assertAll();

	}

	/*
	 * @Test(dependsOnMethods = "opportunityToOrder") public void testMethod() {
	 * System.out.println("Hi James"); }
	 */

}





