package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.TestBase;
import loginAndHomePageAction.HomePgaeAction;
import loginAndHomePageAction.LoginAction;
import utilities.RunMode;

public class LoginAsUser {
	static LoginAction loginAction = new LoginAction();
	static HomePgaeAction homePgaeAction = new HomePgaeAction();
	static TestBase tb = new TestBase();
	static String HomeUrl = null;

	public static void loginAsUser(String lob) throws Throwable {
		
		System.out.println("Login as user: " + lob);
		
		try {
			// String[] credentials = {"", ""};
			String sheetName = "LoginTest";
			String fileLOB = "";
			String username = "";
			String password = "";
			String runmode = "";
			
			int rows = RunMode.excel.getRowCount(sheetName);
			int cols = RunMode.excel.getColumnCount(sheetName);
			System.out.println(rows);
			System.out.println(cols);
			
			//LEONYL: get user credentials & runmode
			for (int row = 2; row <= rows; row++) {
				fileLOB = RunMode.excel.getCellData(sheetName, 3, row);
				
				if (fileLOB.equals(lob)) {					
					username = RunMode.excel.getCellData(sheetName, 0, row);
					password = RunMode.excel.getCellData(sheetName, 1, row);
					runmode = RunMode.excel.getCellData(sheetName, 2, row);
					
					System.out.println(username + "|" + password);
				}
			}
			
			try {
				if(tb.element("username_XPATH").isDisplayed()) {
					
					System.out.println("Log In to Salesforce..");
					
				}
			} catch (Exception e) {
				
				tb.driver.get(tb.config.getProperty("testsiteurl"));
				
			}
			
			
			loginAction.enter_username(username);
			loginAction.enter_password(password);
			loginAction.click_on_login_Btn();
			loginAction.verify_login();
			Thread.sleep(2000);
			tb.driver.navigate().refresh();
			tb.wait.until(ExpectedConditions.titleContains("Home | Salesforce"));
			HomeUrl = tb.driver.getCurrentUrl();
			System.out.println(HomeUrl);
			
			System.out.println("\n=====================\n");
			
//			int rows = RunMode.excel.getRowCount("LoginTest");
//			int cols = RunMode.excel.getColumnCount("LoginTest");
//			System.out.println(rows);
//			System.out.println(cols);
//			String recordes;		
//			
//			for (Row row : RunMode.excel.sheet) {
//				for (Cell cell : row) {
//					recordes = cell.getRichStringCellValue().getString().trim();
//					String runmode = cell.getRow().getCell(2).getStringCellValue();
//					if (runmode.equalsIgnoreCase("Y")) {
//						if (recordes.equals(lob)) {
//							String Username = cell.getRow().getCell(0).getStringCellValue();
//							String password = cell.getRow().getCell(1).getStringCellValue();
//							System.out.println(Username);
//							System.out.println(password);
//
//							/*
//							 * for (int rowNum = 2; rowNum <=rows; rowNum++) { // 2
//							 * 
//							 * String username=RunMode.excel.getCellData("LoginTest", 0, rowNum); String
//							 * Password=RunMode.excel.getCellData("LoginTest", 1, rowNum); String
//							 * runmode=RunMode.excel.getCellData("LoginTest", 2, rowNum); String
//							 * LOB=RunMode.excel.getCellData("LoginTest", 3, rowNum); runmode =
//							 * runmode.trim(); System.out.println(Password); System.out.println(username);
//							 * System.out.println(runmode); System.out.println(LOB);
//							 * if(runmode.equalsIgnoreCase("Y")) { if(LOB.equalsIgnoreCase(lob)) {
//							 */
//							loginAction.enter_username(Username);
//							loginAction.enter_password(password);
//							// TestBase.takeScreenshot();
//							loginAction.click_on_login_Btn();
//							loginAction.verify_login();
//							tb.ThreadWait(5000);
//							HomeUrl = tb.driver.getCurrentUrl();
//
//						}
//
//					}
//				}
//
//			}

		} catch (Exception e) {

		}
	}

	public static void logout() {
		
		try {
			loginAction.logout();
			Thread.sleep(2000);

		} catch (Exception e) {

		}

	}

	@SuppressWarnings("static-access")
	public static void homepagefeature(String feature1) throws Throwable {

		int rows = RunMode.excel.getRowCount("Feature");
		int cols = RunMode.excel.getColumnCount("Feature");
		System.out.println(rows);
		System.out.println(cols);
		for (int rowNum = 2; rowNum <= rows; rowNum++) { // 2

			String feature = RunMode.excel.getCellData("Feature", 0, rowNum);
			String runmode = RunMode.excel.getCellData("Feature", 1, rowNum);
			runmode = runmode.trim();
			System.out.println(feature);
			System.out.println(runmode);
			if (runmode.equalsIgnoreCase("Y")) {
				if (feature.equalsIgnoreCase(feature1)) {
					Thread.sleep(2000);
					homePgaeAction.click_on_Launcer();
					homePgaeAction.enter_Value_In_Searchbox(feature);
					Thread.sleep(2000);
					tb.driver.findElement(By.xpath("//input[@placeholder='Search apps and items...']"))
							.sendKeys(Keys.ENTER);
					// homePgaeAction.click_on_value();
					Thread.sleep(2000);

					// TestBase.takeScreenshot();

				}
			}
		}
	}
}
