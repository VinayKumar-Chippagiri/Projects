package testcases;

import java.io.FileWriter;
import java.io.IOException;

import org.testng.annotations.Test;

import com.opencsv.CSVWriter;
import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.LeadConversionAction;
import pageAction.OpportunityCreationAction;
import utilities.Excel_DP;

public class ProductTesting extends Setup {
	OpportunityCreationAction OpportunityCreationAction = new OpportunityCreationAction();
	LeadConversionAction leadConvertionAction = new LeadConversionAction();
	CommonSteps leadStatusObj = new CommonSteps();
	TestBase tb = new TestBase();
	String previousLOB = null;

	public CSVWriter csvWriter = null;

	String runStatus = "FAIL";
	
	public ProductTesting() {
		FileWriter Writer;
		try {

			Writer = new FileWriter("CSV//PlanTesting2.csv", true);
			csvWriter = new CSVWriter(Writer);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void productPricingTest(String testcaseNo, String deviceName, String paymentType, String capacity, String color,
		  String recurringCharges, String onetimecharges,String lob) {
          String recurringcharge = null;
          String  onetimecharge = null;
          String  planOneTimeTotal = null;
          String  RecurringTimeTotal = null;
          String deviceOneTimeTotal = null;
          String deviceRecurringTimeTotal = null;
          
		runStatus = "FAIL";

		try {

			
			try {
				if (!lob.equalsIgnoreCase(previousLOB)) {
					LoginAsUser.logout();
					LoginAsUser.loginAsUser(lob);
					tb.driver.get(

							"https://pldtoneenterprise--r3uat.lightning.force.com/one/one.app#eyJjb21wb25lbnREZWYiOiJvbmU6YWxvaGFQYWdlIiwiYXR0cmlidXRlcyI6eyJhZGRyZXNzIjoiaHR0cHM6Ly9wbGR0b25lZW50ZXJwcmlzZS0tcjN1YXQubGlnaHRuaW5nLmZvcmNlLmNvbS9hcGV4L3Zsb2NpdHlfY210X19IeWJyaWRDUFE%2FaWQ9MDA2MHcwMDAwMDVEOU1TIn0sInN0YXRlIjp7fX0%3D");


					Thread.sleep(15000);
					tb.driver.switchTo().frame(0);
					OpportunityCreationAction.selectPriceList();
					
				}

			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			OpportunityCreationAction.searchProduct(deviceName);
			Thread.sleep(5000);

			OpportunityCreationAction.addToCart(deviceName);
			tb.ExplicitWait("ProductConfigurationBtn_XPATH");

			Thread.sleep(2000);
			if(!paymentType.isEmpty()) {
			OpportunityCreationAction.configureDevice();
			OpportunityCreationAction.selectDevicePaymentType(paymentType);
			Thread.sleep(1000);

			try {
				OpportunityCreationAction.selectDeviceCapacity(capacity);
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
			try {
				//tb.Scroll("DeviceColor_XPATH");
				OpportunityCreationAction.selectColor(color);
				Thread.sleep(13000);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			}
			 recurringcharge = OpportunityCreationAction.getDeviceRecurringCharges("device").replace("₱", "").replace(",", "").replace(".00", "");
			
			System.out.println(recurringcharge);
			System.out.println("recurringCharges :"+recurringCharges.replace(".0","") );
			if (recurringcharge.trim().equalsIgnoreCase(recurringCharges.replace(".0","").trim().toString())) {

				System.out.println("recurring charges are correct");
				tb.test.log(LogStatus.PASS, "Recurring charge is correct");
				
				runStatus = "PASS";
			} else {
				System.out.println("recurring charges are incorrect");
				tb.test.log(LogStatus.FAIL, "recurring charges are incorrect");
				
				runStatus = "FAIL";
			}

			onetimecharge = OpportunityCreationAction.getDeviceOneTimeCharges("device").replace("₱", "").replace(",", "").replace(".00", "");
			System.out.println(onetimecharge);
            System.out.println("onetimecharges:"+onetimecharges.replace(".0", ""));
			if (onetimecharge.trim().toString().equalsIgnoreCase(onetimecharges.replace(".0", "").trim().toString())) {

				System.out.println("onetime charges are correct");
				tb.test.log(LogStatus.PASS, "One-time charge is correct");
				
				runStatus = "PASS";
			} else {
				System.out.println("onetime charges are incorrect");
				tb.test.log(LogStatus.FAIL, "onetime charges are incorrect");
				
				runStatus = "FAIL";
			}

		
		 planOneTimeTotal=	OpportunityCreationAction.getPlanOneTimetotalCharges().replace("₱", "").replace(",", "").replace(".00", "");
		 RecurringTimeTotal=	OpportunityCreationAction.getPlanRecurringCharges().replace("₱", "").replace(",", "").replace(".00", "");
		 deviceOneTimeTotal=	OpportunityCreationAction.getDeviceOneTimeCharges("device").replace("₱", "").replace(",", "").replace(".00", "");
		 deviceRecurringTimeTotal=OpportunityCreationAction.getDeviceRecurringCharges("device").replace("₱", "").replace(",", "").replace(".00", "");
		Thread.sleep(10000);
		


		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {
			
			tb.test.log(LogStatus.valueOf(runStatus), "Recurring or One-time charges did not match");
		}
		
		
		try {
			String[] data1 = { testcaseNo, deviceName, paymentType, capacity, color, recurringCharges, recurringcharge,
					onetimecharges, onetimecharge,planOneTimeTotal,RecurringTimeTotal,deviceOneTimeTotal,deviceRecurringTimeTotal };
			csvWriter.writeNext(data1);
			csvWriter.flush();
		} catch (Exception e) {
			
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		tb.takeScreenshot();
		//tb.Scroll("ProductConfigurationBtn_XPATH");
		OpportunityCreationAction.deletePlan();
	    //tb.ThreadWait(3000);
		
		previousLOB = lob;
	}
	
	public void name() throws Exception {
		
		csvWriter.close();
		
	}

}
