package testcases;

import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.LeadConversionAction;
import pageAction.CommonSteps;
import utilities.Excel_DP;
import utilities.RunMode;
public class LeadConversionTest {

	LeadConversionAction leadConvertionAction=new LeadConversionAction();
	CommonSteps leadStatusObj=new CommonSteps();
	TestBase tb=new TestBase();
	String previousLOB=null;
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void leadConversionTest(String queuename, String leadname,String lob, String checkOppty ) {

		if(!(RunMode.isTestRunnable("leadConversionTest"))){
			throw new SkipException("Skipping the test "+"leadConversionTest".toUpperCase()+ "as the Run mode is NO");
		}

		SoftAssert softAssert =new SoftAssert();

		try {
			if(!lob.equalsIgnoreCase(previousLOB)) {
				LoginAsUser.logout();
				LoginAsUser.loginAsUser("Credit "+lob);
				Thread.sleep(4000);
				tb.driver.navigate().refresh();
			}
			LoginAsUser.homepagefeature("Leads");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			leadConvertionAction.selectList();
			leadConvertionAction.enterQueueName(queuename);
			Thread.sleep(2000);
			leadConvertionAction.selectQueue();
			Thread.sleep(1000);
			leadConvertionAction.searchLead("leadSearchInput_XPATH",leadname);
			Thread.sleep(4000);
			leadConvertionAction.ClickOnLeadRecord();
			Thread.sleep(2000);
			tb.driver.navigate().refresh();
			Thread.sleep(2000);
			leadStatusObj.clickOnDetail();
			tb.click("LeadInfo_XPATH");
//			tb.Scroll("LeadInfo_XPATH");

			if(tb.element("creditCheckBox_XPATH").isSelected()) {
				tb.Scroll("leadHeaderCompany_XPATH");
				leadConvertionAction.convertLead(checkOppty);
				Thread.sleep(2000);
			} else {
				leadConvertionAction.creditCheck();
				Thread.sleep(2000);
				tb.Scroll("leadHeaderCompany_XPATH");
				//js.executeScript("arguments[0].scrollIntoView();", tb.driver.findElement(By.xpath("//p[text()='Company']")));
				leadConvertionAction.convertLead(checkOppty);
				Thread.sleep(2000);
			}
			
			try {
				if(tb.element("LeadCovertError_XPATH").isDisplayed()) {
					String Errormsg=null;
					 try {
						Errormsg=tb.element("LeadCovertError_XPATH").getText();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					tb.test.log(LogStatus.FAIL, Errormsg);
					tb.takeScreenshot();
					Thread.sleep(2000);
					leadConvertionAction.CancelLeadConversion();
					softAssert.assertTrue(false, Errormsg);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		previousLOB=lob;
		softAssert.assertAll();
	}

}
