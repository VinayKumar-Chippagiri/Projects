package testcases;

import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;
import com.smart.testcases.LeadCreationTest;

import base.TestBase;
import pageAction.CreateConatctAction;
import utilities.Excel_DP;
import utilities.RunMode;

public class CreateContactTest {


	CreateConatctAction  createConatctAction =new CreateConatctAction();
	TestBase tb=new TestBase();
	int rownum=1;
	String previousLOB=null;

	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void createContactWithRequiredData(String firstName, String midName, String lastName,String contactCurrency, String email, String lob, String accountName,
										      String role, String gender, String phone, String mobile, String fax, String bdate) {

		 if(!(RunMode.isTestRunnable("createContactWithRequiredData"))){

				throw new SkipException("Skipping the test "+"createContactWithRequiredData".toUpperCase()+ "as the Run mode is NO");
			}
		 SoftAssert softAssert =new SoftAssert();


		 if(LeadCreationTest.firstLogin==true) {

			 accountName=LeadCreationTest.company;

				}

		 try {
				if(!lob.equalsIgnoreCase(previousLOB)) {
					LoginAsUser.logout();
					LoginAsUser.loginAsUser(lob);
					Thread.sleep(4000);
					tb.driver.navigate().refresh();
				}
//				LoginAsUser.homepagefeature("Contacts");
				tb.navigateURL("https://pldtoneenterprise--r2xuat.lightning.force.com/lightning/o/Contact/list?filterName=Recent");
				tb.ThreadWait(5000);

			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		try {
			createConatctAction.click_on_new();
			createConatctAction.firstName(firstName);
			createConatctAction.middleName(midName);
			createConatctAction.lastName(lastName);
			createConatctAction.Enter_AccountName(accountName);
//			createConatctAction.contactCurrency(contactCurrency);
			createConatctAction.contactRole(role);
			createConatctAction.email(email);

			//LEONYL: additional mandatory fields
			//createConatctAction.fax(fax);

			tb.scrollElementIntoView("contactGender_XPATH");
			createConatctAction.gender(gender);

			createConatctAction.mobile(mobile);
			createConatctAction.phone(phone);
			//createConatctAction.birthdate(bdate);

			createConatctAction.clickonSave();
			 try {
					if(tb.element("errorOnLeadPage_XPATH").isDisplayed()) {
						tb.takeScreenshot();
						 String  ErrorMSG=null;
						 try {
							 ErrorMSG=tb.element("errorMSG_XPATH").getText();
							// Excel_DP.excel.setCellData("createOpportunityWithRequireddata", "Error", rownum, tb.element("errorMSG_XPATH").getText());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						tb.test.log(LogStatus.FAIL,ErrorMSG);
						 createConatctAction.clickOnCancel();
						 rownum=rownum+1;
						 softAssert.assertTrue(false, ErrorMSG);

					 }
				} catch (Exception e) {
					tb.takeScreenshot();
					 rownum=rownum+1;


				}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/*
		 * HomePageTest hpt = new HomePageTest(); try { hpt.homepage_test(); } catch
		 * (Throwable e) { // TODO Auto-generated catch block e.printStackTrace(); }
		 */
			previousLOB=lob;
		softAssert.assertAll();
	}

}
