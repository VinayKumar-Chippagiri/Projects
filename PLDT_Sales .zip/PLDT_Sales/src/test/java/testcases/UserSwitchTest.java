package testcases;

public class UserSwitchTest {

}
