package testcases;

import java.util.Date;

import org.openqa.selenium.By;
import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;
import com.smart.common.Login;

import base.TestBase;
import pageAction.OpportunityCreationAction;
import utilities.Excel_DP;
import utilities.RunMode;

public class OpportunityTest  extends TestBase{

	OpportunityCreationAction OpportunityCreationAction= new OpportunityCreationAction();
	TestBase tb = new TestBase();
	HomePageTest hpt = new HomePageTest();
	String type;
	int rownum = 1;
	public static boolean flag=false;
	String previousLOB = null;
	String previousType=null;

	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void opportunityTest(String OpportunityName, String ContractingParty, String OpportunintyType,
			String closeDate, String stage, String opportunintyCurrency, String NumberofContractMonth,
			String AccountName, String type ) {

		if (!(RunMode.isTestRunnable("opportunityTest"))) {

			throw new SkipException(
					"Skipping the test " + "opportunityTest".toUpperCase() + "as the Run mode is NO");
		}
		SoftAssert softAssert = new SoftAssert();

		this.type=type;

		//generate unique Opportunity name using timestamp
		Date d= new Date();
		String date=d.toString().replace(":","").replace(" ", "").substring(0, 12);
		OpportunityName = OpportunityName + date;
		System.out.println("Fine");
		try {
			/*
			 * if (!ContractingParty.equalsIgnoreCase(previousLOB)||!type.equalsIgnoreCase(
			 * previousType)) { if(previousLOB!=null) {
			 * 
			 * LoginAsUser.logout(); } if(type.contentEquals("EE")) {
			 * 
			 * LoginAsUser.loginAsUser("EE " + ContractingParty); } else {
			 * 
			 * LoginAsUser.loginAsUser(ContractingParty); } }
			 */
			//			LoginAsUser.homepagefeature("Opportunities");
			Login.asAdmin();
			Login.switchToRelationshipManager();			
			hpt.featureURL("Opportunity");
			tb.ExplicitWait("new_btn_XPATH");

		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		OpportunityCreationAction.click_on_new();

		if(!type.contentEquals("EE")) {

			OpportunityCreationAction.click_on_Next();
		}
		OpportunityCreationAction.Enter_OpportunityName(OpportunityName);
		OpportunityCreationAction.Enter_AccountName(AccountName);
		OpportunityCreationAction.EnterContractingParty(ContractingParty);
		OpportunityCreationAction.OpportunintyType(OpportunintyType);
		OpportunityCreationAction.Enter_CloseDate(closeDate);
		OpportunityCreationAction.stage(stage);
		OpportunityCreationAction.opportunintyCurrency(opportunintyCurrency);
		OpportunityCreationAction.NumberofContractMonth(NumberofContractMonth);

		/*
		 * if(!PriceBook.isEmpty()) {
		 *
		 * OpportunityCreationAction.Enter_PriceBook(PriceBook); }
		 */
		OpportunityCreationAction.clickonSave();

		System.out.println("\n=====================\n");

		try {
			if (tb.element("errorOnLeadPage_XPATH").isDisplayed()) {

				tb.takeScreenshot();
				String ErrorMSG = tb.element("errorMSG_XPATH").getText();
				TestBase.test.log(LogStatus.FAIL, ErrorMSG);
				OpportunityCreationAction.clickOnCancel();
				rownum = rownum + 1;
				softAssert.assertTrue(false, ErrorMSG);
				// Excel_DP.excel.setCellData("createOpportunityWithRequireddata", "Error",
				// rownum, tb.element("errorMSG_XPATH").getText());
			}
		} catch (Exception e) {


			//tb.driver.navigate().refresh();
			//CommonSteps.clickOnDetail();

			flag=true;
			tb.takeScreenshot();
			rownum = rownum + 1;
		}
		previousLOB = ContractingParty;
		previousType=type;


	}

	// Adding variables for Plan, Devices, Vanity

	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata",dependsOnMethods = "opportunityTest")
	public void addProductToCart(String ContractingParty, String ProductName, String DeviceName, String DeviceCapcity, String DeviceColor, String SecondDevice, String vasName, String accessoriesName,
			String Addons,String DiscountOnPlanMSF,String DiscountOnDevive,String vanityNoType,String OrderQuantity,String ETSSolutionDesign, String contractTerm, String speed,
			String PaymentMethod,String PlanName, String PaymentFrequency, String NumberType) {

		if (!(RunMode.isTestRunnable("addProductToCart"))) {

			throw new SkipException(
					"Skipping the test " + "addProductToCart".toUpperCase() + "as the Run mode is NO");
		}

		SoftAssert softAssert=new SoftAssert();
		System.out.println("Add product to cart...");

		//tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[1]")));

		try {
			//tb.ExplicitWait("Configure_XPATH");

			OpportunityCreationAction.clickONConfigure();
			Thread.sleep(5000);
			tb.driver.navigate().refresh();
			Thread.sleep(5000);
			try {
				System.out.println("Number of Frames "+tb.driver.findElements(By.tagName("iframe")).size());
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			//			tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("//iframe[@title='accessibility title']")));
			tb.driver.switchTo().frame(0);

			//Amit: Condition to check PriceList to be used
			if (ContractingParty.contains("SMART")) {
				OpportunityCreationAction.SelectSmartPriceList();
			}
			else {
				if(ContractingParty.contains("PLDT")){
					OpportunityCreationAction.SelectPLDTPriceList();
				}
			}

			Thread.sleep(3000);

			OpportunityCreationAction.searchProduct(ProductName);
			try {
				if (tb.element("NoProductAvailable_XPATH").isDisplayed()) {
					tb.takeScreenshot();
					String ErrorMSG = tb.element("NoProductAvailable_XPATH").getText();
					TestBase.test.log(LogStatus.FAIL, ErrorMSG);
					// OpportunityCreationAction.clickOnCancel();
					rownum = rownum + 1;
					softAssert.assertTrue(false, ErrorMSG);
				}
			} catch (Exception e) {

				OpportunityCreationAction.addToCart(ProductName);

				tb.ExplicitWait("ProductConfigurationBtn_XPATH");
				Thread.sleep(1000);

				//Bulk Order
				if(!OrderQuantity.replace(".0", "").contentEquals("1")) {

					OpportunityCreationAction.IncreaseQuantity(OrderQuantity.replace(".0", ""));

				}
				//Add blocks for Smart and PLDT
				//Amit:Condition to check if LOB is Smart
				if (ContractingParty.contains("SMART")) {

					System.out.println("Add device");
					// Adding Device with Plan
					if(!DeviceName.isEmpty()) {

						OpportunityCreationAction.AddChildDevice(DeviceName, "One Time Cash out", DeviceCapcity, DeviceColor);

						//Ankita : Add 2nd device if the product is 5G(Bright)

						if(ProductName.contains("5G") && SecondDevice.contains("Y")) {

							OpportunityCreationAction.AddChildDevice2(DeviceName, "One Time Cash out",
									DeviceCapcity, DeviceColor);

						}

					}
					// Amit: Adding VAS with Plan
					if(!vasName.isEmpty()) {
						if(!ProductName.contains("Bizload")) {

							OpportunityCreationAction.addVASToPlan(vasName);
						}
					}

					// Adding Accessories with Plan
					if(!accessoriesName.isEmpty()) {
						if(!ProductName.contains("A2P")&&!ProductName.contains("Bizload")) {

							OpportunityCreationAction.addAccessoriesToPlan(accessoriesName);
						}
					}
					
					if(ProductName.contains("5G")&&!Addons.isEmpty()) {
						
							OpportunityCreationAction.addAddonsto5GPlans(Addons);;
						
					}
					
					if(ProductName.contains("5G")&&!DiscountOnPlanMSF.isEmpty()) {
						
						OpportunityCreationAction.DiscountOn5GPlan(DiscountOnPlanMSF);
					}
						
					// Adding Vanity
					if((vanityNoType.contains("Premium Number")||vanityNoType.contains("Special Number"))&&!vanityNoType.isEmpty()) {
						OpportunityCreationAction.addVanityNumberFeeToCart(); // add vanity fee to cart

						OpportunityCreationAction.vanityNumberFeeConfiguration();
						Thread.sleep(1000);
						OpportunityCreationAction.selectNumberType(vanityNoType); // Number type
					}

				}
			}

			//Amit:Condition to check if LOB is PLDT
			if (ContractingParty.contains("PLDT")) {

				System.out.println("Add PLDT device");
				//Add Code from James here

				if(!contractTerm.isEmpty())
					OpportunityCreationAction.contractTerm(contractTerm);

				if(!speed.isEmpty())
					OpportunityCreationAction.speed(speed);

				if(!PaymentMethod.isEmpty())
					OpportunityCreationAction.paymentMethod(PaymentMethod);

				if(!PlanName.isEmpty())
					OpportunityCreationAction.planName(PlanName);

				if(!PaymentFrequency.isEmpty())
					OpportunityCreationAction.paymentFrequency(PaymentFrequency);
			}

			tb.takeScreenshot();
			OpportunityCreationAction.ViewRecord();

			System.out.println("\n=====================\n");

			tb.driver.switchTo().parentFrame();

			tb.ExplicitWait("detailBtn_XPATH");

			if(type.equalsIgnoreCase("Business")) {

				OpportunityCreationAction.ChangestatustoEstablishNeed();
			}


		} catch (Exception e) {
			rownum = rownum + 1;
			e.printStackTrace();
		}

	}

}
