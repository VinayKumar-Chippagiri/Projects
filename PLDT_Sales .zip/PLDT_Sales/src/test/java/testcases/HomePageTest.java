package testcases;

import org.testng.SkipException;
import org.testng.annotations.Test;

import base.TestBase;
import loginAndHomePageAction.HomePgaeAction;
import utilities.RunMode;

public class HomePageTest {

	HomePgaeAction homePgaeAction = new HomePgaeAction();
	TestBase tb = new TestBase();
	
	@Test
	public void homepage_test() throws Throwable {

		if (!(RunMode.isTestRunnable("homepage_test"))) {
			throw new SkipException("Skipping the test " + "homepage_test".toUpperCase() + "as the Run mode is NO");
		}

		int rows = RunMode.excel.getRowCount("Feature");
		int cols = RunMode.excel.getColumnCount("Feature");
		System.out.println(rows);
		System.out.println(cols);
		for (int rowNum = 2; rowNum <= rows; rowNum++) { // 2

			String feature = RunMode.excel.getCellData("Feature", 0, rowNum);
			String runmode = RunMode.excel.getCellData("Feature", 1, rowNum);
			runmode = runmode.trim();
			System.out.println(feature);
			System.out.println(runmode);
			if (runmode.equalsIgnoreCase("Y")) {
				Thread.sleep(2000);
				homePgaeAction.click_on_Launcer();
				homePgaeAction.enter_Value_In_Searchbox(feature);
				Thread.sleep(2000);
				homePgaeAction.click_on_value();
				Thread.sleep(2000);
				// TestBase.takeScreenshot();

			}

		}
	}
	
	//LEONYL: This is a new generic method to open the SF global tabs (ie. Opportunities, Cases, Quotes, etc.)
	public void featureURL(String feature) {
		System.out.println("Navigate to Recently Viewed | " + feature);
	    tb.ThreadWait(2000);
		String HomeUrl = tb.driver.getCurrentUrl();
		System.out.println(HomeUrl);
		//Ankita: Go to the specific feature link
        String featurelink= "o/" + feature + "/list?filterName=Recent";
        String featureurl=HomeUrl.replace("page/home", featurelink);
        tb.navigateURL(featureurl);
		//tb.navigateURL("https://pldtoneenterprise--" + tb.config.getProperty("environment") + ".lightning.force.com/lightning/o/" + feature + "/list?filterName=Recent");		
		tb.ExplicitWait("recentlyViewed_XPATH");
	}


}
