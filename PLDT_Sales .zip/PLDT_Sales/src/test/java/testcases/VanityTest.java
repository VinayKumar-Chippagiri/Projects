package testcases;

import java.io.FileWriter;
import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.opencsv.CSVWriter;
import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;
import pageAction.LeadConversionAction;
import pageAction.OpportunityCreationAction;
import utilities.Excel_DP;

public class VanityTest extends Setup {

	OpportunityCreationAction OpportunityCreationAction = new OpportunityCreationAction();
	LeadConversionAction leadConvertionAction = new LeadConversionAction();
	CommonSteps leadStatusObj = new CommonSteps();
	TestBase tb = new TestBase();

	int rownum = 1;
	String previousLOB = null;

	public CSVWriter csvWriter = null;

	String runStatus = "FAIL";

	public VanityTest() {
		FileWriter Writer;
		try {

			Writer = new FileWriter("VanityTesting.csv", true);
			csvWriter = new CSVWriter(Writer);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata")
	public void vanityNumberFee(String category, String planType, String vanityNoType, String onetimecharges, String lob) {

		String onetimecharge = null;

		runStatus = "FAIL";

		try {

			try {
				if (!lob.equalsIgnoreCase(previousLOB)) {
					LoginAsUser.logout();
					LoginAsUser.loginAsUser(lob);
//					tb.driver.get( //quote
//							"https://pldtoneenterprise--r2xsit.lightning.force.com/one/one.app#eyJjb21wb25lbnREZWYiOiJvbmU6YWxvaGFQYWdlIiwiYXR0cmlidXRlcyI6eyJhZGRyZXNzIjoiaHR0cHM6Ly9wbGR0b25lZW50ZXJwcmlzZS0tcjJ4c2l0LmxpZ2h0bmluZy5mb3JjZS5jb20vYXBleC92bG9jaXR5X2NtdF9fSHlicmlkQ1BRP2lkPTBRMDBwMDAwMDAwOHJjaCJ9LCJzdGF0ZSI6e319");

					tb.driver.get( //opportunity
							"https://pldtoneenterprise--r2xsit.lightning.force.com/one/one.app#eyJjb21wb25lbnREZWYiOiJvbmU6YWxvaGFQYWdlIiwiYXR0cmlidXRlcyI6eyJhZGRyZXNzIjoiaHR0cHM6Ly9wbGR0b25lZW50ZXJwcmlzZS0tcjJ4c2l0LmxpZ2h0bmluZy5mb3JjZS5jb20vYXBleC92bG9jaXR5X2NtdF9fSHlicmlkQ1BRP2lkPTAwNjBwMDAwMDA3cE5EQSJ9LCJzdGF0ZSI6e319");

					Thread.sleep(15000);
					tb.driver.switchTo().frame(0);
					OpportunityCreationAction.selectPriceList();

				}

			} catch (Throwable e) {
				e.printStackTrace();
			}

			OpportunityCreationAction.searchProduct(planType);
			Thread.sleep(5000);

			OpportunityCreationAction.addToCart(planType);
			tb.ExplicitWait("ProductConfigurationBtn_XPATH");
			Thread.sleep(2000);

			OpportunityCreationAction.addVanityNumberFeeToCart(); // add vanity fee to cart
			
			for (int i=0; i<3; i++) {
				System.out.println("adding vanity to cart....");
				Thread.sleep(5000);
				
				if (tb.driver.findElements(By.xpath("//span[text()='Vanity Number Fee']/../../../following-sibling::div[5]//span[@class='cpq-underline']")).size() > 0) {
					i = 3;
				}
			}
			
			OpportunityCreationAction.vanityNumberFeeConfiguration();
			
			Thread.sleep(1000);
			tb.takeScreenshot();
			
			OpportunityCreationAction.selectNumberType(vanityNoType); // Number type
			Thread.sleep(13000);

			onetimecharge = OpportunityCreationAction.getVanityOneTimeCharges().replace("₱", "").replace(",", "").replace(".00", "");
			System.out.println(onetimecharge);
			System.out.println("onetimecharges:" + onetimecharges.replace(".0", ""));
			
			if (onetimecharge.trim().toString().equalsIgnoreCase(onetimecharges.replace(".0", "").trim().toString())) {

				System.out.println("onetime charges are correct");
				tb.test.log(LogStatus.PASS, "One-time charge is correct");

				runStatus = "PASS";
			} else {
				System.out.println("onetime charges are incorrect");
				tb.test.log(LogStatus.FAIL, "onetime charges are incorrect");

				runStatus = "FAIL";
			}

		} catch (Exception e) {
			e.printStackTrace();

		} finally {

			tb.test.log(LogStatus.valueOf(runStatus), "Recurring or One-time charges did not match");
		}

		try {
			String[] data1 = { category, planType, vanityNoType, onetimecharges, onetimecharge };
			csvWriter.writeNext(data1);
			csvWriter.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}

		tb.takeScreenshot();
		OpportunityCreationAction.deletePlan();
		previousLOB = lob;

	}
}
