package casemgmt;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.SkipException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

import base.ExtentManager;
import base.TestBase;
import casePageAction.CustomerPortalAction;
import casePageAction.EditCaseAction;
import casePageAction.FulfillmentAndClosureAction;
import casePageAction.SearchCaseAction;
import casePageAction.SmartCasesAction;
import casePageAction.WebToCaseAction;
import junit.framework.Assert;
import loginAndHomePageAction.HomePgaeAction;
import testcases.HomePageTest;
import testcases.LoginAsUser;
import testcases.LoginTest;
import utilities.Excel_DP;
import utilities.RunMode;

public class CaseTest {

	// case related variables
	String caseNumber = "";
	String caseOwner = "";
	String caseDescription = "";
	String runStatus = "";
	String previousUser = "";
	String reportFolder = "Report_" + ExtentManager.getStringDate(); 
	String caseUrl = "";

	int contactSupportDataCount = 1;
	int caseE2ECount = 1;
	int webToCaseDataCount = 1;
	int caseClosureCount = 1;
	int manualCaseCount = 1;
	int autoAssignCount = 1;
	int manualAssignCount = 1;
	int noOfFields = 0;

	boolean firstLogin = true;
	boolean ownerIsQueue = false;

	static SmartCasesAction SmartCasesAction = new SmartCasesAction();
	static HomePgaeAction HomePageAction = new HomePgaeAction();
	static WebToCaseAction WebToCaseAction = new WebToCaseAction();
	static SearchCaseAction SearchCaseAction = new SearchCaseAction();
	static EditCaseAction EditCaseAction = new EditCaseAction();
	static CustomerPortalAction CustomerPortalAction = new CustomerPortalAction();
	static FulfillmentAndClosureAction FulfillmentAndClosureAction = new FulfillmentAndClosureAction();

	static LoginTest LoginTest = new LoginTest();
	static HomePageTest HomePageTest = new HomePageTest();

	public boolean launchFlag = true;
	int rowNum = 1;

	static TestBase tb = new TestBase();
	HomePageTest hpt = new HomePageTest();
	boolean errorFlag = false;


	@SuppressWarnings("static-access")
	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void smartInquiry(String subject, String LoB, String customerRequest, String type, String highlevelTC,
			String transactionType, String transactionSubType, String transactionReason, String amountlimit,
			String caseOrigin, String assignedTo) {

		try {
			String dataSheetName = "smartInquiry";
			Thread.sleep(1000);
			SmartCasesAction.clickOnNewBtn();
			tb.driver.navigate().refresh();
			Thread.sleep(1000);
			SmartCasesAction.clickOnSMARTInqiury();
			SmartCasesAction.clickOnNext();

			CaseCreation(subject, LoB, customerRequest, type, highlevelTC, transactionType, transactionSubType,
					transactionReason, amountlimit, caseOrigin, assignedTo, dataSheetName);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void smartComplaint(String subject, String LoB, String customerRequest, String type, String highlevelTC,
			String transactionType, String transactionSubType, String transactionReason, String amountlimit,
			String caseOrigin, String assignedTo) {
		try {
			String dataSheetName = "smartComplaint";

			Thread.sleep(3000);
			SmartCasesAction.clickOnNewBtn();
			tb.driver.navigate().refresh();
			Thread.sleep(2000);
			SmartCasesAction.clickOnSMARTComplaint();
			SmartCasesAction.clickOnNext();

			CaseCreation(subject, LoB, customerRequest, type, highlevelTC, transactionType, transactionSubType,
					transactionReason, amountlimit, caseOrigin, assignedTo, dataSheetName);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void smartServiceRequest(String subject, String US, String LoB, String customerRequest, String type,
			String highlevelTC, String transactionType, String transactionSubType, String transactionReason,
			String amountlimit, String caseOrigin, String assignedTo, String description) {
		try {
			String dataSheetName = "smartServiceRequest";

			Thread.sleep(3000);
			SmartCasesAction.clickOnNewBtn();
			tb.driver.navigate().refresh();
			Thread.sleep(2000);
			SmartCasesAction.clickOnSMARTServiceRequest();
			SmartCasesAction.clickOnNext();
			Thread.sleep(2000);

			CaseCreation(subject, LoB, customerRequest, type, highlevelTC, transactionType, transactionSubType,
					transactionReason, amountlimit, caseOrigin, assignedTo, dataSheetName);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void PLDTInquiry(String subject, String LoB, String customerRequest, String type, String highlevelTC,
			String transactionType, String transactionSubType, String transactionReason, String amountlimit,
			String caseOrigin, String assignedTo) {
		try {
			String dataSheetName = "PLDTInquiry";
			Thread.sleep(3000);
			SmartCasesAction.clickOnNewBtn();
			tb.driver.navigate().refresh();
			Thread.sleep(1000);
			SmartCasesAction.clickOnPLDTInquiry();
			SmartCasesAction.clickOnNext();

			CaseCreation(subject, LoB, customerRequest, type, highlevelTC, transactionType, transactionSubType,
					transactionReason, amountlimit, caseOrigin, assignedTo, dataSheetName);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void PLDTComplaint(String subject, String LoB, String customerRequest, String type, String highlevelTC,
			String transactionType, String transactionSubType, String transactionReason, String amountlimit,
			String caseOrigin, String assignedTo) {
		try {
			String dataSheetName = "PLDTComplaint";
			Thread.sleep(3000);
			SmartCasesAction.clickOnNewBtn();
			tb.driver.navigate().refresh();
			Thread.sleep(1000);
			SmartCasesAction.clickOnPLDTComplaint();
			SmartCasesAction.clickOnNext();

			CaseCreation(subject, LoB, customerRequest, type, highlevelTC, transactionType, transactionSubType,
					transactionReason, amountlimit, caseOrigin, assignedTo, dataSheetName);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void PLDTServiceRequest(String subject, String US, String LoB, String customerRequest, String type,
			String highlevelTC, String transactionType, String transactionSubType, String transactionReason,
			String amountlimit, String caseOrigin, String assignedTo, String Description) {
		try {
			String dataSheetName = "PLDTServiceRequest";
			Thread.sleep(3000);
			SmartCasesAction.clickOnNewBtn();
			tb.driver.navigate().refresh();
			Thread.sleep(1000);
			SmartCasesAction.clickOnPLDTServiceRequest();
			SmartCasesAction.clickOnNext();

			CaseCreation(subject, LoB, customerRequest, type, highlevelTC, transactionType, transactionSubType,
					transactionReason, amountlimit, caseOrigin, assignedTo, dataSheetName);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void ICTInquiry(String subject, String US, String LoB, String customerRequest, String type,
			String highlevelTC, String transactionType, String transactionSubType, String transactionReason,
			String amountlimit, String caseOrigin, String assignedTo, String description) {
		try {
			String dataSheetName = "ICTInquiry";
			Thread.sleep(3000);
			SmartCasesAction.clickOnNewBtn();
			tb.driver.navigate().refresh();
			Thread.sleep(1000);
			SmartCasesAction.clickOnICTInquiry();
			SmartCasesAction.clickOnNext();

			CaseCreation(subject, LoB, customerRequest, type, highlevelTC, transactionType, transactionSubType,
					transactionReason, amountlimit, caseOrigin, assignedTo, dataSheetName);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void ICTCompliant(String subject, String US, String LoB, String customerRequest, String type,
			String highlevelTC, String transactionType, String transactionSubType, String transactionReason,
			String amountlimit, String caseOrigin, String assignedTo, String description) {
		try {
			String dataSheetName = "ICTCompliant";
			Thread.sleep(3000);
			SmartCasesAction.clickOnNewBtn();
			tb.driver.navigate().refresh();
			Thread.sleep(1000);
			SmartCasesAction.clickOnICTComplaint();
			SmartCasesAction.clickOnNext();

			CaseCreation(subject, LoB, customerRequest, type, highlevelTC, transactionType, transactionSubType,
					transactionReason, amountlimit, caseOrigin, assignedTo, dataSheetName);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void ICTServiceRequest(String subject, String US, String LoB, String customerRequest, String type,
			String highlevelTC, String transactionType, String transactionSubType, String transactionReason,
			String amountlimit, String caseOrigin, String assignedTo, String description) {
		try {
			String dataSheetName = "ICTServiceRequest";
			Thread.sleep(3000);
			SmartCasesAction.clickOnNewBtn();
			tb.driver.navigate().refresh();
			Thread.sleep(2000);
			SmartCasesAction.clickOnICTServiceRequest();
			SmartCasesAction.clickOnNext();
			CaseCreation(subject, LoB, customerRequest, type, highlevelTC, transactionType, transactionSubType,
					transactionReason, amountlimit, caseOrigin, assignedTo, dataSheetName);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void WebToCase(String testCaseNo, String contactName, String emailAddress, String phoneNumber,
			String subject, String description, String lob, String typeOfCustomerRequest, String type,
			String highlevelTC, String transactionType, String transactionSubType, String transactionReason,
			String amountlimit, String caseOrigin, String queue, String agent, String runFlag) throws Throwable {

		String dataSheetName = "WebToCase";
		boolean submitSuccess = false;
		SoftAssert softAssert = new SoftAssert();

		String[] credentials = { "", "" };

		try {

			System.out.println("Web to Case test started... " + testCaseNo);

			runStatus = "FAIL";
			webToCaseDataCount++;

			if (runFlag.equals("Y")) {

				// open new incognito window
				// tb.openNewIncognitoChrome(tb.config.getProperty("webtocaseurl"));
				tb.navigateURL(tb.config.getProperty("customerportaldev2"));

				tb.wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("contactName_XPATH"))));
				WebToCaseAction.enter_ContactName(contactName);
				WebToCaseAction.enter_EmailAddress(emailAddress);
				WebToCaseAction.enter_PhoneNumber(phoneNumber);
				WebToCaseAction.enter_Subject(subject);
				WebToCaseAction.enter_Description(description);

				Thread.sleep(1000);
				tb.takeScreenshot(); // web details

				JavascriptExecutor js = (JavascriptExecutor) tb.driver;
				js.executeScript("arguments[0].scrollIntoView();", tb.element("lob_XPATH"));

				WebToCaseAction.select_LOB(lob);
				WebToCaseAction.select_TypeOfCustomerRequest(typeOfCustomerRequest);

				Thread.sleep(1000);
				tb.takeScreenshot(); // web details

				WebToCaseAction.click_SubmitButton();

				tb.wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("submitSuccess_XPATH"))));

				caseOwner = "Web";

				Thread.sleep(1000);
				tb.takeScreenshot(); // success message

				if (WebToCaseAction.verify_Submit()) {
					// case creation
					System.out.println("Web Request Submission: PASSED");

					Thread.sleep(10000); // 10seconds wait for the submitted case to be created
					// tb.driver.get(tb.config.getProperty("testsiteurlUAT"));
					tb.navigateURL(tb.config.getProperty("testsiteurlUAT"));

					credentials = tb.getUserCredentials(agent);
					//					LoginTest.logintest(credentials[0], credentials[1]);
					HomePageTest.homepage_test();

					Thread.sleep(1000);
					tb.takeScreenshot();

					SearchAndAcceptCase(subject, queue);
					SearchAndViewCase("Recently Viewed Cases", subject);

					tb.wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("editButton_XPATH"))));

					EditCase(type, highlevelTC, transactionType, transactionSubType, transactionReason, amountlimit,
							caseOrigin);
					Thread.sleep(5000);

					tb.driver.navigate().refresh();
					Thread.sleep(2000);

					js.executeScript("arguments[0].scrollIntoView();", tb.element("caseInformation_XPATH"));
					tb.takeScreenshot();

					caseNumber = WebToCaseAction.get_CaseNumber();
					caseOwner = WebToCaseAction.get_CaseOwner();
					//caseDescription = WebToCaseAction.get_CaseTransactionDescription();

					LoginAsUser.logout();

					Thread.sleep(5000);
					tb.takeScreenshot();

					runStatus = "PASS";
					//caseDescription = caseNumber;

				} else {
					System.out.println("Web Request Submission: FAILED");

					TestBase.test.log(LogStatus.FAIL, "Contact Support  Request Submission: FAILED");

				}
			}

		} catch (Exception e) {
			System.out.println("Method WebToCase Catch block");
			e.printStackTrace();

			softAssert.assertTrue(false);

			tb.test.log(LogStatus.FAIL, "Exception error: " + e.getMessage());

		} finally {
			System.out.println("WebToCase Finally block");

			if (runFlag.equals("Y")) {
				Excel_DP.excel.setCellData(dataSheetName, "Assigned", contactSupportDataCount, caseOwner);
				Excel_DP.excel.setCellData(dataSheetName, "Description", contactSupportDataCount, caseNumber);
				Excel_DP.excel.setCellData(dataSheetName, "Status", contactSupportDataCount, runStatus);

				tb.test.log(LogStatus.valueOf(runStatus), "Case Assigned to: " + caseOwner);

			} else {
				System.out.println("Skipped test case: " + testCaseNo);

				runStatus = "SKIP";
				Excel_DP.excel.setCellData(dataSheetName, "Status", contactSupportDataCount, runStatus);

				TestBase.test.log(LogStatus.SKIP, "Testcase not run");
			}
		}

		softAssert.assertAll();

	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void CustomerPortalContactSupport(String testCaseNo, String subject, String lob,
			String typeOfCustomerRequest, String type, String highlevelTC, String transactionType,
			String transactionSubType, String transactionReason, String amountlimit, String caseOrigin, String queue,
			String user, String runFlag) throws Throwable {

		String dataSheetName = "CustomerPortalContactSupport";
		boolean submitSuccess = false;
		SoftAssert softAssert = new SoftAssert();

		String[] credentials = { "", "" };

		try {

			System.out.println("Create case from Customer Portal Contact Support test started... " + testCaseNo);

			runStatus = "FAIL";
			contactSupportDataCount++;

			if (runFlag.equals("Y")) {

				// open new incognito window, login on customer portal and submit request
				//			tb.openNewIncognitoChrome(tb.config.getProperty("customerportaluat"));
				//			tb.openNewIncognitoChrome(tb.config.getProperty("customerportaldev2"));
				tb.navigateURL(tb.config.getProperty("customerportaldev2"));

				// credentials = tb.getUserCredentials("CustomerUAT");
				credentials = tb.getUserCredentials("CustomerDEV2");

				submitSuccess = CustomerPortalLoginAndSubmitRequest(credentials[0], credentials[1], subject,
						typeOfCustomerRequest, lob);
				// submitSuccess =
				// CustomerPortalLoginAndSubmitRequest(tb.config.getProperty("customerPortalUsername"),
				// tb.config.getProperty("customerPortalPassword"),
				// subject, typeOfCustomerRequest, lob);

				caseOwner = "Customer";

				Thread.sleep(5000);
				tb.takeScreenshot();

				if (submitSuccess) {
					System.out.println("Contact Support Request Submission: SUCCESS");
					// login to salesfore as agent to accept and edit the case
					// tb.driver.get(tb.config.getProperty("testsiteurlUAT"));
					// tb.driver.get(tb.config.getProperty("testsiteurl")); //SIT

					credentials = tb.getUserCredentials(user);
					//					LoginTest.logintest(credentials[0], credentials[1]);
					HomePageTest.homepage_test();

					Thread.sleep(1000);
					tb.takeScreenshot();

					System.out.println("Case Number: " + caseNumber);
					SearchAndAcceptCase(caseNumber, queue);
					SearchAndViewCase(caseNumber, queue);

					tb.wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("editButton_XPATH"))));

					EditCase(type, highlevelTC, transactionType, transactionSubType, transactionReason, amountlimit,
							caseOrigin);
					Thread.sleep(5000);

					tb.driver.navigate().refresh();
					Thread.sleep(2000);

					JavascriptExecutor js = (JavascriptExecutor) tb.driver;
					js.executeScript("arguments[0].scrollIntoView();", tb.element("caseInformation_XPATH"));
					tb.takeScreenshot();

					caseNumber = WebToCaseAction.get_CaseNumber();
					caseOwner = WebToCaseAction.get_CaseOwner();
					//					caseDescription = WebToCaseAction.get_CaseTransactionDescription();

					LoginAsUser.logout();

					Thread.sleep(5000);
					tb.takeScreenshot();

					runStatus = "PASS";
					//					caseDescription = caseNumber;

				} else {
					System.out.println("Contact Support  Request Submission: FAILED");

					TestBase.test.log(LogStatus.FAIL, "Contact Support  Request Submission: FAILED");
					TestBase.test.log(LogStatus.FAIL, "Case Assigned to: " + caseOwner);

				}

				//				tb.driver.close();
			}

		} catch (Exception e) {
			System.out.println("Method CustomerPortalContactSupport Catch block");
			e.printStackTrace();

			softAssert.assertTrue(false);

			tb.test.log(LogStatus.FAIL, "Exception error: " + e.getMessage());

		} finally {
			System.out.println("CustomerPortalContactSupport Finally block");

			if (runFlag.equals("Y")) {
				Excel_DP.excel.setCellData(dataSheetName, "Assigned", contactSupportDataCount, caseOwner);
				Excel_DP.excel.setCellData(dataSheetName, "Description", contactSupportDataCount, caseNumber);
				Excel_DP.excel.setCellData(dataSheetName, "Status", contactSupportDataCount, runStatus);

				tb.test.log(LogStatus.valueOf(runStatus), "Case Assigned to: " + caseOwner);

			} else {
				System.out.println("Skipped test case: " + testCaseNo);

				runStatus = "SKIP";
				Excel_DP.excel.setCellData(dataSheetName, "Status", contactSupportDataCount, runStatus);

				TestBase.test.log(LogStatus.SKIP, "Testcase not run");
			}
		}

		softAssert.assertAll();

	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void CustomerPortalChatSupport(String testCaseNo, String subject, String lob, String typeOfCustomerRequest,
			String type, String highlevelTC, String transactionType, String transactionSubType,
			String transactionReason, String amountlimit, String caseOrigin, String queue, String user, String runFlag)
					throws Throwable {

		String dataSheetName = "CustomerPortalChatSupport";
		boolean submitSuccess = false;
		SoftAssert softAssert = new SoftAssert();

		String[] credentials = { "", "" };

		try {

			System.out.println("Case creation from Customer Portal Chat support test started... " + testCaseNo);
			//			tb.test.log(LogStatus.INFO, "Case creation from Customer Portal Chat support test started... " + testCaseNo);

			runStatus = "FAIL";
			contactSupportDataCount++;

			if (runFlag.equals("Y")) {

				// open new incognito window, login on customer portal and submit request
				// tb.openNewIncognitoChrome(tb.config.getProperty("customerportaluat"));
				//				tb.openNewIncognitoChrome(tb.config.getProperty("customerportaldev2"));
				tb.navigateURL(tb.config.getProperty("customerportaldev2"));

				// credentials = tb.getUserCredentials("CustomerUAT");
				credentials = tb.getUserCredentials("CustomerDEV2");

				submitSuccess = CustomerPortalLoginAndSubmitRequestChat(credentials[0], credentials[1], subject,
						typeOfCustomerRequest, lob);

				caseOwner = "Customer";

				Thread.sleep(5000);
				tb.takeScreenshot();

				if (submitSuccess) {
					System.out.println("Contact Support Request Submission: SUCCESS");

					// login to salesfore as agent to accept and edit the case
					// tb.driver.get(tb.config.getProperty("testsiteurl")); //SIT
					tb.navigateURL(tb.config.getProperty("testsiteurlUAT"));

					credentials = tb.getUserCredentials(user);

					//					LoginTest.logintest(credentials[0], credentials[1]);

					tb.wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("appName_XPATH"))));
					HomePageTest.homepage_test();

					Thread.sleep(1000);
					tb.takeScreenshot();

					System.out.println("Case Number: " + caseNumber);

					SearchAndAcceptCase(caseNumber, queue);
					SearchAndViewCase(caseNumber, queue);

					tb.wait.until(ExpectedConditions
							.presenceOfElementLocated(By.xpath(tb.OR.getProperty("editButton_XPATH"))));
					EditCase(type, highlevelTC, transactionType, transactionSubType, transactionReason, amountlimit,
							caseOrigin);
					Thread.sleep(3000);

					// log fail if errors found on after Edit>Save
					//					if (tb.element("commonError_XPATH").isDisplayed()) {
					if (tb.isElementPresent(By.xpath(tb.OR.getProperty("commonError_XPATH")))) {
						System.out.println("Missing mandatory fields check...");
						Thread.sleep(2000);
						tb.takeScreenshot();

						tb.test.log(LogStatus.FAIL, tb.element("caseError_XPATH").getText());
						EditCaseAction.click_CancelButton();
					}

					//					tb.driver.navigate().refresh();
					//					Thread.sleep(2000);

					JavascriptExecutor js = (JavascriptExecutor) tb.driver;
					js.executeScript("arguments[0].scrollIntoView();", tb.element("caseInformation_XPATH"));
					tb.takeScreenshot();

					caseNumber = WebToCaseAction.get_CaseNumber();
					caseOwner = WebToCaseAction.get_CaseOwner();
					//					caseDescription = WebToCaseAction.get_CaseTransactionDescription();

					LoginAsUser.logout();

					Thread.sleep(3000);
					tb.takeScreenshot();

					runStatus = "PASS";

				} else {
					System.out.println("Contact Support  Request Submission: FAILED");

					tb.test.log(LogStatus.FAIL, "Contact Support  Request Submission: FAILED");
					tb.test.log(LogStatus.FAIL, "Case Assigned to: " + caseOwner);
				}

				// tb.driver.close();
			}

		} catch (Exception e) {
			System.out.println("Method CustomerPortalChatSupport Catch block");
			e.printStackTrace();

			softAssert.assertTrue(false);

			tb.test.log(LogStatus.FAIL, "Exception error: " + e.getMessage());

		} finally {
			System.out.println("CustomerPortalChatSupport Finally block");

			if (runFlag.equals("Y")) {
				Excel_DP.excel.setCellData(dataSheetName, "Assigned", contactSupportDataCount, caseOwner);
				Excel_DP.excel.setCellData(dataSheetName, "Description", contactSupportDataCount, caseNumber);
				Excel_DP.excel.setCellData(dataSheetName, "Status", contactSupportDataCount, runStatus);

				tb.test.log(LogStatus.valueOf(runStatus), "Case Assigned to: " + caseOwner);

			} else {
				System.out.println("Skipped test case: " + testCaseNo);

				runStatus = "SKIP";
				Excel_DP.excel.setCellData(dataSheetName, "Status", contactSupportDataCount, runStatus);

				TestBase.test.log(LogStatus.SKIP, "Testcase not run");
			}
		}

		softAssert.assertAll();
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void CaseFulfillmentAndClosure(String testCaseNo, String contact, String subject, String LoB,
			String typeOfCustomerRequest, String type, String highlevelTC, String transactionType,
			String transactionSubType, String transactionReason, String amountlimit, String caseOrigin, String product,
			String otherOneTimeFee, String waiverOfMoveFee, String transactionEntry, String noOfLines, String l1User,
			String l1Queue, String l2User, String l2Queue, String l3User, String l3Queue, String resolveFlag,
			String runFlag) throws Throwable {

		String dataSheetName = "CaseFulfillmentAndClosure";
		boolean submitSuccess = false;
		boolean closeSuccess = false;
		SoftAssert softAssert = new SoftAssert();

		String[] credentials = { "", "" };

		try {

			System.out.println("Case Fulfillment & Closure test started... " + testCaseNo);

			runStatus = "FAIL";
			caseClosureCount++;
			softAssert.assertTrue(true);

			if (runFlag.equals("Y")) {
				tb.navigateURL(tb.config.getProperty("testsiteurlUAT"));

				//				credentials = tb.getUserCredentials(l1User);
				//				System.out.println(credentials[0] + " | " + credentials[1]);
				//				LoginTest.logintest(credentials[0], credentials[1]);
				LoginAsUser.loginAsUser(l1User);

				System.out.println("Title: " + tb.driver.getTitle());

				//				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("appName_XPATH"))));				
				HomePageTest.homepage_test();

				System.out.println("Title: " + tb.driver.getTitle());

				Thread.sleep(3000);
				tb.takeScreenshot();

				// case creation
				CaseCreation(contact, subject, LoB, typeOfCustomerRequest, type, highlevelTC, transactionType,
						transactionSubType, transactionReason, amountlimit, caseOrigin, product, otherOneTimeFee,
						waiverOfMoveFee, transactionEntry, noOfLines);

				// wait until case is saved
				while (tb.driver.getTitle().contains("New Case")) {
					Thread.sleep(1000);
				}

				tb.takeScreenshot();

				//				if (SmartCasesAction.verify_SaveNewCase()) {

				caseNumber = WebToCaseAction.get_CaseNumber();
				System.out.println("Case Number: " + caseNumber);
				tb.test.log(LogStatus.INFO, "Case Number: " + caseNumber);

				//					caseOwner = WebToCaseAction.get_CaseOwner();					
				//					System.out.println("Case Owner level 1: " + caseOwner);
				//					tb.test.log(LogStatus.INFO, "Case Owner: " + caseOwner);

				hpt.featureURL("Case"); //nagivate to Recently Viewed Cases

				if (!l1Queue.isEmpty()) {
					SearchAndAcceptCase(caseNumber, l1Queue);
					hpt.featureURL("Case"); 
				}

				SearchAndViewCase("Recently Viewed Cases", caseNumber);

				tb.refreshPage();

				// check for re-assignment to level 2
				if (!l2User.isEmpty()) {

					if (!l2Queue.isEmpty()) {
						ChangeOwner(l2Queue, "Queue"); // assign to level 2 queue
					} else {
						ChangeOwner(l2User, "People"); // assign to level 2 user
					}

					tb.takeScreenshot();

					LoginAsUser.logout(); // logout level 1
					tb.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='footer']")));
					tb.navigateURL(tb.config.getProperty("testsiteurlUAT"));

					//					credentials = tb.getUserCredentials(l2User);
					//					LoginTest.logintest(credentials[0], credentials[1]); // login level 2		
					//					HomePageTest.homepage_test();

					LoginAsUser.loginAsUser(l2User);
					tb.navigateToHome();

					if (!l2Queue.isEmpty()) {
						SearchAndAcceptCase(caseNumber, l2Queue);
						hpt.featureURL("Case"); 
					}

					SearchAndViewCase("All Cases", caseNumber);

					if (!l3User.isEmpty()) { // check for re-assignment to level 3

						// current case is loaded
						tb.refreshPage();

						if (!l3Queue.isEmpty()) {
							ChangeOwner(l3Queue, "Queue"); // assign to level 3 queue
						} else {
							ChangeOwner(l3User, "People"); // assign to level 3 user
						}

						LoginAsUser.logout(); // logout level 2
						tb.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='footer']")));
						tb.navigateURL(tb.config.getProperty("testsiteurlUAT"));

						//						credentials = tb.getUserCredentials(l3User);
						//						LoginTest.logintest(credentials[0], credentials[1]); // login level 2
						//						HomePageTest.homepage_test();

						LoginAsUser.loginAsUser(l3User);
						tb.navigateToHome();

						if (!l3Queue.isEmpty()) {
							SearchAndAcceptCase(caseNumber, l3Queue);
							hpt.featureURL("Case");
						}

						SearchAndViewCase("All Cases", caseNumber);
					}
				}

				tb.refreshPage();
				Thread.sleep(2000);

				// resolve & close the case
				closeSuccess = ResolveAndCloseCase(caseNumber, resolveFlag);
				if (closeSuccess) {
					runStatus = "PASS";
				}

				caseOwner = WebToCaseAction.get_CaseOwner();
				tb.scrollElementIntoView("caseOwnerIcon_XPATH");
				System.out.println("Case Owner: " + caseOwner);
				Thread.sleep(1000);
				tb.takeScreenshot();

				LoginAsUser.logout(); // logout user
			} // successful Save

			//			}//runFlag = Y

		} catch (Exception e) {
			System.out.println("Method CaseFulfillmentAndClosure Catch block");
			e.printStackTrace();

			LoginAsUser.logout(); // logout user

			softAssert.assertTrue(false);
			tb.test.log(LogStatus.FAIL, "Exception error: " + e.getMessage());

		} finally {
			System.out.println("CaseFulfillmentAndClosure Finally block");

			if (runFlag.equals("Y")) {
				Excel_DP.excel.setCellData(dataSheetName, "Assigned", caseClosureCount, caseOwner);
				Excel_DP.excel.setCellData(dataSheetName, "Description", caseClosureCount, caseNumber);
				Excel_DP.excel.setCellData(dataSheetName, "Status", caseClosureCount, runStatus);

				tb.test.log(LogStatus.valueOf(runStatus), "Case Assigned to: " + caseOwner);

			} else {
				System.out.println("Skipped test case: " + testCaseNo);

				runStatus = "SKIP";
				Excel_DP.excel.setCellData(dataSheetName, "Status", caseClosureCount, runStatus);

				tb.test.log(LogStatus.SKIP, "Testcase not run");
			}
		} // finally block

		softAssert.assertAll();

	} // CaseFulfillmentAndClosure end

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled=false)
	public void ManualCaseCreation(String testCaseNo, String runFlag, String contact, String subject, String LoB,
			String typeOfCustomerRequest, String type, String highlevelTC, String transactionType,
			String transactionSubType, String transactionReason, String amountlimit, String caseOrigin, String product,
			String otherOneTimeFee, String waiverOfMoveFee, String transactionEntry, String noOfLines, String agent) throws Throwable {

		//skip if runmode is NO
		String dataSheetName = "ManualCaseCreation";
		if (!(RunMode.isTestRunnable(dataSheetName))) {
			throw new SkipException("Skipping the test " + dataSheetName.toUpperCase() + " as the Run mode is NO");
		}

		boolean submitSuccess = false;
		boolean closeSuccess = false;
		SoftAssert softAssert = new SoftAssert();

		String[] credentials = { "", "" };

		try {

			System.out.println("Manual Case Creation test started... " + testCaseNo);

			//add columns for test results
			if (manualCaseCount == 1) {
				Excel_DP.excel.addColumn(dataSheetName, "CaseOwner");
				Excel_DP.excel.addColumn(dataSheetName, "CaseNumber");
				Excel_DP.excel.addColumn(dataSheetName, "Status");
				Excel_DP.excel.addColumn(dataSheetName, "Report");
			}

			runStatus = "FAIL";
			manualCaseCount++;
			softAssert.assertTrue(true);

			if (runFlag.equals("Y")) {
				//				tb.navigateURL(tb.config.getProperty("testsiteurlUAT"));
				//				System.out.println("users: " + previousUser + " | " + agent);

				if (previousUser != "" && !agent.equals(previousUser)) {
					LoginAsUser.logout(); 
					tb.navigateURL(tb.config.getProperty("testsiteurl"));

					firstLogin = true;
				}

				if (firstLogin) {
					previousUser = agent;

					//					credentials = tb.getUserCredentials(agent);
					//					System.out.println(credentials[0] + " | " + credentials[1]);
					//					LoginTest.logintest(credentials[0], credentials[1]);
					//					//					System.out.println("login first time");

					LoginAsUser.loginAsUser(agent);
					firstLogin = false;
				}

				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("appName_XPATH"))));
				hpt.featureURL("Case"); 

				Thread.sleep(3000);
				tb.takeScreenshot();

				// case creation
				CaseCreation(contact, subject, LoB, typeOfCustomerRequest, type, highlevelTC, transactionType,
						transactionSubType, transactionReason, amountlimit, caseOrigin, product, otherOneTimeFee,
						waiverOfMoveFee, transactionEntry, noOfLines);

				Thread.sleep(2000);
				tb.takeScreenshot();

				caseNumber = WebToCaseAction.get_CaseNumber();
				System.out.println("Case Number: " + caseNumber);

				caseOwner = WebToCaseAction.get_CaseOwner();;			
				if(caseOwner.endsWith("_Q")) {
					ownerIsQueue = true;
					caseOwner = caseOwner.substring(0, caseOwner.length() - 2);
				}
				System.out.println("Case Owner: " + caseOwner);

				runStatus = "PASS";

			} // runFlag = Y

		} catch (Exception e) {
			System.out.println("Manual Case Creation Catch block");
			e.printStackTrace();

			softAssert.assertTrue(false);
			tb.test.log(LogStatus.FAIL, "Exception error: " + e.getMessage());

		} finally {
			System.out.println("Manual Case Creation Finally block");

			if (runFlag.equals("Y")) {				
				//populate next flow (Manual Case Assignment) with case number & owner
				Excel_DP.excel.setCellData("ManualCaseAssignment", "CaseNumber", manualCaseCount, caseNumber);
				if (ownerIsQueue) {
					Excel_DP.excel.setCellData("ManualCaseAssignment", "ownerQueue", manualCaseCount, caseOwner);
				} else {
					Excel_DP.excel.setCellData("ManualCaseAssignment", "ownerPerson", manualCaseCount, caseOwner);
				}

				Excel_DP.excel.setCellData(dataSheetName, "CaseOwner", manualCaseCount, caseOwner);
				Excel_DP.excel.setCellData(dataSheetName, "CaseNumber", manualCaseCount, caseNumber);
				Excel_DP.excel.setCellData(dataSheetName, "Report", manualCaseCount, reportFolder);

				tb.test.log(LogStatus.valueOf(runStatus), "Case Assigned to: " + caseOwner);

			} else {
				System.out.println("Skipped test case: " + testCaseNo);

				runStatus = "SKIP";
				tb.test.log(LogStatus.SKIP, "Testcase not run");
			}

			Excel_DP.excel.setCellData(dataSheetName, "Status", manualCaseCount, runStatus);

		} // finally block

		softAssert.assertAll();

	} // CaseFulfillmentAndClosure end

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled=false)
	public void CaseAutoAssignment(String testCaseNo, String runFlag, String contact, String subject, String LoB,
			String typeOfCustomerRequest, String type, String highlevelTC, String transactionType,
			String transactionSubType, String transactionReason, String amountlimit, String caseOrigin, String product,
			String otherOneTimeFee, String waiverOfMoveFee, String transactionEntry, String noOfLines, String agent,
			String assignee ) throws Throwable {

		//skip if runmode is NO
		String dataSheetName = "CaseAutoAssignment";
		if (!(RunMode.isTestRunnable(dataSheetName))) {
			throw new SkipException("Skipping the test " + dataSheetName.toUpperCase() + " as the Run mode is NO");
		}

		boolean submitSuccess = false;
		SoftAssert softAssert = new SoftAssert();

		String[] credentials = { "", "" };

		try {

			System.out.println("Case Auto Assignment test started... " + testCaseNo);

			//add columns for test results
			if (autoAssignCount == 1) {
				Excel_DP.excel.addColumn(dataSheetName, "CaseOwner");
				Excel_DP.excel.addColumn(dataSheetName, "CaseNumber");
				Excel_DP.excel.addColumn(dataSheetName, "Status");
				Excel_DP.excel.addColumn(dataSheetName, "Report");
			}

			runStatus = "FAIL";
			autoAssignCount++;
			softAssert.assertTrue(true);

			if (runFlag.equals("Y")) {

				System.out.println("previous user: " + previousUser);
				System.out.println("current agent: " + agent);

				if (previousUser != "" && !agent.equals(previousUser)) {
					System.out.println("logout inside if check");
					LoginAsUser.logout();

					firstLogin = true;
				}

				if (firstLogin) {
					System.out.println("first login true");
					previousUser = agent;

					LoginAsUser.loginAsUser(agent);

					firstLogin = false;
				}

				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("appName_XPATH"))));
				hpt.featureURL("Case"); 

				System.out.println("Title: " + tb.driver.getTitle());
				Thread.sleep(2000);
				tb.takeScreenshot();

				// case creation
				CaseCreation(contact, subject, LoB, typeOfCustomerRequest, type, highlevelTC, transactionType,
						transactionSubType, transactionReason, amountlimit, caseOrigin, product, otherOneTimeFee,
						waiverOfMoveFee, transactionEntry, noOfLines);

				// wait until case is saved
				while (tb.driver.getTitle().contains("New Case")) {
					Thread.sleep(1000);
				}

				tb.takeScreenshot();

				caseNumber = WebToCaseAction.get_CaseNumber();
				System.out.println("Case Number: " + caseNumber);
				tb.test.log(LogStatus.INFO, "Case Number: " + caseNumber);

				caseOwner = WebToCaseAction.get_CaseOwner();
				tb.scrollElementIntoView("caseOwnerIcon_XPATH");
				if(caseOwner.endsWith("_Q")) {
					ownerIsQueue = true;
					caseOwner = caseOwner.substring(0, caseOwner.length() - 2);
				}
				System.out.println("Case Owner: " + caseOwner);

				Thread.sleep(1000);
				tb.takeScreenshot();

				// compare assigned queue
				if (caseOwner.contentEquals(assignee)) {
					runStatus = "PASS";
				}

			} // runFlag = Y

		} catch (Exception e) {
			System.out.println("Case Auto Assignment Catch block");
			e.printStackTrace();

			previousUser = "";	
			tb.click("newCaseCancelButton_XPATH");
			Thread.sleep(3000);
			LoginAsUser.logout(); // logout user

			softAssert.assertTrue(false);
			tb.test.log(LogStatus.FAIL, "Exception error: " + e.getMessage());

		} finally {
			System.out.println("Case Auto Assignment Finally block");
			tb.takeScreenshot();

			if (runFlag.equals("Y")) {			
				//populate next flow (Manual Case Assignment) with case number & owner
				Excel_DP.excel.setCellData("ManualCaseAssignment", "CaseNumber", autoAssignCount, caseNumber);
				Excel_DP.excel.setCellData("ManualCaseAssignment", "testCaseNo", autoAssignCount, testCaseNo);
				Excel_DP.excel.setCellData("CaseClosure", "CaseNumber", autoAssignCount, caseNumber);
				Excel_DP.excel.setCellData("CaseClosure", "testCaseNo", autoAssignCount, testCaseNo);

				if (ownerIsQueue) {
					Excel_DP.excel.setCellData("ManualCaseAssignment", "ownerQueue", autoAssignCount, caseOwner);
					Excel_DP.excel.setCellData("CaseClosure", "ownerQueue", autoAssignCount, caseOwner);
				} else {
					Excel_DP.excel.setCellData("ManualCaseAssignment", "ownerPerson", autoAssignCount, caseOwner);
					Excel_DP.excel.setCellData("CaseClosure", "ownerPerson", autoAssignCount, caseOwner);
				}

				Excel_DP.excel.setCellData(dataSheetName, "CaseOwner", autoAssignCount, caseOwner);
				Excel_DP.excel.setCellData(dataSheetName, "CaseNumber", autoAssignCount, caseNumber);
				Excel_DP.excel.setCellData(dataSheetName, "Report", autoAssignCount, reportFolder);

				tb.test.log(LogStatus.valueOf(runStatus), "Case Assigned to: " + caseOwner);

			} else {
				System.out.println("Skipped test case: " + testCaseNo);

				runStatus = "SKIP";
				tb.test.log(LogStatus.SKIP, "Testcase not run");
			}

			Excel_DP.excel.setCellData(dataSheetName, "Status", autoAssignCount, runStatus);

		} // finally block

		softAssert.assertAll();

	} // CaseAutoAssignment end

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled=false)
	public void ManualCaseAssignment(String testCaseNo, String runflag, String caseNo, String ownerQueue, String ownerPerson, String assignToPerson, String assignToQueue) throws Throwable {

		//skip if runmode is NO
		String dataSheetName = "ManualCaseAssignment";
		if (!(RunMode.isTestRunnable(dataSheetName))) {
			throw new SkipException("Skipping the test " + dataSheetName.toUpperCase() + " as the Run mode is NO");
		}

		boolean closeSuccess = false;
		SoftAssert softAssert = new SoftAssert();

		String[] credentials = { "", "" };

		try {

			System.out.println("Case Manual Assignment test started... " + testCaseNo);

			//add columns for test results
			if (manualAssignCount == 1) {
				Excel_DP.excel.addColumn(dataSheetName, "CaseOwner");
				Excel_DP.excel.addColumn(dataSheetName, "Status");
				Excel_DP.excel.addColumn(dataSheetName, "Report");
			}

			runStatus = "FAIL";
			manualAssignCount++;
			softAssert.assertTrue(true);

			if (runflag.equals("Y")) {
				tb.navigateURL(tb.config.getProperty("testsiteurl"));

				LoginAsUser.loginAsUser(ownerPerson);
				hpt.featureURL("Case");

				System.out.println("Title: " + tb.driver.getTitle());

				Thread.sleep(2000);
				tb.takeScreenshot();

				if (!ownerQueue.isEmpty()) {
					SearchAndAcceptCase(caseNo, ownerQueue);
				}

				SearchAndViewCase("My Cases", caseNo);
				tb.refreshPage();
				Thread.sleep(2000);

				// assign the case
				if (!assignToQueue.isEmpty()) {
					ChangeOwner(assignToQueue, "Queue"); // assign to queue
				} else {
					ChangeOwner(assignToPerson, "People"); // assign to person
				}

				caseNumber = WebToCaseAction.get_CaseNumber();
				System.out.println("Case Number: " + caseNumber);
				tb.test.log(LogStatus.INFO, "Case Number: " + caseNumber);

				caseOwner = WebToCaseAction.get_CaseOwner();
				tb.scrollElementIntoView("caseOwnerIcon_XPATH");
				System.out.println("Case Owner: " + caseOwner);
				Thread.sleep(1000);
				tb.takeScreenshot();

				LoginAsUser.logout(); // logout user

				runStatus = "PASS";

			} // runFlag = Y

		} catch (Exception e) {
			System.out.println("Method ManualCaseAssignment Catch block");
			e.printStackTrace();

			LoginAsUser.logout(); // logout user
			tb.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='footer']")));

			softAssert.assertTrue(false);
			tb.test.log(LogStatus.FAIL, "Exception error: " + e.getMessage());

		} finally {
			System.out.println("ManualCaseAssignment Finally block");

			if (runflag.equals("Y")) {
				Excel_DP.excel.setCellData(dataSheetName, "CaseOwner", manualAssignCount, caseOwner);
				Excel_DP.excel.setCellData(dataSheetName, "Report", manualAssignCount, reportFolder);

				tb.test.log(LogStatus.valueOf(runStatus), "Case Assigned to: " + caseOwner);

			} else {
				System.out.println("Skipped test case: " + testCaseNo);

				runStatus = "SKIP";
				tb.test.log(LogStatus.SKIP, "Testcase not run");
			}

			Excel_DP.excel.setCellData(dataSheetName, "Status", manualAssignCount, runStatus);

		} // finally block

		softAssert.assertAll();
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled=false)
	public void CaseClosure(String testCaseNo, String runflag, String caseNo, String queue, String user, String resolveFlag) throws Throwable {

		//skip if runmode is NO
		String dataSheetName = "CaseClosure";
		if (!(RunMode.isTestRunnable(dataSheetName))) {
			throw new SkipException("Skipping the test " + dataSheetName.toUpperCase() + " as the Run mode is NO");
		}

		boolean closeSuccess = false;
		SoftAssert softAssert = new SoftAssert();

		String[] credentials = { "", "" };

		try {

			System.out.println("Case Closure test started... " + testCaseNo);

			//add columns for test results
			if (caseClosureCount == 1) {
				Excel_DP.excel.addColumn(dataSheetName, "CaseOwner");
				Excel_DP.excel.addColumn(dataSheetName, "Status");
				Excel_DP.excel.addColumn(dataSheetName, "Report");
			}

			runStatus = "FAIL";
			caseClosureCount++;
			softAssert.assertTrue(true);

			if (runflag.equals("Y")) {
				tb.navigateURL(tb.config.getProperty("testsiteurl"));

				//				credentials = tb.getUserCredentials(user);
				//				System.out.println(credentials[0] + " | " + credentials[1]);
				//				LoginTest.logintest(credentials[0], credentials[1]);
				//				HomePageTest.homepage_test();

				LoginAsUser.loginAsUser(user);
				tb.navigateToHome();

				System.out.println("Title: " + tb.driver.getTitle());

				Thread.sleep(3000);
				tb.takeScreenshot();

				if (!queue.isEmpty()) {
					SearchAndAcceptCase(caseNo, queue);
				}

				SearchAndViewCase("All Cases", caseNo);
				tb.refreshPage();
				Thread.sleep(2000);

				// resolve & close the case
				closeSuccess = ResolveAndCloseCase(caseNo, resolveFlag);
				if (closeSuccess) {
					runStatus = "PASS";
				}

				caseOwner = WebToCaseAction.get_CaseOwner();
				tb.scrollElementIntoView("caseOwnerIcon_XPATH");
				System.out.println("Case Owner: " + caseOwner);
				Thread.sleep(1000);
				tb.takeScreenshot();

				LoginAsUser.logout(); // logout user
				tb.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='footer']")));

			} // runFlag = Y

		} catch (Exception e) {
			System.out.println("Method CaseClosure Catch block");
			e.printStackTrace();

			LoginAsUser.logout(); // logout user
			tb.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='footer']")));

			softAssert.assertTrue(false);
			tb.test.log(LogStatus.FAIL, "Exception error: " + e.getMessage());

		} finally {
			System.out.println("CaseClosure Finally block");

			if (runflag.equals("Y")) {
				Excel_DP.excel.setCellData(dataSheetName, "CaseOwner", caseClosureCount, caseOwner);
				Excel_DP.excel.setCellData(dataSheetName, "Report", caseClosureCount, reportFolder);

				tb.test.log(LogStatus.valueOf(runStatus), "Case Assigned to: " + caseOwner);

			} else {
				System.out.println("Skipped test case: " + testCaseNo);

				runStatus = "SKIP";
				tb.test.log(LogStatus.SKIP, "Testcase not run");
			}

			Excel_DP.excel.setCellData(dataSheetName, "Status", caseClosureCount, runStatus);

		} // finally block

		softAssert.assertAll();

	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled=true)
	public void CaseMgmtEndToEnd(String testCaseNo, String runFlag, String contact, String subject, String LoB,	String typeOfCustomerRequest, String type, String highlevelTC, String transactionType,
			String transactionSubType, String transactionReason, String amountlimit, String caseOrigin, String product, String otherOneTimeFee, String waiverOfMoveFee, String transactionEntry, 
			String noOfLines, String l1User, String l1Queue, String l2User, String l2Queue, String l3User, String l3Queue, String autoAssignee, String autoAssignFlag, String resolveFlag) throws Throwable {

		//skip if runmode is NO
		String dataSheetName = "CaseMgmtEndToEnd";
		if (!(RunMode.isTestRunnable(dataSheetName))) {
			throw new SkipException("Skipping the test " + dataSheetName.toUpperCase() + " as the Run mode is NO");
		}

		boolean submitSuccess = false;
		boolean closeSuccess = false;
		SoftAssert softAssert = new SoftAssert();

		try {

			System.out.println("Case Management End-to-End test started... " + testCaseNo);

//			//add columns for test results
//			if (caseE2ECount == 1) {
//				Excel_DP.excel.addColumn(dataSheetName, "CaseOwner");
//				Excel_DP.excel.addColumn(dataSheetName, "CaseNumber");
//				Excel_DP.excel.addColumn(dataSheetName, "Status");
//				Excel_DP.excel.addColumn(dataSheetName, "Report");
//			}

			runStatus = "FAIL";
			caseE2ECount++;
			softAssert.assertTrue(true);

			if (runFlag.equals("Y")) {
				tb.navigateURL(tb.config.getProperty("testsiteurl"));

				LoginAsUser.loginAsUser(l1User);
				hpt.featureURL("Case");

				System.out.println("Title: " + tb.driver.getTitle());

				Thread.sleep(3000);
				tb.takeScreenshot();

				// case creation
				CaseCreation(contact, subject, LoB, typeOfCustomerRequest, type, highlevelTC, transactionType,
						transactionSubType, transactionReason, amountlimit, caseOrigin, product, otherOneTimeFee,
						waiverOfMoveFee, transactionEntry, noOfLines);

				// wait until case is saved
				while (tb.driver.getTitle().contains("New Case")) {
					Thread.sleep(1000);
				}

				caseUrl = tb.driver.getCurrentUrl();  
				caseNumber = WebToCaseAction.get_CaseNumber();
				System.out.println("Case Number: " + caseNumber);
				tb.test.log(LogStatus.INFO, "Case Number: " + caseNumber);

				caseOwner = WebToCaseAction.get_CaseOwner();
				tb.scrollElementIntoView("caseOwnerIcon_XPATH");
				if(caseOwner.endsWith("_Q")) {
					caseOwner = caseOwner.substring(0, caseOwner.length() - 2);
				}
				System.out.println("Case Owner: " + caseOwner);

				Thread.sleep(1000);
				tb.takeScreenshot();

				// check auto-assignment and continue of PASSED
				if (caseOwner.contentEquals(autoAssignee)) {

					hpt.featureURL("Case"); //nagivate to Recently Viewed Cases

					if (!l1Queue.isEmpty()) {
						SearchAndAcceptCase(caseNumber, l1Queue); 
					}

					tb.navigateURL(caseUrl);

					// check for re-assignment to level 2
					if (!l2User.isEmpty()) {

						//bypass case assignment if autoAssign Flag is Y
						if(!autoAssignFlag.equals("Y")) {					
							if (!l2Queue.isEmpty()) {
								ChangeOwner(l2Queue, "Queue"); // assign to level 2 queue
							} else {
								ChangeOwner(l2User, "People"); // assign to level 2 user
							}
						}
						
						tb.takeScreenshot();

						Thread.sleep(3000);
						LoginAsUser.logout(); // logout level 1
//						tb.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='footer']")));
						tb.wait.until(ExpectedConditions.titleContains("Login | Salesforce"));
						tb.navigateURL(tb.config.getProperty("testsiteurl"));

						LoginAsUser.loginAsUser(l2User);
						hpt.featureURL("Case"); 

						if (!l2Queue.isEmpty()) {
							SearchAndAcceptCase(caseNumber, l2Queue);
						}

						tb.navigateURL(caseUrl);
					}

					// check for re-assignment to level 3
					if (!l3User.isEmpty()) { 

						if (!l3Queue.isEmpty()) {
							ChangeOwner(l3Queue, "Queue"); // assign to level 3 queue
						} else {
							ChangeOwner(l3User, "People"); // assign to level 3 user
						}

						tb.takeScreenshot();
						
						Thread.sleep(3000);
						LoginAsUser.logout(); // logout level 2
//						tb.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='footer']")));
						tb.wait.until(ExpectedConditions.titleContains("Login | Salesforce"));
						tb.navigateURL(tb.config.getProperty("testsiteurl"));

						LoginAsUser.loginAsUser(l3User);
						hpt.featureURL("Case"); 

						if (!l3Queue.isEmpty()) {
							SearchAndAcceptCase(caseNumber, l3Queue);
						}

						tb.navigateURL(caseUrl);
					}

					tb.refreshPage();
					Thread.sleep(2000);

					caseOwner = WebToCaseAction.get_CaseOwner();
					tb.scrollElementIntoView("caseOwnerIcon_XPATH");
					if(caseOwner.endsWith("_Q")) {
						caseOwner = caseOwner.substring(0, caseOwner.length() - 2);
					}
					System.out.println("Case Owner: " + caseOwner);
					
					// resolve & close the case
					closeSuccess = ResolveAndCloseCase(caseNumber, resolveFlag);
					if (closeSuccess) {
						runStatus = "PASS";
					}

				}

				Thread.sleep(1000);
				tb.takeScreenshot();

				LoginAsUser.logout(); // logout user
				tb.wait.until(ExpectedConditions.titleContains("Login | Salesforce"));

			} //runFlag = Y

		} catch (Exception e) {
			System.out.println("CaseMgmtEndToEnd Catch block");
			e.printStackTrace();

			LoginAsUser.logout(); // logout user
			tb.wait.until(ExpectedConditions.titleContains("Login | Salesforce"));

			tb.test.log(LogStatus.FAIL, "Exception error: " + e.getMessage());
			softAssert.assertTrue(false, e.getMessage());
			
		} finally {
			System.out.println("CaseMgmtEndToEnd Finally block");

			if (runFlag.equals("Y")) {			
//				Excel_DP.excel.setCellData(dataSheetName, "CaseOwner", caseE2ECount, caseOwner);
//				Excel_DP.excel.setCellData(dataSheetName, "CaseNumber", caseE2ECount, caseNumber);
//				Excel_DP.excel.setCellData(dataSheetName, "Report", caseE2ECount, reportFolder);

				tb.test.log(LogStatus.valueOf(runStatus), "Case Assigned to: " + caseOwner);

			} else {
				System.out.println("Skipped test case: " + testCaseNo);

				runStatus = "SKIP";
				tb.test.log(LogStatus.SKIP, "Testcase not run");
			}

//			Excel_DP.excel.setCellData(dataSheetName, "Status", caseE2ECount, runStatus);
			
			String [] reportData =  {testCaseNo, contact, LoB, typeOfCustomerRequest, type, highlevelTC, transactionType, transactionSubType,  transactionReason, caseOrigin, caseOwner, caseNumber, runStatus, reportFolder}; 
			tb.writeToCSV(reportData, "CaseEndToEnd.csv" );
			

		} // finally block

		softAssert.assertAll();

	} // CaseMgmtEndToEnd end

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void RBAWhatYouSee(String objType, String input, String output, String runflag) throws Throwable {
		// try issue from ankita

		String dataSheetName = "RBAWhatYouSee";
		autoAssignCount++;

		try {
			if (runflag.equals("Y")) {

				if (firstLogin) {

					tb.navigateURL(tb.config.getProperty("testsiteurlUAT"));
					//					LoginTest.logintest("leonyl.benito@capgemini.com.r2newsit", "Capgemini321");
					Thread.sleep(3000);

					firstLogin = false;

					// login user
					tb.navigateURL(
							"https://pldtoneenterprise--r2newsit.lightning.force.com/lightning/setup/ManageUsers/page?address=%2F0051y000001JFBtAAO%3Fnoredirect%3D1%26isUserEntityOverride%3D1%26retURL%3D%252Fsetup%252Fhome");
					Thread.sleep(5000);

					//				tb.wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//iframe[starts-with(@name,'vfFrameId')]")));
					tb.driver.switchTo().frame(0);
					Thread.sleep(3000);
					tb.jsClick("loginUser_XPATH");
					//				Thread.sleep(5000);

				}

				// ==== Extract field names ====
				System.out.println(tb.config.getProperty(objType));
				tb.wait.until(ExpectedConditions.titleIs("Home | Salesforce"));
				tb.navigateURL(tb.config.getProperty(objType));
				Thread.sleep(3000);
				tb.refreshPage();
				Thread.sleep(5000);

				try {
					tb.driver.findElement(By.xpath("//a[text()='Details']")).click();
				} catch (NoSuchElementException ne) {
					tb.driver.findElement(By.xpath("//span[text()='Details']")).click();
				}

				Thread.sleep(3000);

				List<WebElement> fields = tb.driver.findElements(
						By.xpath("//div[@class='record-layout-container']//span[@class='test-id__field-label']"));

				if (fields.size() == 0) {
					fields = tb.driver.findElements(By.xpath("//span[@class='test-id__field-label']"));
				}

				String[] all_elements_text = new String[fields.size()];

				FileWriter wr = new FileWriter(System.getProperty("user.dir")
						+ "\\src\\test\\resources\\data\\extract\\" + objType + "_EXTRACT.txt", true);
				BufferedWriter bW = new BufferedWriter(wr);

				System.out.println(objType + " Total Number of fields: " + fields.size());
				noOfFields = fields.size();

				for (int i = 0; i < noOfFields; i++) {

					all_elements_text[i] = fields.get(i).getText();

					bW.write(fields.get(i).getText());
					bW.newLine();

					System.out.println(fields.get(i).getText());
				}

				bW.close();

				String result = "_PASSED_";
				String sCurrentLine;

				BufferedReader br = new BufferedReader(new FileReader(
						System.getProperty("user.dir") + "\\src\\test\\resources\\data\\input\\" + objType + ".txt"));
				FileWriter writer = new FileWriter(System.getProperty("user.dir")
						+ "\\src\\test\\resources\\data\\output\\" + objType + "Results.txt", true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				while ((sCurrentLine = br.readLine()) != null) {
					System.out.println(sCurrentLine);
					if (ArrayUtils.contains(all_elements_text, sCurrentLine)) {
						System.out.println(sCurrentLine + "|FOUND");
						bufferedWriter.write(sCurrentLine + "|FOUND");
					} else {
						System.out.println(sCurrentLine + "|NOT_FOUND");
						bufferedWriter.write(sCurrentLine + "|NOT_FOUND");
						result = "_FAILED_";
					}

					bufferedWriter.newLine();
				}

				System.out.println("End of Fields for object :" + objType);
				bufferedWriter.close();

				File oldfile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\data\\output\\"
						+ objType + "Results.txt");
				File newfile = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\data\\output\\"
						+ result + objType + "Results.txt");
				oldfile.renameTo(newfile);

				// return to home
				tb.navigateURL("https://pldtoneenterprise--r2newsit.lightning.force.com/lightning/page/home");
				Thread.sleep(5000);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Excel_DP.excel.setCellData(dataSheetName, "Assigned", autoAssignCount, String.valueOf(noOfFields));
			noOfFields = 0;
		}
	}

	@Test(dataProviderClass = Excel_DP.class, dataProvider = "testdata", enabled = false)
	public void Test(String testCaseNo) throws Throwable {

		tb.navigateURL(tb.config.getProperty("testsiteurlUAT"));
		//		LoginTest.logintest("leonyl.benito@capgemini.com.r2newsit", "Capgemini321");
		Thread.sleep(3000);

		//		tb.navigateURL("https://pldtoneenterprise--ctr1.lightning.force.com/one/one.app#eyJjb21wb25lbnREZWYiOiJvbmU6YWxvaGFQYWdlIiwiYXR0cmlidXRlcyI6eyJhZGRyZXNzIjoiaHR0cHM6Ly9wbGR0b25lZW50ZXJwcmlzZS0tY3RyMS5saWdodG5pbmcuZm9yY2UuY29tL2FwZXgvdmxvY2l0eV9jbXRfX0h5YnJpZENQUT9pZD0wMDYwcDAwMDAwOEZHQ2EifSwic3RhdGUiOnt9fQ%3D%3D");
		tb.navigateURL(
				"https://pldtoneenterprise--r2newsit.lightning.force.com/one/one.app#eyJjb21wb25lbnREZWYiOiJvbmU6YWxvaGFQYWdlIiwiYXR0cmlidXRlcyI6eyJhZGRyZXNzIjoiaHR0cHM6Ly9wbGR0b25lZW50ZXJwcmlzZS0tcjJuZXdzaXQubGlnaHRuaW5nLmZvcmNlLmNvbS9hcGV4L3Zsb2NpdHlfY210X19IeWJyaWRDUFE%2FaWQ9MDA2MGwwMDAwMERPaDVsIn0sInN0YXRlIjp7fX0%3D");
		Thread.sleep(10000);
		tb.driver.switchTo().frame(0);
		Thread.sleep(3000);
		tb.driver.findElement(By.xpath("//button[@title='Show Actions']")).click();
		Thread.sleep(3000);
		tb.driver.findElement(By.xpath("//li[@class='slds-dropdown__item cpq-item-actions-dropdown__item'][3]"))
		.click();
		Thread.sleep(3000);
		//		tb.driver.findElement(By.xpath("//select[@name='productconfig_field_0_0']")).click();
		//		tb.driver.findElement(By.xpath("//input[@name='productconfig_field_0_1']")).sendKeys(testCaseNo);
		tb.driver.findElement(By.xpath("//label[text()='Quantity']/following-sibling::div/input")).sendKeys("100");
		//		tb.driver.findElement(By.xpath("//select[@name='productconfig_field_2_1']")).click();
	}

	//------- reusable methods
	@SuppressWarnings("static-access")
	public void CaseCreation(String subject, String LoB, String customerRequest, String type, String highlevelTC,
			String transactionType, String transactionSubType, String transactionReason, String amountlimit,
			String caseOrigin, String assignedTo, String dataSheetName) {
		try {
			errorFlag = false;
			if (caseOrigin.contentEquals("Hotline") || caseOrigin.contentEquals("Chat")) {
				SmartCasesAction.searchContact();
			}
			Thread.sleep(2000);
			SmartCasesAction.enter_Subject(subject.trim());
			JavascriptExecutor js = (JavascriptExecutor) tb.driver;
			js.executeScript("arguments[0].scrollIntoView();", tb.element("caseInfo_XPATH"));
			Thread.sleep(1000);
			SmartCasesAction.selectLoB(LoB.trim());
			SmartCasesAction.select_type(type.trim());
			SmartCasesAction.selectHighLevelTransaction(highlevelTC.trim());
			Thread.sleep(1000);
			SmartCasesAction.transactionType(transactionType.trim());
			SmartCasesAction.transactionSubType(transactionSubType.trim());

			SmartCasesAction.transactionReason(transactionReason.trim());
			SmartCasesAction.amountlimit(amountlimit);
			Thread.sleep(1000);
			SmartCasesAction.caseOrigin(caseOrigin.trim());
			SmartCasesAction.clickOnSave();
			Thread.sleep(2000);

			try {
				if (tb.element("commonError_XPATH").isDisplayed()) {
					Thread.sleep(2000);
					tb.takeScreenshot();
					TestBase.test.log(LogStatus.FAIL, tb.element("caseError_XPATH").getText());
					SmartCasesAction.clickOnCancel();
					rowNum = rowNum + 1;
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				// e1.printStackTrace();

				js.executeScript("arguments[0].scrollIntoView();", tb.element("caseInfo_XPATH"));
				Thread.sleep(1000);
				// ChangeOwner(assignedTo);

				if (errorFlag == false) {

					Thread.sleep(1000);
					tb.takeScreenshot();

					String assigned1 = null;
					String discription = null;
					boolean assignedFlag = true;
					rowNum = rowNum + 1;

					try {
						assigned1 = tb.element("caseOwner_XPATH").getText();
						try {
							discription = tb.element("Descrition_XPATH").getText();
						} catch (Exception e) {
							discription = tb.element("Description2_XPATH").getText();
						}

					} catch (Exception e) {
						// e.printStackTrace();
						System.out.println("Inside Catch of assigned1");
						Excel_DP.excel.setCellData(dataSheetName, "Assigned", rowNum, "Null");
						TestBase.test.log(LogStatus.INFO, "unknown");
						Excel_DP.excel.setCellData(dataSheetName, "Description", rowNum, discription);
						Excel_DP.excel.setCellData(dataSheetName, "Status", rowNum, "Fail");

						assignedFlag = false;
					}

					if (assigned1 != null && assignedFlag == true) {
						Excel_DP.excel.setCellData(dataSheetName, "Assigned", rowNum, assigned1);
						Excel_DP.excel.setCellData(dataSheetName, "Description", rowNum, discription);
						Excel_DP.excel.setCellData(dataSheetName, "Status", rowNum, "Pass");

						TestBase.test.log(LogStatus.PASS, "assigned : " + assigned1);
					}
					System.out.println("assigned1: " + assigned1);
					System.out.println("discription :" + discription);
				}

				/*
				 * else { Excel_DP.excel.setCellData(dataSheetName, "Assigned", rowNum, "Null");
				 * TestBase.test.log(LogStatus.FAIL, "unknown");
				 * Excel_DP.excel.setCellData(dataSheetName, "Status", rowNum, "Fail"); }
				 */

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rowNum = rowNum + 1;
		}

		try {
			hpt.homepage_test();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void ChangeOwner(String EnterAssignee) {

		try {
			errorFlag = false;
			Thread.sleep(2000);
			SmartCasesAction.clickOnChangeownerIcon();
			Thread.sleep(1000);
			SmartCasesAction.clickOndropdownIcon();
			Thread.sleep(1000);

			SmartCasesAction.clickonQueue();
			Thread.sleep(1000);
			SmartCasesAction.EnterAssignee(EnterAssignee);
			Thread.sleep(2000);
			SmartCasesAction.clickOnAssignee(EnterAssignee);
			Thread.sleep(1000);

			SmartCasesAction.clickOncheckbox();
			Thread.sleep(1000);
			SmartCasesAction.clickOnChangeownerBTN();

			if (tb.element("changeOwnerError_XPATH").isDisplayed() || tb.element("InvalidOption_XPATH").isDisplayed()) {
				SmartCasesAction.clickOnCancelBTN_ChangeOwner();
				errorFlag = true;
				Thread.sleep(2000);
				tb.takeScreenshot();
				TestBase.test.log(LogStatus.FAIL, tb.element("changeOwnerError_XPATH").getText());
				rowNum = rowNum + 1;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void ChangeOwner(String assignee, String PorQ) {

		System.out.println("Change Case owner: " + PorQ + " | " + assignee);

		try {
			errorFlag = false;
			Thread.sleep(2000);

			tb.scrollElementIntoView("caseOwnerIcon_XPATH");
			SmartCasesAction.clickOnChangeownerIcon();
			Thread.sleep(1000);

			if (PorQ.equals("Queue")) {
				System.out.println("Change search to Queues...");
				SmartCasesAction.clickOndropdownIcon();
				Thread.sleep(1000);
				SmartCasesAction.clickonQueue();
			}

			Thread.sleep(1000);
			SmartCasesAction.EnterAssignee(assignee, PorQ);
			Thread.sleep(2000);
			SmartCasesAction.clickAssignee(assignee, PorQ);
			Thread.sleep(1000);
			SmartCasesAction.clickOncheckbox();
			Thread.sleep(1000);

			tb.takeScreenshot();
			Thread.sleep(1000);

			SmartCasesAction.clickOnChangeownerBTN();
			Thread.sleep(2000);

			tb.waitElementtoBecomeInvisble("changeOwnerBTN_XPATH");
			tb.refreshPage();

			Assert.assertTrue(SmartCasesAction.verifyOwnerChange(assignee));
			Thread.sleep(1000);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void SearchAndAcceptCase(String searchText, String queue) {

		System.out.println("Search and Accept case method...");

		try {

			hpt.featureURL("Case");

			// search and accept the case
			// tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("caseListDropdown_XPATH"))));
			SearchCaseAction.searchCaseQueue(queue);
			Thread.sleep(2000);

			tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("caseCheckbox_XPATH"))));
			tb.takeScreenshot();

			SearchCaseAction.searchCaseFromList(searchText);

			tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("caseCheckbox_XPATH"))));
			tb.takeScreenshot();

			SearchCaseAction.acceptCase();

			tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("acceptMessage_XPATH"))));
			tb.takeScreenshot();
			
			Thread.sleep(2000);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void EditCase(String type, String highlevelTC, String transactionType, String transactionSubType,
			String transactionReason, String amountlimit, String caseOrigin) throws InterruptedException {

		System.out.println("Edit case method...");

		tb.driver.navigate().refresh();
		Thread.sleep(2000);

		tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("editButton_XPATH"))));
		tb.takeScreenshot();

		EditCaseAction.click_EditButton();

		// edit case details
		Thread.sleep(1000);
		JavascriptExecutor js = (JavascriptExecutor) tb.driver;
		js.executeScript("arguments[0].scrollIntoView();", tb.element("editType_XPATH"));

		Thread.sleep(1000);
		EditCaseAction.select_type(type.trim());

		if (tb.compareText(highlevelTC, tb.getText("editHighLevelTC_XPATH")) == false) {
			EditCaseAction.selectHighLevelTransaction(highlevelTC.trim());
		}

		if (tb.compareText(transactionType, tb.getText("editTransactionType_XPATH")) == false) {
			EditCaseAction.transactionType(transactionType.trim());
		}

		tb.takeScreenshot();

		if (tb.compareText(caseOrigin, tb.getText("editCaseOrigin_XPATH")) == false) {
			EditCaseAction.caseOrigin(caseOrigin.trim());
		}

		if (tb.compareText(transactionSubType, tb.getText("editTrsactionSubType_XPATH")) == false) {
			EditCaseAction.transactionSubType(transactionSubType.trim());
		}

		if (tb.compareText(transactionReason, tb.getText("editTransactionReason_XPATH")) == false) {
			EditCaseAction.transactionReason(transactionReason.trim());
		}

		SmartCasesAction.amountlimit(amountlimit);

		Thread.sleep(1000);
		tb.takeScreenshot();

		EditCaseAction.click_SaveButton();
		EditCaseAction.verify_EditSuccessful(caseNumber);

	}

	public boolean CustomerPortalLoginAndSubmitRequest(String username, String password, String subject,
			String requestType, String LOB) {

		boolean submitSuccess = false;
		boolean loginSuccess = false;

		System.out.println("Login to Customer Portal");

		try {

			// login
			CustomerPortalAction.enter_Username(username);
			CustomerPortalAction.enter_Password(password);

			Thread.sleep(1000);
			tb.takeScreenshot();

			CustomerPortalAction.click_LoginButton();
			Thread.sleep(15000);
			loginSuccess = CustomerPortalAction.verify_Login();

			Thread.sleep(1000);
			tb.takeScreenshot();

			if (loginSuccess) {

				// submit request
				CustomerPortalAction.click_ContactSupport();
				Thread.sleep(3000);

				tb.wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("custPortalLOB_XPATH"))));

				CustomerPortalAction.select_LineOfBusiness(LOB);
				CustomerPortalAction.select_TypeOfCustomerRequest(requestType);
				CustomerPortalAction.enter_Subject(subject);

				Thread.sleep(1000);
				tb.takeScreenshot();

				CustomerPortalAction.click_SubmitButton();

				submitSuccess = CustomerPortalAction.verify_Submit();
				caseNumber = CustomerPortalAction.getCaseNumber();

				Thread.sleep(1000);
				tb.takeScreenshot();

				CustomerPortalAction.click_Logout();
			}

			if (caseNumber.equals("")) {
				submitSuccess = false;
			}

			return submitSuccess;

		} catch (Exception e) {

			e.printStackTrace();

			return submitSuccess;

		}

	}

	public boolean CustomerPortalLoginAndSubmitRequestChat(String username, String password, String subject,
			String requestType, String LOB) throws InterruptedException {

		boolean submitSuccess = false;
		boolean loginSuccess = false;

		System.out.println("Login to Customer Portal");

		//		try {	

		// login
		CustomerPortalAction.enter_Username(username);
		CustomerPortalAction.enter_Password(password);

		Thread.sleep(1000);
		tb.takeScreenshot();

		CustomerPortalAction.click_LoginButton();
		Thread.sleep(15000);
		loginSuccess = CustomerPortalAction.verify_Login();

		Thread.sleep(1000);
		tb.takeScreenshot();

		if (loginSuccess) {

			// submit request
			tb.wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("custPortalChatContactUsButton_XPATH"))));
			CustomerPortalAction.click_ContactUsButton();

			tb.wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("custPortalChatSubmitButton_XPATH"))));
			CustomerPortalAction.enter_SubjectOnChatbox(subject);
			CustomerPortalAction.select_LOBOnChatbox(LOB);
			CustomerPortalAction.select_RequestTypeOnChatbox(requestType);

			Thread.sleep(1000);
			tb.takeScreenshot();

			CustomerPortalAction.click_SubmitOnChatbox();
			tb.wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("custPortalChatDoneButton_XPATH"))));

			Thread.sleep(1000);
			tb.takeScreenshot();

			submitSuccess = CustomerPortalAction.verify_SubmitForChat();
			CustomerPortalAction.click_DoneButtonOnChatbox();

			Thread.sleep(1000);
			tb.takeScreenshot();

			tb.driver.navigate().refresh();

			// search for case 3 times - to give time until created
			for (int i = 0; i < 3; i++) {
				int searchResult = 0;

				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath(tb.OR.getProperty("custPortalChatContactUsButton_XPATH"))));
				CustomerPortalAction.click_HelpAndSupportLink();

				tb.wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("custPortalCaseList_XPATH"))));
				CustomerPortalAction.search_CaseSubject(subject);

				System.out.println("Search results found: " + searchResult);
				Thread.sleep(3000);
				searchResult = tb.driver
						.findElements(By.xpath(tb.OR.getProperty("custPortalCaseListResult_XPATH"))).size();

				if (searchResult == 1) {
					break;
				}

			}

			Thread.sleep(1000);
			tb.takeScreenshot();

			tb.wait.until(ExpectedConditions.elementToBeClickable(By.linkText(subject)));
			tb.click(subject);
			caseNumber = CustomerPortalAction.getCaseNumberForChat();
			System.out.println(caseNumber);

			Thread.sleep(1000);
			tb.takeScreenshot();

			CustomerPortalAction.click_Logout();

		}

		if (caseNumber.equals("")) {
			submitSuccess = false;
		}

		return submitSuccess;

		//		} catch (Exception e) {
		//
		//			e.printStackTrace();
		//			
		//			return submitSuccess;
		//			
		//		}

	}

	public boolean ResolveAndCloseCase(String caseNumber, String resolveFlag) {
		boolean successFlag = false;

		try {
			if (resolveFlag.equals("Y")) {
				FulfillmentAndClosureAction.resolveCase();
				tb.takeScreenshot();
				Thread.sleep(2000);
			}

			FulfillmentAndClosureAction.closeCase();
			Thread.sleep(2000);

			// check for errors
			if (tb.driver.findElements(By.xpath(tb.OR.getProperty("caseStatusChangeFailureMessage_XPATH"))).size() > 0) {
				successFlag = false;
			} else
				successFlag = true;

			Thread.sleep(2000);
			tb.takeScreenshot();

			return successFlag;
		} catch (Exception e) {
			e.printStackTrace();

			return successFlag;
		}

	}

	public void CaseCreation(String contact, String subject, String LoB, String typeOfCustomerRequest, String type,
			String highlevelTC, String transactionType, String transactionSubType, String transactionReason,
			String amountlimit, String caseOrigin, String product, String otherOneTimeFee, String waiverOfMoveFee,
			String transactionEntry, String noOfLines) {

		try {

			SmartCasesAction.clickOnNewBtn();

			System.out.println("Title: " + tb.driver.getTitle());

			tb.wait.until(ExpectedConditions.titleContains("New Case | Salesforce"));
			if (LoB.equals("PLDT"))	SmartCasesAction.select_TypeOfRequest(typeOfCustomerRequest, LoB);
			else if (LoB.equals("SMART")) SmartCasesAction.select_TypeOfRequest(typeOfCustomerRequest, "Smart");
			else SmartCasesAction.select_TypeOfRequest(typeOfCustomerRequest, "ICT");

			Thread.sleep(1000);
			tb.takeScreenshot();

			SmartCasesAction.clickOnNext();
			Thread.sleep(3000);

			tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("newCaseAccountName_XPATH"))));
			SmartCasesAction.searchAccount(contact);
			Thread.sleep(2000);

			tb.scrollElementIntoView("newCaseLineOfBusiness_XPATH");
			Thread.sleep(1000);

			if (tb.compareText(LoB, tb.getText("newCaseLineOfBusiness_XPATH")) == false) {
				SmartCasesAction.selectLoB(LoB.trim());
			}

			if (tb.compareText(type, tb.getText("newCaseType_XPATH")) == false) {
				SmartCasesAction.select_type(type.trim());
			}

			if (tb.compareText(highlevelTC, tb.getText("newCaseHighLevelTxnClassification_XPATH")) == false) {
				SmartCasesAction.selectHighLevelTransaction(highlevelTC.trim());
			}

			Thread.sleep(1000);

			if (tb.compareText(transactionType, tb.getText("newCaseTxnType_XPATH")) == false) {
				SmartCasesAction.transactionType(transactionType.trim());
			}

			if (tb.compareText(caseOrigin, tb.getText("newCaseOrigin_XPATH")) == false) {
				SmartCasesAction.caseOrigin(caseOrigin.trim());
			}

			Thread.sleep(1000);
			tb.takeScreenshot();

			if (!transactionSubType.isEmpty()) {
				if (tb.compareText(transactionSubType, tb.getText("newCaseTxnSubType_XPATH")) == false) {
					SmartCasesAction.transactionSubType(transactionSubType.trim());
				}
			}

			if (!transactionReason.isEmpty()) {
				if (tb.compareText(transactionReason, tb.getText("newCaseTxnReason_XPATH")) == false) {
					SmartCasesAction.transactionReason(transactionReason.trim());
				}
			}

			SmartCasesAction.enter_Subject(subject.trim());

			if (!amountlimit.isEmpty()) {
				SmartCasesAction.amountlimit(amountlimit);
			}

			Thread.sleep(1000);

			// additional fields for non-technical
			// product, otherOneTimeFee, waiverOfMoveFee, noOfLines
			if (!product.isEmpty()) {
				if (tb.compareText(product, tb.getText("")) == false) {
					SmartCasesAction.select_Product(product);
				}
			}

			if (!otherOneTimeFee.isEmpty()) {
				SmartCasesAction.enter_OtherOneTimeFee(otherOneTimeFee);
			}

			if (!waiverOfMoveFee.isEmpty()) {
				SmartCasesAction.enter_WaiverOfMoveFee(waiverOfMoveFee);
			}

			if (!noOfLines.isEmpty()) {
				SmartCasesAction.enter_NumberOfLines(noOfLines);
			}

			// new field 09242020
			if (!amountlimit.isEmpty()) {
				if (tb.compareText(transactionEntry, tb.getText("newCaseTransactionEntry_XPATH")) == false) {
					SmartCasesAction.transactionEntry(transactionEntry.trim());
				}
			}

			// save the case
			SmartCasesAction.clickOnSave();
			Thread.sleep(2000);

			Assert.assertEquals(true, SmartCasesAction.verify_SaveNewCase());

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void SearchAndViewCase(String queue, String searchText) {
		System.out.println("Search and View Case... " + searchText);
		try {

			hpt.featureURL("Case");

			SearchCaseAction.searchCaseQueue(queue);
			Thread.sleep(2000);

			SearchCaseAction.searchCaseFromList(searchText);
			tb.takeScreenshot();

			tb.retryClick(searchText);
			Thread.sleep(2000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
