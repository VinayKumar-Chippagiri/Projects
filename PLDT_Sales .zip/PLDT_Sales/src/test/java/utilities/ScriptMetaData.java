package utilities;


	

	import java.lang.annotation.Retention;
	import java.lang.annotation.RetentionPolicy;



	@Retention(RetentionPolicy.RUNTIME)
	public @interface ScriptMetaData {

	     boolean productionReady();
	    
	/*
	 * // first letst get the annotation value from the filed test case.
	 * ScriptMetaData meta =
	 * arg0.getMethod().getConstructorOrMethod().getMethod().getAnnotation(
	 * ScriptMetaData.class); // get the annotation parameter value as a boolean
	 * boolean isProductionReady = meta.productionReady(); // Check if the
	 * annotation attribute value is productionReady=true if (isProductionReady) {
	 * System.out.println("IS PRODUCTION READY : "+isProductionReady);
	 * JiraServiceProvider jiraSP = new
	 * JiraServiceProvider("https://e-3d-jira2.capgemini.com/jira2/login.jsp",
	 * "arathore", "C@pg3m1ni02", "P001653");
	 * 
	 * // Add the failed method name as the issue summary String issueSummary =
	 * arg0.getMethod().getConstructorOrMethod().getMethod().getName() +
	 * " was failed due to an exception";
	 * 
	 * // get the error message from the exception to description String
	 * issueDescription = "Exception details : "+ arg0.getThrowable().getMessage() +
	 * "\n"; // Append the full stack trace to the description.
	 * issueDescription.concat(ExceptionUtils.getFullStackTrace(arg0.getThrowable())
	 * );
	 * 
	 * jiraSP.createJiraIssue("BUG", issueSummary, issueDescription,
	 * "Rathore Ankita");
	 * 
	 * 
	 * }
	 * 
	 */
	}

