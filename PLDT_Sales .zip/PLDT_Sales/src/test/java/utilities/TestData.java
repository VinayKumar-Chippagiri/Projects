package utilities;

public class TestData {
	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getLob() {
		return lob;
	}


	public void setLob(String lob) {
		this.lob = lob;
	}

	public static String username = null;
	public static String password = null;
	public static String lob = null;
	public static String runMode = null;
	public static String getRunMode() {
		return runMode;
	}


	public static void setRunMode(String runMode) {
		TestData.runMode = runMode;
	}
}
