package utilities;

public class RunMode {
	 public static ExcelReader excel=new ExcelReader(System.getProperty("user.dir") + "\\src\\test\\resources\\excelFiles\\logintest.xlsx");
	public static boolean isTestRunnable(String testName){
		
			String sheetName="test_suite";
			boolean flag =false;
			int rows = excel.getRowCount(sheetName);
			
			
			for(int rNum=2; rNum<=rows; rNum++){
				
				String testCase = excel.getCellData(sheetName, "TCID", rNum);
				
				if(testCase.equalsIgnoreCase(testName)){
					
					String runmode = excel.getCellData(sheetName, "Runmode", rNum);
					
					if(runmode.equalsIgnoreCase("Y")) {
						flag=true;
					
				}}
				
				
			}
			return flag;
		}

}
