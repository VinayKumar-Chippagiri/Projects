package utilities;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.testng.annotations.Test;



public class TestList {
   static String recordes;
   static String Username;
   static String Password;

	@Test
	public static void log(){
		 for (Row row : RunMode.excel.sheet) {
		        for (Cell cell : row) {
		        	recordes=cell.getRichStringCellValue().getString().trim();
		             if (recordes.equals("SMART")) {
		            	 Username=cell.getRow().getCell(0).getStringCellValue();
		            	 Password=cell.getRow().getCell(1).getStringCellValue();
		                    System.out.println(Username);
		                    System.out.println(Password);
		                    
		                }
		            }
		        }

		/*int rows =excel.getRowCount("LoginTest");
			int cols = excel.getColumnCount("LoginTest");

			for (int rowNum = 2; rowNum <=rows; rowNum++) {

				String username= excel.getCellData("LoginTest", 0, rowNum);
				String password= excel.getCellData("LoginTest", 1, rowNum);
				String runmode1=excel.getCellData("LoginTest", 2, rowNum);
				String lob=excel.getCellData("LoginTest", 3, rowNum);
				runmode1 = runmode1.trim();

				if(lobApp.equalsIgnoreCase(lob)) {
					String newUserName =username;
					String newPassword =password;
					System.out.println("LOB Changes From:"+lobApp+" to "+lob);
					System.out.println("New User Name :"+newUserName);
					System.out.println("New Password :"+newPassword);
					loginChange = true;
				}
				if(loginChange) {
				   break;
				}
			}}
				catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		 */
	}
}


