package utilities;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.math3.ode.sampling.AbstractFieldStepInterpolator;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;

public class ExcelManager {
	/*
	 * static Fillo fillo=new Fillo(); static Connection connection; final String
	 * excelFilePath = ".\\src\\test\\resources\\excelFiles\\CaseCreation.xlsx"; //
	 * excel file name String excelWorksheetName = null;
	 */ private String connectionString;
	private String testDataStartRow = "1";
	String excelWorksheetName = null;

	public ExcelManager() {
	}

	public ExcelManager(String excelWorksheetName) {
		this.excelWorksheetName = excelWorksheetName;
	}

	public Object[][] getExcelData() throws FilloException {
		this.connectionString = "select * from " + excelWorksheetName;
		Fillo fillo = new Fillo();
		Connection connection = null;
		String excelFilePath = ".\\src\\test\\resources\\excelFiles\\RegressionSuite.xlsx"; // excel file name
		// String excelWorksheetName = null;
		System.setProperty("ROW", testDataStartRow);// Table start row
		System.setProperty("COLUMN", "1");// Table start column
		fillo = new Fillo();
		if (connection == null) {
			connection = fillo.getConnection(excelFilePath);
		}
		Recordset recordset = connection.executeQuery(connectionString);
		Hashtable<String, String> table;
		Object[][] data = new Object[recordset.getCount()][1];
		int rowIndex = 0;
		while (recordset.next()) {
			table = new Hashtable<>(); // creating a hashtable
			for (String strColumn : recordset.getFieldNames()) {
				table.put(strColumn, recordset.getField(strColumn.toString()));
				// putting table header (column name) and corresponding data in hash table as
				// key value pair
			}
			data[rowIndex][0] = table; // putting hash table into Object array
			rowIndex++;
		}
		recordset.close();
		connection.close();
		return data;
	}

	@DataProvider(name = "testdata")
	public Object[][] dp(Method m) throws FilloException {
		System.out.println("test: " + m.getName());
		ExcelManager reader = new ExcelManager(m.getName());
		return reader.getExcelData();
	}

	public static void setCaseIdInCSVFile(String column, String value)
			throws Exception {
		FileInputStream fs = null;
		XSSFWorkbook wb = null;
		try {
			fs = new FileInputStream(".\\src\\test\\resources\\excelFiles\\" + "BulkFile.xlsx");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			wb = new XSSFWorkbook(fs);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DataFormatter formatter = new DataFormatter();
		XSSFSheet sh = wb.getSheetAt(0);
		int rowcount = sh.getPhysicalNumberOfRows();
		int colcount = sh.getRow(0).getPhysicalNumberOfCells();
		for (int i = 0; i < rowcount; i++) {
			for (int j = 0; j < colcount; j++) {
				String val = formatter.formatCellValue(sh.getRow(i).getCell(j));
				if (val.equals("CaseID")) {
					sh.getRow(i).getCell(j).setCellValue(value);
				}
			}
		}



		File fo = new File(".\\src\\test\\resources\\excelFiles\\bulk.xlsx");
		FileOutputStream fos = new FileOutputStream(fo);
		wb.write(fos);
		fos.close();
		wb.close();

		xlsx(new File(".\\src\\test\\resources\\excelFiles\\bulk.xlsx"),new File(".\\src\\test\\resources\\excelFiles\\uploadBulk.csv"));

	}


	
	
	public static void updateCSV(String caseID) throws IOException {
        File inputFile = new File(".\\src\\test\\resources\\excelFiles\\BulkFile.csv");

        // Read existing file
        CSVReader reader = new CSVReader(new FileReader(inputFile));
        List<String[]> csvBody = null;
		try {
			csvBody = reader.readAll();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CsvException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // get CSV row column and replace with by using row and column
        for(int i=1; i<csvBody.size(); i++){
            String[] strArray = csvBody.get(i);
            strArray[0]=caseID;
//            for(int j=0; j<strArray.length; j++){
//                if(strArray[j].equalsIgnoreCase("CaseID")){ //String to be replaced
//                    csvBody.get(i)[j] = caseID; //Target replacement
//                }
//            }
        }
        reader.close();

        // Write to CSV file which is open
        CSVWriter writer = new CSVWriter(new FileWriter(inputFile));
        writer.writeAll(csvBody);
        writer.flush();
        writer.close();
    }
	
	
	

	public static void UpdateCaseIDInCSVFile(String file,String value)
	{

	try {

	FileReader filereader = new FileReader(file);

	// create csvReader object passing
	// file reader as a parameter
	CSVReader csvReader = new CSVReader(filereader);
	List<String[]> csvBody = csvReader.readAll();
	Iterator<String[]> iterator = csvBody.iterator();
	iterator.next();
	int rowno=1;
	while (iterator.hasNext()) {
	String[] row = iterator.next();
	for(int i=1;i<row.length;i++)
	{
	csvBody.get(rowno)[0] =value;
	System.out.println(csvBody.get(rowno)[0] =value);
	}
	rowno=rowno+1;
	//Do stuff with row
	}

	csvReader.close();
	FileWriter outputfile = new FileWriter(file);
	CSVWriter writer = new CSVWriter(outputfile);
	writer.writeAll(csvBody);
	writer.flush();
	writer.close();
	}
	catch (Exception e) {
	e.printStackTrace();
	}
	}









	static void xlsx(File inputFile, File outputFile) {
        // For storing data into CSV files
        StringBuffer data = new StringBuffer();

        try {
            FileOutputStream fos = new FileOutputStream(outputFile);
            // Get the workbook object for XLSX file
            FileInputStream fis = new FileInputStream(inputFile);
            Workbook workbook = null;

            String ext = FilenameUtils.getExtension(inputFile.toString());

            if (ext.equalsIgnoreCase("xlsx")) {
                workbook = new XSSFWorkbook(fis);
            } else if (ext.equalsIgnoreCase("xls")) {
                workbook = new HSSFWorkbook(fis);
            }

            // Get first sheet from the workbook

            int numberOfSheets = workbook.getNumberOfSheets();
            Row row;
            Cell cell;
            // Iterate through each rows from first sheet

            for (int i = 0; i < numberOfSheets; i++) {
                org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheetAt(0);
                Iterator<Row> rowIterator = sheet.iterator();

                while (rowIterator.hasNext()) {
                    row = rowIterator.next();
                    // For each row, iterate through each columns
                    Iterator<Cell> cellIterator = row.cellIterator();
                    while (cellIterator.hasNext()) {

                        cell = cellIterator.next();

                        switch (cell.getCellType()) {
                        case BOOLEAN:
                            data.append(cell.getBooleanCellValue() + ",");

                            break;
                        case NUMERIC:
                            data.append(cell.getNumericCellValue() + ",");

                            break;
                        case STRING:
                            data.append(cell.getStringCellValue() + ",");
                            break;

                        case BLANK:
                            data.append("" + ",");
                            break;
                        default:
                            data.append(cell + ",");

                        }
                    }
                    data.append('\n'); // appending new line after each row
                }

            }
            fos.write(data.toString().getBytes());
            fos.close();

        } catch (Exception ioe) {
            ioe.printStackTrace();
        }
    }


	public static void setData(String column, String value) throws FilloException {
		System.setProperty("ROW", "1");// Table start row
		System.setProperty("COLUMN", "1");
		Fillo fillo = new Fillo();
		Connection connection = fillo.getConnection(".\\src\\test\\resources\\excelFiles\\" + "storedata.xlsx");
		String query = "UPDATE data SET " + column + "=" + "\'" + value + "\'" + " where ID=1";
		System.out.println(query);
		connection.executeUpdate(query);
		connection.close();
	}

	public static String getData(String sheetname, String columnname) throws FilloException {
		System.setProperty("ROW", "1");// Table start row
		System.setProperty("COLUMN", "1");
		Fillo fillo = new Fillo();
		Connection connection = fillo.getConnection(".\\src\\test\\resources\\excelFiles\\" + "storedata.xlsx");
		String query = "select " + columnname + " from " + sheetname + " where id=1";
		System.out.println(query);
		Recordset recordset = connection.executeQuery(query);
		if (recordset.next()) {
			return recordset.getField(columnname);
		}
		return " ";
	}
}
