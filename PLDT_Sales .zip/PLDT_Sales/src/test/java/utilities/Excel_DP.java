package utilities;

import java.lang.reflect.Method;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.testng.annotations.DataProvider;



public class Excel_DP {
	public static ExcelReader excel=new ExcelReader(System.getProperty("user.dir") + "\\src\\test\\resources\\excelFiles\\testdata.xlsx");
	DataFormatter dataFormatter=new DataFormatter();
	public static int rows;


	@DataProvider(name="testdata")
	public Object[][] getData(Method m) {

		Object[][] data=null;
		try {
			String sheetName = m.getName();
			int rows = excel.getRowCount(sheetName);
			int cols = excel.getColumnCount(sheetName);
			int rowNum = 0;
			System.out.println(rows);
			System.out.println(cols);
			System.out.println(sheetName);
			/*
			 * excel.addColumn(sheetName, "Recurring Charges"); excel.addColumn(sheetName,
			 * "Recurring Total");
			 */

			data = new Object[rows - 1][cols];


			for (rowNum = 2; rowNum <=rows; rowNum++) { // 2


				for (int colNum = 0; colNum < cols; colNum++) {

					// data[0][0]

					data[rowNum-2][colNum] = excel.getCellData(sheetName, colNum, rowNum);


				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return data;

	}

}
