package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import net.bytebuddy.agent.builder.AgentBuilder.DescriptionStrategy.SuperTypeLoading;
import pageAction.CommonSteps;

public class Retention extends TestBase {
	
	private String orderURL = null;
	
	// Asset
	private By homeSearch = By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate");
	private By assets = By.xpath("//ul/li//force-hoverable-link//slot//*[contains(text(),'Assets')]");
	private By newBtn = By.xpath("//div[text()='Change Owner']/ancestor::ul/li/a/div[text()='New']");
	//private By newBtn = By.xpath("(//div[text()='New'])[2]");
	private By casesBtn = By.xpath(
			"//a[@class='slds-card__header-link baseCard__header-title-container']//following::span[text()='Cases']");
	private By smartRadio = By.xpath("//*[text()='SMART Service Request']");
	private By nextBtn = By.xpath("//span[.='Next']");

	// Case Modification: By Vidya
	private By openCase = By.xpath("//a[@title='retension upgrade 19nov']");

	private By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	private By editButton = By.xpath("(//button[text()='Edit'])[2]");
	private By remarks = By.xpath("//label[text()='Remarks']/following::div/input[@name='Remarks__c']");
	private By offerMigrationType = By.xpath("//label[text()='Offer Migration Type']/following::div/div/input");
	private By saveRecord = By.xpath("//button[text()='Save Record']");
	private By cancel = By.xpath("//button[text()='Cancel']");
	private By nextArrow = By.xpath("//span[text()='Next']");
	public By resolutionInProgress = By.xpath("//span[text()='Resolution In Progress']");
	private By markStatusComplete = By.xpath("//span[text()='Mark as Current Status']/..");
	private By retension = By.xpath("(//span[text()='Retention'])[1]");
	private By planName = By.xpath("//span[contains(text(),'Plan Name')]/parent::label/parent::div/input");
	private By planName1 = By.xpath("//input[@type='text']");
	private By modificationNextButton = By.xpath("//p[text()='Next']");

	private By quickfilter = By.xpath("//button[@title='Show quick filters']");
	
	
	
	private By subjectInput = By.xpath("(//label[text()='Subject']/following::input)[1]");
	private By postcartItem = By.xpath("//div[@id='PostCartItems']/div/p[3]/button[2]");

	private By newcaseformheading = By.cssSelector(
			"h2.inlineTitle.slds-p-top--large.slds-p-horizontal--medium.slds-p-bottom--medium.slds-text-heading--medium");
	private By caseformclosebutton = By.cssSelector(
			"button.slds-button.slds-button_icon.slds-modal__close.closeIcon.slds-button_icon-bare.slds-button_icon-inverse");
	private By prod = By.cssSelector("button.slds-button.slds-button_neutral.slds-button_brand");

	private By deviceArrow = By.xpath("//span[text()='Devices']/parent::span/button");
	private By deviceArrow2 = By.xpath("(//span[text()='Devices']/parent::span/button)[2]");
	private By deviceSearch = By.xpath("(//input[@placeholder='Search'])[2]");
	private By deviceSearch2 = By.xpath("(//input[@placeholder='Search'])[5]");
	private By configArrow = By.xpath("(//button[@title='Show Actions'])[2]");
	private By configArrow2 = By.xpath("(//button[@title='Show Actions'])[3]");
	//private By configbutton = By.xpath("(//span[@class='slds-truncate cpq-action-item-label'])[10]");
	private By configbutton = By.xpath("(//button[@title='Show Actions'])[2]/following-sibling::div/ul/li[3]/a");
	
	private By configbutton2 = By.xpath("(//button[@title='Show Actions'])[4]/following-sibling::div/ul/li[3]/a");
	private By Color = By.xpath("//select[@name='productconfig_field_1_2']");
	private By Close = By.xpath("//button[@ng-click='importedScope.close()']");
	private By viewRecord = By.xpath("//button[@title='View Record']");
	private By ValidateCart = By.xpath("(//span[text()='Validate Cart'])[1]");
	private By GoToQuote = By.xpath("//div[@title='Go to Quote']");
	private By QuotePageheading = By.cssSelector("div.entityNameTitle.slds-line-height_reset");
	private By EditQuotationValidityPeriodButton = By.xpath("//button[@title='Edit Quotation Validity Period (Days)']");
	private By QuotationValidityPeriodBox = By
			.xpath("(//span[text()='Quotation Validity Period (Days)'])[2]/following::input");

	private By deliveryDate = By.xpath("//button[@title='Edit Delivery Date']");
	private By deliveryDateBox = By.xpath("//span[text()='Delivery Date']/parent::label/following-sibling::div/input");

	private By EditCreditApprovalStatusButton = By.xpath("//button[@title='Edit Credit Approval Status']");
	private By CreditApprovalStatusBox = By
			.xpath("//span[text()='Credit Approval Status']/parent::span/following-sibling::div//a");
	private By CreditApprovalConditionBox = By
			.xpath("//span[text()='Credit Approval Condition']/parent::span/following-sibling::div//a");
	private By CreditRemarksbox = By.xpath("//span[text()='Credit Remarks']/parent::label/following-sibling::textarea");

	private By threedot = By.xpath("//i[@class='icon icon-v-menu2'][@ng-click='toggleDropDown()']");
	private By deviceavanext = By.cssSelector(
			"button.nds-button.nds-button_brand.nds-p-around_xx-small.nds-size_1-of-1.nds-medium-size_3-of-12");

	private By DeviceReservationbtn = By.xpath("(//span[text()='Device Reservation'])[1]/parent::div");
	private By reservationNext = By.xpath("//div[@id=\"Step3_nextBtn\"]");
	private By DeliveryModeNext = By.xpath("//div[@id='Step6_nextBtn']");
	//private By DeviceAllocationStatus = By.xpath("//div[@id='DeviceAllocationStatus_nextBtn']");

	private By contractcreatebtn = By.xpath("(//span[text()='Create Contract'])[1]/parent::div");
	private By contractcreatenext = By.xpath("//div[@id='TypeofContract_nextBtn']");
	private By contractheading = By.xpath("//span[@title='Contract Line Items']");
	private By signedBtn = By.xpath("//a[@title='Signed']");
	private By markstatusascmplt = By.xpath("//span[text()='Mark Status as Complete']");
	private By contractDetails = By.xpath("(//a[@title='Details'])[2]");
	private By contractquotelink = By.xpath("//span[text()='Quote']/parent::div/following-sibling::div");
	private By related = By.xpath("(//a[@title='Related'])[1]");
	private By orderheading = By.xpath("//span[@title='Orders']");
	private By DeviceAllocationStatus = By.xpath("(//p[text()='Next'])[3]");
	
	private By firstOrderNum = By.xpath("//table[@class='slds-table forceRecordLayout slds-table--header-fixed slds-table--edit slds-table--bordered resizable-cols slds-table--resizable-cols uiVirtualDataTable']/tbody/tr/th//a");
	
	private By relaodQutotaionUpdate = By.xpath("//div[@class='reloadButton']/button/span");
	private By orderdetails= By.xpath("//a[@title='Details']/span[@class='title']");
	private By DeviceResvInfoHeading = By.xpath("//span[text()='Device Reservation Information']/parent::button");
	private By CreditInfoHeading = By.xpath("//span[text()='Credit Information']/parent::button");
	
	
	private By DeliveryModeHeading = By.xpath("(//h1[@class='slds-page-header__title vlc-slds-page-header__title slds-truncate ng-binding'])[2]");
	private By SIMAllocationStatusHeading = By.xpath("(//h1[@class='slds-page-header__title vlc-slds-page-header__title slds-truncate ng-binding'])[3]");
	
	private By SIMAllocationTestOne = By.xpath("(//p[@class='ng-binding']/p)[1]");
	private By SIMAllocationTestTwo = By.xpath("(//p[@class='ng-binding']/p)[2]");
	private By cartpageheading = By.cssSelector("div.slds-page-header.cpq-base-header-container");
	//public static By quickfilter = By.xpath("(//button[@title='Show quick filters'])");
	private By assetinput = By.xpath("(//label[text()='Asset Name']/following::input)[1]");
	private By mininput = By.xpath("(//label[text()='MIN']/following::input[@name='Asset-MIN__c'])");
	public  By showAll = By.xpath("//ul/following-sibling::div/a[contains(text(),'Show All')]");
	public  By asset = By.xpath("//ul/li//force-hoverable-link//slot//*[contains(text(),'Assets')]");

	
	

	/*
	 * login as RM (Ronna Bueno) and serach for min (639988410527) scroll to case
	 * section click on new button
	 * 
	 */

	public Retention() {
	}

	public void pathForCaseCreationRetention(String accountName, String MinNum, String assetID) {
		try {
			
//			super.clickUsingJs(assets);
//			
//			By assetIDXpath = By.xpath("//span[text()='" + MinNum
//					+ "']/parent::span/parent::td/preceding-sibling::td//span//span/following::th//span//a[text()='"
//					+ assetID + "']");
//			super.scrollIntoElement(assetIDXpath);
//			super.clickUsingJs(assetIDXpath);
			super.clickUsingJs(casesBtn);
			super.clickUsingJs(newBtn);
			super.clickUsingJs(smartRadio);
			super.clickUsingJs(nextBtn);
			/* super.clickOn(assetIDXpath); super.clickOn(casesBtn); super.clickOn(newBtn);
			 * super.clickOn(smartRadio); super.clickOn(nextBtn);*/
			 
			super.takeScreenshot();
			test.log(LogStatus.INFO, "Navigated to asset page and clicked on new button from cases section.. ");
			Log.info(" Navigated to asset page and clicked on new button from cases section.. ");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void findNewlyCreatedCase(String subject) throws InterruptedException {
		try {

			Thread.sleep(5000);
			super.refreshPage();
			super.clickUsingJs(quickfilter);
			super.waitFor(3);
			super.clickUsingJs(subjectInput);
			super.enterData(subjectInput, subject);
			Thread.sleep(3000);
			super.enterKey();
			Thread.sleep(3000);
			String Cat = "//a[text()='" + subject + "']";
			super.takeScreenshot();
			super.clickUsingJs(By.xpath(Cat));

			test.log(LogStatus.INFO, " Successfully opened newly created case by filtering case...");
			Log.info(" Successfully opened newly created case by filtering case...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void caseModification(String remarkvalue) {
		try {
			super.waitFor(transactionDetails, 10, true);
			super.clickOn(transactionDetails);
			super.scrollIntoElement(editButton);
			super.clickUsingJs(editButton);
			super.scrollIntoElement(saveRecord);
			super.enterData(remarks, remarkvalue);
			super.clickUsingJs(offerMigrationType);
			super.clickDropdownValue("Legacy to Legacy");
			super.takeScreenshot();
			super.clickUsingJs(saveRecord);
			Thread.sleep(5000);
			CommonSteps.markCaseStatus(resolutionInProgress);
			super.clickUsingJs(markStatusComplete);
			
			//CommonSteps.ChangeStatus("NegotiatingStage_XPATH", "MarkStatus_XPATH");
			//textarea[@name='Remarks_Comments__c']
			
			Thread.sleep(5000);
			super.takeScreenshot();
			Thread.sleep(15000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void retentionAction(String plan,String Retention) {
		try {
			
			CommonSteps.SwitchToFrame();
			super.WaitUntilPresenseofElement(retension);
			super.clickUsingJs(retension);
			if(Retention.equalsIgnoreCase("Brand Migration"))
			{
				CommonSteps.refreshSwitchToFrame();
				super.WaitUntilPresenseofElement(planName1);
				super.clickUsingJs(planName1);
				super.typeDataTo(planName1, plan);
				Thread.sleep(2000);
				super.clickUsingJs(By.xpath("//ul//li//*[text()='" + plan + "']"));
				Thread.sleep(3000);
				super.clickUsingJs(modificationNextButton);
				Thread.sleep(5000);
			}
			else
			{
				CommonSteps.refreshSwitchToFrame();
				super.WaitUntilPresenseofElement(planName);
				super.clickUsingJs(planName);
				super.typeDataTo(planName, plan);
				Thread.sleep(2000);
				super.clickUsingJs(By.xpath("//ul//li//*[text()='" + plan + "']"));
				Thread.sleep(3000);
				super.clickUsingJs(modificationNextButton);
				Thread.sleep(12000);
			}
			
			Thread.sleep(10000);
		//	https://stackoverflow.com/questions/20903231/how-to-wait-until-an-element-is-present-in-selenium
			super.WaitUntilPresenseofElement(cartpageheading);
			super.takeScreenshot();
			Thread.sleep(5000);
			//super.WaitUntilPresenseofElement(prod);
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public void addDevice(String deviceName, String TransactionType) 
	{
			try {
				//https://pldtoneenterprise--r32sit.lightning.force.com/one/one.app#eyJjb21wb25lbnREZWYiOiJvbmU6YWxvaGFQYWdlIiwiYXR0cmlidXRlcyI6eyJhZGRyZXNzIjoiaHR0cHM6Ly9wbGR0b25lZW50ZXJwcmlzZS0tcjMyc2l0LmxpZ2h0bmluZy5mb3JjZS5jb20vYXBleC92bG9jaXR5X2NtdF9fSHlicmlkQ1BRP2lkPTBRMDFzMDAwMDAwNjVJNkNBSSJ9LCJzdGF0ZSI6e319
				CommonSteps.refreshSwitchToFrame();
				Thread.sleep(5000);
//				if (!TransactionType.equalsIgnoreCase("Gold to Infinity with Retention"))
//				{
//					
//					super.WaitUntilPresenseofElement(deviceArrow2);
//					super.clickUsingJs(deviceArrow2);
//					super.enterData(deviceSearch2, deviceName);
//					Thread.sleep(5000);
//					super.clickUsingJs(By.xpath("//div[text()='" + deviceName + "']"));
//					Thread.sleep(10000);
//					super.clickUsingJs(configArrow2);
//					super.clickUsingJs(configbutton2);
//					test.log(LogStatus.INFO, " On cart page added device and configured device...");
//					Log.info(" On cart page added device and configured device...");
//
//				}
//				else
//				{
				super.WaitUntilPresenseofElement(deviceArrow);
				super.clickUsingJs(deviceArrow);
				super.enterData(deviceSearch, deviceName);
				Thread.sleep(5000);
				super.clickUsingJs(By.xpath("//div[text()='" + deviceName + "']"));
				Thread.sleep(10000);
				super.clickUsingJs(configArrow);
				super.WaitUntilPresenseofElement(configbutton);
				super.clickUsingJs(configbutton);

				test.log(LogStatus.INFO, " On cart page added device and configured device...");
				Log.info(" On cart page added device and configured device...");
//				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void viewRecord() {
		try {
			super.clickUsingJs(Close);
			Thread.sleep(2000);
			super.clickUsingJs(viewRecord);
			super.driver.switchTo().parentFrame();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void validateCart() {
		try {

			super.WaitUntilPresenseofElement(QuotePageheading);
			CommonSteps.SwitchToFrame();
			super.WaitUntilPresenseofElement(ValidateCart);
			Thread.sleep(2000);
			super.clickUsingJs(ValidateCart);
			CommonSteps.refreshSwitchToFrame();
			super.WaitUntilPresenseofElement(GoToQuote);
			Thread.sleep(2000);
			super.clickUsingJs(GoToQuote);
			Thread.sleep(5000);
			super.driver.switchTo().parentFrame();
			super.WaitUntilPresenseofElement(QuotePageheading);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void rtnUpdateQuoteValidationPeriod() {
		try {
			super.refreshPage();
			super.ExplicitWait("QuoteNumber_XPATH");
			super.ThreadWait(1000);
			super.scroll(300, 400);
			super.waitFor(By.xpath(OR.getProperty("ScrollTillContract_XPATH")), 20, true);
			super.Scroll("ScrollTillContract_XPATH");
			super.jsClick("EditQuoteValidityPeriod_XPATH");
			super.ThreadWait(1000);
			super.type("InputQuoteday_XPATH", "30");
			super.ThreadWait(1000);
			super.Scroll("InputQuoteday_XPATH");
			super.takeScreenshot();
			super.ThreadWait(2000);
			test.log(LogStatus.INFO, "Updated Quote Validation Period on quote page");
			Log.info("Updated Quote Validation Period on quote page");
		} catch (Exception e) {
		}
	}

	public void updateContact(String AuthorizeSigonatory, String BillRecipient, String DeliveryRecipient) {
		try {

			Log.info("Select Authorize Sigonatory Name...");
			super.jsClick("quoteAuthorizedSignatory_XPATH");
			super.type("quoteAuthorizedSignatory_XPATH", AuthorizeSigonatory);
			super.ThreadWait(1000);
			super.element("quoteAuthorizedSignatory_XPATH").sendKeys(Keys.BACK_SPACE);

			super.ThreadWait(1000);
			try {
				System.out.println(AuthorizeSigonatory);
				// tb.driver.findElement(By.xpath("(//ul//li//*[@title='"+AuthorizeSigonatory+"'])")).click();
				super.clickUsingJs(By.xpath("(//ul//li//*[@title='" + AuthorizeSigonatory + "'])[1]"));
				test.log(LogStatus.INFO, "In contact section selected Authorize Sigonatory contact..");
				Log.info("In contact section selected Authorize Sigonatory contact..");

			} catch (Exception e) {
				e.printStackTrace();
			}

			Log.info("Select Bill Recipient Name...");
			super.type("quoteBillRecipient_XPATH", BillRecipient);
			super.ThreadWait(1000);
			super.element("quoteBillRecipient_XPATH").sendKeys(Keys.BACK_SPACE);

			super.ThreadWait(1000);
			try {
				System.out.println(BillRecipient);
				super.clickUsingJs(By.xpath("(//ul//li//*[@title='" + BillRecipient + "'])[1]"));
				test.log(LogStatus.INFO, "In contact section selected Bill Recipient contact..");
				Log.info("In contact section selected Bill Recipient contact..");
			} catch (Exception e) {
				e.printStackTrace();
			}

			Log.info("Select Delivery Recipient Name...");
			super.type("quoteDeliveryRecipient_XPATH", DeliveryRecipient);
			super.ThreadWait(1000);
			super.element("quoteDeliveryRecipient_XPATH").sendKeys(Keys.BACK_SPACE);

			super.ThreadWait(1000);
			
			
			Log.info("//ul//li//*[@title='" + DeliveryRecipient + "'])[1]");
			super.clickUsingJs(By.xpath("(//ul//li//*[@title='" + DeliveryRecipient +  "'])[1]"));
			test.log(LogStatus.INFO, "In contact section selected Delivery Recipient contact..");
			Log.info("In contact section selected Delivery Recipient contact..");

//			for (int i = 1; i <= 3; i++) {
//
//				try {
//
//					// System.out.println("//ul//li//*[@title='" + DeliveryRecipient + "'])[" + i +
//					// "]");
//					
//					Log.info("//ul//li//*[@title='" + DeliveryRecipient + "'])[" + i + "]");
//					super.clickUsingJs(By.xpath("(//ul//li//*[@title='" + DeliveryRecipient + "'])[" + i + "]"));
//					test.log(LogStatus.INFO, "In contact section selected Delivery Recipient contact..");
//					Log.info("In contact section selected Delivery Recipient contact..");
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void QuoteDeliveryDate(String date) {
		try {
			Thread.sleep(2000);
			super.scrollIntoElement(DeviceResvInfoHeading);
			super.clickUsingJs(deliveryDateBox);
			super.enterData(deliveryDateBox, date);
			System.out.println("clickOnSAVE");
			super.takeScreenshot();
			super.retryClick("save_XPATH");
			super.ExplicitWait("QuoteNumber_XPATH");
			test.log(LogStatus.INFO, "Selected Quote Delivery Date... ");
			Log.info("Selected Quote Delivery Date... ");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void clickOnReload() {
		try {
			super.clickUsingJs(relaodQutotaionUpdate);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public boolean reload() {		
		boolean flag =false;
		if (super.isElementPresent(relaodQutotaionUpdate)) {
			flag = true;
		} 
		return flag;
	}

	public String getQuoteURL() {
		return driver.getCurrentUrl();
	}

	public void creditcheck(String newStatus, String condition, String Remark) {

		try {
			super.scrollIntoElement(CreditInfoHeading);
			super.clickUsingJs(EditCreditApprovalStatusButton);
			super.clickUsingJs(CreditApprovalStatusBox);
			super.jsClink_LinkText(newStatus);
			super.clickUsingJs(CreditApprovalConditionBox);
			super.driver.findElement(By.xpath("//a[text()='" + condition + "']")).click();
			super.typeDataTo(CreditRemarksbox, Remark);

			System.out.println("clickOnSAVE");
			super.takeScreenshot();
			super.retryClick("save_XPATH");
			super.ExplicitWait("QuoteNumber_XPATH");
			super.ThreadWait(2000);

			test.log(LogStatus.INFO, "Performed credit check using Credit Analyst...");
			Log.info("Performed credit check using Credit Analyst...");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void DeviceAvalibility() {

		try {

			Thread.sleep(5000);
			CommonSteps.SwitchToFrame();
			Log.info("\nInside the frame : Device Availability\n");
//			super.waitFor(By.xpath("(//i[@class='icon icon-v-menu2'])[1]"), 60, true);
			super.clickUsingJs(threedot);
			super.clickUsingJs(By.xpath(OR.getProperty("Menue_XPATH")));
			super.clickUsingJs(By.xpath(OR.getProperty("DeviceAvailabilityCheck_XPATH")));
			super.ThreadWait(2000);
			super.driver.navigate().refresh();

			CommonSteps.refreshSwitchToFrame();
			// super.ExplicitWait("DeviceCheckNexsupertn_XPATH");
			super.ThreadWait(5000);
			super.takeScreenshot();
			// AllDevicecheck(QuoteName, "DeviceAvailability", runStatus);
			// super.click("DeviceCheckNexsupertn_XPATH");
			super.WaitUntilPresenseofElement(deviceavanext);
			super.scrollIntoElement(deviceavanext);
			super.clickUsingJs(deviceavanext);
			super.driver.switchTo().parentFrame();
			super.ThreadWait(5000);
			test.log(LogStatus.INFO, "Performed device availability check...");
			Log.info("Performed device availability check...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ChangeStatustoCustomerApproved() {
		try {
			CommonSteps.ChangeStatus("CustomerApprovedStage_XPATH", "MarkStatus_XPATH");
			super.refreshPage();
			super.ExplicitWait("MarkAsComplete_XPATH");
			
			test.log(LogStatus.INFO, "Move Quote to Customer Approved status...");
			Log.info("Move Quote to Customer Approved status...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void DeviceReservation() {
		try {
			
			Thread.sleep(5000);
			CommonSteps.SwitchToFrame();
			Thread.sleep(5000);
			super.clickUsingJs(DeviceReservationbtn);
			
			CommonSteps.refreshSwitchToFrame();
			Thread.sleep(5000);
			super.takeScreenshot();
			super.scrollIntoElement(reservationNext);
			super.WaitUntilPresenseofElement(reservationNext);
			super.clickUsingJs(reservationNext);

			
			super.WaitUntilPresenseofElement(DeliveryModeNext);
			Thread.sleep(5000);
			super.takeScreenshot();
			super.clickUsingJs(DeliveryModeNext);
			
			
			super.WaitUntilPresenseofElement(DeviceAllocationStatus);
			Thread.sleep(5000);
			super.takeScreenshot();
			super.clickUsingJs(DeviceAllocationStatus);
			
			
			super.WaitUntilPresenseofElement(QuotePageheading);
			Thread.sleep(5000);
			test.log(LogStatus.INFO, " Performed device reservation...");
			Log.info(" Performed device reservation...");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ChangeStatustoAccepted() {
		boolean flag = false;
		do {
			try {
				CommonSteps.ChangeStatus("AcceptedStage_XPATH", "MarkStatus_XPATH");
				super.refreshPage();
				super.ExplicitWait("MarkAsComplete_XPATH");
				flag = super.element("MarkAsComplete_XPATH").isDisplayed();
			} catch (Exception e) {
				super.refreshPage();
				Log.info("Page Will Refresh..");
			}
		} while (!flag);

		test.log(LogStatus.INFO, "Move Quote to Accepted status...");
		Log.info("Move Quote to Accepted status...");
	}

	public void CreateContract() {
		try {

			CommonSteps.SwitchToFrame();
			Thread.sleep(5000);
			super.clickUsingJs(contractcreatebtn);
			
			CommonSteps.refreshSwitchToFrame();
			Thread.sleep(5000);
			super.clickUsingJs(contractcreatenext);
			super.WaitUntilPresenseofElement(contractheading);
			Thread.sleep(5000);
			super.driver.switchTo().parentFrame();
			
			CommonSteps.ChangeStatus("NegotiatingStage_XPATH", "MarkStatus_XPATH");
			Thread.sleep(5000);
			CommonSteps.ChangeStatus("AwaitingSingnture_XPATH", "MarkStatus_XPATH");
			Thread.sleep(5000);
			CommonSteps.ChangeStatus("Signed_XPATH", "MarkStatus_XPATH");
			Thread.sleep(5000);
			test.log(LogStatus.INFO, " Created contract by clicking on Create Contract button...");
			Log.info(" Created contract by clicking on Create Contract button...");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void order() {

		try {
			//CommonSteps.clickOnDetail();
			
			super.clickUsingJs(orderdetails);
			super.ExplicitWait("gotoQuote_XPATH");
			super.click("gotoQuote_XPATH");

			super.WaitTillPresenseofElement("quotesRelatedTab_XPATH");
			super.jsClink_LinkText("Related");

			// scroll to order
			String quoteNumber = null;
			String quotesString = null;
			String orderString = null;

			try {

				int i = 0;
				do {
					super.driver.navigate().refresh();
					super.ThreadWait(4000);
					super.jsClink_LinkText("Related");
					super.ThreadWait(4000);

					((JavascriptExecutor) super.driver).executeScript("window.scrollBy(0,1800)");
					super.ThreadWait(2000);
					// super.Scroll("quotesOrdersTitle_XPATH");

					System.out.println("OrderCount Text: " + super.getText("OrderCount_XPATH"));
					quotesString = super.getText("OrderCount_XPATH");
					Log.info("quotesString "+quotesString);
					orderString = super.getText("OrderCount_XPATH");
					Log.info("orderString "+orderString);
					if (quotesString.contains("0")) {

						quotesString = super.getText("OrderCount2_XPATH");
					}
					quoteNumber = quotesString.substring(1, 2);
					i = Integer.parseInt(quoteNumber);
				} while (i < 1);

				System.out.println("Click on Orders Title..");
				if (orderString.contains("0")) {

					super.jsClick("quotesOrdersTitle2_XPATH");
				}

				else {

					super.jsClick("quotesOrdersTitle_XPATH");
				}
				quoteNumber = super.getText("quotesOrderNumber_XPATH");
				Log.info("quoteNumber "+quoteNumber);
				super.takeScreenshot();
				
				
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			// return quoteNumber;

		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	
	public void masterOrderStatus() {
		
		try {
			
			String ornum = super.getTextFromPage(firstOrderNum);
			WebElement ele = super.driver.findElement(By.xpath("(//a[text()='"+ ornum +"'])[2]"));
			ele.click();
			super.scroll(400, 400);
			super.takeScreenshot();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	//https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Quote/0Q01s00000066YyCAI/view
	
	public void selectMaster() {
		try {
			super.clickUsingJs(quickfilter);
			orderURL = super.driver.getCurrentUrl();
			super.enterValueUsingJs(By.xpath("//input[@name='Order-TotalAmount-min']"), "0");
			super.enterValueUsingJs(By.xpath("//input[@name='Order-TotalAmount-max']"), "0");
			super.enterKey();
			super.clickUsingJs(By.xpath("//th/span/a"));
			super.scroll(400, 400);
			super.takeScreenshot();
			super.test.log(LogStatus.PASS, "Case is selected");
		} catch (Exception e) {
			Assert.fail();
			super.test.log(LogStatus.FAIL, "Case is selected");
		}
	}

	public void selectSubOrder() {
		try {
			super.navigateURL(orderURL);
			super.clickUsingJs(quickfilter);
			super.clickUsingJs(By.xpath("//button[text()='Clear']"));
			super.enterValueUsingJs(By.xpath("//input[@name='Order-TotalAmount-min']"), "1");
			super.enterKey();
			super.waitFor(By.xpath("//td[4]/span/span[text()='PHP 0.000']"), 5, false);
			super.clickUsingJs(By.xpath("//th/span/a"));
			super.test.log(LogStatus.PASS, "Case is selected");
		} catch (Exception e) {
			Assert.fail();
			super.test.log(LogStatus.FAIL, "Case is selected");
		}
	}
	public void selectAsset(String minValue, String assetNameValue) {
		try {
		//super.clickUsingJs(assets);
		super.clickUsingJs(quickfilter);
		super.clickUsingJs(assetinput);
		super.typeDataTo(assetinput, assetNameValue);
		super.clickUsingJs(mininput);
		super.typeDataTo(mininput, minValue);
		super.enterKey();
		String pat = "//a[text()=" + "'" + assetNameValue + "'" + "]";
		super.clickUsingJs(By.xpath(pat));
		TestBase.test.log(LogStatus.PASS, "Searched for an Specific Asset");
		} catch (Exception e) {
		Assert.fail();
		TestBase.test.log(LogStatus.FAIL, "Searched for an Specific Asset");
		}
		}
	public void goToAccountAssets() {
		try {
			super.clickUsingJs(showAll);
			super.clickUsingJs(asset);
			TestBase.test.log(LogStatus.PASS, "Clicked on Assets in Account Page");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked on Assets in Account Page");
		}
	}


}
