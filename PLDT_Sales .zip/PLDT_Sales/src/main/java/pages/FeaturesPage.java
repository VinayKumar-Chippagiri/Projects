package pages;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;

public class FeaturesPage extends TestBase {

	private String orderURL = null;
	private String CaseID = null;

	private By caseAcceptbtn = By.xpath("//div[@title='Accept']");
	private By casecheckbox = By.xpath("(//span[@class='slds-checkbox--faux'])[2]");
	private By searchList = By.xpath("//input[@placeholder='Search this list...']");
	private By morebtn = By
			.xpath("//a[@class='slds-button slds-button_reset slds-context-bar__label-action']//span[text()='More']");
	private By casebtn = By.xpath("//span[@class=\"slds-truncate\"]//span[text()='Cases']");
	private By filterCase = By.xpath("//button[@title='Select List View']");
	private By filterCaseSearch = By.xpath(
			"//input[@class='slds-input default input uiInput uiInputTextForAutocomplete uiInput--default uiInput--input']");
	private By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	private By editButton = By.xpath("(//button[text()='Edit'])[2]");
	private By remarks = By.xpath("//label[text()='Remarks']/following::div/input[@name='Remarks__c']");
	private By saveRecord = By.xpath("//button[text()='Save Record']");
	public By resolutionInProgress = By.xpath("//span[text()='Resolution In Progress']");
	private By markStatusComplete = By.xpath("//span[text()='Mark as Current Status']/..");
	private By roaming = By.xpath("//span[text()='Roaming']");
	private By idd = By.xpath("//span[text()='IDD']");
	private By voiceOutgoing = By.xpath("//span[text()='Voice Outgoing']");
	private By voiceIncomingOutgoing = By.xpath("//span[text()='Voice Incoming & Outgoing']");
	private By data = By.xpath("//span[text()='Data']");
	private By moveDocumentArrow = By.xpath("//button[@title='Move selection to Chosen']");
	private By dropdown = By.xpath("//i[@ng-click=\"toggleDropDown()\"]");
	private By featureDeactivation = By.xpath("(//span[text()='Feature Deactivation'])[1]");
	private By featureActivation = By.xpath("(//span[text()='Feature Activation'])[1]");
	private By afterSalesDoneButton = By.xpath("//p[text()='Done']");
	private By trasactionAseet = By.xpath("//span[@title='Transaction Asset']");

	private By relatedSection = By.xpath("(//flexipage-record-home-scrollable-column)[3]");
	private By transactionAsset = By.xpath("(//span[text()='Transaction Asset'])[1]/following-sibling::span");
	private By order = By.xpath("//span[text()='Orders']/parent::a[@class='slds-card__header-link baseCard__header-title-container']");
	private static By quickfilter = By.xpath("//button[@title='Show quick filters']");

	private By appLauncher = By.xpath("//*[@aria-label=\"App\"]/one-app-launcher-header/button/div");
	private By appSearch = By.xpath("//input[@placeholder=\"Search apps and items...\"]");

	private By nextArrow = By.xpath("//span[text()='Next']");
	
	
	private By showMoreActions = By.xpath("//span[text()='Show more actions']");
	private By uploadBulk = By.xpath("//span[text()='Upload Bulk File']");
	private By customObjects = By.xpath("//a[text()='Custom objects']");
	private By transactionAssetOption = By.xpath("//a[text()='Transaction Assets']");
	private By addNewRecords = By.xpath("//a[text()='Add new records']");
	private By csv =By.xpath("//span[text()='CSV']");
	private By chooseFile = By.xpath("//input[@name='file']");
	private By importFileNextButton =By.xpath("//a[text()='Next']");
	private By editMappingFieldNextButton =By.xpath("//a[text()='Next']");
	private By startImport=By.xpath("//a[text()='Start Import']");
	private By okButton=By.xpath("//a[text()='OK']");
	private By reload =By.xpath("//input[@id='j_id0:theForm:thePageBlock:theButtons:reloadButton']");
	private By orderLink = By.cssSelector("h3.primaryField.slds-tile__title.slds-truncate a[href]");
	private By filter = By.xpath("(//*[text()='Select List View'])/parent::*");
	private  By showAll = By.xpath("//ul/following-sibling::div/a[contains(text(),'Show All')]");
	private  By asset = By.xpath("//ul/li//force-hoverable-link//slot//*[contains(text(),'Assets')]");
	private  By assetinput = By.xpath("(//label[text()='Asset Name']/following::input)[1]");
	private  By mininput = By.xpath("(//label[text()='MIN']/following::input[@name='Asset-MIN__c'])");
	private  By cases = By.xpath("(//div/h2/a/span[text()='Cases'])[1]");
	private  By newButton = By.xpath("//div[text()='Change Owner']/ancestor::ul/li/a/div[text()='New']");
	
	public String getCaseID() {
		return CaseID;
	}

	public void setCaseID(String caseID) {
		
		if (caseID == null) {
			CaseID = driver.findElement(By.xpath("//p[@title='Case Number']/following-sibling::p/slot/lightning-formatted-text")).getText();
		} else {
			CaseID = caseID;
		}	
	}
	
	public void clickOnAppLauncher() {
		super.clickOn(appLauncher);
	}

	public void enterValueOnAppSearch() {
		super.typeDataTo(appSearch, "Cases");
		super.clickOn(By.xpath("//b[.='Cases']"));
	}

	public void acceptCase(String subject) throws InterruptedException {

		try {

			clickOnAppLauncher();
			enterValueOnAppSearch();
			Thread.sleep(3000);
			super.clickUsingJs(filterCase);
			
			super.clickUsingJs(filterCaseSearch);
			super.typeDataTo(filterCaseSearch, "SMART Enterprise Support");
			super.clickOn(By.xpath("//mark[text()='SMART Enterprise Support']"));
			super.clickUsingJs(searchList);
			super.typeDataTo(searchList, subject);
			super.enterKey();
			super.clickUsingJs(casecheckbox);
			super.clickUsingJs(caseAcceptbtn);
			Thread.sleep(5000);
			super.clickUsingJs(filterCase);
			super.clickUsingJs(filterCaseSearch);
			super.typeDataTo(filterCaseSearch, "My Cases");
			super.clickOn(By.xpath("//mark[text()='My Cases']"));

			String Cat = "//a[text()='"+subject+"']";
			super.takeScreenshot();
			super.clickUsingJs(By.xpath(Cat));
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private By a = By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']");

	public void caseModification(String remarkvalue, String FeaturesAvailable) {
		try {
			super.waitFor(transactionDetails, 10, true);
			super.clickOn(transactionDetails);
			super.scrollIntoElement(editButton);
			super.clickUsingJs(editButton);
			super.enterData(remarks, remarkvalue);
			Thread.sleep(2000);
			super.enterTab();
			Thread.sleep(3000);

			String[] split = Arrays.stream(FeaturesAvailable.split(","))
					.map(String::trim)
					.toArray(String[]::new);

			for (String feature : split) {

			WebElement ele;
			switch (feature) {
			case "Roaming":
				Thread.sleep(2000);
				ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Roaming']"));
				ele.click();
				break;

			case "IDD":
				Thread.sleep(2000);
				ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='IDD']"));
				ele.click();
				break;

			case "VoiceOutgoing":
				ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Voice Outgoing']"));
				ele.click();
				break;

			case "VoiceIncoming&Outgoing":
				ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Voice Incoming & Outgoing']"));
				ele.click();
				break;

			case "SMSOutgoing":
				ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='SMS Outgoing']"));
				ele.click();
				break;

			case "SMSIncoming&Outgoing":
				ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='SMS Incoming & Outgoing']"));
				ele.click();
				break;

			case "Data":
				ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Data']"));
				ele.click();
				break;

			default:
				Log.info("Did not select any features");
				System.out.println("Did not select any features");
				break;
			}
			super.clickOn(moveDocumentArrow);
			Thread.sleep(2000);
		}

			super.takeScreenshot();
			super.clickUsingJs(saveRecord);
			Thread.sleep(5000);
			super.refreshPage();
			super.scrollIntoElement(nextArrow);
			Thread.sleep(3000);
			super.waitFor(resolutionInProgress, 10, true);
			CommonSteps.markCaseStatus(resolutionInProgress);
			Thread.sleep(3000);
			super.clickUsingJs(markStatusComplete);
			Thread.sleep(3000);
			super.takeScreenshot();
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void featureAction(String feature) {
		try {
			CommonSteps.SwitchToFrame();
			
			
		
			Thread.sleep(5000);
			if (feature.equalsIgnoreCase("Feature Deactivation")) {
				super.clickOn(dropdown);
				super.clickUsingJs(featureDeactivation);
			} else {
				if(driver.findElements(featureActivation).size()==1)
				{
					super.clickUsingJs(featureActivation);
				}
				else
				{
					CommonSteps.SwitchToFrame();
					super.clickUsingJs(featureActivation);
				}
				
			}
			Thread.sleep(5000);
			CommonSteps.refreshSwitchToFrame();
			super.clickOn(afterSalesDoneButton);
			Thread.sleep(3000);
			super.driver.switchTo().parentFrame();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyTransactionAsset() {

		try {
			js = (JavascriptExecutor) driver;
			// System.out.println(js.executeScript("return
			// arguments[0].scrollTop",tb.driver.findElement(transactionAsset)));
			js.executeScript("arguments[0].scroll(0,2500)", super.driver.findElement(relatedSection));
			// tb.scrollIntoElement(transactionAsset);
			if (!super.getTextFromPage(transactionAsset).equals("(0)")) {
				System.out.println("pass");
				Log.info(super.getTextFromPage(transactionAsset));
			}
			super.takeScreenshot();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	

	public void verifyOrder() {

		try {
			js = (JavascriptExecutor) driver;
			// System.out.println(js.executeScript("return
			// arguments[0].scrollTop",tb.driver.findElement(transactionAsset)));
			js.executeScript("arguments[0].scroll(0,2500)", super.driver.findElement(relatedSection));
			// tb.scrollIntoElement(transactionAsset);
			if (!super.getTextFromPage(order).equals("(0)")) {
				System.out.println("pass");
				Log.info(super.getTextFromPage(order));
			}
			super.takeScreenshot();
			Thread.sleep(3000);
			//super.clickUsingJs(orderLink);
			super.clickUsingJs(order);
			super.takeScreenshot();


		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void selectMaster() {
		try {
			super.clickUsingJs(quickfilter);
			orderURL = super.driver.getCurrentUrl();
			super.enterValueUsingJs(By.xpath("//input[@name='Order-TotalAmount-min']"), "0");
			super.enterValueUsingJs(By.xpath("//input[@name='Order-TotalAmount-max']"), "0");
			super.enterKey();
			super.clickUsingJs(By.xpath("//th/span/a"));
			super.test.log(LogStatus.PASS, "Case is selected");
		} catch (Exception e) {
			Assert.fail();
			super.test.log(LogStatus.FAIL, "Case is selected");
		}
	}

	public void selectSubOrder() {
		try {
			super.navigateURL(orderURL);
			super.clickUsingJs(quickfilter);
			super.clickUsingJs(By.xpath("//button[text()='Clear']"));
			super.enterValueUsingJs(By.xpath("//input[@name='Order-TotalAmount-min']"), "1");
			super.enterKey();
			super.waitFor(By.xpath("//td[4]/span/span[text()='PHP 0.000']"), 5, false);
			super.clickUsingJs(By.xpath("//th/span/a"));
			super.test.log(LogStatus.PASS, "Case is selected");
		} catch (Exception e) {
			Assert.fail();
			super.test.log(LogStatus.FAIL, "Case is selected");
		}
	}
	
	
	public void bulk(String location)
	{
		try 
		{				
			Thread.sleep(5000);
			super.refreshPage();
			super.scrollIntoElement(nextArrow);
			Thread.sleep(3000);
			super.waitFor(resolutionInProgress, 10, true);
			CommonSteps.markCaseStatus(resolutionInProgress);
			Thread.sleep(3000);
			super.clickUsingJs(markStatusComplete);
			Thread.sleep(3000);
			super.takeScreenshot();
			Thread.sleep(10000);
			
			String url = super.driver.getCurrentUrl();
			super.clickUsingJs(showMoreActions);
			super.clickUsingJs(uploadBulk);
			Thread.sleep(5000);
			super.switchToNewWindow();
			super.WaitUntilPresenseofElement(customObjects);
			super.clickUsingJs(customObjects);
			super.scrollIntoElement(transactionAssetOption);
			super.clickUsingJs(transactionAssetOption);
			super.clickUsingJs(addNewRecords);
			super.clickUsingJs(csv);
			driver.findElement(chooseFile).sendKeys(location);		
			super.clickUsingJs(importFileNextButton);
			super.clickUsingJs(editMappingFieldNextButton);
			super.clickUsingJs(startImport);
			super.clickUsingJs(okButton);
			super.navigateURL(url);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	public void goToAccounts() {
		try {
			super.clickUsingJs(appLauncher);
			super.clickUsingJs(appSearch);
			super.typeDataTo(appSearch, "Accounts");
			super.clickDropdownValue("Accounts");
			TestBase.test.log(LogStatus.PASS, "Navigated to Account search page");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Navigated to Account search page");
		}
	}

	public void searchAndSelectAccount(String acountNameValue) {
		try {
			super.clickUsingJs(filter);
			super.clickDropdownValue("All Accounts - Business Accounts");
			super.typeDataTo(searchList, acountNameValue);
			super.waitFor(By.xpath("//table[1]"), 5, true);
			super.enterKey();
			String path = "//a[text()=" + "'" + acountNameValue + "'" + "]";
			System.out.println(path);
			super.clickUsingJs(By.xpath(path));
			TestBase.test.log(LogStatus.PASS, "Specific Acount is selected");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Specific Acount is selected");
		}
	}

	public void goToAccountAssets() {
		try {
			super.clickUsingJs(showAll);
			super.clickUsingJs(asset);
			TestBase.test.log(LogStatus.PASS, "Clicked on Assets in Account Page");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked on Assets in Account Page");
		}
	}

	public void selectAsset(String minValue, String assetNameValue) {
		try {
			super.clickUsingJs(quickfilter);
			super.clickUsingJs(assetinput);
			super.typeDataTo(assetinput, assetNameValue);
			super.clickUsingJs(mininput);
			super.typeDataTo(mininput, minValue);
			super.enterKey();
			String pat = "//a[text()=" + "'" + assetNameValue + "'" + "]";
			super.clickUsingJs(By.xpath(pat));
			TestBase.test.log(LogStatus.PASS, "Searched for an Specific Asset");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Searched for an Specific Asset");
		}
	}
	public void goToCreateCase() {
		try {
			super.clickUsingJs(cases);
			super.clickUsingJs(newButton);
			super.clickUsingJs(By.xpath("//*[text()='SMART Service Request']"));
			super.clickUsingJs(By.xpath("//span[.='Next']"));
			TestBase.test.log(LogStatus.PASS, "Created new Case");
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Created new Case");
		}
	}

}
