package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import pageAction.CommonSteps;
import pages.Retention;

public class ChangePlan extends TestBase {

	Retention retention;
	private By Ebit = By.xpath(
			"((//label[@class=\"label inputLabel uiLabel-left form-element__label uiLabel\"]/parent::div)[15])/input");
	private By dropdown = By.xpath("//i[@ng-click=\"toggleDropDown()\"]");
	private By planChange = By.xpath("(//span[text()='Change Of Plan'])[1]");
	private By planName = By.xpath("//span[contains(text(),'Plan Name')]/parent::label/parent::div/input");
	private By selectPlanNextButton = By.xpath("//p[text()='Next']");

	private By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	private By editButton = By.xpath("(//button[text()='Edit'])[2]");
	private By remarks = By.xpath("//textarea[@name='Remarks_Comments__c']");
	private By offerMigrationType = By.xpath("//label[text()='Offer Migration Type']/following::div/div/input");
	private By saveRecord = By.xpath("//button[text()='Save Record']");
	public By resolutionInProgress = By.xpath("//span[text()='Resolution In Progress']");
	private By markStatusComplete = By.xpath("//span[text()='Mark as Current Status']/..");
	private By cartpageheading = By.cssSelector("div.slds-page-header.cpq-base-header-container");
	private By ProductConfiguration=By.xpath("(//button[@class='slds-button slds-button_icon-border-filled cpq-item-actions-dropdown-button'])[1]");
	private By viewRecord = By.xpath("//button[@title='View Record']");

	public void caseModificationChangePlan(String remarkvalue, String OfferMigrationType) {
		try {
			super.waitFor(transactionDetails, 10, true);
			super.clickOn(transactionDetails);
			super.scrollIntoElement(editButton);
			super.clickUsingJs(editButton);
			super.scrollIntoElement(saveRecord);
			super.enterData(remarks, remarkvalue);
			super.clickUsingJs(offerMigrationType);
			super.clickDropdownValue(OfferMigrationType);
			super.takeScreenshot();
			super.clickUsingJs(saveRecord);
			Thread.sleep(5000);
			CommonSteps.markCaseStatus(resolutionInProgress);
			super.clickUsingJs(markStatusComplete);

			//CommonSteps.ChangeStatus("NegotiatingStage_XPATH", "MarkStatus_XPATH");


			Thread.sleep(5000);
			super.takeScreenshot();
			Thread.sleep(15000);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	public void EBIT(String ebit) {
		retention = new Retention();
		super.clickUsingJs(Ebit);
		super.enterData(Ebit, ebit);
	}


	public void changePlan(String plan) {
		try {
			CommonSteps.SwitchToFrame();
			super.WaitUntilPresenseofElement(dropdown);
			super.clickUsingJs(planChange);
			Thread.sleep(10000);
			CommonSteps.refreshSwitchToFrame();
			super.clickUsingJs(planName);
			// super.enterData(planName, plan);
			super.typeDataTo(planName, plan);
			Thread.sleep(2000);
			super.clickUsingJs(By.xpath("//ul//li//*[text()='" + plan + "']"));
			Thread.sleep(5000);
			super.clickUsingJs(selectPlanNextButton);
			Thread.sleep(5000);
			if(plan.contains("5G")) {

				Thread.sleep(5000);
				super.driver.switchTo().parentFrame();
				Thread.sleep(2000);

				try {
					//super.WaitUntilPresenseofElement(cartpageheading);
					super.WaitUntilPresenseofElement(ProductConfiguration);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}

				super.driver.navigate().refresh();
				CommonSteps.SwitchToFrame();
				super.WaitUntilPresenseofElement(ProductConfiguration);
				super.takeScreenshot();
				Thread.sleep(5000);
				System.out.println("Click on View Record");
				super.clickUsingJs(viewRecord);
			}
			super.driver.switchTo().parentFrame();
			super.takeScreenshot();
			Thread.sleep(20000);
			//			super.WaitUntilPresenseofElement(prod);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("indsie catch block");
			e.printStackTrace();
		}

	}

}
