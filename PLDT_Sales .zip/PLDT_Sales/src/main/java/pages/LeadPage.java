package pages;

import org.openqa.selenium.By;

public class LeadPage {

	 private By appLauncher = By.xpath("//*[@aria-label=\"App\"]/one-app-launcher-header/button/div");
	 
	
	 
	
}
