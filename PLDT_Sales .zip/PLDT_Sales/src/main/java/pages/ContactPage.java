package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

import base.TestBase;

public class ContactPage  {
	    private static TestBase tb =new TestBase();
	    private static By contactSalutation = By.xpath("//input[@name='salutation']");
	    private static By contactFirstName = By.xpath("//input[@placeholder='First Name']");
	    private static By contactMidName = By.xpath("//input[@placeholder='Middle Name']");
	    private static By contactLastName = By.xpath("//input[@placeholder='Last Name']");
	    private static By contactSuffix = By.xpath("//input[@placeholder='Suffix']");
	    private static By contactRole = By.xpath("//label[text()='Contact Roles']//parent::lightning-combobox//input");
	    private static By phone = By.xpath("//input[@name='Phone']");
	    private static By mobile = By.xpath("//input[@name='MobilePhone']");
	    private static By appLauncher = By.xpath("//*[@aria-label=\"App\"]/one-app-launcher-header/button/div");
	    private static By appSearch = By.xpath("//input[@placeholder=\"Search apps and items...\"]");
	    private static By newcontactButton = By.xpath("//div[@title=\"New\"]");
	    private static By save = By.xpath("//button[@name='SaveEdit']");
	    private static By email = By.xpath("//input[@name=\"Email\"]");

	    public static void clickOnAppLauncher() {
	        tb.clickOn(appLauncher);
	        }

	        public static void enterValueOnAppSearch() {
	        tb.typeDataTo(appSearch, "contacts");
	        tb.enterKey();
	        }

	        public static  void clickOnNewContactButton() {
	        tb.clickOn(newcontactButton);
	        }

	        public static void fillContactForm(String Salutation, String firstName, String middleName, String lastName, String Suffix, String Account, String Role, String Phone, String Mobile,String Email)
		    {
	        	tb.clickUsingJs(contactSalutation);
	       	    tb.jsClink_LinkText(Salutation);


	        	tb.enterValueUsingJs(contactFirstName ,firstName);
	        	tb.enterValueUsingJs(contactMidName ,middleName);
	        	tb.enterValueUsingJs(contactLastName ,lastName);
	        	tb.enterValueUsingJs(contactSuffix ,Suffix);
	        	enterAccountName(Account);
	        	tb.clickUsingJs(contactRole);
	       	    tb.jsClink_LinkText(Role);
	            tb.enterValueUsingJs(phone,Phone);
	            tb.enterValueUsingJs(mobile,Mobile);
	            tb.enterValueUsingJs(email,Email);
	            tb.clickOn(save);
	            tb.waitFor(5);
	            tb.takeScreenshot();

		    }



	    	public static void enterAccountName(String AccountName) {
	    		System.out.println("Select Account Name...");

	    		try {
	    			tb.type("searchAccount1_XPATH", AccountName);
	    		} catch (NoSuchElementException e1) {
	    			tb.type("searchAccount_XPATH", AccountName);
	    		}
	    		tb.ThreadWait(1000);
	    		try {
	    			System.out.println("(//a[text()='"+AccountName+"'])");
	    			tb.driver.findElement(By.xpath("(//ul//li//*[@title='"+AccountName+"'])")).click();
	    		} catch (Exception e) {
	    			System.out.println("Hello Catch Block");
	    			e.printStackTrace();
	    		}

	    	}
}
