package casePageAction;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;

public class FulfillmentAndClosureAction {

	static TestBase tb = new TestBase();
	
	public void resolveCase() {
		System.out.println("RESOLVE the case..");
		tb.test.log(LogStatus.INFO, "Move case status to RESOLVED.");
		
		JavascriptExecutor js = (JavascriptExecutor) tb.driver;
		js.executeScript("arguments[0].click();", tb.element("caseStatusResolveButton_XPATH"));
		js.executeScript("arguments[0].click();", tb.element("caseMarkAsCurrentStatusButton_XPATH"));	
	}
	
	public void closeCase() {
		System.out.println("CLOSE the case..");
		tb.test.log(LogStatus.INFO, "Move case status to CLOSED.");
		
		JavascriptExecutor js = (JavascriptExecutor) tb.driver;
		js.executeScript("arguments[0].click();", tb.element("caseStatusClosedButton_XPATH"));
		js.executeScript("arguments[0].click();", tb.element("caseSelectClosedStatusButton_XPATH"));
		
		tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("caseClosureDialogHeader_XPATH"))));
		tb.select("caseCloseStatus_XPATH", "Closed");
		
		tb.click("caseClosureSaveButton_XPATH"); //Save
	}
	
	public void waitForCaseToBeLoaded(String caseNumber) throws InterruptedException {
		System.out.println("Wait for the case to be loaded: " + caseNumber);
		
		String currentSelectedCase = tb.getText("caseSelectedTab_XPATH");
		int i = 0;
		
		while(i < 3) {
			System.out.println("Current Selected case: " + currentSelectedCase);
		
			if(tb.compareText(caseNumber, currentSelectedCase) == true) {
				break;
			}
			
			Thread.sleep(2000);
			currentSelectedCase = tb.getText("caseSelectedTab_XPATH");
			
			i++;
		} 
			
	}
	
}
