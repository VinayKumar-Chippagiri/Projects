package casePageAction;

import base.TestBase;

public class SmartCasesAction2 {
	
	static TestBase tb=new TestBase(); 
	
 public void clickOnNewBtn() {
	 System.out.println("Click New button...");
	
	tb.click("newBtn_XPATH");
	
}
public void clickOnSMARTInqiury() {
	
	tb.click("smartInquiry_XPATH");
	
}
public void clickOnSMARTComplaint() {
	
	tb.click("smartComplaint_XPATH");
	
}public void clickOnSMARTServiceRequest() {
	
	tb.click("smartServiceRequest_XPATH");
	
}public void clickOnPLDTInquiry() {
	
	tb.click("PLDTInquiry_XPATH");
	
}public void clickOnPLDTComplaint() {
	
	tb.click("PLDTComplaint_XPATH");
	
}public void clickOnPLDTServiceRequest() {
	
	tb.click("PLDTServiceRequest_XPATH");
	
}
public void clickOnICTInquiry() {
	
	tb.click("ICTinquiry_XPATH");
	
}

public void clickOnICTComplaint() {
	
	tb.click("ICTComplain_XPATH");
	
}
public void clickOnICTServiceRequest() {
	
	tb.click("ICTServiceRequest_XPATH");
	
}

public void clickOnNext() {
	tb.click("next_XPATH");
	
}

public void searchContact() {
	tb.type("searchContact_XPATH", "Carla Test");
	tb.click("contactName_XPATH");
	
}


public void enter_Subject(String subject) {
	
	tb.type("subject_XPATH", subject);
	
}
public void selectLoB(String LoB) {
	
	tb.click("lob_XPATH");
	tb.click(LoB);
	
}
public void select_type(String type) {
	
	tb.click("type_XPATH");
	tb.click(type);
	
}
public void selectHighLevelTransaction(String highlevelTC) {
	
	tb.click("highLevelTC_XPATH");
	tb.click(highlevelTC);
	
}
public void transactionType(String transactionType) {
	
	tb.click("transactionType_XPATH");
	tb.click(transactionType);
	
	
}
public void transactionSubType(String transactionSubType) {
	
	try {
		tb.click("trsactionSubType_XPATH");
		tb.click(transactionSubType);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
public void transactionReason(String transactionReason) {
	
	tb.click("transactionReason_XPATH");
	tb.click(transactionReason);
	
	
}
public void caseOrigin(String caseOrigin ) {

	tb.click("caseOrigin_XPATH");
	tb.click(caseOrigin);
	
}
public void clickOnSave() {
	
	tb.click("Save_XPATH");
	
}
public void clickOnCancel() {
	
	tb.click("cancel_XPATH");
	
}
public void amountlimit(String amountlimit ) {
	
	tb.type("AmountLimit_XPATH", amountlimit);
	
}
public void clickOnChangeownerIcon() {
	
	tb.click("caseOwnerIcon_XPATH");
	
}
public void clickOndropdownIcon() {
	tb.click("selectBTN_XPATH");
	
}
public void clickonQueue() {
	
	tb.click("Queue_XPATH");
	
}

public void EnterAssignee(String EnterAssignee) {
	
	tb.type("EnterQueue_XPATH", EnterAssignee);
	
}
public void clickOnAssignee(String EnterAssignee) {
	
	try {
		tb.click("QueueValue_XPATH");
	} catch (Exception e) {
		tb.click(EnterAssignee);
	}
	
}
public void clickOncheckbox() {
	tb.click("EmailNotification_XPATH");

}
public void clickOnChangeownerBTN() {
	
	tb.click("changeOwnerBTN_XPATH");
}
public void clickOnCancelBTN_ChangeOwner() {
	
	tb.click("cancelChangeowner_XPATH");
	
}




}