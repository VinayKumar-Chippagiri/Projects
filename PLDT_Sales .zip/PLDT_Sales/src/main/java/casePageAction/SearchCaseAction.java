package casePageAction;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import base.TestBase;

public class SearchCaseAction {

	static TestBase tb = new TestBase();

	public void searchCaseQueue(String queueName) throws InterruptedException {
		System.out.println("Search Case Queue name | " + queueName);

		tb.click("recentCasesDropdown_XPATH");
		Thread.sleep(3000);

		tb.retryClick("caseListSearchBox_XPATH");
		tb.pasteText("caseListSearchBox_XPATH", queueName);
		Thread.sleep(1000);

		tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("searchResult_XPATH"))));
		tb.retryClick("searchResult_XPATH");

		Thread.sleep(1000);

	}

	public void searchCaseFromList(String searchText) throws InterruptedException {
		System.out.println("Search Case from list using: " + searchText);

		tb.pasteText("listSearchBox_XPATH", searchText);
//		tb.element("listSearchBox_XPATH").sendKeys(Keys.ENTER);
		tb.click("refreshButton_XPATH");
		Thread.sleep(1000);
		
//		Assert.assertTrue(tb.isElementDisplayed(searchText));	//check if case is displayed

	}

	public void acceptCase() throws InterruptedException {
		System.out.println("Accept the case");

		tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("caseCheckbox_XPATH"))));
		tb.click("caseCheckbox_XPATH");
		
		tb.click("acceptButton_XPATH");
		Thread.sleep(5000);

	}

	public void viewCaseDetails(String subject) {
		System.out.println("View case details");

		tb.click("caseSubjectLink_XPATH");

	}
	
	
}
