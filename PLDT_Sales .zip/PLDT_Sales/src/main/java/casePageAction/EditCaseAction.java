package casePageAction;

import org.junit.Assert;
import base.TestBase;

public class EditCaseAction {

	static TestBase tb = new TestBase();

	public void click_EditButton() throws InterruptedException {
		System.out.println("Click Edit button.");

//		JavascriptExecutor js = (JavascriptExecutor) tb.getdriver();
//		js.executeScript("arguments[0].scrollIntoView();", tb.element("editButton_XPATH"));
		tb.retryClick("editButton_XPATH");

	}

	public void click_SaveButton() {
		System.out.println("Click Save button.");
		
		tb.click("editSaveButton_XPATH");
	}

	public void click_CancelButton() {
		System.out.println("Click Cancel button");
		
		tb.click("editCancelButton_XPATH");
	}
	
	public void select_type(String type) {
		System.out.println("Select Case type.");
		tb.click("editType_XPATH");
		tb.click(type);

	}

	public void selectHighLevelTransaction(String highlevelTC) {
		System.out.println("Select High-level Transaction Classification.");
		tb.click("editHighLevelTC_XPATH");
		tb.click(highlevelTC);

	}

	public void transactionType(String transactionType) {
		System.out.println("Select Transaction type.");
		tb.click("editTransactionType_XPATH");
		tb.click(transactionType);

	}

	public void transactionSubType(String transactionSubType) {
		System.out.println("Select Transaction Sub-type.");
		tb.click("editTrsactionSubType_XPATH");
		tb.click(transactionSubType);

	}

	public void transactionReason(String transactionReason) {
		System.out.println("Select Transaciton Reason.");
		tb.click("editTransactionReason_XPATH");
		tb.click(transactionReason);

	}

	public void caseOrigin(String caseOrigin) {
		System.out.println("Select Case Origin.");
		tb.click("editCaseOrigin_XPATH");
		tb.click(caseOrigin);

	}
	
	public void verify_EditSuccessful(String caseNumber) {
		System.out.println("Verify edit success message");
		System.out.println(tb.getText("editSaveMessage_XPATH"));
		
		String message = tb.getText("editSaveMessage_XPATH");
		System.out.println(message);
		
		Assert.assertTrue(message.contains(caseNumber));
			
	}
}
