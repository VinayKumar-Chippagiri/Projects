package casePageAction;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import base.TestBase;

public class CustomerPortalAction {

	static TestBase tb = new TestBase();
	
	public void enter_Username(String username) {
		System.out.println("Enter Customer Portal Username");
		
		tb.type("custPortalUsername_XPATH", username);
		
	}
	
	public void enter_Password(String password) {
		System.out.println("Enter Customer Portal Password");
		
		tb.type("custPortalPassword_XPATH", password);
	}
	
	public void click_LoginButton() {
		System.out.println("Click Customer Portal Login Button");
		
		tb.click("custPortalLoginButton_XPATH");
	}
	
	public void click_ContactSupport() throws InterruptedException {
		System.out.println("Click Customer Portal Contact Us Button");
		
		tb.click("custPortalProfileName_XPATH");
		
		Thread.sleep(1000);
		tb.takeScreenshot();
		
		tb.click("Contact Support");
	}
	
	public void enter_Subject(String subject) {
		System.out.println("Enter Subject");
		
		tb.type("custPortalSubject_XPATH", subject);
	}
	
	public void select_TypeOfCustomerRequest(String requestType) {
		System.out.println("Select Type of Customer Request");
		
		tb.click("custPortalTypeOfRequest_XPATH");
		tb.click(requestType);
		
	}
	
	public void select_LineOfBusiness(String LOB) {
		System.out.println("Select Line of Business");
		
		tb.retryClick("custPortalLOB_XPATH");
		tb.click(LOB);
		
	}
	
	public void click_SubmitButton() {
		System.out.println("Click Customer Portal Submit Button");
		
		tb.click("custPortalSubmitButton_XPATH");
	}
	
	public boolean verify_Login() {
		boolean loginFlag = false;
		
		System.out.println("Verify Login Success..");
		
		tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("custPortalChatContactUsButton_XPATH"))));
		loginFlag = tb.compareText("WELCOME TO PLDT ENTERPRISE CUSTOMER PORTAL!", tb.getText("custPortalHeadlineText_XPATH"));	
		
		Assert.assertEquals(true, loginFlag);
		
		return loginFlag;
		
	}
	
	public boolean verify_Submit() {
		boolean successFlag = false;
		
		System.out.println("Verify Submit Success message..");
		
		tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("custPortalCaseCreated_XPATH"))));
		successFlag = tb.compareText("YOUR CASE WAS CREATED.", tb.getText("custPortalCaseCreated_XPATH"));
		
		Assert.assertEquals(true, successFlag);
		
		return successFlag;
		
	}
	
	public boolean verify_SubmitForChat() {
		boolean successFlag = false;
		
		System.out.println("Verify Submit Success message from Chatbox..");
		
		tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("custPortalChatDoneButton_XPATH"))));
		successFlag = tb.compareText("Case submitted", tb.getText("custPortalChatCaseSubmitted_XPATH"));
		
		Assert.assertEquals(true, successFlag);
		
		return successFlag;
		
	}
	
	public String getCaseNumber() {
		System.out.println("Get Case Number..");
		
		return tb.getText("custPortalCaseNumber_XPATH");
	}
	
	public String getCaseNumberForChat() {
		System.out.println("Get Case Number for Chatbox request..");
		
		return tb.getText("custPortalChatCaseNumber_XPATH");
	}
	
	public void click_Logout() throws InterruptedException {
		System.out.println("Click Customer Portal Logout link");
		
		tb.click("custPortalProfileName_XPATH");
		
		Thread.sleep(1000);
		tb.takeScreenshot();

		tb.click("Logout");
	}
	
	//CHAT Contact Us
	public void click_ContactUsButton() {
		System.out.println("Click Customer Portal Contact Us Button");
		
		tb.retryClick("custPortalChatContactUsButton_XPATH");
	}

	public void enter_SubjectOnChatbox(String subject) {
		System.out.println("Enter subject on Chatbox");
		
		tb.type("custPortalChatSubject_XPATH", subject);
	}
	
	public void select_RequestTypeOnChatbox(String requestType) {
		System.out.println("Select Type of Customer Request on Chatbox");
		
		tb.select("custPortalChatRequestType_XPATH", requestType);
	}
	
	public void select_LOBOnChatbox(String LOB) {
		System.out.println("Select LOB on Chatbox");
		
		tb.select("custPortalChatLOB_XPATH", LOB);
	}
	
	public void click_SubmitOnChatbox() {
		System.out.println("Click Customer Portal Submit Button on chatbox");
		
		tb.click("custPortalChatSubmitButton_XPATH");
		
	}

	public void click_DoneButtonOnChatbox() {
		System.out.println("Click Customer Portal DONE Button on chatbox");
		
		tb.click("custPortalChatDoneButton_XPATH");
	}
	
	public void click_HelpAndSupportLink() {
		System.out.println("Click Customer Portal Help & Support Link");
		
		tb.click("custPortalHelp_XPATH");
	}
	
	public void search_CaseSubject(String subject) {
		System.out.println("Enter Case subject to search");
		
		tb.type("custPortalCaseSearchInput_XPATH", subject);
		tb.element("custPortalCaseSearchInput_XPATH").sendKeys(Keys.ENTER);
		
	}
	
	
	
}
