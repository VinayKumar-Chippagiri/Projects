package casePageAction;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;

public class SmartCasesAction {
	
	static TestBase tb=new TestBase(); 
	static WebToCaseAction wtc = new WebToCaseAction();
	
 public void clickOnNewBtn() {
	 System.out.println("Click New button...");
	
	tb.click("newBtn_XPATH");
	
}
public void clickOnSMARTInqiury() {
	
	tb.click("smartInquiry_XPATH");
	
}
public void clickOnSMARTComplaint() {
	
	tb.click("smartComplaint_XPATH");
	
}public void clickOnSMARTServiceRequest() {
	
	tb.click("smartServiceRequest_XPATH");
	
}public void clickOnPLDTInquiry() {
	
	tb.click("PLDTInquiry_XPATH");
	
}public void clickOnPLDTComplaint() {
	
	tb.click("PLDTComplaint_XPATH");
	
}public void clickOnPLDTServiceRequest() {
	
	tb.click("PLDTServiceRequest_XPATH");
	
}
public void clickOnICTInquiry() {
	
	tb.click("ICTinquiry_XPATH");
	
}

public void clickOnICTComplaint() {
	
	tb.click("ICTComplain_XPATH");
	
}
public void clickOnICTServiceRequest() {
	
	tb.click("ICTServiceRequest_XPATH");
	
}

public void clickOnNext() {
	System.out.println("Click on Next button..");
	
	tb.click("next_XPATH");
	
}

public void searchContact() {

	tb.type("searchContact_XPATH", "Carla Test");
	tb.click("contactName_XPATH");
	
}


public void enter_Subject(String subject) {
	System.out.println("Enter Case Subject");
	
	tb.pasteText("newCaseSubject_XPATH", subject);
	
}
public void selectLoB(String LoB) {
	
	tb.click("newCaseLineOfBusiness_XPATH");
	tb.click(LoB);
	
}
public void select_type(String type) {
	
	tb.click("newCaseType_XPATH");
	tb.click(type);
	
}
public void selectHighLevelTransaction(String highlevelTC) {
	
	tb.click("newCaseHighLevelTxnClassification_XPATH");
	tb.click(highlevelTC);
	
}
public void transactionType(String transactionType) {
	System.out.println("Select Transaction Type: " + transactionType);
	
	tb.click("newCaseTxnType_XPATH");
//	if(tb.isElementPresent(By.linkText(transactionType))) {
//		tb.click(transactionType);
//	}else {
//		System.out.println("ELSE - TRANSACTION TYPE");
		tb.driver.findElement(By.xpath("//a[text()=\"" + transactionType + "\"]")).click();
//	}
	
}

//added 09242020
public void transactionEntry(String transactionEntry) {
	
	tb.click("newCaseTransactionEntry_XPATH");
	tb.click(transactionEntry);
	
	
}
public void transactionSubType(String transactionSubType) {
	
//	try {
		tb.click("newCaseTxnSubType_XPATH");
		tb.click(transactionSubType);
//	} catch (Exception e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
	
}
public void transactionReason(String transactionReason) {
	
	tb.click("newCaseTxnReason_XPATH");
	tb.click(transactionReason);
	
	
}
public void caseOrigin(String caseOrigin ) {

	tb.click("newCaseOrigin_XPATH");
	tb.click(caseOrigin);
	
}
public void clickOnSave() {
	System.out.println("Click Save button");
	
	tb.click("newCaseSaveButton_XPATH");
	
}
public void clickOnCancel() {
	
	tb.click("newCaseCancelButton_XPATH");
	
}
public void amountlimit(String amountlimit ) {
	
	tb.type("newCaseAdjustmentAmount_XPATH", amountlimit);
	
}
public void clickOnChangeownerIcon() {
	
	tb.jsClick("caseOwnerIcon_XPATH");
	
}
public void clickOndropdownIcon() {
	tb.click("selectBTN_XPATH");
	
}
public void clickonQueue() {
	
	tb.click("Queue_XPATH");
	
}

public void EnterAssignee(String EnterAssignee) {
	
	tb.type("EnterQueue_XPATH", EnterAssignee);
}


public void EnterAssignee(String EnterAssignee, String PorQ) {
	
	if(PorQ.contentEquals("Queue")) {
		System.out.println("Enter assignee: QUEUE");
//		
//		tb.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(tb.OR.getProperty("EnterQueue_XPATH"))));	
		tb.click("EnterQueue_XPATH");
		tb.element("EnterQueue_XPATH").clear();
		tb.type("EnterQueue_XPATH", EnterAssignee);
		
	} else {
		System.out.println("Enter assignee: PEOPLE");
//		
//		tb.wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(tb.OR.getProperty("EnterPeople_XPATH"))));		
		tb.click("EnterPeople_XPATH");
		tb.element("EnterPeople_XPATH").clear();
		tb.type("EnterPeople_XPATH", EnterAssignee);
		
	}
		
}

public void clickOnAssignee(String EnterAssignee) {
	
	try {
		tb.click("QueueValue_XPATH");
	} catch (Exception e) {
		tb.click(EnterAssignee);
	}
	
}

public void clickAssignee(String assignee, String PorQ) {
	System.out.println("Search for new Case Owner...");

	if (PorQ.contentEquals("Queue")) {
		tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.getProperty("searchQueues_XPATH"))));	
		tb.click("searchQueues_XPATH");
		
//		tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("changeQueueResults_XPATH"))));				
//		tb.click(assignee);
		
	} else {
		tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.getProperty("searchPeople_XPATH"))));	
		tb.click("searchPeople_XPATH");
		
//		tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("changeUserResults_XPATH"))));				
//		tb.click(assignee);
	}
	
	tb.click(assignee);
}


public void clickOncheckbox() {
	tb.click("EmailNotification_XPATH");

}
public void clickOnChangeownerBTN() {
	
	tb.click("changeOwnerBTN_XPATH");
}
public void clickOnCancelBTN_ChangeOwner() {
	
	tb.click("cancelChangeowner_XPATH");
	
}

//added method
public void select_TypeOfRequest(String type, String LoB) {
	System.out.println("Select type of request...");
	
	//	tb.driver.findElement(By.xpath("//span[text()='" + type + "']/parent::label")).click();	
	tb.driver.findElement(By.xpath("//span[contains(text(), '" + LoB + "') and contains(text(), '" + type + "')]/parent::*")).click();
}

public void select_Product(String product) {
	System.out.println("Select Type of Product");
	
	tb.click("newCaseProduct_XPATH");
	tb.click(product);
}

public void enter_OtherOneTimeFee(String otherOneTimeFee) {
	System.out.println("Enter Other One time fee");
	
	tb.type("newCaseOtherOneTimeFee_XPATH", otherOneTimeFee);
}

public void enter_WaiverOfMoveFee(String waiverOfMoveFee) {
	System.out.println("Enter Waiver fo Move fee");
	
	tb.type("newCaseWaiverOfMoveFee_XPATH", waiverOfMoveFee);
}


public void enter_NumberOfLines(String numberOfLines) {
	System.out.println("Enter Number of Lines");
	
	tb.type("newCaseNumberOfLines_XPATH", numberOfLines);
}

public boolean verify_SaveNewCase() {
	System.out.println("Verify Save New case...");
	
	boolean successFlag = true;	
	boolean errorFlag = tb.isElementPresent(By.xpath(tb.OR.getProperty("commonError_XPATH")));
	
	if (errorFlag == true) {
		System.out.println("Missing mandatory fields check...");	
	
		successFlag = false;
		tb.takeScreenshot();
	
		tb.click("newCaseCancelButton_XPATH");
		
		tb.test.log(LogStatus.FAIL, "ERRORS FOUND: " + tb.element("caseError_XPATH").getText());
	} 
	
	System.out.println("Save successful? : " + successFlag);
	return successFlag;
}

public boolean verifyOwnerChange(String owner) {
	System.out.println("Verify Change of Owner...");
	boolean successFlag = false;
	
	String getOwner = wtc.get_CaseOwner();
	if(getOwner.endsWith("_Q")) {
		getOwner = getOwner.substring(0, getOwner.length() - 2);
	}
	
	if(tb.compareText(owner, getOwner)) {
		successFlag = true;
	}
	
	return successFlag;
}

public void searchContact(String contact) throws InterruptedException  {
	System.out.println("Search Case Contact Name");

	tb.type("newCaseContactName_XPATH", contact);
	Thread.sleep(1000);
	
	tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.getProperty("newCaseSearchContacts_XPATH"))));	
	tb.click("newCaseSearchContacts_XPATH");
	
	tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("newCaseContactResultsHeader_XPATH"))));				
	tb.click(contact);
	
}

public void searchAccount(String account) throws InterruptedException  {
	System.out.println("Search Case Account Name");

	tb.pasteText("newCaseAccountName_XPATH", account);
	Thread.sleep(1000);
	
	tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.getProperty("newCaseSearchAccounts_XPATH"))));	
	tb.click("newCaseSearchAccounts_XPATH");
	
	tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("newCaseAccountResultsHeader_XPATH"))));				
	tb.click(account);
	
}

public void clickOnPeople() {
	System.out.println("Click on People");
	tb.click("changeOwnerToPeople_XPATH");
}



}