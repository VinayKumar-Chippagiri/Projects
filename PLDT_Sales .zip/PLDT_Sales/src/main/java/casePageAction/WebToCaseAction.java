package casePageAction;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import base.TestBase;

public class WebToCaseAction {

	static TestBase tb = new TestBase();

	public void enter_ContactName(String contactName) {
		System.out.println("Type contact name");
		tb.type("contactName_XPATH", contactName);

	}

	public void enter_EmailAddress(String email) {
		System.out.println("Type email address");
		tb.type("emailAddress_XPATH", email);

	}

	public void enter_PhoneNumber(String phoneNumber) {
		System.out.println("Type phone number");
		tb.type("phoneNumber_XPATH", phoneNumber);

	}

	public void enter_Subject(String subject) {
		System.out.println("Type subject");
		tb.type("subject_XPATH", subject);

	}

	public void enter_Description(String description) {
		System.out.println("Type description");
		tb.type("description_XPATH", description);

	}

	public void select_LOB(String LOB) {
		System.out.println("Select LOB");
		tb.click("lob_XPATH");

		tb.type("searchBox_XPATH", LOB);
		tb.element("searchBox_XPATH").sendKeys(Keys.ENTER);


	}

	public void select_TypeOfCustomerRequest(String typeOfRequest) {
		System.out.println("Select type of Customer Request");
		tb.click("typeOfCustomerRequest_XPATH");

		tb.type("searchBox_XPATH", typeOfRequest);
		tb.element("searchBox_XPATH").sendKeys(Keys.ENTER);

	}

	public void click_SubmitButton() {
		System.out.println("Click Submit button.");
		tb.click("submitButton_XPATH");
	}

	public boolean verify_Submit() {
		String successMessage;
		boolean successFlag = false;
		
		System.out.println("Verify Submit");
		successMessage = tb.element("submitSuccess_XPATH").getText();
		
		if (successMessage.equals("Your request has been successfully submitted!")) {
			successFlag = true;
		}
		
		return successFlag;
	}

	public String get_CaseOwner() {
		String owner = "";
		
		if(tb.isElementPresent(By.xpath(TestBase.OR.getProperty("caseOwner_XPATH")))) {
			System.out.println("Get case owner: QUEUE");
			owner = tb.getText("caseOwner_XPATH") + "_Q";
		} else {
			System.out.println("Get case owner: PEOPLE");
			owner = tb.getText("caseowner2_XPATH");
		}
		
		return owner; 
	}
	
	public String get_CaseTransactionDescription() {
		System.out.println("Get the case Transaction description...");
		
		return tb.getText("viewCaseTxnDesc_XPATH");
	}
	
	public String get_CaseNumber() {
		System.out.println("Get the case number...");
		
//		return 	tb.getdriver().getTitle().substring(0,8);
		return tb.getText("caseNumber_XPATH");
	}
}
