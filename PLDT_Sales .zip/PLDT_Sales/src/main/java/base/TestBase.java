package base;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.net.UrlChecker.TimeoutException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.apache.log4j.PropertyConfigurator;
import org.apache.logging.log4j.core.config.Loggers;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.CSVWriter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.sf.json.JSONObject;

public class TestBase {
	public static  WebDriver driver;
	public static ThreadLocal<WebDriver> dr = new ThreadLocal<WebDriver>();
	public static Properties config = new Properties();
	public  static Properties OR = new Properties();
	public static FileInputStream fis;
	public static Properties property;
	public static Logger Log;
	public static Wait<WebDriver> wait=null;

	public static ExtentReports rep = ExtentManager.getInstance();
	public static ExtentTest test;
	public static String browser;
	public static JavascriptExecutor js;
	public static String screenshotPath = System.getProperty("user.dir") + "\\target\\surefire-reports\\Report_"
			+ ExtentManager.getStringDate();
	public static String userCredentials = System.getProperty("user.dir") + "\\src\\test\\resources\\data\\Users.csv";
	public Select select = null;
	Boolean retry = true;
	int retryCount = 3;
	int executionCount = 0;
	static Actions actions = null;
	static Alert alert;

	// Modified by Pranay :
	public static void setdriver(WebDriver webdriver) {
		dr.set(webdriver);
		driver = dr.get();
	}

	// edit by waseem: Before and After suite
	@BeforeSuite
	public void setup() {
		setDateForLog4j();
		String invokedBrowserName = setUp();
		Log.info(invokedBrowserName + " browser initiated");
		wait=new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(1))
				.ignoring(NoSuchElementException.class);
	}

	@AfterSuite
	public void teardown() {
		tearDown();
		Log.info("browser closed");
	}

	public void setDateForLog4j() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("_ddMMyyyy_HHmmss");
		System.setProperty("current_date", dateFormat.format(new Date()));
		PropertyConfigurator.configure("./src/main/resources/properties/log4j.properties");
	}

	// All Required Configuration - Initializing Driver, Properties Files, Browser
	// Configuration
	public String setUp() {
		// edit by waseem for logs
		Log = LoggerFactory.getLogger(this.getClass());
		try {
			property = new Properties();
			FileInputStream inputStream = new FileInputStream(
					System.getProperty("user.dir") + "\\src\\main\\resources\\properties\\log4j.properties");
			property.load(inputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// Load properties
		try {
			config.load(new FileInputStream(
					System.getProperty("user.dir") + "\\src\\main\\resources\\properties\\Config.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			OR.load(new FileInputStream(
					System.getProperty("user.dir") + "\\src\\main\\resources\\properties\\OR.properties"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// driver initialization
		// edit by waseem for browser set up
		String broswerName = config.getProperty("browser");
		switch (broswerName.toLowerCase()) {
		case "chrome":
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--disable-notifications");
			options.addArguments("--start-maximized");
			options.addArguments("--disable-web-security");
			options.addArguments("--no-proxy-server");
			options.addArguments("--deny-permission-prompts");
			//options.addArguments("--headless");
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			options.setExperimentalOption("prefs", prefs);

			options.addArguments("user-data-dir=C:\\Users\\plukka\\AppData\\Local\\Google\\Chrome\\User Data\\Default");

			setdriver(new ChromeDriver(options));
			break;
		case "ie":
			WebDriverManager.iedriver().setup();
			setdriver(new InternetExplorerDriver());
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			setdriver(new FirefoxDriver());
			break;
		default:
			System.out.println("Path of Driver Executable is not Set for any Browser");
			Log.info("browser not initiated");
			break;
		}
		driver.get(config.getProperty("testsiteurl"));
		driver.manage().window().maximize();
		driver.manage().timeouts()
				.implicitlyWait(Duration.ofSeconds(Integer.parseInt(config.getProperty("implicit.wait"))));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
		//wait = new WebDriverWait(driver, Duration.ofSeconds(60));

		String title = driver.getTitle();
		System.out.println(title);
		return config.getProperty("browser");
	}

	public void ImpliciWait(int time) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(Integer.parseInt(config.getProperty("implicit.wait"))));

	}

	public void waitElementtoBecomeInvisble(String Locator) {
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(TestBase.OR.getProperty(Locator))));
		System.out.print("Missing Attribute validation is now invisible");
	}

	public void ExplicitWait(String Locator) {
		
	}

	public void WaitTillPresenseofElement(String Locator) {
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(TestBase.OR.getProperty(Locator))));
		System.out.println("Element is Present");
	}

	public void WaitUntilPresenseofElement(By locator) {
		try {
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		System.out.println(locator+" Element is Present");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void click(String locator) {
		try {
			if (locator.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).click();
			} else if (locator.endsWith("_ID")) {
				driver.findElement(By.id(OR.getProperty(locator))).click();
			} else {
				driver.findElement(By.linkText(locator)).click();
			}
			Log.info( "Clicking on : " + locator);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void type(String locator, String value) {
		try {
			if (locator.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).clear();
				driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(value);
			} else if (locator.endsWith("_ID")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).clear();
				driver.findElement(By.id(OR.getProperty(locator))).sendKeys(value);
			} else {
				dropdown = driver.findElement(By.id(locator));
			}
			Log.info( "Typing in : " + locator + " entered value as " + value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static WebElement dropdown;

	public void select(String locator, String value) {
		try {
			if (locator.endsWith("_XPATH")) {
				dropdown = driver.findElement(By.xpath(OR.getProperty(locator)));
			} else if (locator.endsWith("_ID")) {
				dropdown = driver.findElement(By.id(OR.getProperty(locator)));
			} else {
				dropdown = driver.findElement(By.id(locator));
			}
			Select select = new Select(dropdown);
			select.selectByVisibleText(value);
			System.out.println("Current Value: " + value);
			Log.info( "Selecting from dropdown : " + locator + " value as " + value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public WebElement element(String locator) {
		WebElement element = null;
		if (locator.endsWith("_XPATH")) {
			element = driver.findElement(By.xpath(OR.getProperty(locator)));
		} else if (locator.endsWith("_ID")) {
			element = driver.findElement(By.id(OR.getProperty(locator)));
		}
		return element;
	}

	public void Scroll(String locator) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath(OR.getProperty(locator))));
	}

	public void retryClick(String locator) {
		int attempts = 0;
		while (attempts < 2) {
			System.out.println("Clicking attempt " + attempts);
			try {
				if (locator.endsWith("_XPATH")) {
					driver.findElement(By.xpath(OR.getProperty(locator))).click();
				} else if (locator.endsWith("_ID")) {
					driver.findElement(By.id(OR.getProperty(locator))).click();
				} else {
					driver.findElement(By.linkText(locator)).click();
				}
				Log.info( "Clicking on : " + locator);
			} catch (Exception e) {
			}
			attempts++;

			try {
			    driver.switchTo().alert().dismiss();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

	public boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public static void verifyEquals(String expected, String actual) throws IOException {
		try {
			Assert.assertEquals(actual, expected);
		} catch (Throwable t) {
			TestUtil.captureScreenshot();
			// ReportNG
			Reporter.log("<br>" + "Verification failure : " + t.getMessage() + "<br>");
			Reporter.log("<a target=\"_blank\" href=" + TestUtil.screenshotName + "><img src=" + TestUtil.screenshotName
					+ " height=200 width=200></img></a>");
			Reporter.log("<br>");
			Reporter.log("<br>");
			// Extent Reports
			test.log(LogStatus.FAIL, " Verification failed with exception : " + t.getMessage());
			test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		}
	}

	public void scrollElementIntoView(String locator) {
		System.out.println("Scroll into view : " + locator);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", this.element(locator));
	}

	public void takeScreenshot() {
		System.setProperty("org.uncommons.reportng.escape-output", "false");
		try {
			base.TestUtil.captureScreenshot();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		test.log(LogStatus.INFO, test.addScreenCapture(base.TestUtil.screenshotName));
		rep.endTest(test);
		rep.flush();
		Reporter.log("<a target=\"_blank\" href=" + screenshotPath + "\\" + TestUtil.screenshotName + "><img src="
				+ TestUtil.screenshotName + " height=200 width=200></img></a>");
		Reporter.log("<br>");
		Reporter.log("<br>");
	}

	public void jsClick(String locator) {
		System.out.println("Click using javascript: " + locator);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		performMouseHover(locator);
		js.executeScript("arguments[0].click();", this.element(locator));
		Log.info( "Click on: " + locator);
	}

	public String getText(String locator) {
		String text = "";
		try {
			if (locator.endsWith("_XPATH")) {
				text = driver.findElement(By.xpath(OR.getProperty(locator))).getText();
			} else if (locator.endsWith("_ID")) {
				text = driver.findElement(By.id(OR.getProperty(locator))).getText();
			} else {
				text = driver.findElement(By.linkText(locator)).getText();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return text;
	}

	public void ThreadWait(int wait) {
		try {
			Thread.sleep(wait);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void pageUp() {
		System.out.println("Press PAGE UP key...");
		driver.findElement(By.tagName("body")).sendKeys(Keys.PAGE_UP);
	}

	public void tearDown() {
		if (driver != null) {
			// driver.quit();
		}
	}
	// additional methods used in Case Management

	// LEONYL: This is a method to compare two Strings and returns TRUE is they
	// match
	public boolean compareText(String text1, String text2) {
		boolean compareResult = false;
		System.out.println("Compare two strings... " + text1 + " | " + text2);
		if (text1.equals(text2)) {
			compareResult = true;
		}
		return compareResult;
	}

	// LEONYL: This is a method to check if an element is displayed
	public boolean isElementDisplayed(String locator) {
		boolean isDisplayed = false;
		try {
			if (locator.endsWith("_XPATH")) {
				isDisplayed = driver.findElement(By.xpath(OR.getProperty(locator))).isDisplayed();
			} else if (locator.endsWith("_ID")) {
				isDisplayed = driver.findElement(By.id(OR.getProperty(locator))).isDisplayed();
			} else {
				isDisplayed = driver.findElement(By.linkText(locator)).isDisplayed();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Element is displayed: " + isDisplayed);
		return isDisplayed;
	}

	// LEONYL: This method will get the current URL and navigate to it. Works like
	// refresh.
	public void refreshPage() {
		System.out.println("Refresh page...");
		this.navigateURL(this.driver.getCurrentUrl());
	}

	// LEONYL: This is a method to get credentials (ie, username & password) from a
	// CSV file
	// using the String parameter to search
	public String[] getUserCredentials(String user) {
		String[] credentials = { "", "" };
		System.out.println("Get login credentials for user: " + user);
		try {
			FileReader fileReader = new FileReader(userCredentials);
			CSVReader csvReader = new CSVReaderBuilder(fileReader).withSkipLines(1).build();
			String[] record;
			while ((record = csvReader.readNext()) != null) {
				if (record[0].equals(user)) {
					credentials[0] = record[1];
					credentials[1] = record[2];
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return credentials;
	}

	// LEONYL: this is a method to open new chrome
	public void openNewChromeWindow() {
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("profile.default_content_setting_values.notifications", 1);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		driver = new ChromeDriver(options);
		setdriver(driver);
		driver.get(config.getProperty("testsiteurlUAT"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),
				TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, 20);
		String title = driver.getTitle();
		System.out.println(title);
	}

	// LEONYL: This is a method to open chrome in incognito
	public void openNewIncognitoChrome() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		driver = new ChromeDriver(options);
		setdriver(driver);
		driver.get(config.getProperty("testsiteurlUAT"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),
				TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, 20);
		String title = driver.getTitle();
		System.out.println(title);
	}

	// LEONYL: This is a generic method to navigate to a specified URL
	public void navigateURL(String url) {
		System.out.println("Navigate to: " + url);
		driver.get(url);
	}

	// LEONYL: This is a new method to navigate to Home tab
	public void navigateToHome() {
		System.out.println("Navigate to Home tab...");
		driver.get("https://pldtoneenterprise--" + this.config.getProperty("environment")
				+ ".lightning.force.com/lightning/page/home");
	}

	public String getDropdownText(String locator) {
		String value = null;
		try {
			if (locator.endsWith("_XPATH")) {
				dropdown = driver.findElement(By.xpath(OR.getProperty(locator)));
			} else if (locator.endsWith("_ID")) {
				dropdown = driver.findElement(By.id(OR.getProperty(locator)));
			} else {
				dropdown = driver.findElement(By.id(locator));
			}
			Select select = new Select(dropdown);
			value = select.getFirstSelectedOption().getText();
			System.out.println("Current Value: " + value);
			Log.info( "Dropdown : " + locator + " selected value as " + value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}

	// LEONYL: This is method to paste a String
	public void pasteText(String locator, String text) {
		System.out.println("Paste text... " + text);
		// copy text to clipboard
		StringSelection stringSelection = new StringSelection(text);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, null);
		try {
			if (locator.endsWith("_XPATH")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).clear();
				driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(Keys.SHIFT, Keys.INSERT);
			} else if (locator.endsWith("_ID")) {
				driver.findElement(By.xpath(OR.getProperty(locator))).clear();
				driver.findElement(By.id(OR.getProperty(locator))).sendKeys(Keys.SHIFT, Keys.INSERT);
			}
			Log.info( "Paste text in : " + locator + " entered value as " + text);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// LEONYL: This is a method to write DATA to CSV file
	public void writeToCSV(String[] data, String csvName) throws Exception {
		String csv = csvName;
		CSVWriter csvWriter = new CSVWriter(new FileWriter(csv, true));
		csvWriter.writeNext(data);
		csvWriter.close();
	}

	public void selectFromList(String locator, String text) {
		try {
			if (!text.isEmpty()) {
				click(locator);
				System.out.println("Click on: " + locator);
				click(text);
				System.out.println("Enter : " + text);
			}
		} catch (Exception e) {
			System.out.println("Unable to Click on: " + locator + " / Unable to select from List: " + text);
			test.log(LogStatus.FAIL, "Unable to Click on: " + locator + " / Unable to select from List: " + text);
			e.printStackTrace();
		}
	}

	// Ankita : To perform Mouse Hover
	public void performMouseHover(String locator) {
		Actions actions = new Actions(driver);
		WebElement element = null;
		if (locator.endsWith("_XPATH")) {
			element = driver.findElement(By.xpath(OR.getProperty(locator)));
		} else {
			element = driver.findElement(By.linkText(locator));
		}
		// To mouseover on menu
		actions.moveToElement(element).perform();
	}

	public void switchToFrame(String locator) {
		WaitTillPresenseofElement(locator);
		driver.switchTo().frame(driver.findElement(By.xpath(OR.getProperty(locator))));
		System.out.println("Switched to Frame");
	}

	public void jsClink_LinkText(String LinkText) {
		List<WebElement> elements = driver.findElements(By.xpath("//*[text()='" + LinkText + "']"));
		System.out.println("Number of Elements :" + elements.size());
		for (int i = 1; i <= elements.size(); i++) {
			try {
				WebElement element = driver.findElement(By.xpath("(//*[text()='" + LinkText + "'])[" + i + "]"));
				js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();", element);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Log.info( "Clicking on : " + LinkText);
	}



	/**
	 * @author Pranay :  Method that can be called to click on an element
	 *         in the dropdown in currently opened WebPage using javascript.
	 *
	 * @param locator Identifies the element which needs to be clicked.
	 * @return Return true, if able to click on the element, else will return false.
	 */



	public Boolean clickDropdownValue(String dropdownvalue)
	{
		try {
			Log.info("Clicking on element '" + dropdownvalue + "'");
            scrollIntoElement(By.xpath("//*[text()='" + dropdownvalue + "']"));
			clickUsingJs(By.xpath("//*[text()='" + dropdownvalue + "']"));
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				clickDropdownValue(dropdownvalue);
			else
				return false;
		}
		return true;



	}

	/**
	 * @author Pranay :  Method that can be called to click on an element
	 *         in the currently opened WebPage using javascript.
	 *
	 * @param locator Identifies the element which needs to be clicked.
	 * @return Return true, if able to click on the element, else will return false.
	 */



	public Boolean clickUsingJs(By locator) {
		js = (JavascriptExecutor) driver;
		Log.info("Clicking on element '" + locator.toString() + "'");

		try {
			scrollIntoElement(locator);
			//waitForClickable(locator, 10);
			waitFor(locator, 10, true);
		} catch (Exception e) {
			scrollIntoElement(locator);
		}

		try {

			js.executeScript("arguments[0].click();", driver.findElement(locator));
			Log.info("Clicked on element '" + locator.toString() + "'");
		} catch (Exception e) {
			retry = handleException(e);
			if (retry) {

				clickUsingJs(locator);

			}

			else
				return false;
		}
		return true;
	}

	//
	/**
	 * @author Pranay :  Method that can be called to navigate to a particular URL.
	 *
	 * @param URL URL to which the driver needs to navigate to.
	 * @return Return true, if the able to navigate to the given URL, else will
	 *         return false.
	 */
	public Boolean gotoURL(String URL) {
		try {
			Log.info("Navigating to '" + URL + "'");
			driver.navigate().to(URL);
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				gotoURL(URL);
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay : @author Pranay :  Method that can be called to click on an element
	 *         in the currently opened WebPage.
	 *
	 * @param locator Identifies the element which needs to be clicked.
	 * @return Return true, if able to click on the element, else will return false.
	 */
	public Boolean clickOn(By locator) {
		try {

			Log.info("Clicking on element '" + locator.toString() + "'");
			 scrollIntoElement(locator);
			 waitFor(locator,60, true);
			waitForClickable(locator, 5);

			driver.findElement(locator).click();
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				{
				clickOn(locator);}
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be called to send data to any Field which is
	 *         currently available in the WebPage.
	 *
	 * @param locator Identifies the element which the data needs to be sent.
	 * @param data    Data than needs to be sent
	 * @return Return true, if able to sent data to the provided field, else will
	 *         return false.
	 */
	public Boolean enterData(By locator, String data) {
		if (data.equals(""))
			return true;
		try {
			Log.info("Sending data '" + data + "' to field '" + locator.toString() + "'");
			 scrollIntoElement(locator);
			driver.findElement(locator).clear();
			driver.findElement(locator).sendKeys(data);
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				{
				enterData(locator, data);}
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be called to send Data to a field. Used to
	 *         send Data to a field which is validated on key-press and slow to
	 *         accept input.
	 *
	 * @param locator Identifies the element which the data needs to be sent.
	 * @param data    If Date then should be in format 'DD/MM/YYYY hh:mm'
	 * @return
	 */
	public Boolean typeDataTo(By locator, String data) {
		if (data.equals(""))
			return true;
		clearField(locator);
		try {
			char[] dateChars = data.toCharArray();
			Log.info("Typing in data '" + data + "' to '" + locator.toString() + "'");
			for (int i = 0; i < data.length(); i++) {
				 scrollIntoElement(locator);
				driver.findElement(locator).sendKeys(Character.toString(dateChars[i]));
				Thread.sleep(100);
			}
		} catch (Exception e) {
			handleException(e);
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be called to clear any Input field which is
	 *         currently available in the WebPade.
	 *
	 * @param locator Identifies the element that needs to be cleared
	 * @return Returns true, if able to clear the Field, or else will return false.
	 */
	public Boolean clearField(By locator) {
		try {
			Log.info("Clearing field '" + locator.toString() + "'");
			 scrollIntoElement(locator);
			driver.findElement(locator).clear();
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				clearField(locator);
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be called to select a value from a DropDown
	 *         based on index value provided.
	 *
	 * @param locator Identifies the drop down element.
	 * @param index   The index of the value that needs to be selected.
	 * @return Returns true, if able to select the provided index from the provided
	 *         element in WebPage
	 */
	public Boolean selectBy(By locator, int index) {
		if (countOf(locator) == 0) {
			Log.info("ERROR : Element located by '" + locator.toString() + "' is not available.");
			return false;
		}
		try {
			Log.info("Selecting index '" + index + "' from '" + locator.toString() + "'");
			select = new Select(driver.findElement(locator));
			select.selectByIndex(index);
			waitFor(1);
			Log.info("Selected value : " + this.getSelectedOption(locator));
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				selectBy(locator, index);
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be called to select a value from a DropDown
	 *         based on the text available in the drop down.
	 *
	 * @param locator Identifies the drop down element.
	 * @param index   The Text of the value that needs to be selected.
	 * @return Returns true, if able to select the provided Text from the provided
	 *         element in WebPage
	 */
	public Boolean selectBy(By locator, String visibleText) {
		if (visibleText.equals(""))
			return true;
		try {
			Log.info("Selecting value '" + visibleText + "' from '" + locator.toString() + "'");
			select = new Select(driver.findElement(locator));
			select.selectByVisibleText(visibleText);
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				selectBy(locator, visibleText);
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be called to select a value from a DropDown
	 *         based on the Value of the Select.
	 *
	 * @param locator Identifies the drop down element.
	 * @param index   The Text of the value that needs to be selected.
	 * @return Returns true, if able to select the provided Text from the provided
	 *         element in WebPage
	 */
	public Boolean selectByValue(By locator, String value) {
		if (value.equals(""))
			return true;
		try {
			Log.info("Selecting value '" + value + "' from '" + locator.toString() + "'");
			select = new Select(driver.findElement(locator));
			select.selectByValue(value);
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				selectByValue(locator, value);
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be called to select a value from a DropDown
	 *         based on the partial text passed
	 *
	 * @param locator     Identifies the drop down element.
	 * @param partialText The partial Text of the value that needs to be selected
	 * @return Returns true, if able to select the provided Text from the provided
	 *         element in WebPage
	 */
	public boolean selectByPartialText(By locator, String partialText) {
		String xpath = getXpath(locator);
		String fullText = "";
		xpath = xpath + "/descendant::option";
		try {
			List<WebElement> options = driver.findElements(By.xpath(xpath));
			for (WebElement option : options) {
				if (option.getText().contains(partialText)) {
					fullText = option.getText();
					Log.info("Full Text : " + fullText);
					break;
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			handleException(e);
		}
		return selectBy(locator, fullText);
	}

	/**
	 * @author Pranay :  Method to get the index of an Option from Select
	 *
	 * @param locator    The Locator of Select
	 * @param SelectText The Text to get the index of.
	 * @return 0 if not found. Else the index.
	 */
	public int getIndexOfSelect(By locator, String SelectText) {
		String xpath = getXpath(locator);
		xpath = xpath + "/descendant::option";
		int index = 0;
		List<WebElement> options = driver.findElements(By.xpath(xpath));
		for (WebElement option : options) {
			if (option.getText().contains(SelectText)) {
				index = options.indexOf(option);
				break;
			}
		}
		return (index + 1);
	}

	/**
	 * @author Pranay :  Method to get the selected value from The Drop-down.
	 *
	 * @param locator The locator of drop down from which the selected value should
	 *                be returned.
	 * @return The selected value as String.
	 */
	public String getSelectedValue(By dropdown) {
		String xpath = getXpath(dropdown);
		xpath = xpath + "/descendant::option[@selected='selected']";
		return getTextFromPage(By.xpath(xpath));
	}

	/**
	 * @author Pranay :  Method that can be called to wait until an element is
	 *         available on not available based of parameter 'visibility'.
	 *
	 * @param locator    The visibility of element that needs to be considered for
	 *                   waiting.
	 * @param seconds    Maximum time in seconds, waited for before throwing timeout
	 *                   exception.
	 * @param visibility True : Wait till element is available, False : Wait till
	 *                   element is not available.
	 * @return Returns true, when able to wait for element visibility successfully,
	 *         false if exception is thrown.
	 */
	public Boolean waitFor(By locator,int seconds,Boolean visibility) {
		wait=new FluentWait<WebDriver>(driver)
		.withTimeout(Duration.ofSeconds(seconds))
		.pollingEvery(Duration.ofSeconds(1))
		.ignoring(NoSuchElementException.class);
		try {
			if (visibility) {
				Log.info("Waiting '" + seconds + "' seconds for '" + locator.toString() + "' to appear");
				wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			} else {
				Log.info("Waiting '" +seconds + "' seconds for '" + locator.toString() + "' to disappear");
				wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
			}
		} catch (Exception e) {

		}
		return true;
	}

	/**
	 * @author Pranay :  Method called to wait till an element is clickable.
	 *
	 * @param locator The locator which needs to be considered for waiting.
	 * @param seconds Max time to wait in seconds.
	 * @return Return true, if element is clickable in the given time. Else will
	 *         return false.
	 */
	public Boolean waitForClickable(By locator, int seconds) {

		try {
			Log.info("Waiting '" + seconds + "' seconds for '" + locator.toString() + "' to be clickable");
			wait.until(ExpectedConditions.elementToBeClickable(locator));
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				waitForClickable(locator, seconds);
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be used to wait for passed value of seconds
	 *
	 * @param seconds Seconds that need to be waited for
	 * @return Always return true.
	 */
	public Boolean waitFor(int seconds) {
		try {
			Log.info("Waiting for '" + seconds + "' seconds");
			Thread.sleep(seconds * 1000);
		} catch (Exception e) {

		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be called to get the count of passed Element
	 *         in the WebPage.
	 *
	 * @param locator The element that needs to be counted.
	 * @return Returns 0, if the element is not available, else will return the
	 *         count.
	 */
	public int countOf(By locator) {
		int count = 0;
		try {
			Log.info("Counting the occurence of element '" + locator.toString() + "'");
			count = driver.findElements(locator).size();
			Log.info("Count is : " + count);
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				countOf(locator);
			else
				return 0;
		}
		return count;
	}

	/**
	 * @author Pranay :  Method to check is passed Text is available in page.
	 *
	 * @param Text The Text that needs to be checked for availability.
	 * @return True: If available, False : If not available.
	 */
	public boolean isTextAvailable(String Text) {
		int count = 0;
		By locator = By.xpath("//*[text()[contains(.,'" + Text.trim() + "')]]");
		try {

			Log.info("Checking Availability of text : '" + Text + "'");
			count = driver.findElements(locator).size();
			Log.info("Count is : " + count);
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				countOf(locator);
			else
				return false;
		}
		return (count > 0);
	}

	/**
	 * @author Pranay :  Method that can be called to get the selected value from a
	 *         Drop-down.
	 *
	 * @param locator The locator from which the selected value should be retrieved.
	 * @return Returns the selected option as String. Returns '' if the nothing is
	 *         selected or failed to get the value from the locator.
	 */
	public String getSelectedOption(By locator) {
		String option = "";
		try {
			Log.info("Getting selected value from '" + locator.toString() + "'");
			Select select = new Select(driver.findElement(locator));
			option = select.getFirstSelectedOption().getText();
			Log.info("Selected value is : " + option);
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				getSelectedOption(locator);
			else
				return "";
		}
		return option;
	}

	/**
	 * @author Pranay :  Method called to get text from page based on locator
	 *
	 * @param locator The locator from which the text should be taken.
	 * @return Returns the text
	 */
	public String getTextFromPage(By locator) {
		String text = "";
		try {
			Log.info("Getting text from '" + locator.toString() + "'");
			scrollIntoElement(locator);
			text = driver.findElement(locator).getText();
			Log.info("Text is : " + text);
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				getTextFromPage(locator);
			else
				return "";
		}
		return text;
	}

	/**
	 * @author Pranay :  Method that can be called to switch to another frame in a web
	 *         page.
	 *
	 * @param locator The unique locator of the frame where the driver should switch
	 *                to.
	 * @return returns True, if able to switch else false.
	 */
	public Boolean switchToFrame(By locator) {
		try {
			Log.info("Switching to frame '" + locator.toString() + "'");
			driver.switchTo().frame(driver.findElement(locator));
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				switchToFrame(locator);
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that can be called to switch to newly opened
	 *         Window/Tab.
	 *
	 * @return returns True, if able to switch else false.
	 */
	public Boolean switchToNewWindow() {
		try {
			Log.info("Switching to New Window");
			Set<String> WindowHandles = driver.getWindowHandles();
			String[] Window = WindowHandles.toArray(new String[WindowHandles.size()]);
			driver.switchTo().window(Window[Window.length - 1]);
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				switchToNewWindow();
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method that is called to switch to default frame in the page.
	 *
	 * @return returns True, if able to switch else false.
	 */
	public Boolean switchBacktoMain() {
		try {
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)
				switchBacktoMain();
			else
				return false;
		}
		return true;
	}

	/**
	 * @author Pranay :  Method called to get the xpath from By class object
	 *
	 * @param locator The locator from which xpath needs to be retrieved.
	 * @return The xpath locator as string. Returns "" if nothing found.
	 */
	public String getXpath(By locator) {
		return locator.toString().replace("By.xpath:", "").trim();
	}

	/**
	 * @author Pranay :  Method called to close current tab.
	 */
	public void closeTab() {
		driver.close();
	}

	/**
	 * @author Pranay :  Method called to quit current session.
	 */
	public void quit() {
		driver.quit();
	}

	/**
	 * @author Pranay :  This Method scrolls the Web document by the specified number
	 *         of pixels.
	 *
	 * @param horizontalScrollAmount
	 *
	 *                               How many pixels to scroll by, along the x-axis
	 *                               (horizontal). Positive values will scroll to
	 *                               the right, while negative values will scroll to
	 *                               the left
	 *
	 * @param verticalScrollAmount
	 *
	 *                               How many pixels to scroll by, along the y-axis
	 *                               (vertical). Positive values will scroll down,
	 *                               while negative values scroll up
	 */
	public void scroll(int horizontalScrollAmount, int verticalScrollAmount) {
		try {
			js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(" + horizontalScrollAmount + ", " + verticalScrollAmount + ");");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @author Pranay :  Simple method that can be called to scroll Up
	 */
	public void scrollUp() {
		Log.info("Scrolling up");
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-2000)", "");
	}

	/**
	 * @author Pranay :  Simple method that can be called to scroll Down
	 */
	public void scrollDown() {
		Log.info("Scrolling down");
		js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,2000)", "");
	}

	/**
	 * @author Pranay :  Method to retrieve all elements located by the passed Locator
	 *         as a list.
	 *
	 * @param locator The locator of the elements that need to be returned.
	 * @return All webElements as a list.
	 */
	public List<WebElement> getElements(By locator) {
		return driver.findElements(locator);
	}

	/**
	 * @author Pranay :  Method that is called to process and exception and take
	 *         appropriate action.
	 *
	 * @param e The exception object that is passed, for processing.
	 * @return Returns true, if the step can be retried. Else will return false, can
	 *         can stop execution.
	 */
	private boolean handleException(Exception e) {
		// e.printStackTrace();
		// This code block checks how many times the step is executed. If >
		// retryCount, it will exit stopping execution of step.
		executionCount = executionCount + 1;
		if (executionCount >= retryCount) {
			executionCount = 0;
			Log.info("ERROR : UAVOIDABLE ERROR OCCURED.");
			e.printStackTrace();
			return false;
		}
		// This code block with get the type of exception occurred and Handle
		// it.
		if (e instanceof StaleElementReferenceException) {
			Log.info("WARNING : StaleElementReferenceException occured");
			waitFor(1);
			return true;
		} else if (e instanceof TimeoutException) {
			Log.info("WARNING : TimeoutException occured");
			return false;
		} else if (e instanceof InvalidElementStateException) {
			Log.info("WARNING : InvalidElementStateException occured");
			waitFor(1);
			return true;
		} else if (e instanceof WebDriverException) {
			Log.info("WARNING : WebDriverException occured");
			waitFor(1);
			if (countOf(By.xpath("//input[@value='OK']")) > 0) {
				clickOn(By.xpath("(//input[@value='OK'])[last()]"));
				waitFor(By.xpath("//input[@value='OK']"),2, false);
			}
			return true;
		} else {
			Log.info("ERROR");
			Log.info(e.getMessage());
			e.printStackTrace();
			return false;
		}
	}

//
	// To Check Element is Displayed or No.
	public boolean isElementDisplayed(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			boolean elementDisplayed = element.isDisplayed();
			if (elementDisplayed) {
				Log.info("Element is Displayed");
			} else {

				Log.info("Element is not Displayed");

			}
		} catch (Exception e) {
			retry = handleException(e);
			if (retry)

				isElementDisplayed(locator);
			else
				return false;


		}
		return true;
	}

	// To Check Element is Enabled or No.
	public static void isElementEnabled(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			boolean elementEnabled = element.isEnabled();
			if (elementEnabled) {
				Log.info("Element is Enabled");
			} else {
				Log.info("Element is not Enabled");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//To Validate Drop Down Values.
	public static List<String> dropDownValuesValidation(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			Select select = new Select(element);
			List<WebElement> dropDownValues = select.getOptions();
			List<String> toolsDropDownValues = new ArrayList<String>();
			for (WebElement listOfDropDownValues : dropDownValues) {
				toolsDropDownValues.add(listOfDropDownValues.getText());
			}
			return toolsDropDownValues;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// To Select Radio Button.
	public void selectRadioButton(By locator, String value) {
		try {
			List<WebElement> element = driver.findElements(locator);
			for (WebElement elements : element) {
				if (elements.getText().equalsIgnoreCase(value)) {
					elements.click();
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To Accept Alert Pop-Up.
	public static void acceptAlertPopup() throws InterruptedException {
		try {
			alert = driver.switchTo().alert();
			Log.info(alert.getText());
			Thread.sleep(2000);
			alert.accept();
			Log.info("Alert Accepted Successfully");
		} catch (Exception e) {
			Log.info("Something Went Wrong ==>> Please Check ::: " + e.getMessage());
		}
	}

	// To Dismiss Alert Pop-Up.
	public static void dismissAlertPopup() throws InterruptedException {
		try {
			alert = driver.switchTo().alert();
			Log.info(alert.getText());
			Thread.sleep(2000);
			alert.dismiss();
			Log.info("Alert Dismissed Successfully");
		} catch (Exception e) {
			Log.info("Something Went Wrong ==>> Please Check ::: " + e.getMessage());
		}
	}

	// To Match Value with List of Elements and Click on it.
	public void clickOnMatchingValue(By locator, String valueToBeMatched) {
		try {
			List<WebElement> listOfElements = driver.findElements(locator);
			for (WebElement element : listOfElements) {
				if (element.getText().equalsIgnoreCase(valueToBeMatched)) {
					element.click();
					return;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To Click on Element using Actions Class.
	public void clickOnElementUsingActions(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			actions = new Actions(driver);
			actions.moveToElement(element).click().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To Mouse Hover and Click or Select an Element using Actions Class.
	public void moveToElement(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			actions = new Actions(driver);
			actions.moveToElement(element).build().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To Perform Drag and Drop action using Actions Class - 1.
	public static void dragAndDrop_1(By source, By destination) {
		try {
			WebElement sourceElement = driver.findElement(source);
			WebElement destinationElement = driver.findElement(destination);
			actions = new Actions(driver);
			actions.dragAndDrop(sourceElement, destinationElement).pause(Duration.ofSeconds(2)).release().build()
					.perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To Perform Drag and Drop action using Actions Class - 2.
	public static void dragAndDrop_2(By source, By destination) {
		try {
			WebElement sourceElement = driver.findElement(source);
			WebElement destinationElement = driver.findElement(destination);
			actions = new Actions(driver);
			actions.clickAndHold(sourceElement).pause(Duration.ofSeconds(2)).moveToElement(destinationElement)
					.pause(Duration.ofSeconds(2)).release().build().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To Perform Right Click action using Actions Class.
	public static void rightClick(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			actions = new Actions(driver);
			actions.contextClick(element).build().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// To perform Double Click action using Actions Class.
	public static void doubleClick(By locator) {
		try {
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void scrollIntoElement(By locator) {
		WebElement element = driver.findElement(locator);
		js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void enterKey() {
		actions = new Actions(driver);
		actions.sendKeys(Keys.ENTER).build().perform();
	}

	public void enterTab() {
		actions = new Actions(driver);
		actions.sendKeys(Keys.TAB).build().perform();
	}

	public Boolean enterValueUsingJs(By locator, String value) {
		WebElement webelement = driver.findElement(locator);
		js = (JavascriptExecutor) driver;
		String args = "arguments[0].value=" + "'" + value + "'";
		System.out.println(args);
		try {
			js.executeScript(args, driver.findElement(locator));
		} catch (Exception e) {

			retry = handleException(e);
			if (retry)
				enterValueUsingJs(locator,value);
			else
				return false;

		}
		return true;




	}
}
