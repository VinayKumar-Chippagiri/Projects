package base;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;

public class ExtentManager {
	
	public static ExtentReports extent;
	public static String stringDate = "";
	
	public static ExtentReports getInstance(){
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
		stringDate  = dateFormat.format(new Date());
		
		if(extent==null){
			
			extent = new ExtentReports(System.getProperty("user.dir")+ "\\target\\surefire-reports\\Report_" + stringDate + "\\extent.html",true,DisplayOrder.OLDEST_FIRST);
			extent.loadConfig(new File(System.getProperty("user.dir")+"\\src\\main\\resources\\extentConfig\\ReportsConfig.xml"));
		
		}
		
		return extent;
		
	}
	
	public static String getStringDate() {
		return stringDate;
	}

}
