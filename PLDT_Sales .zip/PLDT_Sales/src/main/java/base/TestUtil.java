package base;

import java.io.File;
import java.io.IOException;

import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class TestUtil extends TestBase {

	public static String screenshotPath;
	public static String screenshotName;
	
	static String reportFolder = ExtentManager.getStringDate(); 
	

	public static void captureScreenshot() throws IOException {
		

		System.out.println("Driver Value" +TestBase.driver);
		File scrFile = ((TakesScreenshot)TestBase.driver).getScreenshotAs(OutputType.FILE);

		Date d = new Date();
		screenshotName = d.toString().replace(":", "_").replace(" ", "_") + ".jpg";

		FileUtils.copyFile(scrFile,
				new File(System.getProperty("user.dir") + "\\target\\surefire-reports\\Report_" + reportFolder + "\\" + screenshotName));
		
	}

	
	
	
	
}
