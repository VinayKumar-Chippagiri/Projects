package base;

public class ProjectBeans {
	
	private static String LeadID = null;
	private static String LeadName = null;
	private static String AccountID = null;
	private static String AccountName= null;
	private static String opportunity_ID = null;
	private static String opportunity_Name = null;
	private static String caseID = null;
	private static String caseName = null;
	private static String caseURL =null;
	
	public static void setCaseID(String caseID) {
		ProjectBeans.caseID = caseID;
	}
	public static String getCaseID() {
		return caseID;
	}
	public static String getCaseName() {
		return caseName;
	}
	public static void setCaseName(String caseName) {
		ProjectBeans.caseName = caseName;
	}
	
	
	public String getLeadID() {
		return LeadID;
	}
	public static void setLeadID(String leadID) {
		LeadID = leadID;
	}
	public static String getLeadName() {
		return LeadName;
	}
	public static void setLeadName(String leadName) {
		LeadName = leadName;
	}
	public static String getAccountID() {
		return AccountID;
	}
	public static void setAccountID(String accountID) {
		AccountID = accountID;
	}
	public static String getAccountName() {
		return AccountName;
	}
	public static void setAccountName(String accountName) {
		AccountName = accountName;
	}
	public static String getOpportunityID() {
		return opportunity_ID;
	}
	public static void setOpportunityID(String opportunityID) {
		opportunity_ID = opportunityID;
	}
	public static String getOpportunityName() {
		return opportunity_Name;
	}
	public static void setOpportunityName(String opportunityName) {
		opportunity_Name = opportunityName;
	}
	public static String getCaseURL() {
		return caseURL;
	}
	public static void setCaseURL(String caseURL) {
		ProjectBeans.caseURL = caseURL;
	}
	
	
}
