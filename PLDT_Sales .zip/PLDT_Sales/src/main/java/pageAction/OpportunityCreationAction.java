package pageAction;

import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;
import junit.framework.Assert;

public class OpportunityCreationAction {
	TestBase tb = new TestBase();
    private By appLauncher = By.xpath("//*[@aria-label=\"App\"]/one-app-launcher-header/button/div");
    private By appSearch = By.xpath("//input[@placeholder=\"Search apps and items...\"]");


    public void clickOnAppLauncher() {


    try {
		tb.clickUsingJs(appLauncher);
		TestBase.test.log(LogStatus.PASS, "Clicked on the App Launcher");
	} catch (Exception e) {
		Assert.fail();
		TestBase.test.log(LogStatus.FAIL, "Clicked on the App Launcher");
	}
    }

    public void enterValueOnAppSearch() {
  try {
	  try {
		  tb.typeDataTo(appSearch, "Opportunities");
		  tb.clickUsingJs(By.xpath("//b[.='Opportunities']"));
		  TestBase.test.log(LogStatus.PASS, "Entered" +"Opportunities"+"in App search");
	  } catch (Exception e) {
		  Assert.fail();
		  TestBase.test.log(LogStatus.FAIL, "Entered" +"Opportunities"+"in App search");
	  }
	  TestBase.test.log(LogStatus.PASS, "Entered Value On AppSearch");
  }
  catch (Exception e)
  {
	  Assert.fail();
	  TestBase.test.log(LogStatus.FAIL, "Entered Value On AppSearch");
  }





    }










	//old code
	public void click_on_new() {
		try {
			System.out.println("Click on New button...");

			tb.click("new_btn_XPATH");
			TestBase.test.log(LogStatus.PASS, "Clicked On New button");
		}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On New button");
		}


	}

	public void click_on_Next() {
		try {
			System.out.println("Click on Next button...");

			tb.click("nextBTN_XPATH");
			TestBase.test.log(LogStatus.PASS, "Clicked On Next button ");
		}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On Next button");
		}


	}

	public void Enter_OpportunityName(String OpportunityName) {
		System.out.println("Enter Opportunity Name...");
		try {
			try {
				tb.type("opportunityName1_XPATH", OpportunityName);
			} catch (NoSuchElementException e) {
				tb.type("opportunityName_XPATH", OpportunityName);
			}
			TestBase.test.log(LogStatus.PASS, "Entered Opportunity Name");
		}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Entered Opportunity Name");
		}


	}

	@SuppressWarnings("static-access")
	public void Enter_AccountName(String AccountName) {
		System.out.println("Select Account Name...");
		try {
			try {
				tb.type("searchAccount1_XPATH", AccountName);
			} catch (NoSuchElementException e1) {
				tb.type("searchAccount_XPATH", AccountName);
			}
			tb.ThreadWait(1000);
			try {
				System.out.println("(//a[text()='"+AccountName+"'])");
				tb.driver.findElement(By.xpath("(//ul//li//*[@title='"+AccountName+"'])")).click();
			} catch (Exception e) {
				System.out.println("Hello Catch Block");
				e.printStackTrace();
			}
			TestBase.test.log(LogStatus.PASS, "Entered Account Name");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Entered Account Name");
		}


	}

	public void EnterContractingParty(String ContractingParty) {
		System.out.println("Enter Contracting Party...");
		try {
			try {
				tb.click("contractingParty1_XPATH");
				tb.ThreadWait(500);
				tb.driver.findElement(By.xpath("//*[@data-value='"+ContractingParty+"']")).click();
			} catch (NoSuchElementException e) {
				tb.click("contractingParty_XPATH");
				tb.click(ContractingParty);
			}
			TestBase.test.log(LogStatus.PASS, "Entered Contracting Party");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Entered Contracting Party");
		}


	}

	public void OpportunintyType(String OpportunintyType) {
		System.out.println("Enter Opportunity Type...");
		try {
			try {
				tb.click("opportunityType1_XPATH");
				tb.ThreadWait(500);
				tb.driver.findElement(By.xpath("//*[@data-value='"+OpportunintyType+"']")).click();
			} catch (NoSuchElementException e) {
				tb.click("opportunityType_XPATH");
				tb.click(OpportunintyType);
			}
			TestBase.test.log(LogStatus.PASS, "Entered Opportuninty Type");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Entered Opportuninty Type");
		}

	}

	public void Enter_CloseDate(String closeDate) {

		System.out.println("Enter Close Date...");
		try {
			try {
				tb.type("closeDate1_XPATH", closeDate);
			} catch (NoSuchElementException e) {
				tb.type("closeDate_XPATH", closeDate);
			}
			TestBase.test.log(LogStatus.PASS, "Entered Close Date");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Entered Close Date");
		}



	}

	public void stage(String stage) {
		System.out.println("Select Stage...");
		try {
			try {
				tb.click("stage1_XPATH");
				tb.ThreadWait(500);
				tb.driver.findElement(By.xpath("//*[@data-value='"+stage+"']")).click();
			} catch (Exception e) {
				tb.click("stage_XPATH");
				tb.click(stage);
			}
			TestBase.test.log(LogStatus.PASS, "Clicked On Stage");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On Stage");
		}


	}

	public void opportunintyCurrency(String opportunintyCurrency) {
		System.out.println("Select Currency...");
		try {
			try {
				tb.scrollElementIntoView("opportunityCurrency1_XPATH");
				tb.click("opportunityCurrency1_XPATH");
				tb.ThreadWait(500);
				tb.driver.findElement(By.xpath("//*[@title='"+opportunintyCurrency+"']")).click();
			} catch (Exception e) {
				tb.click("opportunintyCurrency_XPATH");
				tb.click(opportunintyCurrency);
			}
			TestBase.test.log(LogStatus.PASS, "Selected Opportuninty Currency");}
		catch (Exception e)
		{  Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Selected Opportuninty Currency");

		}


	}

	public void NumberofContractMonth(String NumberofContractMonth) {
		System.out.println("Enter Number of Contracting months...");
		try {
			try {
				tb.type("numberofContractMonth1_XPATH", NumberofContractMonth);
			} catch (Exception e) {
				tb.type("numberofContractMonth_XPATH", NumberofContractMonth);
			}
			TestBase.test.log(LogStatus.PASS, "Entered Number Of Contract months");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Entered Number Of Contract months");
		}

	}

	public void clickonSave() {
		System.out.println("Click on Save button...");
		try {
			tb.click("opportunitySave_XPATH");
			TestBase.test.log(LogStatus.PASS, "Clicked On Save");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On Save");
		}


	}

	public void clickOnCancel() {
		System.out.println("Click on Cancel button...");
		try {
			tb.click("cancelBTN_XPATH");
			TestBase.test.log(LogStatus.PASS, "Clicked On Cancel");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On Cancel");
		}

	}

	public void clickONConfigure() {
		System.out.println("Click on Configure button...");
		try {
			CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "Configure_XPATH");
		
//			tb.clickUsingJs(By.xpath(tb.OR.getProperty("Menue_XPATH")));
//			tb.clickUsingJs(By.xpath(tb.OR.getProperty("Configure_XPATH")));
			TestBase.test.log(LogStatus.PASS, "Clicked On Configure");
			}
		catch (Exception e)
		{
			//Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On Configure");
		}

		//tb.click("Menue_XPATH");
		//tb.click("Configure_XPATH");

	}

	//Amit - ETS Status Verification method


	//Amit - Renaming to Smart Price List
	public void SelectSmartPriceList() {
		System.out.println("Select Price List...");
		try {
//			tb.ExplicitWait("selectPriceList_XPATH");
//
//			tb.click("selectPriceList_XPATH");
//			tb.click("EnterSmartPricePricing_XPATH");

			tb.clickUsingJs(By.xpath(tb.OR.getProperty("selectPriceList_XPATH")));
			tb.clickUsingJs(By.xpath(tb.OR.getProperty("EnterSmartPricePricing_XPATH")));

			tb.ThreadWait(1000);
			TestBase.test.log(LogStatus.PASS, "Selected Smart Price List");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Selected Smart Price List");
		}


	}
	//Amit - Adding PLDT Price List
	public void SelectPLDTPriceList() {
		System.out.println("Select Price List...");
		try {
			tb.click("selectPriceList_XPATH");
			tb.click("EnterEnterprisePHPPricing_XPATH");
			TestBase.test.log(LogStatus.PASS, "Selected PLDT Price List");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Selected PLDT Price List");
		}



	}


	public void searchProduct(String Product) {
		System.out.println("Search product... | " + Product);
		try {
//			tb.element("ProductSearchBox_XPATH").clear();
//			tb.type("ProductSearchBox_XPATH", Product);

			tb.typeDataTo(By.xpath(tb.OR.getProperty("ProductSearchBox_XPATH")), Product);

			TestBase.test.log(LogStatus.PASS, "Product Searched");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Product Searched");
		}

	}

	@SuppressWarnings("static-access")
	public void addToCart(String productName) {
		System.out.println("Add product to cart...");
		try {
			tb.clickUsingJs(By.xpath("//span[text()='"+productName.trim()+"']/parent::*/parent::*/following-sibling::div//button"));

			TestBase.test.log(LogStatus.PASS, "Product added To Cart");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Product added To Cart");
		}
		//		tb.click("AddToCart_XPATH");

	}
	public void IncreaseQuantity(String Quantity) {
		try {
			tb.element("Quantity_XPATH").clear();
			tb.type("Quantity_XPATH", Quantity);
			TestBase.test.log(LogStatus.PASS, "Quantity Increased");}
		catch (Exception e)
		{  Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Quantity Increased");

		}


	}
	public void addAmmount(String ProductAmount) {
		try {
			tb.click("RecurringCharges_XPATH");
			tb.click("EditPriceBtn_XPATH");
			tb.click("AdjustmentDropdown_XPATH");
			tb.click("SelectAmount_XPATH");
			tb.type("EnterAmount_XPATH", ProductAmount);
			tb.click("Apply_XPATH");
			TestBase.test.log(LogStatus.PASS, "Product Ammount added");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Product Ammount added");
		}

	}

	public void ClickOnCreateQuote() {
		System.out.println("Click on Create Quote button...");
		try {
			tb.click("CreateQuotebtn_XPATH");
			TestBase.test.log(LogStatus.PASS, "Clicked On Create Quote");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On Create Quote");
		}


	}

	public void ClickOnCreateOrder() {
		try {
			tb.click("CreateOrderBTN_XPATH");
			TestBase.test.log(LogStatus.PASS, "Clicked On Create Order");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On Create Order");
		}


	}

	public void ClickOnSubmitOrder() {
		try {
			tb.click("Submitorderbtn_XPATH");
			TestBase.test.log(LogStatus.PASS, "Clicked On Submit Order");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On Submit Order");
		}


	}

	public void ProductConfiguration() {
		System.out.println("Click on Production Configuration...");
		try {
			tb.click("ProductConfigurationBtn_XPATH");
			tb.click("ConfigureDevice_XPATH");
			TestBase.test.log(LogStatus.PASS, "Clicked On Product Configuration");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Clicked On Product Configuration");
		}


	}

	public void addCapacity() {
		System.out.println("Select Device Capacity...");
		try {
			tb.select("DeviceCapacity_XPATH", "32 GB");
			TestBase.test.log(LogStatus.PASS, "Capacity Added");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Capacity Added");
		}

	}

	public void ViewRecord() {
		System.out.println("Click on View Record button...");
		try {
			tb.ExplicitWait("ViewRecord_XPATH");
			tb.click("ViewRecord_XPATH");
			TestBase.test.log(LogStatus.PASS, "Clicked On ViewRecord");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "	Clicked On ViewRecord");
		}

	}

	public void addChildproduct(String Childproductname) {
		System.out.println("Add Child Product...");
		try {
			tb.type("SearchChildProduct_XPATH", Childproductname);
			tb.click("AddChildProduct_XPATH");
			TestBase.test.log(LogStatus.PASS, "Added Child Product");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Added Child Product");
		}

	}

	@SuppressWarnings("static-access")
	public void addDeviceToPlan(String deviceName) {
		System.out.println("Add device to plan | " + deviceName);
		try {
			try {
			

				
				tb.retryClick("DeviceArrow_XPATH");
//			tb.scrollIntoElement(By.xpath("//span[text()='Devices']"));

				tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[2]")).sendKeys(deviceName);
				
				System.out.print(deviceName);


				Thread.sleep(3000);
				tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[2]")).sendKeys(Keys
						.BACK_SPACE);
				tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[2]")).sendKeys(
						deviceName.substring(deviceName.length() - 1));


				String selectDev="//div[text()='"+deviceName+"']";
				Thread.sleep(3000);
				
				tb.clickUsingJs(By.xpath(selectDev));
				//tb.driver.findElement(By.xpath(selectDev)).click();

				Thread.sleep(3000);
				tb.element("searchDevice_XPATH").clear();

				Thread.sleep(3000);


			} catch (Exception e) {
				System.out.println("Indide Catch Of : addDeviceToPlan ");
				e.printStackTrace();

			}
			TestBase.test.log(LogStatus.PASS, "Added Device To Plan");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Added Device To Plan");
		}

	}

	//Amit: Add VAS to plan
	@SuppressWarnings("static-access")
	public void addVASToPlan(String vasName) {

		System.out.println("Add VAS to plan | " + vasName);
		try {
			try {
				tb.retryClick("VasArrow_XPATH");

				tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[3]")).sendKeys(vasName);
				System.out.print(vasName);


				//Thread.sleep(1000);
				tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[3]")).sendKeys(Keys
						.BACK_SPACE);
				tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[3]")).sendKeys(
						vasName.substring(vasName.length() - 1));


				String selectvas="//div[text()='"+vasName+"']";
				//Thread.sleep(3000);
				
				tb.clickUsingJs(By.xpath(selectvas));
				//tb.driver.findElement(By.xpath(selectvas)).click();

				//Thread.sleep(3000);
				tb.element("searchDevice_XPATH").clear();

				//Thread.sleep(3000);


			} catch (Exception e) {
				System.out.println("Indide Catch Of : addVASToPlan ");
				e.printStackTrace();

			}
			TestBase.test.log(LogStatus.PASS, "Added VAS To Plan");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Added VAS To Plan");
		}

	}

	//Amit: Add Accessories to plan
	@SuppressWarnings("static-access")
	public void addAccessoriesToPlan(String accessoriesName) {
		System.out.println("Add Accessories to plan | " + accessoriesName);
		try {
			try {
				tb.retryClick("ACCESSORIESArrow_XPATH");

				tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[4]")).sendKeys(accessoriesName);
				System.out.print(accessoriesName);


				//Thread.sleep(1000);
				tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[4]")).sendKeys(Keys
						.BACK_SPACE);
				tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[4]")).sendKeys(
						accessoriesName.substring(accessoriesName.length() - 1));


				String selectDev="//div[text()='"+accessoriesName+"']";
				//Thread.sleep(3000);
				
				tb.clickUsingJs(By.xpath(selectDev));
				//tb.driver.findElement(By.xpath(selectDev)).click();

				//Thread.sleep(3000);
				tb.element("searchDevice_XPATH").clear();

				//Thread.sleep(3000);


			} catch (Exception e) {
				System.out.println("Indide Catch Of : addAccessoriesToPlan ");
				e.printStackTrace();

			}
			TestBase.test.log(LogStatus.PASS, "Added Accessories To Plan");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Added Accessories To Plan");
		}

	}



	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void addAddonsto5GPlans(String Addons) {

		try {
			try {
//				tb.retryClick("AddonsArrow_XPATH");
				tb.clickUsingJs(By.xpath(tb.OR.getProperty("AddonsArrow_XPATH")));

				String[] split = Arrays.stream(Addons.split(",")).map(String::trim).toArray(String[]::new);

				for (String Addon : split) {

					/*
					 * ArrayList aList= new ArrayList(Arrays.asList((Addons.split(","))));
					 *
					 * System.out.println(aList.size());
					 *
					 * for(int i=0;i<=aList.size();i++) {
					 *
					 * Addon=(String) aList.get(i);
					 */

					System.out.println("Add Addons to 5G Plan | " +Addon );

					tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).sendKeys(Addon);
					Thread.sleep(1000);
					/*
					 * tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).
					 * sendKeys(Keys .BACK_SPACE);
					 * tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).
					 * sendKeys( Addon.substring(Addon.length() - 1));
					 */


					String selectAddon="//div[text()='"+Addon+"']";
					//Thread.sleep(3000);
					
					tb.clickUsingJs(By.xpath(selectAddon));
					tb.clickDropdownValue(selectAddon);
					//tb.driver.findElement(By.xpath(selectAddon)).click();

					//Thread.sleep(3000);
					tb.driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).clear();

					//Thread.sleep(3000);
				}


			} catch (Exception e) {
				System.out.println("Indide Catch Of : addAddonsToPlan ");
				e.printStackTrace();

			}
			TestBase.test.log(LogStatus.PASS, "Added Addons to 5G Plans");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Added Addons to 5G Plans");
		}



	}

	public void DiscountOn5GPlan(String DicountedPrice) {
		try {
			tb.click("RecurringCharges2_XPATH");
			changePrice(DicountedPrice);
			TestBase.test.log(LogStatus.PASS, "Performed Discount On 5G Plan");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Discount On 5G Plan");
		}



	}

	public void changePrice(String DicountedPrice) {
		try {
			tb.click("ChangePrice_XPATH");
			tb.click("SelectOptionforDiscount_XPATH");
			tb.click("OverridePrice_XPATH");

			tb.type("InputDiscountedPrice_XPATH",DicountedPrice );
			tb.click("ApplyDiscount_XPATH");
			TestBase.test.log(LogStatus.PASS, "Price is Changed");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Price is Changed");
		}



	}

	public void deletePlan() {
		System.out.println("Delete the plan...");
		try {
			try {

				tb.click("ProductConfigurationBtn_XPATH");
				tb.click("deletePlan_XPATH");
				tb.click("ConfirmDelete_XPATH");

				Thread.sleep(3000);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			TestBase.test.log(LogStatus.PASS, "Plan is Deleted");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Plan is Deleted");
		}


	}


	public void selectPriceList() {
		System.out.println("Select Price List...");
		try {
			tb.click("selectPriceList_XPATH");
			tb.click("EnterPricePricing_XPATH");
			TestBase.test.log(LogStatus.PASS, "Selected Price List");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Selected Price List");
		}


	}

	@SuppressWarnings("static-access")
	public void deviceConfiguration() {
		System.out.println("Configure device...");
		try {
			tb.click("ConfigureDeviceDropDown_XPATH");

			/*
			 * try { for (int i = 7; i <= 9; i++) {
			 */
			System.out.println("iteration: " + 7);
			tb.driver.findElement(By.xpath("((//span[@class='slds-truncate cpq-action-item-label' and text()[contains(.,'Configure')]])[2])")).click();

			// tb.click("ConfigureDevicePlan2_XPATH");
			TestBase.test.log(LogStatus.PASS, "Performed Device Configuration");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Device Configuration");
		}

		/*
		 * } catch (Exception ne) { // tb.click("ConfigureDevicePlan_XPATH"); }
		 */

	}

	public void deviceConfiguration2() {
		System.out.println("Configure device...");
		try {
			tb.click("ConfigureDeviceDropDown2_XPATH");

			/*
			 * try { for (int i = 7; i <= 9; i++) {
			 */
			System.out.println("iteration: " + 7);
			tb.driver.findElement(By.xpath("((//span[@class='slds-truncate cpq-action-item-label' and text()[contains(.,'Configure')]])[3])")).click();

			// tb.click("ConfigureDevicePlan2_XPATH");
			TestBase.test.log(LogStatus.PASS, "Performed Device Configuration2");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Device Configuration2");
		}

		/*
		 * } catch (Exception ne) { // tb.click("ConfigureDevicePlan_XPATH"); }
		 */

	}


	@SuppressWarnings("static-access")
	public void configureDevice() {
		System.out.println("Configure device...");
		try {
			tb.click("ProductConfigurationBtn_XPATH");
			tb.driver.findElement(By.xpath("(//span[@class=\"slds-truncate cpq-action-item-label\"])[8]")).click();
			TestBase.test.log(LogStatus.PASS, "Performed Configure Device");}
		catch (Exception e)
		{  Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Configure Device");

		}


	}

	public void selectDevicePaymentType(String paymentType) {
		System.out.println("Select Payment type | " + paymentType);
		try {
			try {
				tb.select("DevicePaymentType2_XPATH", paymentType);
			} catch (Exception e) {
				tb.select("DevicePaymentType_XPATH", paymentType);
			}
			TestBase.test.log(LogStatus.PASS, "Selected Device Payment Type");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Selected Device Payment Type");
		}


	}

	public void selectDeviceCapacity(String capacity) {
		System.out.println("Select Device Capacity | " + capacity);
		try {
			try {
				tb.select("DeviceCapacity2_XPATH", capacity);
			} catch (Exception e) {
				tb.select("DeviceCapacity_XPATH", capacity);
			}
			TestBase.test.log(LogStatus.PASS, "Selected Device Capacity");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Selected Device Capacity");
		}


	}

	public void selectColor(String color) {
		System.out.println("Select device color | " + color);
		try {
			try {
				tb.select("DeviceColor2_XPATH", color);
			} catch (Exception e) {
				tb.select("DeviceColor_XPATH", color);
			}
			TestBase.test.log(LogStatus.PASS, "Selected Color");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Selected Color");
		}


	}

	public void mobileInternet(String paymentType) {
		try {
			tb.select("Device_XPATH", paymentType);
			TestBase.test.log(LogStatus.PASS, "Selected Mobile Internet");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Selected Mobile Internet");
		}


	}

	public String getDeviceRecurringCharges() {
		System.out.println("Get Device Recurring Charges...");
		try {

			TestBase.test.log(LogStatus.PASS, "Performed Action on Device Recurring Charges");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Action on Device Recurring Charges");
		}
		return tb.element("DeviceRecurringChareges_XPATH").getText();

	}

	public String getDeviceRecurringCharges(String product) {
		System.out.println("Get Device Recurring Charges...");
		String amount = "";
		try {


			if (product.contentEquals("plan")) {
				amount = tb.element("DeviceRecurringChareges_XPATH").getText();
			} else {
				amount = tb.element("devicePricingRecurringCharge_XPATH").getText();
			}


			TestBase.test.log(LogStatus.PASS, "Performed Action on Device Recurring Charges of Product");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Action on Device Recurring Charges of Product");
		}

		return amount;
	}

	public String getDeviceOneTimeCharges() {
		System.out.println("Get One-time Charges...");
		try {

			TestBase.test.log(LogStatus.PASS, "Performed Action on Device OneTime Charges");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Action on Device OneTime Charges");
		}

		return tb.element("DeviceOneTimeCharges_XPATH").getText();
	}

	public String getDeviceOneTimeCharges(String product) {
		System.out.println("Get One-time Charges...");
		String amount = "";
		try {
			if (product.contentEquals("plan")) {
				amount = tb.element("DeviceOneTimeCharges_XPATH").getText();
			} else {
				amount = tb.element("devicePricingOneTimeCharge_XPATH").getText();
			}


			TestBase.test.log(LogStatus.PASS, "Performed Action on Device One Time Charges");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Action on Device One Time Charges");
		}


		return amount;

	}

	public String getPlanRecurringCharges() {
		try {

			TestBase.test.log(LogStatus.PASS, "Performed Plan Recurring Charges");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Plan Recurring Charges");
		}

		return tb.element("RecurringCharges2_XPATH").getText();
	}

	public String getPlanOneTimetotalCharges() {
		try {

			TestBase.test.log(LogStatus.PASS, "Performed Plan One Time total Charges");}
		catch (Exception e)
		{  Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Plan One Time total Charges");

		}
		return tb.element("PlanOneTimeTotal_XPATH").getText();

	}

	public String getDeviceRecurringTotalCharges() {
		try {

			TestBase.test.log(LogStatus.PASS, "Performed Device Recurring Total Charges");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Device Recurring Total Charges");
		}
		return tb.element("DeviceRecurringTotal_XPATH").getText();

	}

	public String getDeviceOneTimeTotalCharges() {
		try {

			TestBase.test.log(LogStatus.PASS, "Performed Device OneTime Total Charges");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Device OneTime Total Charges");
		}
		return tb.element("DeviceOneTimeTotal_XPATH").getText();

	}

	public void ChangestatustoEstablishNeed() {
		try {
			CommonSteps.ChangeStatus("EstablishNeedStage_XPATH", "MarkStatus_XPATH");
			tb.ExplicitWait("MarkAsComplete_XPATH");

			System.out.println("Changed Status to Establish Need...");
			TestBase.test.log(LogStatus.PASS, "Status Changed to EstablishNeed");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Status Changed to EstablishNeed");
		}


	}

	public void ChangestatustoQualification() {
		System.out.println("Change Status to Qualification...");
		try {
			CommonSteps.ChangeStatus("QualificationStage_XPATH", "MarkStatus_XPATH");
			TestBase.test.log(LogStatus.PASS, " Status Changed to Qualification");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, " Status Changed to Qualification");
		}


	}

	public void addVanityNumberFeeToCart() {
		System.out.println("Add Vanity Number Fee to cart...");
		try {
			tb.click("vanityNoFeeAddToCartButton_XPATH");
			TestBase.test.log(LogStatus.PASS, "Added VanityNumberFee To Cart");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Added VanityNumberFee To Cart");
		}

	}

	public void selectNumberType(String type) {
		System.out.println("Select Vanity number type | " + type);
		try {
			tb.select("vanityNumberTypePicklist_XPATH", type);
			TestBase.test.log(LogStatus.PASS, "Selected Number Type");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Selected Number Type");
		}

	}

	@SuppressWarnings("static-access")
	public void vanityNumberFeeConfiguration() {

		System.out.println("Configure vanity number fee...");
		try {
			tb.click("vanityNoFeeShowActionsButton_XPATH");

			try {
				for (int i = 7; i <= 9; i=i+2) {
					System.out.println("iteration: " + i);
					tb.clickUsingJs(By.xpath("(//span[@class=\\\"slds-truncate cpq-action-item-label\\\"])[\"	+ i + \"]\")"));
					//tb.driver.findElement(By.xpath("(//span[@class=\"slds-truncate cpq-action-item-label\"])["	+ i + "]")).click();
				}
			} catch (Exception ne) {
			}
			TestBase.test.log(LogStatus.PASS, "Performed vanityNumber Fee Configuration");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed vanityNumber Fee Configuration");
		}


	}
	


	public String getVanityOneTimeCharges() {
		System.out.println("Get Vanity One-time Charges...");
		try {

			TestBase.test.log(LogStatus.PASS, "Performed Vanity OneTimeCharges");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Performed Vanity OneTimeCharges");
		}
		return tb.element("vanityNoFeeOnetimeCharge_XPATH").getText();

	}


	public void AddChildDevice (String deviceName, String paymentType, String capacity, String color  ) {
		try {
			try {
				//Thread.sleep(3000);
				
				addDeviceToPlan(deviceName);
				//tb.ExplicitWait("ConfigureDeviceDropDown_XPATH");
				deviceConfiguration(); }
			catch (Exception e2)
			{

			}
			try {

				if(!paymentType.isEmpty())
					selectDevicePaymentType(paymentType);

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {

				if(!capacity.isEmpty())
					selectDeviceCapacity(capacity);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			tb.ThreadWait(2000);
			
			try {

				if(!color.isEmpty())
					selectColor(color);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			tb.waitElementtoBecomeInvisble("AttributeValidation_XPATH");
			tb.ThreadWait(2000);
			tb.click("CloseButton_XPATH");
			TestBase.test.log(LogStatus.PASS, "Added Child Device");}
		catch (Exception e)
		{
			e.printStackTrace();
//			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Added Child Device");
		}




	}

	public void AddChildDevice2 (String deviceName, String paymentType, String capacity, String color  ) {
		try {
			try {
//				tb.driver.switchTo().frame(2);
				//Thread.sleep(3000);
//				tb.scrollIntoElement(By.xpath("//span[@title='Select an Option']"));
				tb.click("DeviceArrow_XPATH");
			addDeviceToPlan(deviceName);
			

			
				//tb.ExplicitWait("ConfigureDeviceDropDown2_XPATH");
				deviceConfiguration2(); 
				}
			catch (Exception e2)
			{

			}
			try {

				if(!paymentType.isEmpty())
					selectDevicePaymentType(paymentType);

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {

				if(!capacity.isEmpty())
					selectDeviceCapacity(capacity);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {

				if(!color.isEmpty())
					selectColor(color);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			tb.waitElementtoBecomeInvisble("AttributeValidation_XPATH");
		//	tb.ThreadWait(2000);
			tb.click("CloseButton_XPATH");
			TestBase.test.log(LogStatus.PASS, "Added Child Device2");}
		catch (Exception e)
		{
			e.printStackTrace();
		//	Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Added Child Device2");
		}




	}


	public String ETSSolutionDesignNeeded(String result)
	{ try {
		String actual_Result = tb.getDropdownText("ETSSolutionDesignNeeded_XPATH");
		if(actual_Result.equalsIgnoreCase(result))
		{
			tb.test.log(LogStatus.PASS, "Expected value: "+result +" and Actual value: "+actual_Result+ "are same");
		}else
			tb.test.log(LogStatus.FAIL, "Expected value: "+result +" but Actual value: "+actual_Result);
		TestBase.test.log(LogStatus.PASS, "Performed Action on ETS Solution Design Needed");}
	catch (Exception e)
	{
		Assert.fail();
		TestBase.test.log(LogStatus.FAIL, "Performed Action on ETS Solution Design Needed");
	}

		return null;
	}

	public void contractTerm(String month)
	{ try {
		tb.select("ContractTerm_XPATH", month);
		TestBase.test.log(LogStatus.PASS, "Selected Contract Term");}
	catch (Exception e)
	{
		Assert.fail();
		TestBase.test.log(LogStatus.FAIL, "Selected Contract Term");
	}

	}

	public void speed(String speed)
	{ try {
		tb.select("Speed_XPATH", speed);
		TestBase.test.log(LogStatus.PASS, "Selected Speed");}
	catch (Exception e)
	{
		Assert.fail();
		TestBase.test.log(LogStatus.FAIL, "Selected Speed");
	}

	}

	public void paymentMethod(String paymentMethod)
	{ try {
		tb.select("PaymentMethod_XPATH", paymentMethod);
		TestBase.test.log(LogStatus.PASS, "Selected Payment Method");}
	catch (Exception e)
	{
		Assert.fail();
		TestBase.test.log(LogStatus.FAIL, "Selected Payment Method");
	}

	}

	public void planName(String planName)
	{ try {
		tb.select("PlanName_XPATH", planName);
		TestBase.test.log(LogStatus.PASS, "Selected Plan Name");}
	catch (Exception e)
	{
		Assert.fail();
		TestBase.test.log(LogStatus.FAIL, "Selected Plan Name");
	}

	}

	public void paymentFrequency(String paymentFrequency)
	{ try {
		tb.select("PaymentFrequency_XPATH", paymentFrequency);
		TestBase.test.log(LogStatus.PASS, "Selected Payment Frequency");}
	catch (Exception e)
	{
		Assert.fail();
		TestBase.test.log(LogStatus.FAIL, "Selected Payment Frequency");
	}

	}

	public void Enter_PriceBook(String PriceBook) {

		System.out.println("Search PriceBook: "+ PriceBook);
		try {
			tb.type("PriceBook_XPATH", PriceBook);
			//tb.ThreadWait(2000);

			try {
				tb.driver.findElement(By.xpath("(//div[@title='"+PriceBook+"'])")).click();
			} catch (Exception e) {
				e.printStackTrace();
			}
			TestBase.test.log(LogStatus.PASS, "Entered Price of Book");}
		catch (Exception e)
		{
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Entered Price of Book");
		}


	}
}