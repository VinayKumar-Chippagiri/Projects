package pageAction;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import base.TestBase;

public class LeadCreationAction2 extends TestBase{
    public TestBase tb;
    private By appLauncher = By.xpath("//*[@aria-label=\"App\"]/one-app-launcher-header/button/div");
    private By appSearch = By.xpath("//input[@placeholder=\"Search apps and items...\"]");
    private By newLeadButton = By.xpath("//div[@title=\"New\"]");
    private By newLeadRecordType = By.xpath("//span[.='Business']");

    // New Lead: Lead Information Section
    private By leadSalutation = By.xpath("//input[@name=\"salutation\"]");
    private By leadFirstName = By.xpath("//input[@placeholder='First Name']");
    private By leadMidName = By.xpath("//input[@placeholder='Middle Name']");
    private By leadLastName = By.xpath("//input[@placeholder='Last Name']");
    private By leadSuffix = By.xpath("//input[@placeholder='Suffix']");
    private By leadTitle = By.xpath("//input[@name=\"Title\"]");
    private By leadRole = By.xpath("//label[text()='Lead Role']//parent::lightning-combobox//input");
    private By leadStatus= By.xpath("//label[text()='Lead Status']//parent::lightning-combobox//input");
    private By notQualifiedReason = By.xpath("//*[text()='Not Qualified Reason']//following::div[3]");
    private By leadSource = By.xpath("//label[text()='Lead Source']//parent::lightning-combobox//input");
    private By productInterest = By.xpath("//label[text()='Product Interest']//parent::lightning-combobox//input");
    private By other = By.xpath("//input[@name=\"Other__c\"]");
    private By description = By.xpath("//label[text()='Description']//parent::lightning-textarea //div/textarea");
    private By leadType = By.xpath("//label[text()=\"Lead Type\"]//parent::lightning-combobox//div/lightning-base-combobox/div/div/input");
    private By leadProductOfInterest = By.xpath("//label[text()=\"Lead Product of Interest\"]//parent::lightning-textarea/div/textarea");
    private By rtsReason = By.xpath("//label[text()=\"RTS Reasons\"]//parent::lightning-combobox/div/lightning-base-combobox/div/div/input");
    private By rfsDate = By.xpath("//input[@name='RFS_Date__c']");
    private By callBackDate = By.xpath("//input[@name=\"Call_Back_Date__c\"]");
    private By annualRevenue = By.xpath("//input[@name=\"AnnualRevenue\"]");
    private By minForPortIn = By.xpath("//input[@name=\"MNP_MIN_for_Port_In__c\"]");
    private By currentProvider = By.xpath("//label[text()='Current Provider']//parent::lightning-combobox//input");
    private By offerPackage = By.xpath("//*[text()='Offer package']//following::div[3]/input");

    // New Lead: Personal Information Section
    private By phone = By.xpath("//input[@name=\"Phone\"]");
    private By mobile = By.xpath("//input[@name=\"MobilePhone\"]");
    private By birthDate = By.xpath("//input[@name=\"Birthdate__c\"]");
    private By email = By.xpath("//input[@name=\"Email\"]");
    private By creditCheck = By.xpath("//input[@name=\"Credit_Check__c\"]");

    //New Lead: Address section
    private By searchAddress = By.xpath("//input[@placeholder=\"Search Address\"]");
    private By country = By.xpath("//input[@name='country']");
    private By Street = By.xpath("//textarea[@name='street']");
    private By city = By.xpath("//input[@name='city']");
    private By stateProvince = By.xpath("//input[@name='province']");
    private By zipPostalCode = By.xpath("//input[@name='postalCode']");

    //New Lead: Company Information section
    private By company = By.xpath("//input[@name='Company']");
    private By companyTIN = By.xpath("//input[@name='Company_TIN__c']");
    private By companyTradeName = By.xpath("//input[@name='Company_Trade_Name__c']");
    private By industry = By.xpath("//*[text()='Industry']//following::div[3]/input");
    private By companySize = By.xpath("//*[text()='Company Size']//following::div[3]/input");
    private By subIndustry = By.xpath("//*[text()='Sub-Industry']//following::div[3]/input");
    private By businessType = By.xpath("//*[text()='Business Type']//following::div[3]/input");
    private By businessRegistrationType = By.xpath("//*[text()='Business Registration Type']//following::div[3]/input");
    private By businessRegistrationNumber = By.xpath("//input[@name='Business_Registration_Number__c']");
    private By otherBusinessRegistrationType = By.xpath("//input[@name='Other_Business_Registration_Type__c']");
    private By website = By.xpath("//input[@name=\"Website\"]");
    private By deadlineOfSubmission = By.name("Deadline_of_Submission__c");

    //New Lead: Additional Information section
    private By lineOfBusiness = By.xpath("//*[text()='LOB(Line of Business)']//following::div[3]/input");
    private By accountClass = By.xpath("//*[text()='Account Class']//following::div[3]/input");
    private By eventTradeShowReferralName = By.xpath("//input[@name='Event_Trade_Show_Referral_Name__c']");

    //New Lead: Consent Management section
    private By salesforceEmailOptOut = By.name("SalesforceEmailOptOut__c");
    private By pardotEmailOptOut = By.name("HasOptedOutOfEmail");
    private By doNotCall = By.name("DoNotCall");
    private By leadGenPrivacyNoticeConsent = By.name("Lead_Gen_Privacy_Notice_Consent__c");
    private By salesEngagementConsent= By.name("Sales_Engagement_Consent__c");

    //New Lead: Marketing Consent Management section
    private By marketingConsent = By.name("Marketing_Consent__c");
    private By eventsConsent = By.name("Events_Consent__c");

    //New Lead: Fotter Section
    private By assignUsingActiveAssignmentRule = By.xpath("//span[text()='Assign using active assignment rule']/../span");
    private By cancelButton = By.xpath("//button[@name='CancelEdit']");
    private By save_New = By.xpath("//button[@name='SaveAndNew']");
    private By save = By.xpath("//button[@name='SaveEdit']");


    public LeadCreationAction2() {
        tb = new TestBase();
        }
        public void clickOnAppLauncher() {
        tb.clickOn(appLauncher);
        }

        public void EnterValueOnAppSearch() {
        tb.typeDataTo(appSearch, "Leads");
        tb.enterKey();
        }

        public void ClickOnNewLeadButton() {
        tb.clickOn(newLeadButton);
        }

        public void SelectNewLeadType(int index) {
        tb.clickOn(newLeadRecordType);
        }

        public void SelectLeadSalutation(String Salutation) {
        tb.selectBy(leadSalutation, Salutation);
        }

        public void EnterFirstName(String FirstName) {
        tb.enterData(leadFirstName, FirstName);
        }

        public void EnterLeadMidName(String MidName) {
        tb.enterData(leadMidName, MidName);
        }

        public void EnterLeadLastName(String LastName) {
        tb.enterData(leadLastName, LastName);
        }

        public void EnterLeadSuffix(String Suffix) {
        tb.enterData(leadSuffix, Suffix);
        }

        public void EnterLeadTitle(String title) {
        tb.enterData(leadTitle, title);
        }

        public void SelectLeadRole(String role) {
        tb.selectByValue(leadRole, role);
        }

        public void SelectLeadStatus(String status) {
        tb.selectByValue(leadStatus, status);
        }

        public void SelectNotQualifiedReason(String notQualifyReason) {
        tb.selectByValue(notQualifiedReason, notQualifyReason);
        }

        public void SelectleadSource(String leadSrc) {
        tb.selectByValue(leadSource, leadSrc);
        }

        public void EnterAnnualRevenue(String AnnualRevenue) {
        tb.enterData(annualRevenue, AnnualRevenue);
        }

        public void SelectProductInterest(String prdInterest) {
        tb.selectByValue(productInterest, prdInterest);
        }

        public void EnterLeadProductOfInterest(String leadprdInterest) {
        tb.enterData(leadProductOfInterest, leadprdInterest);
        }

        public void EnterOther(String otherText) {
        tb.enterData(other, otherText);
        }

        public void EnterDescription(String desc) {
        tb.enterData(description, desc);
        }

        public void SelectLeadType(String ledType) {
        tb.selectByValue(leadType, ledType);
        }

        public void SelectRTSReasons(String reasonsRTS) {
        tb.selectByValue(rtsReason, reasonsRTS);
        }

        public void EnterMINforPortIn(String MIN) {
        tb.enterData(minForPortIn, MIN);
        }

        public void SelectCurrentProvider(String curtprovider) {
        tb.selectByValue(currentProvider, curtprovider);
        }

        public void SelectOfferPackage(String offpackage) {
        tb.selectByValue(offerPackage, offpackage);
        }

        public void EnterPhoneNumber(String PhoneNum) {
        tb.enterData(phone, PhoneNum);
        }

        public void EnterMobileNumber(String mobileNum) {
        tb.enterData(mobile, mobileNum);
        }

        public void EnterEmail(String mail) {
        tb.enterData(email, mail);
        }

        public void EnterBirthday() {

        }

        public void SelectCreditCheck() {
        tb.clickOn(creditCheck);
        }


        public void fillTheLeadForm

        (String salutationValue,String firstNameValue,String middleNameValue,String lastNameValue,String suffixValue,String
        		titleValue,String leadRoleValue,String leadStatusValue,String notQualifiedReasonValue,String leadSourceValue,
        		String otherValue,String descriptionValue,String leadTypeValue,String annualRevenueValue,
        		String productInterestValue,String leadProductOfInterestValue,String rfsDateValue,
        		String rtsReasonsValue,String callBackDateValue,String minForPortInValue,
        		String currentProviderValue,String offerPackageValue,String phoneValue,String mobileValue,String birthdateValue,
        		String emailValue,String addressValue,String countryValue,String streetValue,String cityValue,String stateValue,
        		String zipCodeValue,String companyValue,String companyTradeNameValue,String companySizeValue,String businessTypeValue,
        		String businessRegistrationTypeValue,String companyTinValue,String industryValue,String subindustryValue,
        		String businessRegistrationNumberValue,String otherBusinessRegistrationTypeValue,String websiteValue,
        		String deadlineOfSubmissionValue,String lobValue,String eventValue,String accountClassValue) {


        	tb.clickUsingJs(leadSalutation);
       	    tb.jsClink_LinkText(salutationValue);
//        	tb.enterValueUsingJs(leadFirstName ,firstNameValue);
//        	tb.enterValueUsingJs(leadMidName ,middleNameValue);
//        	tb.enterValueUsingJs(leadLastName ,lastNameValue);
//        	tb.enterValueUsingJs(leadSuffix ,suffixValue);
//        	tb.enterValueUsingJs(leadTitle ,titleValue);
//        	tb.enterValueUsingJs(leadRole ,leadRoleValue);
//        	tb.enterValueUsingJs(leadStatus,leadStatusValue);
//        	tb.enterValueUsingJs(notQualifiedReason ,notQualifiedReasonValue);
//        	tb.enterValueUsingJs(leadSource ,leadSourceValue);

//        	tb.selectFromList(productInterest, productInterestValue);
        	tb.clickUsingJs(productInterest);
       	    tb.jsClink_LinkText(productInterestValue);
//        	tb.enterValueUsingJs(productInterest ,productInterestValue);
//        	tb.enterValueUsingJs(other ,otherValue);
//        	tb.enterValueUsingJs(description ,descriptionValue);
//        	tb.enterValueUsingJs(leadType ,leadTypeValue);
//        	tb.enterValueUsingJs(leadProductOfInterest ,leadProductOfInterestValue);
//        	tb.enterValueUsingJs(rtsReason ,rtsReasonsValue);
//            tb.enterValueUsingJs(rfsDate ,rfsDateValue);
//        	tb.enterValueUsingJs(callBackDate ,callBackDateValue);
//        	tb.enterValueUsingJs(annualRevenue ,annualRevenueValue);
//        	tb.enterValueUsingJs(minForPortIn ,minForPortInValue);
//        	tb.enterValueUsingJs(currentProvider ,currentProviderValue);
//        	tb.enterValueUsingJs(offerPackage ,offerPackageValue);
//            tb.enterValueUsingJs(phone,phoneValue);
//            tb.enterValueUsingJs(mobile,mobileValue);
//            tb.enterValueUsingJs(email,emailValue);
//            tb.enterValueUsingJs(searchAddress,addressValue);
//            tb.enterValueUsingJs(country,countryValue);
//            tb.enterValueUsingJs(Street,streetValue);
//            tb.enterValueUsingJs(city,cityValue);
//            tb.clickOn(stateProvince);
//            tb.enterValueUsingJs(stateProvince,stateValue);
//            tb.enterValueUsingJs(zipPostalCode,zipCodeValue);
//
//            tb.enterValueUsingJs(company,companyValue);
//            tb.enterValueUsingJs(companyTradeName,companyTradeNameValue);
//            tb.enterValueUsingJs(companySize,companySizeValue);
//            tb.enterValueUsingJs(businessType,businessTypeValue);
//            tb.enterValueUsingJs(businessRegistrationType,businessRegistrationTypeValue);
//            tb.enterValueUsingJs(companyTIN,companyTinValue);
//            tb.enterValueUsingJs(industry,industryValue);
//            tb.enterValueUsingJs(subIndustry,subindustryValue);
//            tb.enterValueUsingJs(businessRegistrationNumber,businessRegistrationNumberValue);
//            tb.enterValueUsingJs(otherBusinessRegistrationType,otherBusinessRegistrationTypeValue);
//            tb.enterValueUsingJs(website,websiteValue);
//            tb.enterValueUsingJs(lineOfBusiness,lobValue);
//            tb.enterValueUsingJs(eventTradeShowReferralName,eventValue);
//            tb.enterValueUsingJs(accountClass,accountClassValue);
//            tb.clickOn(save);

try {
	Thread.sleep(240000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}





        }





































    //old code



    public void click_on_NewBtn() {

        tb.click("new_btn_XPATH");

        // Assert.assertTrue(tb.isElementPresent(By.xpath(tb.OR.getProperty("new_lead_XPATH"))),"Create
        // New Lead");

    }

    public void select_salutation(String salutation) {

        tb.click("name_salutation_XPATH");
        tb.click(salutation);

    }

    public void firstName(String firstName) {

        tb.type("firstName_XPATH", firstName);

    }

    public void midNmae(String midNAme) {

        tb.type("midNmae_XPATH", midNAme);

    }

    public void lastName(String lastName) {

        tb.type("lastName_XPATH", lastName);
        tb.click("title_XPATH");

    }

    public void suffix(String suffix) {

        tb.type("suffix_XPATH", suffix);

    }

    public void titleandRole() {

        tb.type("title_XPATH", "Dont Know");
        tb.ThreadWait(1000);
        tb.retryClick("LeadRole_XPATH");
        tb.ThreadWait(1000);
        tb.jsClink_LinkText("Authorized Signatory");


    }

    public void leadStatus(String leadStatus) {

        tb.click("leadStatus_XPATH");
        tb.jsClink_LinkText(leadStatus);

    }

    public void leadCurrency(String leadCurrency) {

        tb.click("leadCurrency_XPATH");
        tb.jsClink_LinkText(leadCurrency);

    }

    public void RTS(String RTS) {

        tb.click("RTS_XPATH");
        tb.jsClink_LinkText(RTS);

    }

    public void stageDate(String date) {
        String stageDate = date.toString().trim();
        tb.type("stageDate_XPATH", stageDate);

    }

    public void stageTime(String time) {
        String stageTime = time.toString().trim();
        tb.type("stageTime_XPATH", stageTime);
    }

    public void rfsDate(String date) {
        String rfsDate = date.toString().trim();
        tb.type("RFS_XPATH", rfsDate);

    }

    public void callBackDate(String date) {
        String callBackDate = date.toString().trim();
        tb.type("callBcak_XPATH", callBackDate);
    }

    public void partnerAccount(String partnerAccount) {

        tb.type("partnerAccount_XPATH", partnerAccount);
    }

    public void notQualifiedReason(String notQualifiedReason) {

        tb.click("notQualifiedReason_XPATH");
        tb.click(notQualifiedReason);

    }

    public void leadSource(String leadSource) {

        tb.jsClick("leadSource_XPATH");
        tb.jsClink_LinkText(leadSource);

    }

    public void productInterest(String productInterest) {

        tb.click("productInterest_XPATH");
        tb.jsClink_LinkText(productInterest);
    }

    public void other(String other) {

        tb.type("other_XPATH", other);

    }

    public void phone(String phone) {

        tb.type("phone_XPATH", phone);

    }

    public void agentCode(String agentCode) {

        tb.type("agentCode_XPATH", agentCode);
    }

    public void mobile(String mobile) {

        tb.type("mobile_XPATH", mobile);

    }

    public void email(String email) {

        tb.type("email_XPATH", email);

    }

    public void emailOptOut() {

        tb.click("emailOptOut_XPATH");

    }

    public void birthDate(String date) {
        String birthDate = date.toString().trim();

        tb.type("birthday_XPATH", birthDate);
    }

    public void website(String website) {

        tb.type("website_XPATH", website);

    }

    public void address(String address) {

        tb.click("address_XPATH");
        tb.type("enterAddress_XPATH", address);

    }

    public void street(String street) {

        tb.type("street_XPATH", street);

    }

    public void city(String city) {

        tb.type("city_XPATH", city);
    }

    public void state(String state) {

        tb.type("state_XPATH", state);

    }

    public void postal(String postal) {

        tb.type("postal_XPATH", postal);

    }

    public void country(String country) {

        tb.type("contey_XPATH", country);

    }

    public void company(String company) {

        tb.type("company_XPATH", company);

    }

    public void companyTin(String companyTin) {

        tb.type("companyTin_XPATH", companyTin);

    }

    public void companySize(String companySize) {

        tb.click("companySize_XPATH");
        tb.click(companySize);

    }

    public void industry(String industry) {

        tb.click("industry_XPATH");
        tb.click(industry);
    }

    public void subIndustry(String subIndustry) {

        tb.click("subindustry_XPATH");
        tb.click(subIndustry);
    }

    public void businessType(String businessType) {

        tb.click("business_XPATH");
        tb.click(businessType);

    }

    public void businessRigsType(String businessRigsType) {

        tb.click("businessRigsType_XPATH");
        tb.click(businessRigsType);

    }

    public void businessRigsNum(String businessRigsNum) {

        tb.type("businessRigsNum_XPATH", businessRigsNum);

    }

    public void companyTName(String companyTName) {
        tb.type("companyTName_XPATH", companyTName);

    }

    public void otherBusinessType(String otherBusinessType) {
        tb.type("otherBusinessType_XPATH", otherBusinessType);

    }

    public void lob(String lob) {

        tb.click("lob_XPATH");
        tb.click(lob);

    }

    public void referralName(String referralName) {
        tb.type("referralName_XPATH", referralName);

    }

    @SuppressWarnings("static-access")
    public void accountClass(String accountClass) {

        tb.click("accountClass_XPATH");
        for (int i = 1; i <= 3; i++) {
            try {
                tb.driver.findElement(By.xpath("(//a[text()='" + accountClass + "'])[" + i + "]")).click();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    public void uncheckTheCheckBox() {

        System.out.println("uncheck the checkbox");
        tb.click("checkbox_XPATH");

    }

    @SuppressWarnings("static-access")
    public void clickOnsaveBtn() {
        for (int i = 1; i <= 2; i++) {
            try {
                tb.driver.findElement(By.xpath(
                        "(//button[@class='slds-button slds-button--neutral uiButton--brand uiButton forceActionButton']//span[contains(@class,'label bBody')][contains(text(),'Save')])["
                                + i + "]"))
                        .click();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
    @SuppressWarnings("static-access")
    public String getQueueOrOwnerName() {
        String queuename = "";

        /*
         * queuename=tb.driver.findElement(By.
         * xpath("(//span[text()='Lead Owner']//parent::div/following-sibling::div/span/slot/slot/force-owner-lookup/div/span/force-lookup/div/force-hoverable-link/div/a)["
         * +rownum+"]")).getText();
         */

    queuename=tb.driver.findElement(By.xpath("(//span[text()='Lead Owner']//parent::div/following-sibling::div/span/slot/slot/force-owner-lookup/div/span/force-lookup/div/force-hoverable-link/div/a)")).getText();

        return queuename;

        }
    public String leadOwner() {

        try {
            return tb.element("leadOwner_XPATH").getText();
        } catch (Exception e) {

            return tb.element("LeadOwner2_XPATH").getText();

        }

    }
    public void clickOnleads() {

        tb.click("lead2_XPATH");
        System.out.println("clicked");
    }

    public void clickOnCancel() {

        tb.click("cancelBTN_XPATH");

    }

    @SuppressWarnings("static-access")
    public void markLeadStatusAsQualified() {
        JavascriptExecutor js = (JavascriptExecutor) tb.driver;
        js.executeScript("arguments[0].click();", tb.element("qualifiedStage_XPATH"));
        js.executeScript("arguments[0].click();", tb.element("MarkStatus_XPATH"));
        // tb.click("qualifiedStage_XPATH");
        // tb.click("MarkStatus_XPATH");

    }

    // required fields for EE before qualification
    public void motherMaidenName(String maidenName) {
        tb.type("motherMaidenName_XPATH", maidenName);
    }

    public void personalTIN(String personalTIN) {
        tb.type("personalTIN_XPATH", personalTIN);
    }

    public void titleandRole(String role) {

        tb.type("title_XPATH", "Dont Know");
        tb.click("LeadRole_XPATH");
        tb.click(role);

    }


}
