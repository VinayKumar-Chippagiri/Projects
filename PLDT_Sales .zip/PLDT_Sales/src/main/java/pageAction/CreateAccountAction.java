package pageAction;

import base.TestBase;

public class CreateAccountAction {

	TestBase tb = new TestBase();

	public void click_on_new() {

		tb.click("new_btn_XPATH");

	}

	public void click_on_Next() {

		tb.click("nextBTN_XPATH");

	}

	public void accountName(String accountName) {

		tb.type("accountName_XPATH", accountName);

	}

	public void parentAccount() {

		tb.type("parentAccount_XPATH", "Ankita");
		tb.click("parentAccountName_XPATH");

	}

	public void AccountCurrency(String AccountCurrency) {
		tb.click("accountCurrency_XPATH");
		tb.click(AccountCurrency);

	}

	public void lob(String lob) {

		tb.click("LOBAccounts_XPATH");
		tb.click(lob);

	}

	public void accountClass(String accountClass) {

		tb.click("accountClass_XPATH");
		tb.click(accountClass);
	}

	public void industry(String industry) {

		tb.click("accountIndustry_XPATH");
		tb.click(industry);
	}

	public void industrySubType(String industrySubType) {

		tb.click("AccountIndustrySubType_XPATH");
		tb.click(industrySubType);
	}

	public void companyTin(String companyTin) {

		tb.type("accountCompanyTin_XPATH", companyTin);

	}

	public void companySize(String companySize) {

		tb.click("accountCompany_Size_XPATH");
		tb.click(companySize);
	}

	public void Businesstype(String Businesstype) {

		tb.click("accountBussinessType_XPATH");
		tb.click(Businesstype);
	}

	public void BusinessRigsType(String BusinessRigsType) {

		tb.click("accountBussinessRigsType_XPATH");
		tb.click(BusinessRigsType);
	}

	public void BusinessRigsNumber(String BusinessRigsNumber) {

		tb.type("accountBussinessRigsNo_XPATH", BusinessRigsNumber);

	}

	public void clickonSave() {

		tb.click("save_XPATH");

	}

	public void clickOnCancel() {
		tb.click("cancelBTN_XPATH");
	}

}
