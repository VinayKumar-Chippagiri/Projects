package pageAction;

import org.openqa.selenium.By;

import base.TestBase;

public class CreateConatctAction {

	TestBase tb=new TestBase();
	public void click_on_new() {

		tb.click("new_btn_XPATH");

	}


	public void firstName(String firstName) {

		tb.type("firstName_XPATH", firstName);

	}
	
	public void lastName(String lastName) {

		tb.type("lastName_XPATH", lastName);

	}
	@SuppressWarnings("static-access")
	public void Enter_AccountName(String AccountName) {

		tb.type("searchAccount_XPATH", AccountName);
		//tb.click("accountName_XPATH");
		try {
//			tb.driver.findElement(By.ByXPath.xpath("(//div/mark[contains(text(),'"+AccountName+"')])[1]")).click();
			tb.driver.findElement(By.ByXPath.xpath("//lightning-base-combobox-formatted-text[@title='" + AccountName + "']")).click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void contactCurrency(String contactCurrency) {
		tb.click("contactCurrency_XPATH");
		tb.click(contactCurrency);

	}
	public void contactRole(String role) {
		tb.click("ContactRoles_XPATH");
//		tb.click(role);
		try {
			tb.driver.findElement(By.ByXPath.xpath("//span[text()='" + role + "']")).click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void email(String email) {

		tb.type("email_XPATH", email);

	}

	public void clickonSave() {

		tb.click("save_XPATH");

	}
	
	public void clickOnCancel() {
		tb.click("cancelBTN_XPATH");
	}
	
	//LEONYL: additional mandatory fields
	public void gender(String gender) {
		System.out.println("Select gender: " + gender);
		tb.click("contactGender_XPATH");
//		tb.click(gender);
		try {
			tb.driver.findElement(By.ByXPath.xpath("//span[text()='" + gender+ "']")).click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void phone(String phone) {
		System.out.println("Enter phone numberr: " + phone);
		tb.type("contactPhone_XPATH", phone);
	}
	
	public void mobile(String mobile) {
		System.out.println("Enter mobile numberr: " + mobile);
		tb.type("contactMobile_XPATH", mobile);
	}
	
	public void fax(String fax) {
		System.out.println("Enter phone numberr: " + fax);
		tb.type("contactFax_XPATH", fax);
	}
	
	public void birthdate(String bdate) {
		System.out.println("Enter birthdate: " + bdate);
		tb.type("contactBdate_XPATH", bdate);
	}

	public void middleName(String midName) {
		System.out.println("Enter birthdate: " + midName);
		tb.type("midNmae_XPATH", midName);

	}
	
}
