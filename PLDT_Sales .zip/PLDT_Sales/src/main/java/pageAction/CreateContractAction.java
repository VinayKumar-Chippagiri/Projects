package pageAction;


import org.openqa.selenium.By;

import base.TestBase;

public class CreateContractAction {
	TestBase tb = new TestBase ();
	QuotePageAction quotePageAction=new QuotePageAction();

	public void SelectAllQuotes() {

		tb.click("SelectAllQuotes_XPATH");

	}
	public void createContractFromOpportunity() {

		tb.click("ContractDropdow_XPATH");
		tb.click("CreateContractLink_XPATH");

	}
	@SuppressWarnings("static-access")
	public void createContractFromQuote() {
		System.out.println("Create Contract....");
		
		CommonSteps.switchToActionFrame();
	CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "QuotePageCreateContractBTN_XPATH");
	
		/*
		 * CommonSteps.SwitchToFrame(); tb.ExplicitWait("Menue_XPATH");
		 * tb.click("Menue_XPATH"); tb.ExplicitWait("QuotePageCreateContractBTN_XPATH");
		 * tb.jsClick("QuotePageCreateContractBTN_XPATH");
		 */
		tb.ThreadWait(4000);
		tb.driver.navigate().refresh();
		tb.ThreadWait(4000);
		quotePageAction.clickOnNext();
		tb.driver.switchTo().parentFrame();

	}
	public void editContract(String startDate,String contractMonth) {


		tb.click("EditContractStartDate_XPATH");
		tb.type("ContractStartDate_XPATH", startDate);
		tb.type("ContractMonth_XPATH", contractMonth);

	}

	@SuppressWarnings("static-access")
	public void GenerateDocument(String template) {
		System.out.println("Click on Generate Document button...");

		tb.Scroll("ActivatedDate_XPATH");
		tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("//iframe[@title='accessibility title']")));
		tb.jsClick("GenerateDocuments_XPATH");
		tb.ThreadWait(5000);
		tb.driver.navigate().refresh();
		tb.ThreadWait(5000);
		CommonSteps.SwitchToFrame();
		tb.ExplicitWait("SelectTemplate_XPATH");
		tb.select("SelectTemplate_XPATH", template);
		tb.ExplicitWait("CheckIn_XPATH");
		tb.jsClick("CheckIn_XPATH");
		tb.ThreadWait(10000);

	}

	public void MoveStageToNegociation() {

		CommonSteps.ChangeStatus("NegotiatingStage_XPATH", "MarkStatus_XPATH");
		tb.ExplicitWait("MarkAsComplete_XPATH");

		System.out.println("Move Quote to Negociation status...");
		tb.ThreadWait(2000);
	}

	public void MoveStageToAwaitingSingnature() {

		CommonSteps.ChangeStatus("AwaitingSingnture_XPATH", "MarkStatus_XPATH");
		tb.ExplicitWait("MarkAsComplete_XPATH");

		System.out.println("Move Quote to Awaiting Singnature status...");
		tb.ThreadWait(2000);
	}

	public void MoveStageToSigned() {

		CommonSteps.ChangeStatus("Signed_XPATH", "MarkStatus_XPATH");
		tb.ExplicitWait("MarkAsComplete_XPATH");

		System.out.println("Move Quote to Signed status...");
		tb.ThreadWait(2000);
	}

	public void MoveStageToActivated() {

		CommonSteps.ChangeStatus("Activated_XPATH", "MarkStatus_XPATH");
		tb.ThreadWait(5000);
	}

	public void updateContractSignedData()
	{
		tb.click("contractSignedDate_XPATH");
		tb.ThreadWait(2000);
		tb.type("editContractSignedDate_XPATH", "12/31/2020");
		tb.ThreadWait(2000);
		tb.click("quotesSaveBtn_XPATH");
	}


}
