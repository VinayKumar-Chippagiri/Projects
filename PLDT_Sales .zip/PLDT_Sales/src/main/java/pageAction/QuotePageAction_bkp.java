package pageAction;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;

public class QuotePageAction_bkp extends TestBase {

	TestBase tb = new TestBase();

	private By appLauncher = By.xpath("//*[@aria-label=\"App\"]/one-app-launcher-header/button/div");
	private By appSearch = By.xpath("//input[@placeholder=\"Search apps and items...\"]");

	public void clickOnAppLauncher() {
		tb.clickOn(appLauncher);
	}

	public void enterValueOnAppSearch() {
		tb.typeDataTo(appSearch, "Quotes");
		tb.enterKey();
	}

	public void searchAndOpenQuote(String quoteName) {
		tb.clickUsingJs(By.xpath(
				"//button[@class='slds-button slds-button--reset downIcon slds-m-top_xxx-small slds-p-right_xxx-small']"));
		tb.jsClink_LinkText("Recently Viewed");

		tb.typeDataTo(By.xpath("//input[@name='Quote-search-input']"), quoteName);
		tb.enterKey();

		String path = "//a[text()=" + "'" + quoteName + "'" + "]";
		tb.clickUsingJs(By.xpath(path));

	}

	public void ChangestatustoEstablishNeed() {

		CommonSteps.ChangeStatus("EstablishNeedStage_XPATH", "MarkStatus_XPATH");
		tb.ExplicitWait("MarkAsComplete_XPATH");
		System.out.println("Change Status to Establish Need...");

	}

	@SuppressWarnings("static-access")
	public void CreateQuote() {

		System.out.println("Click Create Quote button...");

		try {

			/*
			 * tb.driver.switchTo() .frame(tb.driver.findElement(By.
			 * xpath("//iframe[@title='accessibility title']")));
			 * tb.ExplicitWait("Menue_XPATH"); tb.click("Menue_XPATH");
			 * tb.ExplicitWait("CreateQuote_XPATH"); tb.click("CreateQuote_XPATH");
			 * tb.ImpliciWait(4);
			 */
			CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "CreateQuote_XPATH");

			tb.driver.switchTo().parentFrame();
			tb.ExplicitWait("QuoteNumber_XPATH");
			tb.takeScreenshot();
			// tb.Scroll("QuoteNumber_XPATH");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void updateQuoteValidatyPeriod_DeliveryDate_ConatctDetails(String AuthorizeSigonatory, String BillRecipient,
			String CapContact, String DeliveryRecipient) {
		System.out.println("Populate Quote Validity and Delivery Date..");

		try {

			tb.ExplicitWait("QuoteNumber_XPATH");
			tb.ThreadWait(1000);

			tb.scroll(300, 400);
			tb.waitFor(By.xpath(OR.getProperty("ScrollTillContract_XPATH")), 20, true);
			tb.Scroll("ScrollTillContract_XPATH");
			tb.jsClick("EditQuoteValidityPeriod_XPATH");
			tb.ThreadWait(1000);

			tb.type("InputQuoteday_XPATH", "30");
			tb.ThreadWait(1000);
			tb.Scroll("InputQuoteday_XPATH");
			updateAuthorizeSigonatory(AuthorizeSigonatory);
			tb.ThreadWait(1000);

			updateBillRecipient(BillRecipient);
			tb.ThreadWait(1000);

			updateCapContact(CapContact);
			tb.ThreadWait(1000);

			updateDeliveryRecipient(DeliveryRecipient);
			tb.ThreadWait(1000);

			tb.type("DeliveryDate_XPATH", "5/31/2021");
			System.out.println("clickOnSAVE");
			tb.takeScreenshot();
			tb.retryClick("save_XPATH");
			tb.ExplicitWait("QuoteNumber_XPATH");
			tb.ThreadWait(2000);

			System.out.println("\n=====================\n");

			// tb.waitElementtoBecomeInvisble("footer_XPATH");
			// tb.driver.switchTo().alert().dismiss();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void ChangeStatustoCustomerApproved() {
		CommonSteps.ChangeStatus("CustomerApprovedStage_XPATH", "MarkStatus_XPATH");
		tb.ExplicitWait("MarkAsComplete_XPATH");

		System.out.println("Move Quote to Approved status...");

	}

	public void ChangeStatustoPresented() {

		CommonSteps.ChangeStatus("PresentedStage_XPATH", "MarkStatus_XPATH");
		tb.ExplicitWait("MarkAsComplete_XPATH");

		System.out.println("Move Quote to Presented status...");
		tb.ThreadWait(2000);
	}

	public void ChangeStatustoAccepted() {
		boolean flag = false;
		do {
			try {
				CommonSteps.ChangeStatus("AcceptedStage_XPATH", "MarkStatus_XPATH");
				tb.ExplicitWait("MarkAsComplete_XPATH");
				flag = tb.element("MarkAsComplete_XPATH").isDisplayed();
			} catch (Exception e) {
				tb.refreshPage();
				System.out.println("Page Will Refresh..");
			}
		} while (!flag);

		System.out.println("Move Quote to Accepted status...");

		System.out.println("\n=====================\n");
	}

	@SuppressWarnings("static-access")
	public void selectQuotesListView(String viewName) {
		System.out.println("Select Quotes List View: " + viewName);

		tb.click("selectListView_XPATH");
		tb.driver.findElement(By.xpath("//span[text()='" + viewName + "']/parent::*")).click();

	}

	public void searchQuote(String searchText) {
		System.out.println("Search Quote Number: " + searchText);

		tb.pasteText("quoteSearchInput_XPATH", searchText);
		tb.ThreadWait(2000);
		tb.click("accountSearchRefresh_XPATH");

	}

	public void clickQuoteRecord(String quoteName) {
		System.out.println("Click Quote: " + quoteName);

		tb.click(quoteName);
	}

	@SuppressWarnings("static-access")
	public void editCreditApprovalStatus(String newStatus) throws InterruptedException {
		System.out.println("Select Credit Approval Status");

		tb.click("quoteCreditApprovalStatus_XPATH");

		// tb.driver.findElement(By.xpath("//a[text()='" + newStatus + "']")).click();

		tb.jsClink_LinkText(newStatus);
	}

	@SuppressWarnings("static-access")
	public void editCreditApprovalCondition(String condition) throws InterruptedException {
		System.out.println("Select Credit Approval Condition");

		tb.click("quoteCreditApprovalCondition_XPATH");

		tb.driver.findElement(By.xpath("//a[text()='" + condition + "']")).click();
	}

	public void editAdvancePaymentInMonths(String months) {
		System.out.println("Enter Advance Payment in Months... " + months);

		tb.type("quoteSecurityDepositInMonths_XPATH", months);
	}

	public void editSecurityDepositInMonths(String months) {
		System.out.println("Enter Security Deposit in Months... " + months);

		tb.type("quoteAdvancePaymentInMonths_XPATH", months);

	}

	public void editCreditRemart(String Remark) {

		tb.type("QuoteCreditRemart_XPATH", Remark);

	}

	public void saveEditedQuoteDetails() {
		System.out.println("Click Save button on Quote Edit details...");

		tb.click("save_XPATH");
	}

	@SuppressWarnings("static-access")
	public void creditCheckForQuote(String quoteNo) {
		System.out.println("Credit check for Quote| " + quoteNo);

		// tb.click("//a[text()='Credit check for Quote :" + quoteNo + "']");
		// tb.driver.findElement(By.xpath("//a[text()='Credit check for Quote :" +
		// quoteNo + "']")).click();
		tb.driver.findElement(By.xpath("//a[contains(text(),'Credit check for Quote :')]")).click();
		tb.wait.until(ExpectedConditions.titleContains(quoteNo));
		tb.click("quoteCCMarkCompleteButton_XPATH");
	}

	public String getQuoteNumber() {
		System.out.println("Get Quote Number...");

		return tb.getText("quoteNoValue_XPATH");
	}

	public String getQuoteName() {

		System.out.println("Get Quote Name...");

		return tb.getText("quoteNameValue_XPATH");
	}

	public String getCreditCheckValue() {
		System.out.println("Get Credit Check value...");

		return tb.getText("quoteCreditCheck_XPATH");
	}

	@SuppressWarnings("static-access")
	public void clickOnCreditCheck() {
		System.out.println("Click Credit Check Button...");

		CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "creditCheckButton_XPATH");

		/*
		 * CommonSteps.SwitchToFrame(); tb.ExplicitWait("Menue_XPATH");
		 *
		 * tb.click("Menue_XPATH"); tb.ThreadWait(1000);
		 * tb.ExplicitWait("creditCheckButton_XPATH");
		 * tb.jsClick("creditCheckButton_XPATH");
		 */

	}

	@SuppressWarnings("static-access")
	public void clickOnNext() {
		System.out.println("Click On NEXT button...");

		tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("//iframe[@title='accessibility title']")));
		tb.ExplicitWait("ccStatusNextButton_XPATH");
		tb.jsClick("ccStatusNextButton_XPATH");
	}

	public void DeviceAvailabilityChceck(String QuoteName, String runStatus) {
		// tb.driver.navigate().refresh();

		tb.ThreadWait(2000);
		tb.driver.navigate().refresh();
		CommonSteps.SwitchToFrame();
		System.out.println("\nInside the frame : Device Availability\n");
		tb.waitFor(By.xpath("(//i[@class='icon icon-v-menu2'])[1]"), 60, true);
		tb.clickUsingJs(By.xpath(OR.getProperty("Menue_XPATH")));
		tb.clickUsingJs(By.xpath(OR.getProperty("DeviceAvailabilityCheck_XPATH")));
		tb.ThreadWait(2000);
		tb.driver.navigate().refresh();
		tb.ThreadWait(5000);
		CommonSteps.SwitchToFrame();
		tb.ExplicitWait("DeviceCheckNextbtn_XPATH");
		tb.ThreadWait(5000);
		tb.takeScreenshot();
		// AllDevicecheck(QuoteName, "DeviceAvailability", runStatus);
		tb.click("DeviceCheckNextbtn_XPATH");
		tb.driver.switchTo().parentFrame();
		tb.ThreadWait(5000);

	}

	public void DeviceReservation(String QuoteName, String runStatus) {
		try {

			System.out.println("Click on Device Reservation");
			tb.refreshPage();
			CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "DeviceReservation_XPATH");

			/*
			 * CommonSteps.SwitchToFrame(); tb.ExplicitWait("Menue_XPATH");
			 * tb.click("Menue_XPATH");
			 *
			 * tb.ExplicitWait("DeviceReservation_XPATH");
			 * tb.jsClick("DeviceReservation_XPATH");
			 */
			/*
			 * tb.ThreadWait(2000); tb.driver.navigate().refresh(); tb.ThreadWait(2000);
			 * tb.switchToFrame("Frame_XPATH"); tb.ThreadWait(5000);
			 */
			tb.ThreadWait(3000);
			// tb.driver.navigate().refresh();
			tb.ThreadWait(3000);
			CommonSteps.SwitchToFrame();
			// AllDevicecheck(QuoteName, "DeviceReservation", runStatus);
			tb.ExplicitWait("ccStatusNextButton_XPATH");
			CommonSteps.clickOnNextVlocityBtn();
			// tb.ExplicitWait("ccStatusNextButton_XPATH");

			try {
				if (tb.element("DeviceReservationValidation_XPATH").isDisplayed()) {
					System.out.println("Take screenshot");
					tb.ThreadWait(5000);
					tb.takeScreenshot();
					String ErrorMSG = tb.element("DeviceReservationValidation_XPATH").getText();
					System.out.println("Take screenshot");
					TestBase.test.log(LogStatus.FAIL, ErrorMSG);
					CommonSteps.clickOnNextVlocityBtn();
					System.out.println(ErrorMSG);
					// softAssert.assertTrue(false, ErrorMSG);
				}
			} catch (Exception e) {

				// Amit:Click on Next button on delivery mode screen
				tb.ExplicitWait("RM_Delivery_XPATH");
				CommonSteps.clickOnNextVlocityBtn();
				tb.ExplicitWait("DeviceReservedConfirmation_XPATH");
				String DeviceReservedConfirmation = tb.element("DeviceReservedConfirmation_XPATH").getText();
				System.out.println(DeviceReservedConfirmation);
				tb.ThreadWait(3000);
				// Amit:Click on Next button on device and sim allocation status screen
				CommonSteps.clickOnNextVlocityBtn();
				tb.ThreadWait(3000);

				// Amit:Navigate to Quote Details Page
				tb.driver.switchTo().parentFrame();
				tb.ThreadWait(2000);
				tb.refreshPage();
				tb.ExplicitWait("QuoteNumber_XPATH");
				System.out.println("Device Reserved..");

				tb.Scroll("CreditInformation_XPATH");
				String DeviceReservationSalesNumber = tb.element("DeviceReservationsalesNum_XPATH").getText();
				String DeviceReservationStatus = tb.element("DeviceReservationStatus_XPATH").getText();
				// Amit:Check if Device Reservation sales number is generated and status is
				// Reserved
				if ((tb.element("DeviceReservationsalesNum_XPATH").getText() != null)
						&& tb.element("DeviceReservationStatus_XPATH").getText().equals("Reserved")) {

					tb.takeScreenshot();
					System.out.println("Device Reservation sales Number : " + DeviceReservationSalesNumber);
					System.out.println("Device Reservation sales Status : " + DeviceReservationStatus);
					runStatus = "Pass";
					TestBase.test.log(LogStatus.PASS, DeviceReservationSalesNumber + "" + DeviceReservationStatus);
				} else {
					String ErrNoDeviceReservationSalesNumber = tb.element("DeviceReservationsalesNum_XPATH").getText();
					String ErrNoReservedStatus = tb.element("DeviceReservationStatus_XPATH").getText();
					TestBase.test.log(LogStatus.FAIL, ErrNoDeviceReservationSalesNumber + "/t" + ErrNoReservedStatus);
				}

				System.out.println("print err");
				// e.printStackTrace();

			}

			tb.driver.switchTo().parentFrame();

			System.out.println("\n=====================\n");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String getDeviceAvailablity() {

		return tb.getText("checkDeviceavailablity");

	}

	public void AllDevicecheck(String QuoteName, String CSVPath, String runStatus) {

		try {

			String AvailabilityStatus = "";
			String DeviceName = "";

			FileWriter wr = new FileWriter(CSVPath + ".csv", true);
			BufferedWriter bw = new BufferedWriter(wr);
			List<WebElement> devices = tb.driver.findElements(By.xpath("//table[@class='ng-scope']/tbody/tr/td[1]"));
			List<WebElement> status = tb.driver.findElements(By.xpath("//table[@class='ng-scope']/tbody/tr/td[5]"));
			int rows = devices.size();
			System.out.println(devices.size());
			// validate status and write to CSV
			for (int i = 0; i < rows; i++) {
				AvailabilityStatus = status.get(i).getText();
				DeviceName = devices.get(i).getText();
				System.out.println(AvailabilityStatus);
				System.out.println(DeviceName);
				System.out.println(devices.get(i).getText() + "|" + status.get(i).getText());
				bw.write(QuoteName);
				bw.write("|");
				bw.write(DeviceName);
				bw.write("|");
				bw.write(AvailabilityStatus);
				bw.write("|");
				if (!status.get(i).getText().contentEquals("AVAILABLE")) {
					System.out.println(devices.get(i).getText() + "|" + status.get(i).getText() + "|FAILED");

					bw.write("FAILED");
					tb.test.log(LogStatus.FAIL, "Device is not Available");
				} else {
					System.out.println(devices.get(i).getText() + "|" + status.get(i).getText() + "|PASSED");
					runStatus = "PASS";
					bw.write("PASSED");
					tb.test.log(LogStatus.valueOf(runStatus), "Device is Available");
				}
				bw.newLine();
			}
			bw.close();
		} catch (Throwable e) {
			e.printStackTrace();
		}

	}

	// Amit - Method to click on Solution Design
	public void clickONSolutionDesign() {

		System.out.println("Click on Solution Design..");

		tb.ThreadWait(2000);

		CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "SolutionDesign_XPATH");

		tb.ThreadWait(3000);

		/*
		 * CommonSteps.SwitchToFrame();
		 *
		 * tb.ExplicitWait("Menue_XPATH"); tb.click("Menue_XPATH");
		 *
		 * tb.ExplicitWait("SolutionDesign_XPATH"); tb.click("SolutionDesign_XPATH");
		 */

	}

	// Amit - Method to select ETS status
	public void selectETSStatus(String ETSStatus) {

		try {
			tb.driver.navigate().refresh();

			tb.ThreadWait(3000);

			tb.switchToFrame("Frame_XPATH");

			tb.ThreadWait(5000);

			// tb.ExplicitWait("SelectETSStatus_XPATH");
			tb.click("SelectETSStatus_XPATH");
			tb.select("SelectETSStatus_XPATH", "Completed");

			/*
			 * tb.ThreadWait(1000); tb.driver.navigate().refresh();
			 * tb.switchToFrame("Frame_XPATH");
			 */

			tb.ExplicitWait("ClickNextButton_XPATH");
			tb.jsClick("ClickNextButton_XPATH");
			tb.ThreadWait(5000);

			tb.driver.switchTo().parentFrame();
			tb.ThreadWait(5000);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String etsStatusVerify() {

		System.out.println(tb.getText("ETSStatusVerification_XPATH"));

		return tb.getText("ETSStatusVerification_XPATH");
	}

	public void ClickOnTriggerSD() {
		System.out.println("Click on Trigger SD button...");
		tb.refreshPage();
		CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "LockCartbtn_XPATH");

	}

	public void numberAvailabilityCheck(String QuoteName, String runStatus, String NumberType) {

		try {
			tb.ThreadWait(2000);
			try {
				tb.click("detailBtn_XPATH");
			} catch (Exception e2) {
				System.out.println("No Details tab");
				e2.printStackTrace();
			}
			tb.ThreadWait(5000);
			tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("//iframe[@title='accessibility title']")));

			try {
				tb.ExplicitWait("DeviceAvailabilityCheck_XPATH");
			} catch (Exception e) {
				e.printStackTrace();
			}

			boolean NumberAvailabilityCheckVisibility = false;

			NumberAvailabilityCheckVisibility = tb.isElementDisplayed("NumberAvailabilityCheck_XPATH");

			if (NumberAvailabilityCheckVisibility) {
				tb.click("NumberAvailabilityCheck_XPATH");
			} else {
				tb.click("quotesToggleIcon_XPATH");
				tb.jsClick("NumberAvailabilityCheck_XPATH");
			}

			System.out.println("Clicked Button : Number Availability Check");

			tb.driver.switchTo().defaultContent();
			tb.ThreadWait(2000);

			tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[2]")));

			try {
				tb.ExplicitWait("SearchNumber_XPATH");
			} catch (Exception e1) {
				e1.printStackTrace();
				tb.test.log(LogStatus.WARNING, e1);
			}

			tb.click("SearchNumber_XPATH");
			System.out.println("Clicked Button : SearchNumber_XPATH");

			tb.ThreadWait(5000);
			tb.driver.switchTo().defaultContent();
			tb.ThreadWait(2000);

			tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[2]")));

			tb.click("NumberPatternSearch_XPATH");
			tb.jsClick("nextButton_XPATH");
			tb.driver.switchTo().defaultContent();
			tb.ThreadWait(2000);

			tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[2]")));

			try {
				tb.ExplicitWait("SearchMIN_XPATH");
			} catch (Exception e1) {
				e1.printStackTrace();
				tb.test.log(LogStatus.WARNING, e1);
			}
			tb.select("NumberType_XPATH", NumberType);
			System.out.println("Select the value from the Dropdown: " + NumberType);
			tb.ThreadWait(2000);
			tb.click("SearchMIN_XPATH");
			try {
				tb.ExplicitWait("TitleSelectPreferredMIN_XPATH");
			} catch (Exception e) {
				tb.click("SearchMIN_XPATH");
				tb.ExplicitWait("TitleSelectPreferredMIN_XPATH");
			}

			// tb.takeScreenshot();
			numberAvailabilityList(QuoteName, "NumberAvailability", runStatus);
			tb.click("NumberAvailabilityNextBtn_XPATH");
			tb.driver.switchTo().parentFrame();
			tb.ThreadWait(2000);
			tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[2]")));

			tb.click("ViewOpportunity_XPATH");
			tb.driver.switchTo().parentFrame();
			tb.ThreadWait(5000);
		} catch (Exception e) {
			e.printStackTrace();
			tb.test.log(LogStatus.ERROR, e);
			tb.takeScreenshot();
		}
	}

	@SuppressWarnings("static-access")
	public void numberAvailabilityList(String QuoteName, String CSVPath, String runStatus) {

		try {

			FileWriter wr = new FileWriter(CSVPath + ".csv", true);
			BufferedWriter bw = new BufferedWriter(wr);

			List<WebElement> rows = tb.driver.findElements(
					By.xpath("//div[text()='Select Preferred MIN']/parent::div//following::table/tbody/tr"));

			String Number = null;
			String NumberBrand = null;
			String NumberType = null;
			String NumberFee = null;

			System.out.println("Total # of records in the Number Availability Grid: " + rows.size());

			if (rows.size() > 0)
				tb.test.log(LogStatus.PASS, "Number Availability Check | Number is Available");
			else
				tb.test.log(LogStatus.FAIL, "Number Availability Check | Number is not Available");

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();

			for (int i = 1; i <= rows.size(); i++) {
				Number = tb.driver.findElement(By.xpath(
						"//div[text()='Select Preferred MIN']/parent::div//following::table/tbody/tr[" + i + "]/th"))
						.getText();
				NumberBrand = tb.driver.findElement(By.xpath(
						"//div[text()='Select Preferred MIN']/parent::div//following::table/tbody/tr[" + i + "]/td[1]"))
						.getText();
				NumberType = tb.driver.findElement(By.xpath(
						"//div[text()='Select Preferred MIN']/parent::div//following::table/tbody/tr[" + i + "]/td[2]"))
						.getText();
				NumberFee = tb.driver.findElement(By.xpath(
						"//div[text()='Select Preferred MIN']/parent::div//following::table/tbody/tr[" + i + "]/td[3]"))
						.getText();
				bw.write(Number + "," + NumberBrand + "," + NumberType + "," + NumberFee + "," + dtf.format(now));
				bw.newLine();
				tb.test.log(LogStatus.INFO,
						"Available Number Details: " + Number + "," + NumberBrand + "," + NumberType + "," + NumberFee);
			}

			bw.close();

		} catch (Throwable e) {
			e.printStackTrace();
			tb.test.log(LogStatus.ERROR, e);
			tb.takeScreenshot();
		}

	}

	public void numberReservation(String QuoteName, String runStatus, String NumberType) {

		System.out.println("Click on Number Reservation..");

		try {
			tb.refreshPage();
			tb.ThreadWait(2000);
			CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "NumberReservation_XPATH");

			/*
			 * tb.ThreadWait(1000); CommonSteps.SwitchToFrame();
			 *
			 * tb.ExplicitWait("Menue_XPATH"); tb.click("Menue_XPATH");
			 *
			 * tb.ExplicitWait("NumberReservation_XPATH");
			 * tb.jsClick("NumberReservation_XPATH");
			 */
			tb.ThreadWait(4000);
			// tb.refreshPage();
			tb.ThreadWait(3000);
			CommonSteps.SwitchToFrame();

			String numberDetails = null;

			String MINsQuanity = tb.getText("MINSQuantity_XPATH");
			System.out.println("MINsQuantiy " + MINsQuanity);

			tb.click("SearchNumber_XPATH");
			// tb.driver.switchTo().parentFrame();
			tb.ThreadWait(3000);
			tb.driver.navigate().refresh();
			tb.ThreadWait(3000);
			CommonSteps.SwitchToFrame();

			int NumberOfMINS = Integer.parseInt(MINsQuanity.trim());

			if (NumberOfMINS > 1) {

				tb.ExplicitWait("ReserveAnyNAvailbleNumbers_XPATH");
				tb.click("ReserveAnyNAvailbleNumbers_XPATH");
				tb.jsClick("nextButton_XPATH");

				// CommonSteps.SwitchToFrame();

				tb.ExplicitWait("ReserveNumber_XPATH");

				// tb.select("NumberType_XPATH", NumberType);
				tb.ThreadWait(2000);
				tb.click("ReserveNumber_XPATH");

				tb.ThreadWait(3000);

				tb.takeScreenshot();
				numberDetails = numberReservationList(QuoteName, "NumberReservation", runStatus);
				tb.click("NumberAvailabilityNextBtn2_XPATH");
			} else {

				tb.click("NumberPatternSearch_XPATH");
				tb.jsClick("nextButton_XPATH");

				tb.ThreadWait(2000);
				// CommonSteps.SwitchToFrame();

				tb.ExplicitWait("SearchMIN_XPATH");

				tb.select("NumberType_XPATH", NumberType);
				tb.ThreadWait(2000);
				tb.click("SearchMIN_XPATH");
				tb.ThreadWait(2000);
				tb.takeScreenshot();
				numberDetails = numberReservationList(QuoteName, "NumberReservation", runStatus);
				tb.click("NumberAvailabilityNextBtn_XPATH");

			}

			try {
				tb.ThreadWait(1000);

				String[] numberDetailsArray = numberDetails.split("\\s*,\\s*");
				String expectedNumber = numberDetailsArray[0];
				String expectedNumberBrand = numberDetailsArray[1];
				String expectedNumberType = numberDetailsArray[2];
				String expectedStatus = numberDetailsArray[3];

				String actualNumber = tb.element("NumberSelected_XPATH").getText();
				String actualNumberBrand = tb.element("NumberBrandSelected_XPATH").getText();
				String actualNumberType = tb.element("NumberTypeSelected_XPATH").getText();
				String actualStatus = tb.element("ReserveStatus_XPATH").getText();

				String number = actualNumber.substring((actualNumber.indexOf(":") + 2), actualNumber.length());
				String numberBrand = actualNumberBrand.substring((actualNumberBrand.indexOf(":") + 2),
						actualNumberBrand.length());
				String numberType = actualNumberType.substring((actualNumberType.indexOf(":") + 2),
						actualNumberType.length());
				String numberStatus = actualStatus.substring((actualStatus.indexOf(":") + 2), actualStatus.length());

				if (expectedNumber.equalsIgnoreCase(number))
					tb.test.log(LogStatus.PASS, "Assigned Number : " + expectedNumber + " | Reserved Number : " + number
							+ " || Passed: Asigned and Reserved number are same");
				else
					tb.test.log(LogStatus.FAIL, "Assigned Number : " + expectedNumber + " | Reserved Number : " + number
							+ " || Failed: Asigned and Reserved number are different");

				if (expectedNumberBrand.equalsIgnoreCase(numberBrand))
					tb.test.log(LogStatus.PASS,
							"Assigned Number Brand: " + expectedNumberBrand + " | Reserved Number Brand: " + numberBrand
									+ " || Passed: Asigned and Reserved number brand are same");
				else
					tb.test.log(LogStatus.FAIL,
							"Assigned Number Brand: " + expectedNumberBrand + " | Reserved Number Brand: " + numberBrand
									+ " || Failed: Asigned and Reserved number brand are different");

				if (expectedNumberType.equalsIgnoreCase(numberType))
					tb.test.log(LogStatus.PASS,
							"Assigned Number Type: " + expectedNumberType + " | Reserved Number Type: " + numberType
									+ " || Passed: Asigned and Reserved number type are same");
				else
					tb.test.log(LogStatus.FAIL,
							"Assigned Number Type: " + expectedNumberType + " | Reserved Number Type: " + numberType
									+ " || Failed: Asigned and Reserved number type are different");

				if (expectedStatus.equalsIgnoreCase(numberStatus))
					tb.test.log(LogStatus.PASS,
							"Assigned Number Status: " + expectedStatus + " | Reserved Number Status: " + numberStatus
									+ " || Passed: Asigned and Reserved number status are same");
				else
					tb.test.log(LogStatus.FAIL,
							"Assigned Number Status: " + expectedStatus + " | Reserved Number Status: " + numberStatus
									+ " || Failed: Asigned and Reserved number status are different");

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			if (NumberOfMINS == 1) {

				tb.click("SelectedItemsNextBtn_XPATH");
				tb.driver.switchTo().parentFrame();
				tb.ThreadWait(2000);
				tb.refreshPage();
				CommonSteps.SwitchToFrame();

				try {
					tb.click("SuccessReservationNextBtn_XPATH");
				} catch (Exception e) {
					tb.click("FailureReservationNextBtn_XPATH");
				}

			}
			tb.driver.navigate().refresh();
			tb.ThreadWait(2000);
			tb.switchToFrame("Frame_XPATH");
			tb.ExplicitWait("ViewQuote_XPATH");
			tb.click("ViewQuote_XPATH");
			tb.driver.switchTo().parentFrame();

			tb.ExplicitWait("AcceptedStage_XPATH");

			System.out.println("\n=====================\n");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@SuppressWarnings("static-access")
	public String numberReservationList(String QuoteName, String CSVPath, String runStatus) {

		String ReserveList = null;
		try {

			FileWriter wr = new FileWriter(CSVPath + ".csv", true);
			BufferedWriter bw = new BufferedWriter(wr);

			List<WebElement> rows = tb.driver
					.findElements(By.xpath("//div[text()='Numbers Reserved']/parent::div//following::table/tbody/tr"));

			String Number = null;
			String NumberBrand = null;
			String NumberType = null;
			String NumberFee = null;
			String Status = null;

			System.out.println("Total # of records in the Number Availability Grid: " + rows.size());

			if (rows.size() > 0)
				tb.test.log(LogStatus.PASS, "Number Reservation | Number is Available");
			else
				tb.test.log(LogStatus.FAIL, "Number Reservation | Number is not Available");

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();

			for (int i = 1; i <= rows.size(); i++) {
				Number = tb.driver.findElement(By
						.xpath("//div[text()='Numbers Reserved']/parent::div//following::table/tbody/tr[" + i + "]/th"))
						.getText();
				NumberBrand = tb.driver.findElement(By.xpath(
						"//div[text()='Numbers Reserved']/parent::div//following::table/tbody/tr[" + i + "]/td[1]"))
						.getText();
				NumberType = tb.driver.findElement(By.xpath(
						"//div[text()='Numbers Reserved']/parent::div//following::table/tbody/tr[" + i + "]/td[2]"))
						.getText();
				NumberFee = tb.driver.findElement(By.xpath(
						"//div[text()='Numbers Reserved']/parent::div//following::table/tbody/tr[" + i + "]/td[3]"))
						.getText();
				Status = tb.driver.findElement(By.xpath(
						"//div[text()='Numbers Reserved']/parent::div//following::table/tbody/tr[" + i + "]/td[4]"))
						.getText();
				bw.write(Number + "," + NumberBrand + "," + NumberType + "," + NumberFee + "," + Status + ","
						+ dtf.format(now));
				tb.test.log(LogStatus.INFO,
						"Reserved Number Details: " + Number + "," + NumberBrand + "," + NumberType + "," + NumberFee);
				tb.driver.findElement(By
						.xpath("//div[text()='Numbers Reserved']/parent::div//following::table/tbody/tr[" + i + "]/th"))
						.click();
				ReserveList = Number + "," + NumberBrand + "," + NumberType + "," + Status;
				bw.newLine();
			}
			bw.close();

			if (Status.trim().equalsIgnoreCase("Available for Reservation")
					|| Status.trim().equalsIgnoreCase("Number Reservation is successful.")) {
				System.out.println("Actual Status: " + Status.trim() + " | Expected Status: Available for Reservation "
						+ "|Passed");
				tb.test.log(LogStatus.PASS,
						"Actual Status: " + Status.trim() + " | Expected Status: Available for Reservation");
			} else {
				System.out.println("Actual Status: " + Status.trim() + " | Expected Status: Available for Reservation "
						+ "|Failed");
				tb.test.log(LogStatus.FAIL,
						"Actual Status: " + Status.trim() + " | Expected Status: Available for Reservation");
			}

		} catch (Throwable e) {
			e.printStackTrace();
		}

		return ReserveList;

	}

	public void updateAuthorizeSigonatory(String AuthorizeSigonatory ) {
		System.out.println("Select Authorize Sigonatory Name...");

		tb.type("quoteAuthorizedSignatory_XPATH", AuthorizeSigonatory);
		tb.ThreadWait(1000);
		tb.element("quoteAuthorizedSignatory_XPATH").sendKeys(Keys
				.BACK_SPACE);

		tb.ThreadWait(1000);
		try {
			System.out.println(AuthorizeSigonatory);
			//tb.driver.findElement(By.xpath("(//ul//li//*[@title='"+AuthorizeSigonatory+"'])")).click();
			tb.clickUsingJs(By.xpath("(//ul//li//*[@title='"+AuthorizeSigonatory+"'])[1]"));

		} catch (Exception e) {
			System.out.println("Hello Catch Block");
			e.printStackTrace();
		}

	}

	public void updateCapContact(String CapContact) {

		System.out.println("Select CapContact Name...");

		tb.type("quoteCAPContact_XPATH", CapContact);
		tb.ThreadWait(1000);
		tb.element("quoteCAPContact_XPATH").sendKeys(Keys
				.BACK_SPACE);

		tb.ThreadWait(1000);


		try {
			System.out.println(CapContact);
		//tb.driver.findElement(By.xpath("(//ul//li//*[@title='"+CapContact+"'])[1]")).click();;

		tb.clickUsingJs(By.xpath("(//ul//li//*[@title='"+CapContact+"'])[1]"));
		} catch (Exception e) {
			System.out.println("Hello Catch Block");
			e.printStackTrace();
		}
		}


	public void updateBillRecipient(String BillRecipient) {

		System.out.println("Select Bill Recipient Name...");

		tb.type("quoteBillRecipient_XPATH", BillRecipient);
		tb.ThreadWait(1000);
		tb.element("quoteBillRecipient_XPATH").sendKeys(Keys
				.BACK_SPACE);

		tb.ThreadWait(1000);
		try {
			System.out.println(BillRecipient);
			tb.clickUsingJs(By.xpath("(//ul//li//*[@title='"+BillRecipient+"'])[1]"));
		} catch (Exception e) {
			System.out.println("Hello Catch Block");
			e.printStackTrace();
		}

	}

	public void updateDeliveryRecipient(String DeliveryRecipient) {

		System.out.println("Select Delivery Recipient Name...");

		tb.type("quoteDeliveryRecipient_XPATH", DeliveryRecipient);
		tb.ThreadWait(1000);
		tb.element("quoteDeliveryRecipient_XPATH").sendKeys(Keys
				.BACK_SPACE);

		tb.ThreadWait(1000);

		for (int i = 1; i <= 3; i++) {

			try {

				System.out.println("//ul//li//*[@title='"+DeliveryRecipient+"'])["+i+"]");

			tb.clickUsingJs(By.xpath("(//ul//li//*[@title='"+DeliveryRecipient+"'])["+i+"]"));

		} catch (Exception e) {
			System.out.println("Hello Catch Block");
			e.printStackTrace();
		}
		}

	}
	public void updateAccounts(String BiilingAccountName, String ServiceAccountName) {

		try {
			String BiilingAccountName1 = BiilingAccountName.toLowerCase();
			String ServiceAccountName1 = ServiceAccountName.toLowerCase();
			boolean flag;

			CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "Configure_XPATH");

			tb.ThreadWait(3000);
			tb.driver.navigate().refresh();
			tb.ThreadWait(3000);
			CommonSteps.SwitchToFrame();

			tb.ExplicitWait("ProductConfigurationBtn_XPATH");
			tb.click("ProductConfigurationBtn_XPATH");
			tb.click("UpdateAccount_XPATH");
			tb.switchBacktoMain();
			System.out.println("Update Account...");

			tb.ExplicitWait("BillingAccSearch_XPATH");
			tb.ThreadWait(1000);
			tb.click("BillingAccSearch_XPATH");
			tb.type("BillingAccSearch_XPATH", BiilingAccountName1);
			tb.clickUsingJs(By.xpath("(//span[text()='Select Item 1'])[1]"));

//			tb.ThreadWait(1000);
//			do {
//
//				flag = tb.driver.findElement(By.xpath("(//*[text()='" + BiilingAccountName
//						+ "']//parent::div/parent::span/parent::*/parent::td/parent::tr/td//span[@class='slds-radio'])"))
//						.isDisplayed();
//			} while (!flag);
//
//			tb.driver.findElement(By.xpath("(//*[text()='" + BiilingAccountName
//					+ "']//parent::div/parent::span/parent::*/parent::td/parent::tr/td//span[@class='slds-radio'])[1]"))
//					.click();

			tb.type("ServiceAccSearch_XPATH", ServiceAccountName1);
//			tb.ThreadWait(1000);
//			// tb.driver.findElement(By.xpath("//*[text()='"+ServiceAccountName+"']//parent::div/parent::span/parent::*/parent::td/parent::tr/td//span[@class='slds-radio']")).click();
//			tb.driver.findElement(By.xpath(
//					"(//*[contains(text(),'Service')]//parent::div/parent::span/parent::*/parent::td/parent::tr/td//span[@class='slds-radio'])[1]"))
//					.click();

			tb.clickUsingJs(By.xpath("(//span[text()='Select Item 1'])[2]"));

			tb.click("editSaveButton_XPATH");

			CommonSteps.SwitchToFrame();

			tb.ExplicitWait("ViewRecord_XPATH");

			tb.click("ViewRecord_XPATH");

			tb.driver.switchTo().parentFrame();

			tb.ThreadWait(1000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
