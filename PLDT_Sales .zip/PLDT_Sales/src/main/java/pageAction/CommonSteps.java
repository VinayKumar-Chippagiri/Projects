package pageAction;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.LogStatus;

import base.ProjectBeans;
import base.TestBase;
import junit.framework.Assert;


public class CommonSteps {
	static TestBase tb = new TestBase();
	static JavascriptExecutor js = null;

	@SuppressWarnings("static-access")
	public static void clickOnDetail() {
		System.out.println("Click Details tab...");
		/*
		 * tb.driver.findElement(By.xpath("(//li[@data-label='Details']/a)["+rownum+"]")
		 * ).click(); JavascriptExecutor js = (JavascriptExecutor) tb.driver;
		 * js.executeScript("arguments[0].scrollIntoView();",
		 * tb.driver.findElement(By.xpath("(//span[text()='Lead Information'])["+rownum+
		 * "]")));
		 */
		try {
			List<WebElement> myElements = TestBase.driver.findElements(By.xpath("(//li[@data-label='Details']/a)"));
			System.out.println(myElements.size());
			TestBase.driver.findElement(By.xpath("(//li[@data-label='Details']/a)[" + myElements.size() + "]")).click();
		} catch (Exception e) {
			List<WebElement> myElements = TestBase.driver.findElements(By.xpath("//span[text()='Details']"));
			System.out.println(myElements.size());
			TestBase.driver.findElement(By.xpath("(//span[text()='Details'])[" + myElements.size() + "]")).click();
		}
	}

	@SuppressWarnings("static-access")
	public static void ChangeStatus(String locator1, String locator2) {
		System.out.println("Change Status..");
//		JavascriptExecutor js = (JavascriptExecutor) tb.driver;
//
//		js.executeScript("arguments[0].click();", tb.element(locator1));
//		js.executeScript("arguments[0].click();", tb.element(locator2));
		// tb.click("qualifiedStage_XPATH");
		// tb.click("MarkStatus_XPATH");
		tb.clickUsingJs(By.xpath(TestBase.OR.getProperty(locator1)));
		tb.clickUsingJs(By.xpath(TestBase.OR.getProperty(locator2)));
	}

	public static void click_on_Next() {
		tb.click("nextBTN_XPATH");
	}

	@SuppressWarnings("static-access")
	public static void GoToRecord(String SelectListView, String SearchBoxLocator, String RecordName) {
		System.out.println("Select List View: " + SelectListView);
		tb.ThreadWait(2000);
		tb.click("selectListView_XPATH");
		TestBase.driver.findElement(By.xpath("//span[text()='" + SelectListView + "']/parent::*")).click();
		tb.ThreadWait(2000);
		/*
		 * tb.type(SearchBoxLocator, RecordName);
		 * tb.element(SearchBoxLocator).sendKeys(Keys.ENTER); tb.ThreadWait(2000);
		 */
		System.out.println("Click On Record: " + RecordName);
		try {
			tb.ExplicitWait("RecordID_XPATH");
			tb.click(RecordName);
		} catch (Exception e) {
			tb.refreshPage();
			tb.type(SearchBoxLocator, RecordName);
			tb.element(SearchBoxLocator).sendKeys(Keys.ENTER);
			tb.ThreadWait(2000);
			tb.click(RecordName);
		}
	}

	@SuppressWarnings("static-access")
	public static void SwitchToFrame() {
		try {
			// try {
			tb.WaitTillPresenseofElement("Frame_XPATH");
			if (tb.isElementPresent(By.xpath("(//iframe[@title='accessibility title'])"))) {
				List<WebElement> myElements = TestBase.driver
						.findElements(By.xpath("(//iframe[@title='accessibility title'])"));
				System.out.println(myElements.size());
				TestBase.driver.switchTo()
						.frame(TestBase.driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[1]")));
			}
		} catch (Exception e) {
			tb.ThreadWait(5000);
			tb.refreshPage();
			tb.WaitTillPresenseofElement("Frame_XPATH");
			List<WebElement> myElements = TestBase.driver.findElements(By.xpath("//iframe[@title='accessibility title']"));
			System.out.println(myElements.size());
			TestBase.driver.switchTo().frame(TestBase.driver
					.findElement(By.xpath("(//iframe[@title='accessibility title'])[" + myElements.size() + "]")));
			e.printStackTrace();
		}
		// }
//		catch (Exception e) {
//			List<WebElement> myElements = tb.driver.findElements(By.xpath("//iframe[@title='accessibility title']"));
//			System.out.println(myElements.size());
//			tb.driver.switchTo().frame(tb.driver
//					.findElement(By.xpath("(//iframe[@title='accessibility title'])[" + myElements.size() + "]")));
//			e.printStackTrace();
//		}
	}

	@SuppressWarnings("static-access")
	public static void refreshSwitchToFrame() {
		try {
			tb.ThreadWait(5000);
			tb.refreshPage();
			tb.WaitTillPresenseofElement("Frame_XPATH");
			List<WebElement> myElements = TestBase.driver.findElements(By.xpath("//iframe[@title='accessibility title']"));
			System.out.println(myElements.size());
			TestBase.driver.switchTo().frame(TestBase.driver
					.findElement(By.xpath("(//iframe[@title='accessibility title'])[" + myElements.size() + "]")));
		} catch (Exception e2) {
		}
	}

	public static void clickOnNextVlocityBtn() {
		System.out.println("  NEXT button...");
		// tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("//iframe[@title='accessibility
		// title']")));
		for (int i = 1; i <= 3; i++) {
			try {
				if (TestBase.driver.findElement(By.xpath("(//p[text()='Next']/parent::div)[" + i + "]")).isDisplayed()) {
					TestBase.driver.findElement(By.xpath("(//p[text()='Next']/parent::div)[" + i + "]")).click();
					break;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@SuppressWarnings("static-access")
	public static void switchWindow() {
		try {
			String parentWindow = TestBase.driver.getWindowHandle();
			// System.out.println("Parent Window: "+parentWindow);
			Set<String> allWindows = TestBase.driver.getWindowHandles();
			Iterator<String> iterator = allWindows.iterator();
			while (iterator.hasNext()) {
				String child_window = iterator.next();
				if (!parentWindow.equalsIgnoreCase(child_window)) {
					TestBase.driver.switchTo().window(child_window);
					// System.out.println("Child Window: "+child_window);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void clickOnVlocityActionbutton(By locator1, By locator2) {
		tb.clickUsingJs(locator1);
		tb.clickUsingJs(locator2);
	}

	public static void switchToActionFrame() {
		tb.waitFor(By.xpath("(//iframe[contains(@name,'vfFrameId')])[1]"), 60, true);
		tb.driver.switchTo().frame(0);
	}



	public static void clickOnVlocityActionbutton(String locator1, String locator2) {
//		tb.clickUsingJs(By.xpath(TestBase.OR.getProperty(locator1)));
//		tb.clickUsingJs(By.xpath(TestBase.OR.getProperty(locator2)));


		boolean flag = true;
		try {
			do {
				try {
					SwitchToFrame();
					tb.ExplicitWait(locator1);
					tb.jsClick(locator1);
					System.out.println("Clicked on :" + locator1);
					tb.ExplicitWait(locator2);
				} catch (Exception e) {
					tb.refreshPage();
					e.printStackTrace();
					System.out.println("Wait.. Page will Refresh...");
				}
				flag = tb.isElementDisplayed(locator2);
			} while (!flag);
			try {
				tb.jsClick(locator2);
				System.out.println("Clicked on :" + locator2);
			} catch (Exception e) {
				tb.click(locator2);
				System.out.println("Clicked on :" + locator2);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		CommonSteps.SwitchToFrame();
//		tb.waitFor(By.xpath(TestBase.OR.getProperty(locator1)), 30, true);
//		try {
//			tb.clickUsingJs(By.xpath(TestBase.OR.getProperty(locator1)));
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		tb.clickUsingJs(By.xpath(TestBase.OR.getProperty(locator2)));
	}
	// Added below methods by Pranay

	// Pranay :TO Search and open user,quote,opportunity... etc
	public static void switchAndOpen(String Name, String type) {
		js = (JavascriptExecutor) TestBase.driver;
		tb.waitForClickable(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"), 60);
		tb.scrollIntoElement(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"));
		tb.moveToElement(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"));
		js.executeScript(
				"document.querySelector('button.slds-button.slds-button_neutral.search-button.slds-truncate').click()");
		tb.enterValueUsingJs(By.xpath("//*[@placeholder='Search...']"), Name);
		String nameXpath = "//span[@title='" + Name + "']";
		String typeXpath = nameXpath + "/following-sibling::div//span[text()='" + type + "']";
		if (tb.isElementDisplayed(By.xpath(nameXpath))) {
			if (tb.isElementDisplayed(By.xpath(typeXpath))) {
				tb.clickOn(By.xpath(nameXpath));
			}
		}
	}

	public static void switchAndOpenAccount(String Name, String type) {
		JavascriptExecutor js = (JavascriptExecutor) TestBase.driver;
		tb.waitForClickable(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"), 60);
		tb.moveToElement(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"));
		js.executeScript(
				"document.querySelector('button.slds-button.slds-button_neutral.search-button.slds-truncate').click()");
		tb.enterValueUsingJs(By.xpath("//*[@placeholder='Search...']"), Name);
		String nameXpath = "//span[@title='" + Name + "']";
		String typeXpath = nameXpath + "/following-sibling::div//span[contains(text()='" + type + "')]";
		if (tb.isElementDisplayed(By.xpath(nameXpath))) {
			tb.clickOn(By.xpath(nameXpath));
		}
	}
	// Pranay : To mark the case status

	public static void markCaseStatus(By status) {
		js = (JavascriptExecutor) TestBase.driver;
		int temp = 0;
		while (temp <= 5) {
			if (tb.isElementDisplayed(status)) {
				System.out.println(tb.isElementDisplayed(status));
				tb.clickUsingJs(status);
				tb.waitFor(2);
				break;
			}
			tb.clickUsingJs(By.xpath("//button/span[text()='Next']"));
			temp++;
		}
	}

	public static void refreshOrders(int refreshAttempts, int numberOfOrders) {
		String orderNumber = null;
		int ordercount = 0;
		int count = 0;
		while (ordercount < numberOfOrders) {
			try {
				orderNumber = tb.getTextFromPage(By.xpath("//force-list-view-manager-status-info/div/span[1]"));
				ordercount = Integer.parseInt(orderNumber.split(" ")[0]);
				System.out.println(ordercount);
			} catch (Exception e) {
			}
			if (count == refreshAttempts) {
				break;
			}
			tb.refreshPage();
			count++;
		}
	}

	public static void goToCaseOrdersSearchPage(String caseURL) {
		String orderSearchPage = caseURL.replaceFirst("/view", "/related/Orders__r/view");
		tb.gotoURL(orderSearchPage);
	}

	public static void verifyOSPhase(String phase) {
		try {
			WebElement e = TestBase.driver.findElement(By.xpath("//a[text()='" + phase + "']"));
			tb.scrollIntoElement(By.xpath("//a[text()='" + phase + "']"));
			statuscheck(phase, e.getCssValue("fill"));
		} catch (Exception e) {
			Assert.fail();
		}
	}

	private static void statuscheck(String key, String value) {
		String status = null;
		try {
			switch (value) {
			case "rgba(4, 132, 75, 0.95)":
				status = "<b>" + key + "</b> :: " + "Completed state";
				break;
			case "rgb(0, 112, 210)":
				status = "<b>" + key + "</b> :: " + "Ready state";
				break;
			case "rgb(112, 128, 144)":
				status = "<b>" + key + "</b> :: " + "Pending state";
				break;
			case "rgb(208, 2, 27)":
				status = "<b>" + key + "</b> :: " + "Failed state ";
				break;
			default:
				break;
			}
			TestBase.test.log(LogStatus.PASS, "HTML", status);
		} catch (Exception e) {
			Assert.fail();
			TestBase.test.log(LogStatus.FAIL, "Failed to check the status");
		}
	}

	public static void openLink(By locator) {
		String relLink = TestBase.driver.findElement(locator).getAttribute("href");
		tb.navigateURL(relLink);
	}

	public static boolean clickOnTableValue(String page, String value) {
		switch (page) {
		case "accountSearchPage":
		case "contactsSearchPage":
		case "opportunitiesSearchPage":
		case "quotesSearchPage":
		case "assetsSearchPage":
		case "contractsSearchPage":
		case "ordersSearchPage":
			List<WebElement> rows = TestBase.driver.findElements(By.xpath("//table/tbody/tr"));
			for (int i = 0; i < rows.size(); i++) {
				List<WebElement> cols = rows.get(i).findElements(By.xpath("//th/span/a"));
				for (int j = 0; i < cols.size(); j++) {
					if (cols.get(j).getText().equals(value)) {
						js = (JavascriptExecutor) TestBase.driver;
						js.executeScript("arguments[0].click();", cols.get(j));
						return true;
					}
				}
			}
			break;
		case "casesSearchPage":
			break;
		default:
			break;
		}
		return false;
	}

	public static String getIDFromNotificationText() {
		tb.waitFor(By.xpath("//*[@data-aura-class='forceToastMessage']"), 15, true);
		String text = tb.getTextFromPage(By.xpath("//*[@data-aura-class='forceActionsText']"));
		return text.split(" ")[1];
	}

	public static void waitTillLoaderDissapear() {
		tb.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 10, false);
	}

	public static void waitForSearchPage() {
		tb.waitFor(By.xpath("//span[@class='slds-var-p-right_x-small']"), 10, true);
	}

	public static void waitForLeadPage() {
		tb.waitFor(By.xpath("//div[.='Lead']"), 10, true);
	}

	public static void waitForAccountPage() {
		tb.waitFor(By.xpath("//div[.='Account']"), 10, true);
	}

	public static void waitForContactPage() {
		tb.waitFor(By.xpath("//div[.='Contact']"), 10, true);
	}

	public static void waitForOpportunityPage() {
		tb.waitFor(By.xpath("//div[.='Opportunity']"), 10, true);
	}

	public static void waitForQuotePage() {
		tb.waitFor(By.xpath("//div[.='Quote']"), 10, true);
	}

	public static void waitForCasePage() {
		tb.waitFor(By.xpath("//div[.='Case']"), 10, true);
	}

	public static void waitForOrderPage() {
		tb.waitFor(By.xpath("//div[.='Order']"), 10, true);
	}

	public static void waitForContractPage() {
		tb.waitFor(By.xpath("//div[.='Contract']"), 10, true);
	}

	public static void waitForAssetPage() {
		tb.waitFor(By.xpath("//div[.='Asset']"), 10, true);
	}

	public static void waitForOrchestrationPage() {
		tb.waitFor(By.xpath("//div[text()='Orchestration Plan']"), 10, true);
	}

	public static void bulkUpload(String caseURL) {
		try {
			String path =System.getProperty("user.dir")+"\\src\\test\\resources\\excelFiles\\BulkFile.csv";
			tb.gotoURL(caseURL);
			tb.gotoURL("https://pldtoneenterprise--r32sit.lightning.force.com/dataImporter/dataImporter.app");
			//tb.clickUsingJs(By.xpath("//span[text()='Show more actions']"));
			//tb.clickUsingJs(By.xpath("//span[text()='Upload Bulk File']"));
			//tb.waitFor(3);
			//tb.refreshPage();
			tb.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
			tb.clickUsingJs(By.xpath("//a[.='Transaction Assets']"));
			tb.clickUsingJs(By.xpath("//a[.='Add new records']"));
			tb.clickUsingJs(By.xpath("//span[@class='csvType uiOutputText']"));
			TestBase.driver.findElement(By.xpath("//input[@name='file']")).sendKeys(path);
			tb.clickUsingJs(By.xpath("//a[.='Next']"));
		tb.clickUsingJs(By.xpath("//a[.='Next']"));
		tb.clickUsingJs(By.xpath("//a[.='Start Import']"));
		tb.clickUsingJs(By.xpath("//a[.='OK']"));
			tb.gotoURL(caseURL);
			TestBase.test.log(LogStatus.PASS," Bulk File has been Uploaded successfully");
			
		} catch (Exception e) {
		
			 Assert.fail();
		TestBase.test.log(LogStatus.FAIL," Bulk File has been Uploaded successfully");

			 
		}

	}
}