package pageAction;

import org.apache.poi.hssf.record.ObjRecord;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.relevantcodes.extentreports.LogStatus;

import base.TestBase;


public class CreateOrderAction {

	TestBase tb = new TestBase();

	public void NavigateToQuotesPage() {

		System.out.println("Click Quotes button...");
		//TestBase.test.log(LogStatus.INFO, "Click Quotes button");
		try {
			tb.click("quotesMenu_XPATH");
			tb.ExplicitWait("quoteSearchBox_XPATH");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("static-access")
	public void enterQuoteInSearchBox(String QuoteName) {
		try {
			System.out.println("Enter Quote Name: " + QuoteName + "in the Search Box");
			tb.type("quoteSearchBox_XPATH", QuoteName);

			tb.click("quoteRefreshButton_XPATH");
			tb.ThreadWait(2000);

			tb.driver.findElement(By.xpath("//a[@title='" + QuoteName + "']")).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ClickOnCreateQuote() {
		System.out.println("Click on Create Quote Icon...");

		CommonSteps.SwitchToFrame();
		tb.click("CreateQuoteIcon_XPATH");
		tb.ThreadWait(10000);
		tb.driver.switchTo().defaultContent();
	}

	public void updateQuotationValidityPeriod()
	{
		try {
			tb.ExplicitWait("quotesTitle_XPATH");

			((JavascriptExecutor)tb.driver).executeScript("window.scrollBy(0,1800)");
			System.out.println("Click on Quotation Validity Period Edit Icon");
			tb.jsClick("QuotationValidityEditIcon_XPATH");

			tb.ThreadWait(2000);
			tb.type("QuotationValidityEditNumber_XPATH", "12");
			System.out.println("Update Quotation Validity Period");

			tb.click("quotesSaveBtn_XPATH");
			tb.ThreadWait(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ChangestatustoInternalApproval() {
		System.out.println("Change Status to Internal Approval...");

		CommonSteps.ChangeStatus("internalApproval_XPATH", "MarkStatus_XPATH");
		tb.ThreadWait(10000);

	}

	public void ChangestatustoPresented() {
		System.out.println("Change Status to Presented...");

		CommonSteps.ChangeStatus("presented_XPATH", "MarkStatus_XPATH");
		tb.ThreadWait(10000);

	}

	public void ChangestatustoCustomerApproved() {
		System.out.println("Change Status to Customer Approved...");

		CommonSteps.ChangeStatus("customerApproved_XPATH", "MarkStatus_XPATH");
		tb.ThreadWait(10000);

	}

	public void ChangestatustoAccepted() {
		System.out.println("Change Status to Accepted...");

		CommonSteps.ChangeStatus("accepted_XPATH", "MarkStatus_XPATH");
		tb.ThreadWait(10000);

	}

	public void clickOnCreateContract() {

		CommonSteps.SwitchToFrame();
		System.out.println("Click on Create Contract...");
		tb.click("createContract_XPATH");
		tb.driver.switchTo().defaultContent();
		tb.ThreadWait(4000);
	}

	public void clickOnNext()
	{
		CommonSteps.SwitchToFrame();
		System.out.println("Click on Next Button...");
		tb.click("nextButton_XPATH");
		tb.driver.switchTo().defaultContent();
		tb.ThreadWait(4000);
	}

	public void clickOnRelatedTab() {

		try {
			System.out.println("Click on Related Tab");
			tb.click("quotesRelatedTab_XPATH");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String clickOnOrdersTitle() {

		String quoteNumber = null;
		String quotesString = null;
		String orderString=null;

		try {

			int i=0;
			do
			{
				tb.driver.navigate().refresh();
				tb.ThreadWait(4000);
				tb.jsClink_LinkText("Related");
				tb.ThreadWait(4000);

				((JavascriptExecutor)tb.driver).executeScript("window.scrollBy(0,1800)");
				tb.ThreadWait(2000);
				//tb.Scroll("quotesOrdersTitle_XPATH");

				System.out.println("OrderCount Text: "+tb.getText("OrderCount_XPATH"));
				quotesString = tb.getText("OrderCount_XPATH");
				orderString=tb.getText("OrderCount_XPATH");
				if(quotesString.contains("0")) {

					quotesString = tb.getText("OrderCount2_XPATH");
				}
				quoteNumber = quotesString.substring(1, 2);
				i = Integer.parseInt(quoteNumber);
			}while(i<1);

			System.out.println("Click on Orders Title..");
			if(orderString.contains("0")) {

				tb.jsClick("quotesOrdersTitle2_XPATH");
			}

			else {

				tb.jsClick("quotesOrdersTitle_XPATH");
			}
				quoteNumber = tb.getText("quotesOrderNumber_XPATH");
			} catch (Exception e) {
				e.printStackTrace();
			}
			return quoteNumber;
		}

		@SuppressWarnings("static-access")
		public void clickOnOrderLink(String OrderNumber) {

			System.out.println("Click on Order Number: " + OrderNumber);
			try {
				tb.driver.findElement(By.xpath("//a[@title='" + OrderNumber + "']")).click();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		@SuppressWarnings("static-access")
		public void clickOnViewDecomposition() {

			try {
				Thread.sleep(4000);
//				System.out.println("Click on Details tab");
//				tb.ExplicitWait("quotesDetailsTab_XPATH");
//				tb.click("quotesDetailsTab_XPATH");
//				Thread.sleep(4000);

				//CommonSteps.SwitchToFrame();
				tb.refreshPage();
				tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[1]")));

//				System.out.println("Click on ToggleIcon");
//				tb.click("quotesToggleIcon_XPATH");
//				tb.ExplicitWait("quotesViewDecomposition_XPATH");

				//CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "quotesViewDecomposition_XPATH");
				System.out.println("Click on ViewDecomposition");
			//tb.click("quotesViewDecomposition_XPATH");
				tb.waitFor(3);
          tb.clickUsingJs(By.xpath(tb.OR.getProperty("quotesViewDecomposition_XPATH")));


				//tb.driver.switchTo().defaultContent();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

		@SuppressWarnings("static-access")
		public void clickOnViewOrchestrationPlan() {



			try {
			//Thread.sleep(4000);
			// tb.refreshPage();
			// tb.driver.switchTo().frame(tb.driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[1]")));
			// tb.ExplicitWait("quotesViewOrchestrationPlan_XPATH");
			CommonSteps.refreshSwitchToFrame();
			System.out.println("Click on View Orchestration Plan Icon");
			tb.click("quotesViewOrchestrationPlan_XPATH");
			//Thread.sleep(4000);



			} catch (Exception e) {
			e.printStackTrace();
			}
			}

		@SuppressWarnings("static-access")
		public void switchToOrchestrationPlanWindow()
		{
			try {
				CommonSteps.switchWindow();
				CommonSteps.refreshSwitchToFrame();
				tb.scrollElementIntoView("quotesCreateSOStatus_XPATH");
				boolean status = false;
				status = tb.isElementDisplayed("quotesCreateSOStatus_XPATH");

//				if(status)
//				{
//					TestBase.test.log(LogStatus.PASS, "Displayed - Inventory Allocated");
//				}
//
//				else
//				{
//					TestBase.test.log(LogStatus.ERROR, "Not Displayed - Inventory Allocated");
//				}

                tb.moveToElement(By.xpath(tb.OR.getProperty("quotesCreateSOStatus_XPATH")));
				tb.clickUsingJs(By.xpath(tb.OR.getProperty("quotesCreateSOStatus_XPATH")));
				tb.driver.switchTo().defaultContent();
				Thread.sleep(4000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void inventoryAllocatedPage()
		{

			try {
				//CommonSteps.clickOnDetail();
				Thread.sleep(4000);
				String state = tb.getText("quotesInventoryAllocatedState_XPATH");

				if(state.equalsIgnoreCase("Completed"))
					TestBase.test.log(LogStatus.INFO, "Create SO state is Completed");
				else
					TestBase.test.log(LogStatus.ERROR, "Create SO state is not Completed");

			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

		public void goToQuote() {
			System.out.println("Go to Quote..");

			tb.ExplicitWait("gotoQuote_XPATH");
			tb.click("gotoQuote_XPATH");

			tb.WaitTillPresenseofElement("quotesRelatedTab_XPATH");
			//tb.click("quotesRelatedTab_XPATH");
			tb.jsClink_LinkText("Related");


		}


	}