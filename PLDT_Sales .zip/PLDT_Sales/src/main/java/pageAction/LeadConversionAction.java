package pageAction;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import base.TestBase;

public class LeadConversionAction {

	TestBase tb = new TestBase();

	public void selectList() {

		tb.click("selectListView_XPATH");

	}

	public void enterQueueName(String queuename) {
		tb.element("queueSearchBox_XPATH").clear();

		tb.type("queueSearchBox_XPATH", queuename);

	}

	public void selectQueue() {

		
			tb.retryClick("selectQueue_XPATH");
		
	}
	public void searchLead(String locator,String leadname) {

		tb.type(locator, leadname);
		//tb.driver.findElement(By.xpath("//input[@name='Lead-search-input']")).sendKeys(Keys.ENTER); 
		tb.element(locator).sendKeys(Keys.ENTER); 

	}

	public void ClickOnLeadRecord() {

		tb.click("leadRecordID_XPATH");

	}

	public void creditCheck() {
		try {
			tb.click("editCreditCheck_XPATH");
			tb.jsClick("creditCheckBox_XPATH");
			/*
			 * JavascriptExecutor js = (JavascriptExecutor) tb.driver;
			 * js.executeScript("arguments[0].click();",
			 * tb.element("creditCheckBox_XPATH")); Thread.sleep(2000);
			 */
			tb.click("LeadConvertSaveBTN_XPATH");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@SuppressWarnings("static-access")
	public void convertLead() {
		try {
			JavascriptExecutor js = (JavascriptExecutor) tb.driver;
			// tb.click("ConvertStage_XPATH");
			// tb.click("MarkStatus_XPATH");
			js.executeScript("arguments[0].click();", tb.element("ConvertStage_XPATH"));
			Thread.sleep(2000);
			js.executeScript("arguments[0].click();", tb.element("MarkStatus_XPATH"));
			Thread.sleep(8000);
			tb.retryClick("convertLeadcompletionBTN_XPATH");
			Thread.sleep(10000);
			tb.takeScreenshot();
			tb.click("GoToLeads_XPATH");

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	@SuppressWarnings("static-access")
	public void convertLead(String checkOpptyBox) {
		try {
			JavascriptExecutor js = (JavascriptExecutor) tb.driver;
			// tb.click("ConvertStage_XPATH");
			// tb.click("MarkStatus_XPATH");
			js.executeScript("arguments[0].click();", tb.element("ConvertStage_XPATH"));
			Thread.sleep(2000);
			js.executeScript("arguments[0].click();", tb.element("MarkStatus_XPATH"));
			Thread.sleep(8000);
			/*
			 * if (checkOpptyBox.contentEquals("Y")) {
			 * tb.click("convertOpptyCheckbox_XPATH"); }
			 */
			tb.retryClick("convertLeadcompletionBTN_XPATH");
			Thread.sleep(10000);
			tb.takeScreenshot();
			tb.click("GoToLeads_XPATH");

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void CancelLeadConversion() {

		tb.click("closebtn_XPATH");
	}
}
