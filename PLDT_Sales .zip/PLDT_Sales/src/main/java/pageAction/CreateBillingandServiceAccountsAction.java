package pageAction;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.TestBase;

public class CreateBillingandServiceAccountsAction extends TestBase{

	TestBase tb = new TestBase();

	// buttons
	public void clickNewBilling() {
		System.out.println("Click on New Billing button");
		CommonSteps.switchToActionFrame();
		CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "newBilling_XPATH");
		tb.driver.switchTo().parentFrame();
	}

	public void clickNewBillingAgg() {
		System.out.println("Click on New Billing Aggregator button");

		tb.click("newBillingAgg_XPATH");
	}

	public void clickNewService() {
		System.out.println("Click on New Service button");
	
		CommonSteps.switchToActionFrame();
		CommonSteps.clickOnVlocityActionbutton("Menue_XPATH", "newService_XPATH");
		tb.driver.switchTo().parentFrame();

	}

	public void clickCancel() {
		System.out.println("Click on Cancel button");

		tb.click("newBilling_Cancel_XPATH");
	}

	public void clickSave() {
		System.out.println("Click on Save button");

		tb.jsClick("newBilling_Save_XPATH");
	}

	public void clickRefresh() {
		System.out.println("Click on Refresh button");

		tb.retryClick("accountSearchRefresh_XPATH");
	}

	public void deleteAccountName() {
		System.out.println("Click X button to delete Account Name");

		tb.click("newBilling_XAccountName_XPATH");
	}


	// picklists
	public void selectLOB(String lob) {
		System.out.println("Select LOB :"+lob);

		tb.click("newBilling_LOB_XPATH"); tb.ThreadWait(1000);
		
			try {

				tb.clickUsingJs(By.xpath("(//li//a[@title='SMART'])[1]"));

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		
	

	}

	public void selectCurrency(String currency) {

		if(!currency.isEmpty()) {
			System.out.println("Select Currency: "+currency);
			tb.click("newBilling_Currency_XPATH");
			tb.click(currency);
		}
	}

	public void selectAllAccountsListView() {
		System.out.println("Select Accounts List view");

		tb.click("accountRecentListView_XPATH");
		tb.click("allAccounts_XPATH");
	}

	public void selectServiceStatus(String status) {
		System.out.println("Select status of new service");

		tb.click("newService_Status_XPATH");
		tb.click(status);
	}

	public void selectServiceContact(String contact) {
		System.out.println("Select Contact of new service");

		tb.type("newService_Contact_XPATH", contact);
		tb.click("newService_SearchContact_XPATH");
		tb.ThreadWait(1000);
		tb.click(contact);
	}

	// text inputs
	public void enterAccountName(String name) {
		System.out.println("Enter Account Name");

		//tb.type("newBilling_AccountName_XPATH", name);
		tb.type("newBilling_AccountName_XPATH", name);

	
	}

	public void enterStreet(String street) {
		System.out.println("Enter Street");
		tb.ThreadWait(2000);
		//tb.type("newBilling_Street_XPATH", street);
		tb.typeDataTo(By.xpath(OR.getProperty("newBilling_Street_XPATH")), street);
	}

	public void enterCity(String city) {
		System.out.println("Enter City");

		//tb.type("newBilling_City_XPATH", city);
		tb.typeDataTo(By.xpath(OR.getProperty("newBilling_City_XPATH")), city);
	}

	public void enterStateProvince(String province) {
		System.out.println("Enter State/Province");

    	tb.clickUsingJs(By.xpath(OR.getProperty("newBilling_StateProv_XPATH")));
    	//tb.scrollIntoElement(By.xpath("//*[text()='"+province+"']"));
   	    tb.jsClink_LinkText(province);


	}

	public void enterZipCode(String zip) {
		System.out.println("Enter Zip/Postal code");

		//tb.type("newBilling_Zipcode_XPATH", zip);
		tb.typeDataTo(By.xpath(OR.getProperty("newBilling_Zipcode_XPATH")), zip);
	}

	public void enterCountry(String country) {
		System.out.println("Enter Country");

		//tb.type("newBilling_Country_XPATH", country);
	    tb.click("newService_country_XPATH");
   	   //tb.jsClink_LinkText(country);
   	   tb.clickUsingJs(By.xpath("//*[text()='"+country+"']"));
   	    
   	    //tb.clickDropdownValue(country);
	}

	public void enterAccountNameToSearch(String searchText) {
		System.out.println("Enter Account name to search");

		tb.type("accountSearchThisListInput_XPATH", searchText);
		tb.driver.findElement(By.xpath("//input[@name='Account-search-input']")).sendKeys(Keys.ENTER);
	}

	public void enterServiceRecipientName(String name) {
		System.out.println("Enter Recipient name of New Service");

		tb.type("newService_RecipientName_XPATH", name);
	}

	public void enterServiceRecipientNo(String contactNo) {
		System.out.println("Enter Recipient name of New Service");

		tb.type("newService_RecipientNo_XPATH", contactNo);
	}

	// links
	public void clickAccountNameLink(String accountName) {
		System.out.println("Click on Account Name linktext");

		tb.retryClick(accountName);
	}

	public void enterIndustry(String industry) {
		tb.selectFromList("newBillingIndustry_XPATH", industry);
	}

	public void enterIndustrySubType(String industrySubType) {
		tb.selectFromList("newBillingIndustrySubType_XPATH", industrySubType);
	}

	public void enterAccountTypeCode(String accountTypeCode) {
		try {

			if(!accountTypeCode.isEmpty()) {
				System.out.println("Enter Account Type Code: "+accountTypeCode);


				tb.type("newBillingAccountTypeCode_XPATH", accountTypeCode.trim());

				tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.getProperty("newBillingSearchAccountType_XPATH"))));
				tb.click("newBillingSearchAccountType_XPATH");

				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("newBillingSearchAccountTypeResultsHeader_XPATH"))));

				//tb.driver.findElement(By.xpath("//a[@title='"+accountTypeCode+"']")).click();
				//tb.jsClick("AccountTypeCode_XPATH");
				/*
				 * WebElement element =
				 * tb.driver.findElement(By.linkText(accountTypeCode)); JavascriptExecutor
				 * js = (JavascriptExecutor)tb.driver;
				 * js.executeScript("arguments[0].click();",element );
				 */
				tb.jsClink_LinkText(accountTypeCode);



				System.out.println("Clicked...");
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public void enterForTheAccountOf(String accountOf) {
		if(!accountOf.isEmpty()) {
			System.out.println("Enter For the Account Of");
			tb.type("newBillingForTheAccountOf_XPATH", accountOf);
		}
	}

	public void enterAccountOfBizAccount(String bizAccount) {
		if(!bizAccount.isEmpty()) {
			try {
				System.out.println("Enter For the Account Of Biz Account: "+bizAccount);
				tb.type("newBillingBizAccount_XPATH", bizAccount);

				tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.getProperty("newBillingSearchBizAccount_XPATH"))));
				tb.click("newBillingSearchBizAccount_XPATH");

				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("newBillingSearchBizAccountTypeResultsHeader_XPATH"))));
				tb.click(bizAccount);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void enterAssigneeCIFirstName(String firstName) {
		if(!firstName.isEmpty()) {
			System.out.println("Enter Assignee CI First Name: "+firstName);
			tb.type("newBillingAssigneeCIFirstName_XPATH", firstName);
		}
	}

	public void enterAssigneeCIMiddleName(String middleName) {
		if(!middleName.isEmpty()) {
			System.out.println("Enter Assignee CI Middle Name: "+middleName);
			tb.type("newBillingAssigneeCIMidName_XPATH", middleName);
		}
	}

	public void enterAssigneeCILastName(String lastName) {
		if(!lastName.isEmpty()) {
			System.out.println("Enter Assignee CI Last Name: "+lastName);
			tb.type("newBillingAssigneeCILastName_XPATH", lastName);
		}
	}

	public void enterCreditLimit(String CreditLimit) {
		if(!CreditLimit.isEmpty()) {
			System.out.println("Enter Credit Limit: "+CreditLimit);
			tb.type("newBillingCreditLimit_XPATH", CreditLimit);
		}
	}

	public void enterTHSStatus(String thsStatus) {
		tb.ThreadWait(500);
		tb.click("newBillingTHSStatus_XPATH");
		tb.click(thsStatus);
	}

	public void enterTHSRating(String thsRating) {
		tb.selectFromList("newBillingTHSRating_XPATH", thsRating);
	}


	public void enterSubscription(String subscription) {
		if(!subscription.isEmpty()) {
			try {
				System.out.println("Enter For the Account Of Biz Account: "+subscription);
				tb.type("newBillingSubscription_XPATH", subscription);

				tb.ThreadWait(1000);
				tb.element("newBillingSubscription_XPATH").sendKeys(Keys.ENTER);

				/*
				 * tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.
				 * getProperty("newBillingSearchSubscription_XPATH"))));
				 * tb.click("newBillingSearchSubscription_XPATH");
				 */
				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("newBillingSubscriptionResultsHeader_XPATH"))));
				tb.jsClink_LinkText(subscription);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void enterServiceProvider(String serviceProvider) {
		tb.selectFromList("newBillingServiceProvider_XPATH", serviceProvider);
	}

	public void enterNotifyMailId(String notifyMailId) {
		if(!notifyMailId.isEmpty()) {
			System.out.println("Enter Notify Mail Id: "+notifyMailId);
			tb.type("newBillingNotifyEmailID_XPATH", notifyMailId);
		}
	}

	public void selectCreditClass(String creditClass) {
		tb.selectFromList("newBillingCreditClass_XPATH", creditClass);
	}

	public void enterNotifyMobile(String notifyMobileNo) {
		if(!notifyMobileNo.isEmpty()) {
			System.out.println("Enter notifyMobileNo: "+notifyMobileNo);
			tb.type("newBillingNotifyMobileNo_XPATH", notifyMobileNo);
		}
	}

	public void enterPhone(String phone) {
		if(!phone.isEmpty()) {
			System.out.println("Enter phone: "+phone);
			tb.type("newBillingPhone_XPATH", phone);
		}
	}

	public void selectAccountPaymentType(String accountPaymentType) {
		tb.selectFromList("newBillingAccountPaymentType_XPATH", accountPaymentType);
	}

	public void selectTaxExemption(String taxExemption) {
		tb.selectFromList("newBillingTaxExemption_XPATH", taxExemption);
	}

	public void enterTaxProfile(String taxProfile) {
		if(!taxProfile.isEmpty()) {
			try {
				//tb.scrollElementIntoView("newBillingTaxProfile_XPATH");
				System.out.println("Enter taxProfile: "+taxProfile);
				tb.type("newBillingTaxProfile_XPATH", taxProfile);

				tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.getProperty("newBillingSearchTaxProfile_XPATH"))));
				tb.click("newBillingSearchTaxProfile_XPATH");

				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("newBillingTaxProfileResultsHeader_XPATH"))));
				tb.click(taxProfile);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void selectBillFrequency(String billFrequency) {
		//tb.selectFromList("newBillingBillFrequency_XPATH", billFrequency);

		tb.click("newBillingBillFrequency_XPATH"); tb.ThreadWait(1000);
		for (int i = 1; i <2; i++) {

			try {
				WebElement element = tb.driver.findElement(By.xpath("(//li//a[@title='Monthly'])["+i+"]"));
				JavascriptExecutor js = (JavascriptExecutor)tb.driver;
				js.executeScript("arguments[0].click();",element );
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public void enterVIPCode(String VIPCode) {
		if(!VIPCode.isEmpty()) {
			try {
				System.out.println("Enter VIPCode: "+VIPCode);
				tb.type("newBillingVIPCode_XPATH", VIPCode);

				tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.getProperty("newBillingSearchVIPCode_XPATH"))));
				tb.click("newBillingSearchVIPCode_XPATH");

				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.getProperty("newBillingVIPCodeResultsHeader_XPATH"))));
				tb.ThreadWait(1000);
				tb.jsClink_LinkText(VIPCode);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void enterBillDispatchMethod(String BillDispatchMethod) {
		if(!BillDispatchMethod.isEmpty()) {
			try {
				System.out.println("Enter BillDispatchMethod: " + BillDispatchMethod);
				tb.ThreadWait(250);
				tb.type("newBillingBillDispatchMethod_XPATH", BillDispatchMethod);
				tb.ThreadWait(1000);

				/*
				 * WebElement element =
				 * tb.driver.findElement(By.linkText(BillDispatchMethod));
				 * JavascriptExecutor js = (JavascriptExecutor)tb.driver;
				 * js.executeScript("arguments[0].click();",element );
				 *
				 * tb.element("newBillingBillDispatchMethod_XPATH").sendKeys(Keys.ENTER);
				 *
				 * tb.ExplicitWait("newBillingBillDispatchResultsHeader_XPATH");
				 * tb.ThreadWait(250);
				 */

				tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.
						getProperty("newBillingSearchBillDispatch_XPATH"))));
				tb.jsClick("newBillingSearchBillDispatch_XPATH");

				tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.
						getProperty("newBillingBillDispatchResultsHeader_XPATH"))));
				tb.ThreadWait(1000);

				tb.jsClink_LinkText(BillDispatchMethod);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void enterBillCycle(String BillCycle) {
		if(!BillCycle.isEmpty()) {
			try {
				System.out.println("Enter BillCycle: " + BillCycle);
				tb.ThreadWait(250);
				//tb.click("newBillingBillCycle_XPATH");
				tb.ThreadWait(250);
				tb.type("newBillingBillCycle_XPATH", BillCycle);
				tb.ThreadWait(500);
				tb.element("newBillingBillCycle_XPATH").sendKeys(Keys.ENTER);
				tb.ThreadWait(1000);
				tb.ExplicitWait("newBillingBillCycleHeader_XPATH");
				tb.ThreadWait(1000);

				/*
				 * tb.wait.until(ExpectedConditions.elementToBeClickable(By.xpath(tb.OR.
				 * getProperty("newBillingSearchBillCycle_XPATH"))));
				 * tb.click("newBillingSearchBillCycle_XPATH");
				 *
				 * tb.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(tb.OR.
				 * getProperty("newBillingBillCycleResultsHeader_XPATH"))));
				 */
				tb.jsClink_LinkText(BillCycle);
				tb.ThreadWait(250);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void enterBillingAddrLine1(String BillingAddrLine1) {
		if(!BillingAddrLine1.isEmpty()) {
			System.out.println("Enter BillingAddrLine1: "+BillingAddrLine1);
			tb.type("newBillingAddressLine1_XPATH", BillingAddrLine1);
		}
	}

	public void enterBillingAddrLine2(String BillingAddrLine2) {
		if(!BillingAddrLine2.isEmpty()) {
			System.out.println("Enter BillingAddrLine2: "+BillingAddrLine2);
			tb.type("newBillingAddressLine2_XPATH", BillingAddrLine2);
		}
	}

	public void enterBillingAddrLine3(String BillingAddrLine3) {
		if(!BillingAddrLine3.isEmpty()) {
			System.out.println("Enter BillingAddrLine3: "+BillingAddrLine3);
			tb.type("newBillingAddressLine3_XPATH", BillingAddrLine3);
		}
	}

	public void enterBillingCountry(String BillingCountry) {
		tb.selectFromList("newBillingCountry_XPATH", BillingCountry);
	}

	public void enterBillingCity(String BillingCity) {
		try {
			if(!BillingCity.isEmpty()) {
//				System.out.println("Enter BillingCity: "+BillingCity);
				//tb.type("newBillingCity_XPATH", BillingCity);
				tb.typeDataTo(By.xpath(OR.getProperty("newBillingCity_XPATH")), BillingCity);
				tb.ThreadWait(1000);
				tb.element("newBillingCity_XPATH").sendKeys(Keys.ENTER);
				tb.ThreadWait(1000);
				tb.ExplicitWait("newBillingCityHeatder_XPATH");
				tb.ThreadWait(1000);
				tb.jsClink_LinkText(BillingCity);
				tb.ThreadWait(1000);
//				String billCity="//div[@title="+"'"+BillingCity+"'"+"]";
//			tb.clickUsingJs(By.xpath(billCity));


			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void enterBarangay(String Barangay) {
		try {
			if(!Barangay.isEmpty()) {
				System.out.println("Enter Barangay: "+Barangay);
				//tb.type("newBillingBarangay_XPATH", Barangay);
				tb.typeDataTo(By.xpath(OR.getProperty("newBillingBarangay_XPATH")), Barangay);
				tb.ThreadWait(300);
				tb.element("newBillingBarangay_XPATH").sendKeys(Keys.ENTER);
				tb.ThreadWait(500);
				tb.ExplicitWait("newBillinBarangayHeader_XPATH");
				tb.ThreadWait(1000);
				tb.jsClink_LinkText(Barangay);
				tb.ThreadWait(1000);
//				String Barang="//div[@title="+"'"+Barangay+"'"+"]";
//			tb.clickUsingJs(By.xpath(Barang));

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void enterBillingStateProvince(String BillingStateProvince) {
		try {
			if(!BillingStateProvince.isEmpty()) {
				System.out.println("Enter BillingStateProvince: "+BillingStateProvince);
				tb.type("newBillingStateProvince_XPATH", BillingStateProvince);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void enterBillingBillingZipPostal(String BillingZipPostal) {
		try {
			if(!BillingZipPostal.isEmpty()) {
				System.out.println("Enter BillingStateProvince: "+BillingZipPostal);
				//tb.type("newBillingZipPostalCode_XPATH", BillingZipPostal);
				tb.typeDataTo(By.xpath(OR.getProperty("newBillingZipPostalCode_XPATH")), BillingZipPostal);
				tb.ThreadWait(1000);
				tb.element("newBillingZipPostalCode_XPATH").sendKeys(Keys.ENTER);
				tb.ThreadWait(1000);
				tb.ExplicitWait("newbillingZipPostalCodeHeader_XPATH");
				tb.ThreadWait(1000);
				tb.jsClink_LinkText(BillingZipPostal);
				tb.ThreadWait(1000);
//				String Barang="//div[@title="+"'"+BillingZipPostal.toString()+"'"+"]";
//				tb.clickUsingJs(By.xpath(BillingZipPostal));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void selectServiceBillingAccount(String billingAccount) {
		if(!billingAccount.isEmpty()) {
			try {
				System.out.println("Enter billingAccount: " + billingAccount);
				tb.ThreadWait(250);
				tb.click("newService_BillingAccount_XPATH");
				tb.ThreadWait(250);
				tb.type("newService_BillingAccount_XPATH", billingAccount);
				tb.ThreadWait(250);

				tb.driver.findElement(By.xpath("(//div[@title='"+billingAccount+"'])[1]")).click();

				tb.ThreadWait(250);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void enterServiceAccountNumber(String accountNumber) {
		if(!accountNumber.isEmpty()) {
			System.out.println("Enter newService_AccountNumber: "+accountNumber);
			tb.click("newService_AccountNumber_XPATH");
			tb.type("newService_AccountNumber_XPATH", accountNumber);
		}
	}

	public void editServicePhoneNumber(String phoneNumber) {
		/*
		 * tb.scrollElementIntoView("newService_EditPhone_XPATH"); JavascriptExecutor js
		 * = (JavascriptExecutor) tb.driver;
		 * js.executeScript("window.scrollBy(0,-250)");
		 */
		tb.click("newService_EditPhone_XPATH");
		tb.type("newService_Phone_XPATH", phoneNumber);
		tb.ThreadWait(1000);
		/*
		 * try { tb.driver.findElement(By.
		 * xpath("//label[text()='Zip/Postal Code']/following-sibling::div//input")).
		 * click(); } catch (Exception e) {
		 * System.out.println("Not able to click the element"); e.printStackTrace(); }
		 */
	}

	public void clickSaveOnDetailsTab()
	{
		tb.jsClick("newService_Save_XPATH");
		tb.ThreadWait(1000);
	}
}

