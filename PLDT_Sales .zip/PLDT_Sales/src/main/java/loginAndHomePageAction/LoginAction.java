package loginAndHomePageAction;

import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import base.TestBase;

public class LoginAction {

	TestBase tb = new TestBase();

	public void enter_username(String username) {

		tb.type("username_XPATH", username);

	}

	public void enter_password(String password) {

		tb.type("password_XPATH", password);
	}

	public void click_on_login_Btn() {

		tb.click("login_XPATH");

	}

	public void verify_login() {
		boolean flag = false;
		try {
			if (tb.element("remindmelater_XPATH").isDisplayed())

				tb.element("remindmelater_XPATH").click();
			flag = true;

			if (flag == false) {

				if (tb.element("error_XPATH").isDisplayed()) {

					Assert.assertTrue(false, tb.element("error_XPATH").getText());
					;
				}
			}
		} catch (NoSuchElementException e) {

			System.out.println(e.getMessage());
		}

	}

	public void logout() {
		System.out.println("Logout current user...");

		tb.jsClick("user_XPATH");
		tb.jsClick("logout_XPATH");

	}
}
