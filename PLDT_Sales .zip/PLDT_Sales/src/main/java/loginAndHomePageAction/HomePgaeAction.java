package loginAndHomePageAction;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.TestBase;

public class HomePgaeAction {

	TestBase tb=new TestBase();	
	
	public void click_on_Launcer() {
		TestBase.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(TestBase.OR.getProperty("appLauncher_XPATH"))));
		 
		tb.click("appLauncher_XPATH");
		
	}
	public void enter_Value_In_Searchbox(String value) {
		tb.type("searchApps_XPATH", value);
		
	}
	
    @SuppressWarnings("static-access")
	public void click_on_value() {
    	
   tb.driver.findElement(By.xpath("//p[@class='slds-truncate']/b")).click();;
		
   
   }
    
    
}
