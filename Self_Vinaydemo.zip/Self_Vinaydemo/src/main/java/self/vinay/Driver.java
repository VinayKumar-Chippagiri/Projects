package self.vinay;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Driver {
	static WebDriver driver = null;
	
	public static  WebDriver open(String browserType) {
		switch (browserType) {
		case "Chrome":
			 WebDriverManager.chromedriver().setup();
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--remote-allow-origins=*","--start-maximized");
				 driver = new ChromeDriver(options);	
				 driver.get("https://blazedemo.com/index.php");
		}
		return null;
		
	}
	
	public static void LaunchUrl() {
		 
		 driver.get("https://blazedemo.com/index.php");
		
	}
	
	public static void waitFor(int i) {
		try {
			Thread.sleep(i*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void verifyTitle() {
		waitFor(5);
	    String Title = driver.findElement(By.xpath("(//div[@class='container']//h1)")).getText();
	    System.out.println(Title);
	    Assert.assertEquals("Welcome to the Simple Travel Agency!", Title);
	}
	
	public static void checkingTabs() {
		String winHandleBefore = driver.getWindowHandle();
		waitFor(5);
		WebElement Destination =driver.findElement(By.xpath("(//p//a)[1]"));
		Destination.click();
		waitFor(5);
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		// Use the list of window handles to switch between windows
		if ((tabs.size()) > 1) {
			driver.switchTo().window(tabs.get(tabs.size() - 1));
			driver.close();
			driver.switchTo().window(winHandleBefore);
		} 
		String CurrentUrl = driver.getCurrentUrl();
		if(CurrentUrl.contains("vacation")) {
			System.out.println("Url contains Vacation");
		}
		else {
			System.out.println("Url does not contains Vacation");
		}
		
		driver.navigate().back();
		
	}

}
