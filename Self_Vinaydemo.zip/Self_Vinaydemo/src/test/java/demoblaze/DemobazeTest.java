package demoblaze;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DemobazeTest {
	WebDriver driver;
	self.vinay.Driver demoDriver = new self.vinay.Driver();
	
	@BeforeTest(description= "Opening the browser")
	public  void Setup() {
		demoDriver.open("Chrome");
		System.out.println("Chrome browser is Opened and Website url is passed");
		
	}
	
	@Test(description = "Verifying the Title", priority = 1)
	public void VerifytheTitle() {
		demoDriver.verifyTitle();
		System.out.println("Verifying Title");
	}
	
	@Test(description = "Checking the Tabs", priority = 2)
	public void CheckingTabs() {
		demoDriver.checkingTabs();
		System.out.println("Checking the Tabs");
		
	}

}
