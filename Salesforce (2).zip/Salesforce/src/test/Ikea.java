package test;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class Ikea {
	WebDriver driver;
	
	 @Test
	  public void kitchen() throws InterruptedException {
		 String winHandleBefore = driver.getWindowHandle();
//		 driver.findElement(By.cssSelector(".gmtakJ")).click();
		 driver.findElement(By.xpath("//button[text()='Your saved designs']")).click();
		 Thread.sleep(5000);
		 driver.findElement(By.cssSelector(".cKsEkZ")).click();
		 Thread.sleep(5000);
		 ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
			System.out.println(tabs.size());
			driver.switchTo().window(tabs.get(tabs.size() - 1));
			driver.switchTo().defaultContent();
			
			    driver.findElement(By.id("username")).sendKeys("prodau@yopmail.com");
			    driver.findElement(By.id("password")).sendKeys("Tester@1234");
			    driver.findElement(By.id("username")).click();
			    driver.findElement(By.cssSelector(".btn--emphasised > .btn__inner")).click();
	   Thread.sleep(5000);
	   driver.close();
		driver.switchTo().window(winHandleBefore);
	    driver.findElement(By.cssSelector(".sc-bwsPYA > .Link__LinkContent-sc-q3uobp-0")).click();
	    Thread.sleep(10000);
	    driver.switchTo().frame(0);
	    driver.findElement(By.cssSelector(".cta-primary-alt-l > span")).click();
	    driver.findElement(By.id("step-design")).click();
	    
	    WebElement element = driver.findElement(By.id("step-design"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    
	    
	      WebElement element2 = driver.findElement(By.tagName("body"));
	      Actions builder1 = new Actions(driver);
	      builder.moveToElement(element2, 0, 0).perform();
	    
	    driver.findElement(By.cssSelector(".icon-catalog-cabinets")).click();
	    driver.findElement(By.cssSelector("li:nth-child(1) li:nth-child(1) > .bt-text")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector("li:nth-child(1) > article")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector("li:nth-child(2) > article")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector("li:nth-child(3) > article")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector("li:nth-child(4) > article")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector("li:nth-child(5) > article")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector(".close:nth-child(2) svg")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.id("canvas")).click();
	    driver.findElement(By.cssSelector(".icon-action-save > svg")).click();
	    Thread.sleep(10000);
	    driver.findElement(By.id("input-save-name")).click();
	    driver.findElement(By.id("input-save-name")).sendKeys("My IKEA Kitchen_SID");
	    driver.findElement(By.cssSelector(".cta-primary-alt-xl")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector(".icon-view-close:nth-child(2) use")).click();
	    driver.switchTo().defaultContent();
	    driver.findElement(By.cssSelector(".selenium-projectCard-details-button")).click();
	    Thread.sleep(10000);
	    driver.findElement(By.cssSelector(".iHVWho")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector(".iHVWho")).click();
	    driver.findElement(By.cssSelector(".selenium-username")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.cssSelector(".sc-hbqYmb > span:nth-child(2)")).click();
 }

@BeforeTest
public void beforeTest() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get("https://kitchen.planner.ikea.com/au/en/");
	  driver.manage().window().maximize();
	  Thread.sleep(10000);

}

 @AfterTest
 public void afterTest() throws InterruptedException {
	  Thread.sleep(6000);
	  
 }

}
