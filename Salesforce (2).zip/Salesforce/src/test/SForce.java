package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SForce {
	WebDriver driver;
	WebElement uname,password;
  @Test
  public void f() throws InterruptedException {
	  uname=driver.findElement(By.xpath("//input[@id='username']"));
	  uname.sendKeys("chippagiri-vinay.kumar@capgemini.com.r32sit");
	  
	  password=driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/div[2]/div[3]/form/input[1]"));
	  password.sendKeys("Vinay@2022");
	  password.submit();
	  Thread.sleep(2000);
	  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  
	  driver.navigate().to("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/QLI_Account_Details__c/a6E1s0000004hWdEAI/view");
	  driver.findElement(By.xpath("//button[@title='Edit CSP Account Sync Status']")).click();
		System.out.println();
		JavascriptExecutor js = (JavascriptExecutor) driver;
//		WebElement drop = driver.findElement(By.xpath("//span[normalize-space()='Synced']"));
//		js.executeScript("arguments[0].click();", drop);
//		js.executeScript(driver.findElement(By.xpath("//span[normalize-space()='Synced']")).click());
//		driver.findElement(By.xpath("//span[normalize-space()='Synced']")).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//label[.='CSP Account Sync Status']/following::div/button)[1]")).click();
//		driver.findElement(By.xpath("(//label[.='CSP Account Sync Status'])")).click();
//		driver.findElement(By.xpath("(//label[.='CSP Account Sync Status']/following::div[1]//button)[last()]")).click();
//		util.clickUsingJs(By.xpath("//label[.='CSP Account Sync Status']/following::div[1]//button/span"));
//		util.clickUsingJs(By.xpath("(//*[normalize-space(text()) and normalize-space(.)='CSP Account Sync Status'])[1]/following::button[1]"));
//		util.clickUsingJs(By.xpath("//div/lightning-base-combobox-item[@data-value='Synced']"));
		driver.findElement(By.xpath("//div/lightning-base-combobox-item[@data-value='Synced']"));
//		driver.findElement(By.xpath("//label[.='Error Message']/following::div/textarea")).clear();
//		util.clickUsingJs(By.xpath("//lightning-button//button[.='Save']"));
//		util.waitFor(By.xpath("//lightning-button//button[.='Save']"), 10, false);
	  
  }
 
@BeforeTest
  public void beforeTest() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get("https://test.salesforce.com/");
	  driver.manage().window().maximize();
	  Thread.sleep(2000);

  }

  @AfterTest
  public void afterTest() throws InterruptedException {
	  Thread.sleep(6000);
	  
  }

}
