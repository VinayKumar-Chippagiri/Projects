package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class trailredbus {
	WebDriver driver;

  @Test
  public void f() throws InterruptedException {
	  WebElement srcElement = driver.findElement(By.id("src"));
		srcElement.clear();
		srcElement.sendKeys("Bangalore");

		srcElement.sendKeys(Keys.ENTER);

		WebElement dstElement = driver.findElement(By.id("dest"));
		dstElement.clear();
		dstElement.sendKeys("Pune");
		dstElement.sendKeys(Keys.ENTER);
		
		WebElement calendar = driver.findElement(By.xpath(".//input[@id='onward_cal']"));
		calendar.click();
		
		driver.findElement(By.xpath("//*[@id=\"rb-calendar_onward_cal\"]/table/tbody/tr[5]/td[3]")).click();
		Thread.sleep(2000);
		
		WebElement Search= driver.findElement(By.xpath("//button[contains(text(),'Search Buses')]"));
		Search.click();
		Thread.sleep(2000);
		

  }
  @BeforeTest
  public void beforeTest() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get("https://www.redbus.in/");
		driver.manage().window().maximize();
	  Thread.sleep(2000);
  }

  @AfterTest
  public void afterTest() throws InterruptedException {
	  Thread.sleep(5000);
	  
	 
  }

}
