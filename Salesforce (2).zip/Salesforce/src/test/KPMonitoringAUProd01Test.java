package test;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import cucumber.api.java.After;
import cucumber.api.java.Before;
public class KPMonitoringAUProd01Test {
   WebDriver driver;
  private Map<String, Object> vars;
  JavascriptExecutor js;
  @Before
  public void setUp() { 
    driver = new ChromeDriver();
    js = (JavascriptExecutor) driver;
    vars = new HashMap<String, Object>();
    driver.get("https://kitchen.planner.ikea.com/au/en/");
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  public String waitForWindow(int timeout) {
    try {
      Thread.sleep(timeout);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
    Set<String> whNow = driver.getWindowHandles();
    Set<String> whThen = (Set<String>) vars.get("window_handles");
    if (whNow.size() > whThen.size()) {
      whNow.removeAll(whThen);
    }
    return whNow.iterator().next();
  }
  @Test
  public void kPMonitoringAUProd01() {
//    driver.get("https://kitchen.planner.ikea.com/au/en/");
    driver.manage().window().setSize(new Dimension(1296, 688));
    driver.findElement(By.cssSelector(".gmtakJ")).click();
    vars.put("window_handles", driver.getWindowHandles());
    driver.findElement(By.cssSelector(".cKsEkZ")).click();
    vars.put("win9850", waitForWindow(2000));
    vars.put("root", driver.getWindowHandle());
    driver.switchTo().window(vars.get("win9850").toString());
    driver.findElement(By.id("username")).sendKeys("prodau@yopmail.com");
    driver.findElement(By.id("password")).sendKeys("Tester@12345");
    driver.findElement(By.id("username")).click();
    driver.findElement(By.cssSelector(".btn--emphasised > .btn__inner")).click();
    {
      WebElement element = driver.findElement(By.cssSelector(".btn--emphasised > .btn__inner"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.tagName("body"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element, 0, 0).perform();
    }
    driver.close();
    driver.switchTo().window(vars.get("root").toString());
    driver.findElement(By.cssSelector(".sc-bwsPYA > .Link__LinkContent-sc-q3uobp-0")).click();
    driver.switchTo().frame(0);
    driver.findElement(By.cssSelector(".cta-primary-alt-l > span")).click();
    driver.findElement(By.id("step-design")).click();
    {
      WebElement element = driver.findElement(By.id("step-design"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.tagName("body"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element, 0, 0).perform();
    }
    driver.findElement(By.cssSelector(".icon-catalog-cabinets")).click();
    driver.findElement(By.cssSelector("li:nth-child(1) li:nth-child(1) > .bt-text")).click();
    driver.findElement(By.cssSelector("li:nth-child(1) > article")).click();
    driver.findElement(By.cssSelector("li:nth-child(2) > article")).click();
    driver.findElement(By.cssSelector("li:nth-child(3) > article")).click();
    driver.findElement(By.cssSelector("li:nth-child(4) > article")).click();
    driver.findElement(By.cssSelector("li:nth-child(5) > article")).click();
    driver.findElement(By.cssSelector(".close:nth-child(2) svg")).click();
    driver.findElement(By.id("canvas")).click();
    driver.findElement(By.cssSelector(".icon-action-save > svg")).click();
    driver.findElement(By.id("input-save-name")).click();
    driver.findElement(By.id("input-save-name")).sendKeys("My IKEA Kitchen_SID");
    driver.findElement(By.cssSelector(".cta-primary-alt-xl")).click();
    driver.findElement(By.cssSelector(".icon-view-close:nth-child(2) use")).click();
    driver.switchTo().defaultContent();
    driver.findElement(By.cssSelector(".selenium-projectCard-details-button")).click();
    driver.findElement(By.cssSelector(".iHVWho")).click();
    driver.findElement(By.cssSelector(".iHVWho")).click();
    driver.findElement(By.cssSelector(".selenium-username")).click();
    driver.findElement(By.cssSelector(".sc-hbqYmb > span:nth-child(2)")).click();
  }
}
