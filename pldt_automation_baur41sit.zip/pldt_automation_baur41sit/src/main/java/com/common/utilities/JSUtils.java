package com.common.utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class JSUtils {
	JavascriptExecutor executor = new WebDriverTestBase().getDriver();

	public void clickUsingJavaScript(QAFWebElement webElement) {
		Reporter.log("Click using JavaScript on element " + webElement.toString(), MessageTypes.Info);
		executor.executeScript("arguments[0].scrollIntoViewIfNeeded(true)", webElement);
		executor.executeScript("arguments[0].click();", webElement);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void clickUsingJavaScript(By locator) {
		clickUsingJavaScript(new WebDriverTestBase().getDriver().findElement(locator));
	}

	public void enterTextUsingJavaScript(QAFWebElement element, String value) {
		element.waitForVisible(300000);
		executor.executeScript("arguments[0].scrollIntoViewIfNeeded(true)", element);
		String args = "arguments[0].value=" + "'" + value + "'";
		System.out.println(args);
		element.clear();
		executor.executeScript(args, element);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
