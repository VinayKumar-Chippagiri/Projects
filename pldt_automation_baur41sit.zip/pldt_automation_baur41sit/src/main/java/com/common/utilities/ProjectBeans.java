package com.common.utilities;

import java.util.ArrayList;

public class ProjectBeans {

	private static String LeadID = null;
	private static String LeadName = null;
	private static String AccountID = null;
	private static String AccountName = null;
	private static String opportunity_ID = null;
	private static String opportunity_Name = null;
	private static String caseID = null;
	private static String caseName = null;
	private static String caseURL = null;
	private static String quoteURL = null;
	private static String leadURL = null;
	private static String opportunityURL = null;
	private static String contractURL = null;
	private static String accountURL = null;
	private static String QLIURL = null;
	private static String EBMNotificationURL = null;
	private ArrayList<String> orderList = null;
	private static String orderURL = null;

	public ArrayList<String> getOrderList() {
		return orderList;
	}

	public void setOrderList(ArrayList<String> orderList) {
		this.orderList = orderList;
	}

	public static void setCaseID(String caseID) {
		ProjectBeans.caseID = caseID;
	}

	public static String getCaseID() {
		return caseID;
	}

	public static String getCaseName() {
		return caseName;
	}

	public static void setCaseName(String caseName) {
		ProjectBeans.caseName = caseName;
	}

	public String getLeadID() {
		return LeadID;
	}

	public static void setLeadID(String leadID) {
		LeadID = leadID;
	}

	public static String getLeadName() {
		return LeadName;
	}

	public static void setLeadName(String leadName) {
		LeadName = leadName;
	}

	public static String getAccountID() {
		return AccountID;
	}

	public static void setAccountID(String accountID) {
		AccountID = accountID;
	}

	public static String getAccountName() {
		return AccountName;
	}

	public static void setAccountName(String accountName) {
		AccountName = accountName;
	}

	public static String getOpportunityID() {
		return opportunity_ID;
	}

	public static void setOpportunityID(String opportunityID) {
		opportunity_ID = opportunityID;
	}

	public static String getOpportunityName() {
		return opportunity_Name;
	}

	public static void setOpportunityName(String opportunityName) {
		opportunity_Name = opportunityName;
	}

	public static String getCaseURL() {
		return caseURL;
	}

	public static void setCaseURL(String caseURL) {
		ProjectBeans.caseURL = caseURL;
	}

	public static String getQuoteURL() {
		return quoteURL;
	}

	public static void setQuoteURL(String quoteURL) {
		ProjectBeans.quoteURL = quoteURL;
	}

	public static String getLeadURL() {
		return leadURL;
	}

	public static void setLeadURL(String leadURL) {
		ProjectBeans.leadURL = leadURL;
	}

	public static String getOpportunityURL() {
		return opportunityURL;
	}

	public static void setOpportunityURL(String opportunityURL) {
		ProjectBeans.opportunityURL = opportunityURL;
	}

	public static String getContractURL() {
		return contractURL;
	}

	public static void setContractURL(String contractURL) {
		ProjectBeans.contractURL = contractURL;
	}

	public static String getAccountURL() {
		return accountURL;
	}

	public static void setAccountURL(String accountURL) {
		ProjectBeans.accountURL = accountURL;
		// TODO Auto-generated method stub

	}

	public static void setQLIURL(String QLIURL) {

		ProjectBeans.QLIURL = QLIURL;
	}

	public static String getQLIURL() {
		return QLIURL;
	}

	public static String getOrderURL() {
		return orderURL;
	}

	public static void setOrderURL(String orderURL) {
		ProjectBeans.orderURL = orderURL;
	}

	public static void setEBMNotificationURL(String EBMNotificationURL) {

		ProjectBeans.EBMNotificationURL = EBMNotificationURL;
	}

	public static String getEBMNotificationURL() {
		return EBMNotificationURL;
	}

}
