package com.common.utilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.apache.commons.lang.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.pldt.enums.WaitFor;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class AppCommons extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	static JavascriptExecutor executor = null;
	List<String> listId = new ArrayList<>();

	public void markCaseStatus(QAFWebElement status) {
		executor = driver;
		int temp = 0;
		while (temp <= 5) {
			if (status.isDisplayed()) {
				System.out.println(status.isDisplayed());
				status.waitForEnabled(10000);
				util.clickUsingJs(status);
				break;
			}
			QAFWebElement nextArrow = new QAFExtendedWebElement("//button/span[text()='Next']");
			util.clickUsingJs(nextArrow);
			temp++;
		}
	}

	public void UpdateIDInCSVFile(String file, String value) {
		try {
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader);
			List<String[]> csvBody = csvReader.readAll();
			Iterator<String[]> iterator = csvBody.iterator();
			iterator.next();
			int rowno = 1;
			while (iterator.hasNext()) {
				String[] row = iterator.next();
				for (int i = 1; i < row.length; i++) {
					csvBody.get(rowno)[0] = value;
					System.out.println(csvBody.get(rowno)[0] = value);
				}
				rowno = rowno + 1;
			}
			csvReader.close();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeAll(csvBody);
			writer.flush();
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void refreshOrders(int refreshAttempts, int numberOfOrders) throws InterruptedException {
		String orderNumber = null;
		int ordercount = 0;
		int count = 0;
		while (ordercount < numberOfOrders) {
			try {
				orderNumber = driver.findElement(By.xpath("//span[@class='countSortedByFilteredBy']")).getText();
				ordercount = Integer.parseInt(orderNumber.split(" ")[0]);
				System.out.println(ordercount);
			} catch (Exception e) {
			}
			if (count == refreshAttempts) {
				break;
			}
			Thread.sleep(1000);
			driver.navigate().refresh();
			count++;
		}
	}

	public List<String> ReadListOfIDInCSVFile(String file) {
		try {
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader);
			List<String[]> csvBody = csvReader.readAll();
			Iterator<String[]> iterator = csvBody.iterator();
			iterator.next();
			int rowno = 1;
			while (iterator.hasNext()) {
				String[] row = iterator.next();
				String ids = csvBody.get(rowno)[0].toString();
				((ArrayList<String>) listId).add(ids);
				rowno = rowno + 1;
			}
			csvReader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listId;
	}

	public void UpdateListOfIDInCSVFile(String file, List<String> value) {
		try {
			FileReader filereader = new FileReader(file);
			CSVReader csvReader = new CSVReader(filereader);
			List<String[]> csvBody = csvReader.readAll();
			Iterator<String[]> iterator = csvBody.iterator();
			iterator.next();
			int rowno = 1;
			for (int i = 0; i < csvBody.size() - 1; i++) {
				csvBody.get(rowno)[0] = value.get(i);
				System.out.println(csvBody.get(rowno)[0] = value.get(i));
				rowno = rowno + 1;
			}
			csvReader.close();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeAll(csvBody);
			writer.flush();
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// created by waseem
	public String pickLatestFileFromDownloads(String testname) {
		String currentUsersHomeDir = System.getProperty("user.home");
		String downloadFolder = currentUsersHomeDir + File.separator + "Downloads" + File.separator;
		File dir = new File(downloadFolder);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			Reporter.log("There is no file in the folder");
		}
		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		String k = lastModifiedFile.toString();
		System.out.println(lastModifiedFile);
		Path p = Paths.get(k);
		String file = p.getFileName().toString();
		String fileSuffix = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		new File(System.getProperty("user.dir") + "//Downloads//").mkdir();
		boolean newfile = new File(System.getProperty("user.dir") + "//Downloads//" + testname + fileSuffix).mkdir();
		Path sourcepath = Paths.get(k);
		Path destinationepath = Paths
				.get(System.getProperty("user.dir") + "//Downloads//" + testname + fileSuffix + "/" + file);
		try {
			Files.walk(sourcepath)
					.forEach(source -> copy(source, destinationepath.resolve(sourcepath.relativize(source))));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return file;
	}

	static void copy(Path source, Path dest) {
		try {
			Files.copy(source, dest, StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public void cartPageSaveButton() {
		util.scrollIntoElement(By.xpath("//button[@type='submit']"));
		util.waitFor(2);
		util.clickUsingJs(By.xpath("//button[@type='submit']"));
		util.waitFor(3);
		util.waitFor(By.xpath("//div[@class='slds-spinner_container']"), 50, false);
	}

	/**
	 * OrderQuantity --It increases the quantity of Products in the Cart Page.
	 *
	 * @author Vinay
	 * @param Product --name of the product which is going to increase the quantity
	 *                .
	 * @return No return value.
	 */
	public void OrderQuantity(Map<String, String> data, String product) {
		if (!data.get("Order Quantity").equalsIgnoreCase("SKIP")) {
			util.clickUsingJs(
					driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]")));
			driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]")).clear();
			util.enterTextUsingJs(
					driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]")),
					data.get("Order Quantity").toString());
			driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]"))
					.sendKeys(Keys.BACK_SPACE);
			util.waitFor(8);
			// util.waitForCartPageToastMessage();
			util.typeDataTo(
					driver.findElement(By.xpath("(//span[text()='" + product + "']/following::*[@step='any'])[1]")),
					data.get("Order Quantity").toString().charAt(data.get("Order Quantity").toString().length() - 1)
							+ "");
			util.waitFor(8);
			util.waitForCartPageToastMessage();
		}
	}

	/**
	 * 
	 * click_Configure_Product --It Performs the Configuration in the Cart Page.
	 * 
	 * @author Vinay
	 * @param product --name of the Parent product .
	 * @param child   --name of the child product linked with parent product to
	 *                Configure in the cart page.
	 * @return No return value.
	 */
	public void Configure_Parent_Product(String product) {
		util.scrollIntoElement(
				By.xpath("(//span[text()='" + product + "']/following::button[@title='Show Actions'][1])[last()]"));
		String actions = "//span[text()='" + product + "']/following::button[@title='Show Actions'][1]";
		String configure = actions + "/following::a[normalize-space()='Configure'][1]";
//		util.clickUsingJs(By.xpath("//span[text()='" + product + "']/following::button[@title='Show Actions'][1]"));
		String xpathshowactions = pageProps.getString("pldt.cartpage.showactions.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathshowactions, product), "Show Actions");
//		util.clickUsingJs(By.xpath(configure));
		util.waitAndClickUsingJavaScript(configure, "Configure");
	}

	/**
	 * select_Config_Parameter --It Configures the attribrutes in the Cart Page.
	 * 
	 * @author Vinay
	 * @param attribrute --name of the attribrute which is going to Select .
	 * @return No return value.
	 */
	public void select_Config_Parameter(String attribrute) {
		QAFExtendedWebElement element = driver.findElement(
				By.xpath("(//form//label[contains(.,'" + attribrute + "')]//following::select[1])[last()]"));
		util.scrollIntoElement(element);
		Select select = new Select(element);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// Read Test data
		Map<?, ?> map = (Map<?, ?>) pageProps.getObject("testdata");
		// id data value not Skip then it performs the condition.
		if (map.get(attribrute) != null && !map.get(attribrute).toString().equalsIgnoreCase("skip")) {
			select.selectByVisibleText(map.get(attribrute).toString());
		}
	}

	public void cartPageSave() {
		util.waitAndClick("pldt.cartpage.submit.btn", "Submit");
		util.waitFor(By.xpath("//div[@class='slds-spinner_container']"), 30, false);
	}

	/**
	 * click_Configure_Product --It Performs the Configuration in the Cart Page.
	 * 
	 * @author Vinay
	 * @param product --name of the Parent product .
	 * @param child   --name of the child product linked with parent product to
	 *                Configure in the cart page.
	 * @return No return value.
	 */
	public void click_Configure_Product(String product, String child) {
		util.scrollIntoElement(By.xpath("//span[text()='" + product + "']/following::span[normalize-space()='" + child
				+ "']/following::button[@title='Show Actions'][1]"));
		String actions = "//span[text()='" + product + "']/following::span[normalize-space()='" + child
				+ "']/following::button[@title='Show Actions'][1]";
		String configure = actions + "/following::a[normalize-space()='Configure'][1]";
		util.clickUsingJs(By.xpath("//span[text()='" + product + "']/following::span[normalize-space()='" + child
				+ "']/following::button[@title='Show Actions'][1]"));
		util.clickUsingJs(By.xpath(configure));
	}

	/**
	 * addChildProductsToCart --It Performs the addition of child products in the
	 * Cart Page.
	 * 
	 * @author Vinay
	 * @param product --name of the Parent product .
	 * @param child   --name of the child product linked with parent product to add
	 *                in the cart page.
	 * @return No return value.
	 */
	public void addChildProductsToCart(String product, String child) {
		util.clickUsingJs(By.xpath("(//span[text()='" + product + "']/following::span[contains(text(),'" + child
				+ "')]/following::button[contains(text(),'Add')])[1]"));
		util.waitForCartPageToastMessage();
		util.waitFor(3);
		util.waitForCartPageToastMessage();
	}

	/**
	 * grouping_Product --It Performs the Grouping in the Cart Page.
	 * 
	 * @author Vinay
	 * @param product --name of the product which is going to perform grouping .
	 * @return No return value.
	 */
	public void grouping_Product(String product) {
//        By showActions = '//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]';
		util.scrollIntoElement(
				By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]"));
//        util.clickUsingJs(By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]"));
		String xpathshowactions = pageProps.getString("pldt.cartpage.showactions.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathshowactions, product), "Show Actions");
//        util.clickUsingJs(By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]/following::li/a[normalize-space()='Grouping']"));
		String xpathproduct = pageProps.getString("pldt.cartpage.grouping.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathproduct, product), "Product");
		util.waitForVlocityOmniScript();
//        util.AttachFrame();
//        util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"));
		util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
//        util.waitFor(By.xpath("(//li[@role='button'])[last()]"), 10, true);
//        util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"));
		util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"), WaitFor.VISIBLE);
		util.vlocityNextButton();
		util.waitForCartPage();
	}

	/**
	 * grouping_Product_index --It Performs the Grouping in the Cart Page.
	 * 
	 * @author Vinay
	 * @param product --name of the product which is going to perform grouping .
	 * @return No return value.
	 */
	public void grouping_Product_index(String product) {
//		By showActions = '//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]';
		util.scrollIntoElement(
				By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]"));
		util.clickUsingJs(By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]"));
		util.clickUsingJs(By.xpath("//Span[text()='" + product
				+ "']/following::button[@title='Show Actions'][1]/following::li/a[normalize-space()='Grouping']"));
		util.waitForVlocityOmniScript();
//		util.AttachFrame();
//		util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"));
		util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
//		util.waitFor(By.xpath("(//li[@role='button'])[last()]"), 10, true);
//		util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"));
		util.clickUsingJs(By.xpath("(//li[@role='button'])[2]"), WaitFor.VISIBLE);
		util.vlocityNextButton();
		util.waitForCartPage();
	}

	/**
	 * association_Product --It Associates the Other Products in the Cart Page.
	 * 
	 * @author Vinay
	 * @param Product --name of the product which is going to perform Association .
	 * @return No return value.
	 */
	public void association_Product(String product) {
		util.scrollIntoElement(
				By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]"));
//        util.clickUsingJs(By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]"));
		String xpathshowactions = pageProps.getString("pldt.cartpage.showactions.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathshowactions, product), "Show Actions");
//        util.clickUsingJs(By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]/following::li/a[normalize-space()='Associate Products']"));
		String xpathassociateproducts = pageProps.getString("pldt.cartpage.associateproducts.lnk");
		util.waitAndClickUsingJavaScript(String.format(xpathassociateproducts, product), "Associate Products");
		// waiting for Association of Products page.
		util.waitForVlocityOmniScript();
		// Switch to Frame.
		util.AttachFrame();
		// Associating all the Products in Association page.
		String checkboxXpath = "//th/div[.='Product Name']/following::label[@class='slds-checkbox']";
		List<WebElement> elements = driver.findElements(By.xpath(checkboxXpath));
//        for (WebElement el : elements) {
//        el.click();
//        }
		elements.forEach(v -> v.click());
//        util.clickUsingJs(By.xpath("//th/div[.='Product Name']/following::label[@class='slds-checkbox']"));
		// Click on Next Button .
		util.vlocityNextButton();
		util.waitForCartPage();
	}

	/**
	 * select_Config_Parameter --It Configures the attribrutes in the Cart Page.
	 *
	 * @author Krishna
	 * @param attribrute --name of the attribrute which is going to Select .
	 * @return No return value.
	 */
	public void select_Config_Parameter(String attribrute, String attributeData) {
		QAFExtendedWebElement element = driver.findElement(
				By.xpath("(//form//label[contains(.,'" + attribrute + "')]//following::select[1])[last()]"));
		util.scrollIntoElement(element);
		util.selectValuefromDropDown(element, e -> e.selectByVisibleText(attributeData));
	}

	// created by vidya
	public String getToastMessage() {
		util.waitFor(By.xpath("//*[@data-aura-class='forceToastMessage']"), 60, true);
		String msg = new WebDriverTestBase().getDriver()
				.findElement(By.xpath("//*[@data-aura-class='forceToastMessage']")).getText();
		return msg;
	}

	/**
	 * WorkingCart_grouping_Product --It Performs the grouping in working cart page.
	 * 
	 * @author Vinay .
	 * @return No return value.
	 */
	public void WorkingCart_grouping_Product(String ExchangeiD) {
        int j;
        util.waitFor(3);
        util.AttachFrame();
        util.clickUsingJs(By.xpath("//button[@title='Grouping']"));
        util.waitForVlocityOmniScript();
        util.waitFor(5);
        util.AttachFrame();
        util.waitFor(3);
        String checkboxXpath = "//th/div[.='Product Name']/following::label[@class='slds-checkbox']";
        List<WebElement> elements = driver.findElements(By.xpath(checkboxXpath));
        int count = elements.size();
        System.out.println(count);
        int value = 1;
        if (count > 3) {
            for (int i = 3; i <= count + 1; i += 3) {
                System.out.println(i);
                for (j = value; j <= i; j++) {
                    driver.findElement(
                            By.xpath("//th/div[.='Product Name']/following::label[@class='slds-checkbox'][" + j + "]"))
                            .click();
                    if (i > count) {
                        value = j + 1;
                        break;
                    } else {
                        value = j + 1;
                    }
                }
                if (util.isElementDisplayed(By.xpath("//input[@id='QuoteMembers']"))) {
                    util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
//                    driver.findElement(By.xpath("//input[@id='QuoteMembers']")).sendKeys(ExchangeiD);
                    util.waitFor(5);
//                    util.clickUsingJs(By.xpath("(//li/a[@role='menuitem'])[last()]"), WaitFor.VISIBLE);
                    util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"), WaitFor.VISIBLE);
                }
                util.vlocityNextButton();
                util.waitForCartPage();
                util.AttachFrame();
                if (value == count) {
                    break;
                } else {
                    util.AttachFrame();
                    util.clickUsingJs(By.xpath("//button[@title='Grouping']"));
                    util.waitForVlocityOmniScript();
                    util.AttachFrame();
                    continue;
                }
            }
        } else {
            elements.forEach(v -> v.click());
            util.waitFor(5);
            driver.findElement(
                    By.xpath("(//th/div[.='Product Name']/following::label[@class='slds-checkbox'])[last()]")).click();
            util.AttachFrame();
            if (util.isElementDisplayed(By.xpath("//input[@id='QuoteMembers']"))) {
                util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
//                driver.findElement(By.xpath("//input[@id='QuoteMembers']")).sendKeys(ExchangeiD);
                util.waitFor(5);
//                util.clickUsingJs(By.xpath("(//li/a[@role='menuitem'])[last()]"), WaitFor.VISIBLE);
                util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"), WaitFor.VISIBLE);
            }
            util.vlocityNextButton();
            util.waitFor(30);
            util.waitForCartPage();
        }
    }

	/**
	 * WorkingCart_grouping_Product_MultiSites --It Performs the Grouping in the
	 * Working Cart Page.
	 *
	 * @author Vinay
	 * @param product --name of the product which is going to perform grouping .
	 * @return No return value. i used for iterating by 3 j used for clicking
	 *         checkbox value used for the no of products checked count used for
	 *         getting no of products
	 */
	public void WorkingCart_grouping_Product_MultiSites(String groupname,String ExchangeiD) {
		int j;
		util.waitFor(3);
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//button[@title='Grouping']"));
		util.waitForVlocityOmniScript();
		util.AttachFrame();
		QAFExtendedWebElement BulkGroupCheckbox = new QAFExtendedWebElement("//div[text()='" + groupname
				+ "']//parent::td//preceding-sibling::th//span[@class='slds-checkbox--faux']");
		String checkboxXpath = "//input[@ng-change='onProdSelect(p)']//following-sibling::span[@class='slds-checkbox--faux']";
		List<WebElement> elements = driver.findElements(By.xpath(checkboxXpath));
		int count = elements.size();
		System.out.println(count);
		int value = 0;
		if (count > 3) {
			for (int i = 3; i <= count + 2; i += 3) {
				System.out.println(i);
				for (j = value; j < i; j++) {
					value = j + 1;
					driver.findElement(By.xpath(
							"(//input[@ng-change='onProdSelect(p)']//following-sibling::span[@class='slds-checkbox--faux'])["
									+ value + "]"))
							.click();
					if (value == count) {
						break;
					}
				}
				if (BulkGroupCheckbox.isPresent()) {
					util.clickUsingJs(BulkGroupCheckbox);
				} else {
					util.isElementDisplayed(By.xpath("//input[@id='QuoteMembers']"));
					util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
//					driver.findElement(By.xpath("//input[@id='QuoteMembers']")).sendKeys(ExchangeiD);
					util.waitFor(5);
					util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"), WaitFor.VISIBLE);
				}
				util.vlocityNextButton();
				util.waitForCartPage();
				util.waitFor(By.xpath("//title[text()='vlocity_cmt__HybridCPQ | Salesforce']"), 30, true);
				util.AttachFrame();
				if (value == count) {
					break;
				} else {
					util.AttachFrame();
					util.clickUsingJs(By.xpath("//button[@title='Grouping']"));
					util.waitForVlocityOmniScript();
					util.AttachFrame();
					continue;
				}
			}
		} else {
			elements.forEach(v -> v.click());
			if (BulkGroupCheckbox.isPresent()) {
				util.clickUsingJs(BulkGroupCheckbox);
			} else {
				util.isElementDisplayed(By.xpath("//input[@id='QuoteMembers']"));
				util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
//				driver.findElement(By.xpath("//input[@id='QuoteMembers']")).sendKeys(ExchangeiD);
				util.waitFor(5);
				util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"), WaitFor.VISIBLE);
			}
			util.vlocityNextButton();
			util.waitForCartPage();
		}
	}

//	Created by Vinay to Click on both SaveWorkingCart 
	public void SaveWorkingCart() {
		util.waitFor(8);
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(5);
		util.clickUsingJs(By.xpath("//button[@title='Save Working Cart']"));
	}

	/**
	 * WorkingCart_Association --It Associates the Other Products in the Quote Page.
	 * 
	 * @author Vinay
	 * @param Product --name of the product which is going to perform Association .
	 * @return No return value.
	 */
	public void WorkingCart_Association(String product) {
		util.waitForQuotePage();
		util.waitFor(By.xpath("(//span[.='Bundles'])[last()]"), 30, true);
		util.isElementDisplayed(By.xpath("(//span[.='Bundles'])[last()]"));
		util.clickUsingJs(By.xpath("(//span[.='Bundles'])[last()]"));
		util.waitFor(By.xpath("//input[@placeholder='Enter Product Name']"), 30, true);
//			driver.findElement(By.xpath("//input[@placeholder='Enter Product Name']")).sendKeys(product);
		util.waitFor(5);
//			util.clickUsingJs(By.xpath("//label[contains(@for,'lgt-dt-header-factory')]//span[@class='slds-checkbox_faux']"));
		util.clickUsingJs(By.xpath("//lightning-base-formatted-text[.='" + product
				+ "']/ancestor::tr//span[@class='slds-checkbox_faux']"));
		util.clickUsingJs(By.xpath("//button[.='Product Association']"));
		// waiting for Association of Products page.
		util.waitForVlocityOmniScript();
		// Switch to Frame.
		util.waitFor(10);
		util.AttachFrame();
		// Associating all the Products in Association page.
		String checkboxXpath = "//th/div[.='Product Name']/following::label[@class='slds-checkbox']";
		List<WebElement> elements = driver.findElements(By.xpath(checkboxXpath));
		elements.forEach(v -> v.click());
		Reporter.logWithScreenShot("selected product association");
		util.vlocityNextButton();
		util.waitForQuotePage();
	}

	public void Configure_Primary_Product(String productName) {
//      String productXpath = "(//span[contains(@class,'cpq-error-msg')])[1]//following::span[text()='" + productName
//              + "']/following::button[@title='Show Actions'][1]";
//              util.scrollIntoElement(
//              By.xpath(productXpath));
//              String configure = productXpath + "/following::a[normalize-space()='Configure'][1]";
		// util.clickUsingJs(By.xpath(productXpath));
		String productXpath = String.format(pageProps.getString("pldt.cartpage.productxpath"), productName);
		util.waitFor(2);
		util.waitAndClickUsingJavaScript("xpath=" + productXpath, "Product");
//              util.clickUsingJs(By.xpath(configure));
		util.waitFor(2);
		String configureXpath = productXpath + pageProps.getString("pldt.cartpage.configurexpath");
		util.waitFor(2);
		util.waitAndClickUsingJavaScript("xpath=" + configureXpath, "Configure");
	}

	/**
	 * WorkingCart_grouping_Specific --It Performs the Grouping for specific product
	 * in the Working Cart Page.
	 *
	 * @author Vinay
	 * @param product --name of the product which is going to perform grouping .
	 * @param index   --value of the index which is going to select service Address.
	 * @return No return value.
	 */
	public void WorkingCart_grouping_Specific(String product, String index) {
		util.refreshSwitchToFrame();
		util.waitFor(3);
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//button[@title='Grouping']"));
		util.waitForVlocityOmniScript();
		util.AttachFrame();
		util.clickUsingJs(
				By.xpath("//div[.='" + product + "']/ancestor::tr/th/label/span[@class='slds-checkbox--faux']"));
		util.waitFor(5);
		if (util.isElementDisplayed(By.xpath("//input[@id='QuoteMembers']"))) {
			util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
			util.clickUsingJs(By.xpath("(//li[@role='button'])[" + index + "]"), WaitFor.VISIBLE);
		}
		util.vlocityNextButton();
		util.waitForCartPage();
	}

	/**
	 * Association_Validation --Click on Associates_Validation the Other Products in
	 * the Quote Page.
	 *
	 * @author waseem
	 * @return No return value.
	 */
	public void Association_Validation() {
		util.waitForQuotePage();
		QAFExtendedWebElement bundle = new QAFExtendedWebElement("//a[@title='Bundles']");
		bundle.click();
		Reporter.logWithScreenShot("AssociationValidation is done");
		QAFExtendedWebElement AssociationValidation = new QAFExtendedWebElement(
				"//button[text()='Association Validation']");
		AssociationValidation.click();
		util.waitFor(6);
	}

	/**
	 * Input_Config_Parameter --It provides the input value in the Working CartPage.
	 * 
	 * @author Saisree
	 * @param attribrute --name of the attribrute which is going to provide the
	 *                   input field .
	 * @return No return value.
	 */
	public void Input_Config_Parameter(String attribrute) {
		QAFExtendedWebElement element = driver
				.findElement(By.xpath("(//form//label[contains(.,'" + attribrute + "')])[1]//following::input[1]"));
		util.scrollIntoElement(element);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Read Test data
		Map<?, ?> map = (Map<?, ?>) pageProps.getObject("testdata");
		// id data value not Skip then it performs the condition.
		if (map.get(attribrute) != null && !map.get(attribrute).toString().equalsIgnoreCase("skip")) {
			element.sendKeys(map.get(attribrute).toString());
		}
	}

	/**
	 * Input_Config_Parameter --It provides the input value in the Working CartPage.
	 * 
	 * @author Saisree
	 * @param attribrute      --name of the attribrute which is going to provide the
	 *                        input field .
	 * @param attribruteValue --name of the attribrute which is going to provide the
	 *                        input field .
	 * @return No return value.
	 */
	public void Input_Config_Parameter(String plan, String attribrute, String attribruteValue) {
		QAFExtendedWebElement element = driver
				.findElement(By.xpath("(//span[text()='" + plan + "']/ancestor::div//form[last()]//label[contains(.,'"
						+ attribrute + "')])[last()]//following::input[1]"));
		util.scrollIntoElement(element);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Read Test data
		Map<?, ?> map = (Map<?, ?>) pageProps.getObject("testdata");
		// id data value not Skip then it performs the condition.
		if (map.get(attribruteValue) != null && !map.get(attribruteValue).toString().equalsIgnoreCase("skip")) {
			element.sendKeys(map.get(attribruteValue).toString());
		}
		element.click();
	}

	/**
	 * grouping_Product --It Performs the Grouping in the Cart Page for Multisite.
	 *
	 * @author Vidya
	 * @param product --name of the product which is going to perform grouping.
	 * @return No return value.
	 */
	public void grouping_ProductForMultisite(String product, String groupname) {
		util.scrollIntoElement(
				By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]"));
		String xpathshowactions = pageProps.getString("pldt.cartpage.showactions.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathshowactions, product), "Show Actions");
		String xpathproduct = pageProps.getString("pldt.cartpage.grouping.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathproduct, product), "Product");
		util.waitForVlocityOmniScript();
		util.AttachFrame();
		util.clickUsingJs(
				By.xpath("//div[text()='" + groupname
						+ "']//parent::td//preceding-sibling::th//span[@class='slds-checkbox--faux']"),
				WaitFor.ATTACH_FRAME);
		util.vlocityNextButton();
		util.waitForCartPage();
	}

	/**
	 * WorkingCart_grouping_Product --It Performs the Grouping in the Working Cart
	 * Page.
	 *
	 * @author Waseem
	 * @param product --name of the product which is going to perform grouping .
	 * @return No return value.
	 */
	public void WorkingCart_grouping() {
		int i = 0;
		click_grouping();
		String checkboxXpath = "//tbody//label[@class='slds-checkbox']/span[1]";
		List<WebElement> elements = driver.findElements(By.xpath(checkboxXpath));
		int count = elements.size();
		while (i < count) {
			for (int j = 0; j < 3; j++) {
				elements.get(i).click();
				i++;
				if (i == count) {
					break;
				}
			}
			Reporter.logWithScreenShot("Number of products " + i + " selected for grouping");
			select_serviceAdd();
			if (i < count) {
				click_grouping();
				elements = driver.findElements(By.xpath(checkboxXpath));
			}
		}
	}

	public void select_serviceAdd() {
		if (util.isElementDisplayed(By.xpath("//input[@id='QuoteMembers']"))) {
			util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
			util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"), WaitFor.VISIBLE);
		}
		util.vlocityNextButton();
		util.waitForCartPage();
		util.waitFor(15);
	}

	public void click_grouping() {
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//button[@title='Grouping']"));
		util.waitForVlocityOmniScript();
		util.waitFor(15);
		util.AttachFrame();
	}

	/**
	 * select_Countries_Parameter --It Configures the attribrutes in the Cart Page.
	 *
	 * @author waseem
	 * @param attribrute --name of the attribrute which is going to Select .
	 * @return No return value.
	 */
	public void select_Countries_Parameter(String attribrute, int NumberOfCountries) {
		QAFExtendedWebElement element = driver.findElement(
				By.xpath("(//form//label[contains(.,'" + attribrute + "')]//following::select[1])[last()]"));
		Select select = new Select(element);
		List<WebElement> allOptions = select.getOptions();
		Actions actions = new Actions(driver);
		for (int i = 0; i < NumberOfCountries; i++) {
			actions.keyDown(Keys.CONTROL).click(allOptions.get(i)).keyUp(Keys.CONTROL).build().perform();
		}
		Reporter.logWithScreenShot("Countries");
	}

	/**
	 * select_Config_Parameter --It Configures the attribrutes in the Cart Page.
	 *
	 * @author waseem
	 * @param attribrute --name of the attribrute which is going to Select .
	 * @return No return value.
	 */
	public void EnterText_Config_Parameter(String attribrute, String attributeData) {
		QAFExtendedWebElement element = driver.findElement(
				By.xpath("((//form//label[contains(.,'" + attribrute + "')])[last()]//following::div/input)[1]"));
		util.scrollIntoElement(element);
		element.sendKeys(attributeData);
	}

	public String GenerateTollFreeNumber(String tollfreeType) {
		String tollNumber = null;
		TestDataBean bean = new TestDataBean();
		bean.fillRandomData();
		switch (tollfreeType) {
		case "Domestic":
			tollNumber = String.format("1800%s", bean.getTollFreeNumber());
			tollNumber = StringUtils.rightPad(tollNumber, 8, "0");
			break;
		case "MyNumber":
			tollNumber = String.format("1700%s", bean.getTollFreeNumber());
			tollNumber = StringUtils.rightPad(tollNumber, 8, "0");
			break;
		case "International":
			tollNumber = String.format("17180621%s", bean.getTollFreeNumber());
			tollNumber = StringUtils.rightPad(tollNumber, 12, "0");
			break;
		case "Universal":
			tollNumber = String.format("17180621%s", bean.getTollFreeNumber());
			tollNumber = StringUtils.rightPad(tollNumber, 12, "0");
			break;
		default:
			System.out.println("Please enter type of toll free number");
			break;
		}
		return tollNumber;
	}

	/**
	 * associate_Product_ePLDT --It Associates the Other Products in the Cart Page
	 * for ePLDT.
	 * 
	 * @author Vinay
	 * @param Product          --name of the product which is going to perform
	 *                         Association .
	 * @param associateProduct --name of the product which is going to add the
	 *                         product for Association .
	 * @return No return value.
	 */
	public void associate_Product_ePLDT(String product, String associateProduct) {
		util.scrollIntoElement(
				By.xpath("//Span[text()='" + product + "']/following::button[@title='Show Actions'][1]"));
		String xpathshowactions = pageProps.getString("pldt.cartpage.showactions.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathshowactions, product), "Show Actions");
		String xpathassociateproducts = pageProps.getString("pldt.cartpage.associateEPLDT");
		util.waitAndClickUsingJavaScript(String.format(xpathassociateproducts, product), "Associate");
		util.waitFor(By.xpath("(//h2[text()='Configure Relies On Item'])[1]"), 10, true);
		driver.findElement(
				By.xpath("(//span[.=' Please select a product:  ']/following::Input[@placeholder='Search'])[1]"))
				.sendKeys(associateProduct);
		String selectAddon = "//div[@title='" + associateProduct + "']";
		util.clickUsingJs(By.xpath(selectAddon));
		util.clickUsingJs(By.xpath("(//div//button[text()='Add to Cart'])[last()]"));
		util.waitForCartPageToastMessage();
	}

	public void expand_device(String devicename) {
		util.AttachFrame();
		String device = "(//button[contains(@title,'" + devicename + "')])[1]";
		util.clickUsingJs(By.xpath(device));
		util.waitFor(By.xpath("(//span[contains(text(),'" + devicename + "')])[4]"), 60, true);
	}

	// Created by Vinay to Expand the Collapsed items in the Cart Page.
	public void expandingCollapseditems(String Plan) {
		util.waitFor(5);
		String s = driver.findElement(By.xpath("(//span[.='" + Plan + "']/parent::*//*[local-name()='svg'])"))
				.getAttribute("class");
		if (s.contains("cpq-fix-slds-close-switch")) {
			util.clickUsingJs(driver.findElement(By.xpath("(//span[.='" + Plan
					+ "']/parent::button[contains(@class,'slds-button cpq-item-has-children')])")));
			util.waitFor(8);
			System.out.println("Click on " + Plan + " arrow");
		}
	}

	/**
	 * getProductPriceUI -- It gets price for a Particular Plan.
	 * 
	 * @author Waseem
	 * @param prod -- Name of the product which you wants to get price
	 * @param type -- type of the price which you wants to get from the plan
	 *             (example: MRC, ARC and OTC)
	 * @return No return value.
	 */
	public String getProductPriceUI(String prod, String type) {
		String price = null;
		QAFWebElement ele;
		switch (type) {
		case "MRC":
		case "ARC":
			ele = new QAFExtendedWebElement("xpath=//span[text()='" + prod
					+ "']/following::div[@class='cpq-item-base-product-currency cpq-item-currency-value'][3]");
			price = ele.getText();
			break;
		case "OTC":
			ele = new QAFExtendedWebElement("xpath=//span[text()='" + prod
					+ "']/following::div[@class='cpq-item-base-product-currency cpq-item-currency-value'][5]");
			price = ele.getText();
			break;
		}
		return price;
	}

	/**
	 * getbespokePriceUI -- It gets bespoke price for a Particular Plan.
	 * 
	 * @author Waseem
	 * @param prod -- Name of the product which you wants to get price
	 * @param type -- type of the price which you wants to get from the plan
	 *             (example: MRC, ARC and OTC)
	 * @return No return value.
	 */
	public String getbespokePriceUI(String prod, String type) {
		String price = null;
		QAFWebElement ele;
		switch (type) {
		case "MRC":
		case "ARC":
			ele = new QAFExtendedWebElement("xpath=//span[text()='" + prod
					+ "']/following::div[@class='cpq-item-base-product-currency cpq-item-currency-value'][3]//span[@class='cpq-underline']");
			price = ele.getText();
			break;
		case "OTC":
			ele = new QAFExtendedWebElement("xpath=//span[text()='" + prod
					+ "']/following::div[@class='cpq-item-base-product-currency cpq-item-currency-value'][5]//span[@class='cpq-underline']");
			price = ele.getText();
			break;
		}
		return price;
	}

	/**
	 * VerifySave -- It click on save when ever changes applied and save button
	 * enables
	 * 
	 * @author Waseem
	 * @return No return value.
	 */
	public void VerifySave() {
		QAFWebElement submit = new QAFExtendedWebElement("xpath=//button[@type='submit']");
		QAFWebElement closebtn = new QAFExtendedWebElement("xpath=//button[@ng-click='importedScope.close()']");
		if (submit.isEnabled()) {
			submit.click();
			QAFWebElement spinnercontainer = new QAFExtendedWebElement("xpath=//div[@class='slds-spinner_container']");
			while (spinnercontainer.isPresent()) {
				util.waitFor(2);
			}
		} else {
			closebtn.click();
			Reporter.log("no changes applied");
		}
	}

	/**
	 * getOptionsDropdown -- get all the option from the dropdown
	 * 
	 * @author Waseem
	 * @return this method returns all the options of the dropdown as a list of
	 *         WebElement
	 */
	public List<WebElement> getOptionsDropdown(QAFWebElement element) {
		Select select = new Select(element);
		List<WebElement> allOptions = select.getOptions();
		return allOptions;
	}

	/**
	 * getSelectedOptionDropdown -- It
	 * 
	 * @author Waseem
	 * @return
	 * @return this method returns all the options of the dropdown as a list of
	 *         WebElement
	 */
	public String getSelectedOptionDropdown(QAFWebElement element) {
		Select select = new Select(element);
		WebElement ele = select.getFirstSelectedOption();
		return ele.getText();
	}

	/**
	 * bespokeRecurringChargePrice --It OverRides the Recurring Charge Value for a
	 * Particular Plan.
	 * 
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to change the Recurring Charge
	 *              Value .
	 * @param Price --Vale of the Price is giving to Change with Particular Plan .
	 * @return No return value.
	 */
	public void bespokeRecurringChargePrice(String Plan, String Price, String AdjustVALUE) {
		util.clickUsingJs(By.xpath("(//span[.='" + Plan + "']/following::span[@class='cpq-underline'])[3]/span/span"));
		util.clickUsingJs(By.xpath("//span[text()='" + Plan + "']//following::button[@title='Change Price'][2]"));
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//span[contains(text(),'" + AdjustVALUE + "')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(Price);
		Reporter.logWithScreenShot("Selected adjustment type: " + AdjustVALUE + "\nAdjusted price: " + Price);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(6);
		QAFWebElement close = new QAFExtendedWebElement(
				"xpath=//h2[text()='Adjustment']//following::div/button[contains(text(),'Close')]");
		if (close.isPresent()) {
			close.click();
		}
	}

	/**
	 * bespokeOneTimeChargePrice --It OverRides the One Time Charge Value for a
	 * Particular Plan.
	 * 
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to change the One Time Charge
	 *              Value .
	 * @param Price --Vale of the Price is giving to Change with Particular Plan .
	 * @return No return value.
	 */
	public void bespokeOneTimeChargePrice(String Plan, String Price, String AdjustVALUE) {
		util.clickUsingJs(By.xpath("(//span[.='" + Plan + "']/following::span[@class='cpq-underline'])[5]/span/span"));
		util.clickUsingJs(By.xpath("//span[text()='" + Plan + "']//following::button[@title='Change Price'][3]"));
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//span[contains(text(),'" + AdjustVALUE + "')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(Price);
		Reporter.logWithScreenShot("Selected adjustment type: " + AdjustVALUE + "\nAdjusted price: " + Price);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(6);
		QAFWebElement close = new QAFExtendedWebElement(
				"xpath=//h2[text()='Adjustment']//following::div/button[contains(text(),'Close')]");
		if (close.isPresent()) {
			close.click();
		}
	}

	/**
	 * mousemover method help to move the mouse
	 * 
	 * @author Waseem
	 * @return No return value.
	 * @throws AWTException
	 */
	public void mouseMover() {
		Robot robot = null;
		try {
			robot = new Robot();
			Random random = new Random();
			int x = random.nextInt() % 640;
			int y = random.nextInt() % 480;
			robot.mouseMove(x, y);
		} catch (AWTException e) {
			e.printStackTrace();
		}
	}

	/**
	 * checkRecurringChargePrice --It checks the Recurring Charge Value for a
	 * Particular Plan.
	 * 
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to checks the Recurring Charge
	 *              Value .
	 * @param Price --Vale of the Price is giving to validate with cart Price .
	 * @return No return value.
	 */
	public void checkRecurringChargePrice(String Plan, String Price) {
		String cartPrice = driver.findElement(By.xpath(
				"((//span[.='" + Plan + "'])[last()]/following::span/span/span[contains(@ng-class,'imported')])[3]"))
				.getText();
		Reporter.log("Cart Price" + cartPrice + "");
		Validator.verifyThat("Recurring Price of " + Plan, cartPrice, Matchers.equalTo(Price));
	}

	/**
	 * checkOneTimeChargePrice --It checks the One Time Charge Value for a
	 * Particular Plan.
	 * 
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to checks the One Time Charge
	 *              Value .
	 * @param Price --Vale of the Price is giving to validate with cart Price .
	 * @return No return value.
	 */
	public void checkOneTimeChargePrice(String Plan, String Price) {
		String cartPrice = driver.findElement(By.xpath(
				"((//span[.='" + Plan + "'])[last()]/following::span/span/span[contains(@ng-class,'imported')])[5]"))
				.getText();
		Reporter.log("Cart Price" + cartPrice + "");
		Validator.verifyThat("One Time Charge of " + Plan, cartPrice, Matchers.equalTo(Price));
	}

	/**
	 * checkUsagePrice --It checks the Usage Charge Value for a Particular Plan.
	 * 
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to checks the Recurring Charge
	 *              Value .
	 * @param Price --Vale of the Price is giving to validate with cart Price .
	 * @return No return value.
	 */
	public void checkUsagePrice(String Plan, String Price) {
		String cartPrice = driver.findElement(By.xpath(
				"((//span[.='" + Plan + "'])[last()]/following::span/span/span[contains(@ng-class,'imported')])[1]"))
				.getText();
		Validator.verifyThat("Usage Price of " + Plan, cartPrice, Matchers.equalTo(Price));
	}

	/**
	 * bespokeRecurringChargePrice --It OverRides the Recurring Charge Value for a
	 * Particular Plan.
	 * 
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to change the Recurring Charge
	 *              Value .
	 * @param Price --Vale of the Price is giving to Change with Particular Plan .
	 * @return No return value.
	 */
	public void bespokeRecurringChargePrice(String Plan, String Price) {
		Reporter.log("Bespoking Recurring  Charge of " + Plan);
		util.clickUsingJs(By.xpath("(//span[.='" + Plan + "']/following::span[@class='cpq-underline'])[3]/span/span"));
		util.clickUsingJs(By.xpath("(//span[.='" + Plan + "']/following::button[@title='Change Price'])[2]"));
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//span[contains(text(),'Override')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(Price);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(By.xpath("//button[text()[contains(.,'Apply')]]"), 10, false);
		try {
			driver.findElement(By.xpath("//button[contains(text(),'Close')]")).click();
		} catch (Exception e) {
		}
	}

	/**
	 * bespokeOneTimeChargePrice --It OverRides the One Time Charge Value for a
	 * Particular Plan.
	 * 
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to change the One Time Charge
	 *              Value .
	 * @param Price --Vale of the Price is giving to Change with Particular Plan .
	 * @return No return value.
	 */
	public void bespokeOneTimeChargePrice(String Plan, String Price) {
		Reporter.log("Bespoking One Time Charge of " + Plan);
		util.clickUsingJs(By.xpath("(//span[.='" + Plan + "']/following::span[@class='cpq-underline'])[5]/span/span"));
		util.clickUsingJs(By.xpath("(//span[.='" + Plan + "']/following::button[@title='Change Price'])[3]"));
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//span[contains(text(),'Override')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(Price);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(By.xpath("//button[text()[contains(.,'Apply')]]"), 10, false);
		try {
			driver.findElement(By.xpath("//button[contains(text(),'Close')]")).click();
		} catch (Exception e) {
		}
	}

	/**
	 * bespokeRecurringChargePriceChild --It OverRides the Recurring Charge Value
	 * for a Particular Plan.
	 *
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to change the Recurring Charge
	 *              Value .
	 * @param child --name of the child Plan which is going to change the Recurring
	 *              Charge Value .
	 * @param Price --Vale of the Price is giving to Change with Particular Plan .
	 * @return No return value.
	 */
	public void bespokeRecurringChargePriceChild(String Plan, String child, String Price) {
		Reporter.log("Bespoking Recurring Charge of " + Plan);
		util.clickUsingJs(By.xpath("(//span[text()='" + Plan + "']/following::span[normalize-space()='" + child
				+ "'])[2]/following::span[@class='cpq-underline'][3]/span/span"));
		util.clickUsingJs(By.xpath("((//span[text()='" + Plan + "']//following::span[normalize-space()='" + child
				+ "'])[2]//following::button[@title='Change Price'])[2]"));
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//span[contains(text(),'Override')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(Price);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(By.xpath("//button[text()[contains(.,'Apply')]]"), 10, false);
		QAFWebElement close = new QAFExtendedWebElement(
				"xpath=//h2[text()='Adjustment']//following::div/button[contains(text(),'Close')]");
		if (close.isPresent()) {
			close.click();
		}
	}

	/**
	 * bespokeOneTimeChargePriceChild --It OverRides the One Time Charge Value for a
	 * Particular Plan.
	 *
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to change the One Time Charge
	 *              Value .
	 * @param child --name of the child Plan which is going to change the Recurring
	 *              Charge Value .
	 * @param Price --Vale of the Price is giving to Change with Particular Plan .
	 * @return No return value.
	 */
	public void bespokeOneTimeChargePriceChild(String Plan, String child, String Price) {
		Reporter.log("Bespoking One Time Charge of " + Plan);
		util.clickUsingJs(By.xpath("(//span[text()='" + Plan + "']/following::span[normalize-space()='" + child
				+ "'])[2]/following::span[@class='cpq-underline'][5]/span/span"));
		util.clickUsingJs(By.xpath("((//span[text()='" + Plan + "']//following::span[normalize-space()='" + child
				+ "'])[2]//following::button[@title='Change Price'])[3]"));
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//span[contains(text(),'Override')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(Price);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(By.xpath("//button[text()[contains(.,'Apply')]]"), 10, false);
		QAFWebElement close = new QAFExtendedWebElement(
				"xpath=//h2[text()='Adjustment']//following::div/button[contains(text(),'Close')]");
		if (close.isPresent()) {
			close.click();
		}
	}

	/**
	 * checkRecurringChargePriceChild --It checks the Recurring Charge Value for a
	 * Particular Plan.
	 * 
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to checks the Recurring Charge
	 *              Value .
	 * @param child --name of the child Plan which is going to checks the One Time
	 *              Charge Value .
	 * @param Price --Vale of the Price is giving to validate with cart Price .
	 * @return No return value.
	 */
	public void checkRecurringChargePriceChild(String Plan, String child, String Price) {
		String cartPrice = driver
				.findElement(By.xpath("(((//span[.='" + Plan + "'])/following::span[normalize-space()='" + child
						+ "'][2])/following::span/span/span[contains(@ng-class,'imported')])[3]"))
				.getText();
		Reporter.log("Cart Price" + cartPrice + "");
		Validator.verifyThat("One Time Charge of " + child, cartPrice, Matchers.equalTo(Price));
	}

	/**
	 * checkOneTimeChargePriceChild --It checks the One Time Charge Value for a
	 * Particular Plan.
	 * 
	 * @author Vinay
	 * @param Plan  --name of the Plan which is going to checks the One Time Charge
	 *              Value .
	 * @param child --name of the child Plan which is going to checks the One Time
	 *              Charge Value .
	 * @param Price --Vale of the Price is giving to validate with cart Price .
	 * @return No return value.
	 */
	public void checkOneTimeChargePriceChild(String Plan, String child, String Price) {
		String cartPrice = driver
				.findElement(By.xpath("(((//span[.='" + Plan + "'])/following::span[normalize-space()='" + child
						+ "'][2])/following::span/span/span[contains(@ng-class,'imported')])[5]"))
				.getText();
		Reporter.log("Cart Price" + cartPrice + "");
		Validator.verifyThat("One Time Charge of " + child, cartPrice, Matchers.equalTo(Price));
	}

	/**
	 * bespokeRecurringChargePriceForR4 --It OverRides the Recurring Charge Value
	 * for a Particular Plan For R4 Products.
	 * 
	 * @author Vinay
	 * @param Plan        --name of the Plan which is going to change the Recurring
	 *                    Charge Value .
	 * 
	 * @param Price       --Vale of the Price is giving to Change with Particular
	 *                    Plan .
	 * 
	 * @param AdjustVALUE --Choice of the AdjustVALUE is giving to Choose the Price
	 *                    change .
	 * 
	 * @return No return value.
	 */
	public void bespokeRecurringChargePriceForR4(String Plan, String Price, String AdjustVALUE) {
		util.scrollIntoElement(By.xpath("(//span[.='" + Plan + "'])"));
		util.clickUsingJs(By.xpath("(//span[.='" + Plan + "']/following::span[@class='cpq-underline'])[1]/span/span"));
		util.clickUsingJs(By.xpath("//span[text()='" + Plan + "']//following::button[@title='Change Price'][1]"));
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//span[contains(text(),'" + AdjustVALUE + "')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(Price);
		Reporter.logWithScreenShot("Selected adjustment type: " + AdjustVALUE + "\nAdjusted price: " + Price);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(6);
		QAFWebElement close = new QAFExtendedWebElement(
				"xpath=//h2[text()='Adjustment']//following::div/button[contains(text(),'Close')]");
		if (close.isPresent()) {
			close.click();
		}
	}

	/**
	 * bespokeRecurringChargePriceForR4 --It OverRides the Recurring Charge Value
	 * for a Particular Plan For R4 Products.
	 * 
	 * @author Vinay
	 * @param Plan        --name of the Plan which is going to change the Recurring
	 *                    Charge Value .
	 * @param Price       --Vale of the Price is giving to Change with Particular
	 *                    Plan .
	 * 
	 * @param AdjustVALUE --Choice of the AdjustVALUE is giving to Choose the Price
	 *                    change .
	 * 
	 * @return No return value.
	 */
	public void bespokeOneTimeChargePriceForR4(String Plan, String Price, String AdjustVALUE) {
		util.scrollIntoElement(By.xpath("(//span[.='" + Plan + "'])"));
		util.clickUsingJs(By.xpath("(//span[.='" + Plan + "']/following::span[@class='cpq-underline'])[3]/span/span"));
		util.clickUsingJs(By.xpath("//span[text()='" + Plan + "']//following::button[@title='Change Price'][last()]"));
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//a/span[contains(text(),'" + AdjustVALUE + "')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(Price);
		Reporter.logWithScreenShot("Selected adjustment type: " + AdjustVALUE + "\nAdjusted price: " + Price);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(10);
		QAFWebElement close = new QAFExtendedWebElement(
				"xpath=//h2[text()='Adjustment']//following::div/button[contains(text(),'Close')]");
		if (close.isPresent()) {
			close.click();
		}
	}

	/**
	 * bespokeRecurringChargePriceForR4 --It OverRides the Recurring Charge Value
	 * for a Particular Plan For R4 Products.
	 * 
	 * @author Vinay
	 * @param Plan        --name of the Plan which is going to change the Recurring
	 *                    Charge Value .
	 * @param Price       --Vale of the Price is giving to Change with Particular
	 *                    Plan .
	 * 
	 * @param AdjustVALUE --Choice of the AdjustVALUE is giving to Choose the Price
	 *                    change .
	 * 
	 * @return No return value.
	 */
	public void bespokeOneTimeChargePriceForR4Device(String Plan, String Device, String Price, String AdjustVALUE) {
		util.scrollIntoElement(By.xpath("(//span[.='" + Plan + "'])"));
		util.clickUsingJs(By.xpath("(//span[.='" + Plan + "']/following::span[text()='" + Device
				+ "']/following::span[@class='cpq-underline'])[3]/span/span"));
		util.clickUsingJs(By.xpath("//span[.='" + Plan + "']/following::span[text()='" + Device
				+ "']//following::button[@title='Change Price'][2]"));
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//a/span[contains(text(),'" + AdjustVALUE + "')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(Price);
		Reporter.logWithScreenShot("Selected adjustment type: " + AdjustVALUE + "\nAdjusted price: " + Price);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(10);
		QAFWebElement close = new QAFExtendedWebElement(
				"xpath=//h2[text()='Adjustment']//following::div/button[contains(text(),'Close')]");
		if (close.isPresent()) {
			close.click();
		}
	}

}
