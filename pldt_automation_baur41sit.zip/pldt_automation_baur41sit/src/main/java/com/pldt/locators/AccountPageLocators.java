package com.pldt.locators;

public interface AccountPageLocators {
	static final String show_All="xpath=//a[contains(text(),'Show All')]";
	static final String Asset="xpath=//ul/li//records-hoverable-link//slot//*[contains(text(),'Assets')]";
	static final String Opportunities="xpath=//ul/li//records-hoverable-link//slot//*[contains(text(),'Opportunities')]";
	static final String listview = "xpath=//button[@title='Select a List View']"; //updated
	static final String allaccount = "xpath=//span[text()='All Accounts']/parent::a";
	static final String searchInput = "xpath=//input[@placeholder='Search this list...']";
	static final String AllAccountEE = "xpath=//span[text()='All Accounts - EE']/parent::a";
	static final String AllAccountBusiness= "xpath=(//span[text()='All Accounts - Business Accounts'])[1]";
	static final String Quotes = "xpath=//ul/li//force-hoverable-link//slot//*[contains(text(),'Quotes')]";
	static final String filter = "xpath=(//*[text()='Select List View'])/parent::*";
	static final String  searchList = "xpath=//input[@placeholder='Search this list...']";
	static final String contacts= "xpath=(//ul/li//force-hoverable-link//slot//*[contains(text(),'Contacts')])[1]";
	static final String Cases="xpath=//ul/li//records-hoverable-link//slot//*[contains(text(),'Cases')]";

}
