package com.pldt.locators;

public interface BillingAndServiceAccountLocator
{
	static final String Save = "xpath=//span[normalize-space(text())='Save']";
	static final String Menu="xpath=(//i[@class='icon icon-v-menu2'])[1]";
	static final String CreateBillingAccount="xpath=(//span[text()='Create New Billing Account'])[1]";
	static final String CreateServiceAccount="xpath=(//span[text()='Create New Service Account'])[1]";
}
