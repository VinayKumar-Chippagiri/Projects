package com.pldt.locators;

public interface VlocityPageLocators {
	static final String singleTransBtn="xpath=//span[text()='Single transaction']/preceding-sibling::span";
	static final String headingEligibility="xpath=//h1[text()='Eligibility check']";
	static final String phoneNoInputBox="xpath=//input[@class='vlocity-input slds-input']";
	static final String checkEligiBtn="xpath=//span[text()='Check Eligibility']";
	static final String nextBtn="xpath=//span[text()='Next']";
	static final String downloadAsCsvBtn="xpath=//button[@title='Download CSV File']";
	static final String resultNextBtn="xpath=//button[@title='next']";
	static final String finalDoneBtn="xpath=//span[text()='Done']";

	static final String bulkTransBtn="xpath=//span[text()='Bulk transaction']/preceding-sibling::span";
	static final String uploadFile="xpath=//input[@class='slds-file-selector__input slds-assistive-text']";

}
