package com.pldt.locators;

import org.openqa.selenium.By;

public interface AssetPageLocators {
	static final String Case_NewButton = "xpath=(//span[@title='Cases']/following::a[@title='New'])[1]";
	static final String Cases_Btn = "xpath=//div[@class='container']/div[2]//span[@title='Cases']/parent::a";
	static final String quickfilterA = "xpath=//button[@title='Show quick filters']";
	static final String assetinputA = "xpath=(//label[text()='Asset Name']/following::input)[1]";
	static final String mininputA = "xpath=(//label[text()='MIN']/following::input[@name='Asset-MIN__c'])";
	static final String quickfilter = "xpath=//button[@title='Show quick filters']";
	static final String assetinput = "xpath=(//label[text()='Asset Name']/following::input)[1]";
	static final String mininput = "xpath=(//label[text()='MIN']/following::input[@name='Asset-MIN__c'])";
	static final String APPLYBUTTON = "xpath=//button[@title='Apply']";
	static final String CLOSE_FILTER = "xpath=//button[@title='Close Filters']";
	static final String relatedTab = "xpath=//span[text()='Related']";
	static final String RelatedTab = "xpath=//span[text()='Related']";
	public static By details = By.xpath("//span[text()='Details']");
	public static By billAccountNumber = By
			.xpath("//span[text()='CRM Billing Account Number']/parent::div/following-sibling::div/span/span");
	public static By related = By.xpath("//span[text()='Related']");
}
