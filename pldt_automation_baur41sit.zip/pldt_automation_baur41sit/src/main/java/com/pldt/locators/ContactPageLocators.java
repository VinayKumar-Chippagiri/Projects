package com.pldt.locators;

public interface ContactPageLocators {
	static final String CONTACT_NEW ="xpath=(//a[@title='New'])";
	static final String AccCONTACT_NEW="xpath=//button[text()='New']";
	// Contact Information
	static final String CONTACT_SALUTATION = "xpath=//input[@name=\"salutation\"]";
	static final String CONTACT_FIRST_NAME = "xpath=//input[@placeholder='First Name']";
	static final String CONTACT_MID_NAME = "xpath=//input[@placeholder='Middle Name']";
	static final String CONTACT_LAST_NAME = "xpath=//input[@placeholder='Last Name']";
	static final String CONTACT_SUFFIX = "xpath=//input[@placeholder='Suffix']";
	static final String CONTACT_ACCOUNT_NAME = "xpath=(//label[text()='Account Name']/following::div/input[@placeholder='Search Accounts...'])[1]";
	static final String CONTACT_TITLE = "xpath=//input[@name=\"Title\"]";
	static final String CONTACT_ROLE = "xpath=//label[text()='CONTACT Role']//parent::lightning-combobox//input";
	static final String CONTACT_PARTNER = "xpath=(//span[text()='Partner']/following::div//input[@name='vlocity_cmt__IsPartner__c'])";
	static final String CONTACT_STATUS = "xpath=//label[text()='CONTACT Status']//parent::lightning-combobox//input";
	static final String CONTACT_CURENCY = "xpath=(//label[text()='Contact Currency']/following::div/input[@aria-controls='dropdown-element-262'])";
	// Contact Numbers
	static final String CONTACT_PHONE = "xpath=//input[@name=\"Phone\"]";
	static final String CONTACT_MOBILE = "xpath=//input[@name=\"MobilePhone\"]";
	static final String CONTACT_OTHER_PHONE = "xpath=(//label[text()='Other Phone']/following::div//input[@name='OtherPhone'])";
	static final String CONTACT_HOME_PHONE = "xpath=(//label[text()='Home Phone']/following::div//input[@name='HomePhone'])";
	static final String CONTACT_FAX = "xpath=(//label[text()='Fax']/following::div//input[@name='Fax'])";
	// Personal Information
	static final String CONTACT_BIRTHDATE = "xpath=//input[@name='Birthdate']";
	static final String CONTACT_GENDER = "xpath=(//label[text()='Gender']/following::div/input[@aria-controls='dropdown-element-303'])";
	static final String CONTACT_CIVIL_STATUS = "xpath=(//label[text()='Civil Status']/following::div/input[@name='Civil_Status__c'])";
	static final String CONTACT_DRIVERS_LICENSE_NUMBER = "xpath=//input[@name='vlocity_cmt__DriversLicenseNumber__c']";
	static final String CONTACT_TAX_ID = "xpath=//input[@name='vlocity_cmt__TaxId__c']";
	static final String CONTACT_EMAIL = "xpath=//input[@name=\"Email\"]";
	// Employee Details
	static final String CONTACT_EMPLOYEE = "xpath=(//span[text()='Employee']/following::span//input[@name='vlocity_cmt__IsEmployee__c'])";
	static final String CONTACT_EMPLOYER = "xpath=(//label[text()='Employer']/following::div//input[@placeholder='Search Accounts...'])";
	static final String CONTACT_EMPLOYMENT_STATUS = "xpath=(//label[text()='Employment Status']/following::div//input[@aria-controls='dropdown-element-337'])";
	static final String CONTACT_DEPARTMENT = "xpath=(//label[text()='Department']/following::div//input[@name='Department'])";
	// Address Information
	static final String CONTACT_MAILING_ADDRESS = "xpath=(//legend[text()='Mailing Address']/following::input[@placeholder='Search Address'])[1]";
	static final String CONTACT_MAILING_COUNTRY = "xpath=(//label[text()='Mailing Country']/following::div/input[@name='country'])[1]";
	static final String CONTACT_MAILING_STREET = "xpath=(//label[text()='Mailing Street']/following::div/textarea[@name='street'])[1]";
	static final String CONTACT_MAILING_CITY = "xpath=(//label[text()='Mailing City']/following::div/input[@name='city'])[1]";
	static final String CONTACT_MAILING_STATE_PROVINCE = "xpath=(//label[text()='Mailing State/Province']/following::div/input[@name='province'])[1]";
	static final String CONTACT_MAILING_ZIP_POSTAL_CODE = "xpath=(//label[text()='Mailing Zip/Postal Code']/following::div/input[@name='postalCode'])[1]";
	static final String CONTACT_OTHER_ADDRESS = "xpath=(//legend[text()='Other Address']/following::div/input[@placeholder='Search Address'])[1]";
	static final String CONTACT_OTHER_COUNTRY = "xpath=(//label[text()='Other Country']/following::div/input[@name='country'])[1]";
	static final String CONTACT_OTHER_STREET = "xpath=(//label[text()='Other Street']/following::div/textarea[@name='street'])[1]";
	static final String CONTACT_OTHER_CITY = "xpath=(//label[text()='Other City']/following::div/input[@name='city'])[1]";
	static final String CONTACT_OTHER_STATE_PROVINCE = "xpath=(//label[text()='Other State/Province']/following::div/input[@name='province'])[1]";
	static final String CONTACT_OTHER_ZIP_POSTAL_CODE = "xpath=(//label[text()='Other Zip/Postal Code']/following::div/input[@name='postalCode'])[1]";
	// Additional Information
	static final String CONTACT_WEBSITE = "xpath=(//label[text()='Web Site']/following::div/input[@name='vlocity_cmt__WebSite__c'])";
	static final String CONTACT_ASSISTANT = "xpath=(//label[text()='Assistant']/following::div/input[@name='AssistantName'])";
	static final String CONTACT_ASST_PHONE = "xpath=(//label[text()='Asst. Phone']/following::div/input[@name='AssistantPhone'])";
	static final String CONTACT_LEAD_SOURCE = "xpath=(//label[text()='Lead Source']/following::div/input[@role='combobox'])[1]";
	static final String CONTACT_CUSTOMER_SENTIMENT = "xpath=(//label[text()='Customer Sentiment']/following::div/input[@role='combobox'])[1]";
	// Consent Management
	static final String CONTACT_SALESFORCE_EMAIL_OPT_OUT = "XPATH=(//span[text()='Salesforce Email Opt Out']/following::span/input[@name='SalesforceEmailOptOut__c'])";
	static final String CONTACT_PARDOT_EMAIL_OPT_OUT = "xpath=(//span[text()='Pardot Email Opt Out']/following::span/input[@name='HasOptedOutOfEmail'])";
	static final String CONTACT_DO_NOT_CALL = "xpath=(//span[text()='Do Not Call']/following::span/input[@name='DoNotCall'])";
	static final String CONTACT_DATA_PRIVACY_POLICY_ACCEPTANCE = "xpath=(//span[text()='Data Privacy Policy Acceptance']/following::span/input[@name='isPrivacyNoticeAccepted__c'])";
	static final String CONTACT_LEAD_GEN_PRIVACY_NOTICE_CONSENT = "xpath=(//span[text()='Lead Gen Privacy Notice Consent']/following::span/input[@name='Lead_Gen_Privacy_Notice_Consent__c'])";
	static final String CONTACT_SALES_ENGAGEMENT_CONSENT = "xpath=(//span[text()='Sales Engagement Consent']/following::span/input[@name='Sales_Engagement_Consent__c'])";
	// Marketing Consent Management
	static final String CONTACT_ANALYTICS_CONSENT = "xpath=(//span[text()='Analytics Consent']/following::span/input[@name='Analytics_Consent__c'])";
	static final String CONTACT_MARKETING_CONSENT = "xpath=(//span[text()='Marketing Consent']/following::span/input[@name='Marketing_Consent__c'])";
	static final String CONTACT_SERVICE_OUTBOUND_ACTIVITIES_CONSENT = "xpath=(//span[text()='Service Outbound Activities Consent']/following::span/input[@name='Service_Outbound_Activities_Consent__c'])";
	static final String CONTACT_CUSTOMER_PORTAL_CONSENT = "xpath=(//span[text()='Customer Portal Consent']/following::span/input[@name='Customer_Portal_Consent__c'])";
	static final String CONTACT_AUTOMATED_FEEDBACK_FOR_REPAIR = "xpath=(//span[text()='Automated Feedback for Repair']/following::span/input[@name='Automated_Feedback_for_Repair__c'])";
	static final String CONTACT_INSIGHT_GENERATION = "xpath=(//span[text()='Insight Generation']/following::span/input[@name='Insight_Generation__c'])";
	static final String CONTACT_DATA_STORAGE_AFTER_END_OF_CONTRACT = "xpath=(//span[text()='Data Storage After End of Contract']/following::span/input[@name='Data_Storage_After_End_of_Contract__c'])";
	static final String CONTACT_EVENTS_CONSENT = "xpath=(//span[text()='Events Consent']/following::span/input[@name='Events_Consent__c'])";
	static final String CONTACT_BILLING_PLATFORM_CONSENT = "xpath=(//span[text()='Billing Platform Consent']/following::span/input[@name='Billing_Platform_Consent__c'])";
	static final String CONTACT_SURVEY_CONSENT = "xpath=(//span[text()='Survey Consent']/following::span/input[@name='Survey_Consent__c'])";
	static final String CONTACT_RETENTION_AUTOMATED_NOTIFICATION = "xpath=(//span[text()='Retention Automated Notification']/following::span/input[@name='Retention_Automated_Notification__c'])";
	static final String CONTACT_SERVICE_ADVISORIES = "xpath=(//span[text()='Service Advisories']/following::span/input[@name='Service_Advisories__c'])";
	static final String CONTACT_USAGE_ANALYSIS = "xpath=(//span[text()='Usage Analysis']/following::span/input[@name='Usage_Analysis__c'])";
	// Legacy System Numbers
	static final String CONTACT_LEGACY_SFDC_CONTACT_ID = "xpath=(//label[text()='Legacy SFDC Contact Id']/following::div/input[@name='Legacy_SFDC_Contact_Id__c'])";
	static final String CONTACT_LEGACY_CSP_CONTACT_ID = "xpath=(//label[text()='Legacy CSP Contact ID']/following::div/input[@name='Legacy_CSP_Contact_ID__c'])";
	static final String CONTACT_LEGACY_SIEBEL_CONTACT_ID = "xpath=(//label[text()='Legacy Siebel Contact ID']/following::div/input[@name='Legacy_Siebel_Contact_ID__c'])";
	static final String CONTACT_LEGACY_SAP_B1_CONTACT_ID = "xpath=(//label[text()='Legacy SAP B1 Contact ID']/following::div/input[@name='Legacy_SAP_B1_Contact_ID__c'])";
	static final String CONTACT_LEGACY_DATA_MIGRATION_SOURCE_SYSTEM = "xpath=(//label[text()='Legacy Data Migration Source System']/following::div/input[@name='Legacy_Data_Migration_Source_System__c'])";
	static final String CONTACT_CANCEL_BUTTON = "xpath=//button[@name='CancelEdit']";
	static final String CONTACT_SAVE_NEW_BUTTON = "xpath=//button[@name='SaveAndNew']";
	static final String CONTACT_SAVE = "xpath=//button[@name='SaveEdit']";

	//Account List Dropdown
	static final String CONTACT_ACCOUNT_LIST="xpath=//label[text()='Account Name']/following::div/div//div/div[@role='listbox']/ul/li";

}
