package com.pldt.locators;

public interface DashboardPageLocators {
	static final String Dasboard_NEW ="xpath=(//a[@title='New Dashboard'])";
	static final String DASHBOARD_CREATE ="xpath=(//button[.='Create'])";
	static final String DASBOARD_SEARCH  ="xpath=//input[contains(@placeholder,'Search all dashboards')]";
	static final String Report_NEW ="xpath=(//a[@title='New Report'])";
	static final String Footer_Save="xpath=(//footer/button[text()='Save'])";

}
