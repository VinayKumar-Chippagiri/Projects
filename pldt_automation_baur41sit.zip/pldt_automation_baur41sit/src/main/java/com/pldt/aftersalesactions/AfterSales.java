package com.pldt.aftersalesactions;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.util.Reporter;

public class AfterSales extends WebDriverBaseTestPage<WebDriverTestPage>{
	WebUtilities util = new WebUtilities();
	static String billingAccountNumber = null;
	private static By save = By.xpath("//button[@title='Save']");
	public static By resolutionInProg = By
			.xpath("//span[text()='Resolution In Progress'][@class='title slds-path__title']");
	public static By markCurrentStatus = By.xpath("//span[text()='Mark as Current Status']");
	public static By related = By.xpath("//span[text()='Related']");
	public static By billAccountNumber = By
			.xpath("//span[text()='CRM Billing Account Number']/parent::div/following-sibling::div/span/span");
	public static By details = By.xpath("//span[text()='Details']");
	public static By appLauncher = By.xpath("//*[@aria-label=\"App\"]/one-app-launcher-header/button/div");
	public static By appSearch = By.xpath("//input[@placeholder=\"Search apps and items...\"]");
	public static By filter = By.xpath("(//*[text()='Select a List View'])/parent::*");
	public static By searchList = By.xpath("//input[@placeholder='Search this list...']");
	public static By showAll = By.xpath("//ul/following-sibling::div/a[contains(text(),'Show All')]");
	public static By asset = By.xpath("//ul/li//records-hoverable-link//slot/span[contains(text(),'Assets')]");
	public static By quickfilter = By.xpath("(//button[@title='Show quick filters'])");
	public static By assetinput = By.xpath("(//label[text()='Asset Name']/following::input)[1]");
	public static By mininput = By.xpath("(//label[text()='MIN']/following::input[@name='Asset-MIN__c'])");
	public static By cases = By.xpath("(//div/h2/a/span[text()='Cases'])[1]");
	public static By newButton = By.xpath("//div[text()='Change Owner']/ancestor::ul/li/a/div[text()='New']");
	public static By subjectInput = By.xpath("(//label[text()='Subject']/following::input)[1]");
	public static By assetID = By.xpath("//span[.='Asset ID']/following::div[1]");
	public static By MINNumber = By.xpath("//span[.='MIN Number']/following::div[1]");
	public static By transactionStatus = By.xpath("//span[.='Transaction Status']/following::div[1]");
	public static By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	public static By goToQuote =By.xpath("//div[@id='GoToQuote']");
	private static By ordersHeaderLink =By.xpath("//span[@title='Orders']");
	private static By simReplacementFee = By.xpath("//span[.='SIM Replacement Fee']/following::div[1]");
	private static By changeOwnerEdit = By.xpath("//button[@title='Change Owner']");
	private static By searchUser = By.xpath("//input[@placeholder='Search Users...']");
	private static By changeOwnerButton = By.xpath("//button[@name='change owner']");
	private static By relatedSection = By.xpath("(//flexipage-record-home-scrollable-column)[3]");
	private static By transactionAsset = By.xpath("(//span[text()='Transaction Asset'])[1]/following-sibling::span");
	private static By editButton = By.xpath("//button[text()='Edit'][@class='slds-button slds-button_brand']");
	private static By highLevelDisconnection = By.xpath(
			"(//label[text()='High Level Disconnection Reason']/following::input[@name='High_Level_Disconnection_Reason__c'])");
	private static By saveRecord = By.xpath("//button[@class='slds-button slds-button_brand'][@type='submit']");
	private static By servicereq = By.xpath("//input[@class='slds-input slds-combobox__input']");
	private static By doneButton = By.xpath("//p[.='Done']");
	private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	private static By moveDocumentArrow = By.xpath("//span[text()='Move selection to Chosen']");
	private static By consigneeName = By
			.xpath("(//span[text()='Consignee Name']/following::input[@placeholder='Search Contacts...'])");
	private static By billingAccountName = By
			.xpath("//span[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");
	String current =null;
		public void createNewCaseFromAsset(Map<String ,String> data) {
			util.clickUsingJs(newButton);
			util.clickUsingJs(By.xpath("//*[text()='SMART Service Request']"));
			util.clickUsingJs(By.xpath("//span[.='Next']"));
			if(data.get("Transaction Type").contains("SIM Replacement"))
			{
				util.selectAndClickCaseSuggestedValue(consigneeName,data.get("Consignee Name"));
			}
			util.selectAndClickCaseSuggestedValue(billingAccountName, billingAccountNumber);
			util.type("Subject");
			util.select("Line of Business");
			util.select("Type of Customer Request");
			util.select("Type");
			util.select("High Level Transaction Classification");
			util.select("Transaction Type");
			util.select("Case Origin");
			click_availableDocuments();
			click_moveAvailableDocuments();
			util.clickUsingJs(save);
			Reporter.logWithScreenShot(util.waitForGenericToastMessage());
			Reporter.log("Entered mandatory fields and case got created..");
		}



		public void goToAccountRelatedCaseSearchPage()
		{

			String [] s=current.split("/");
			driver.get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Case/"+s[s.length-2]+"/related/Cases/view");
		}

		public  void markCaseStatus(By status,String Status) {
			int temp = 0;
			while (temp <= 5) {
				if (util.isElementDisplayed(status)) {
					System.out.println(util.isElementDisplayed(status));
					//util.clickUsingJs(status);

					util.ChangeStatus(Status);
					break;
				}
				util.clickUsingJs(By.xpath("//button/span[text()='Next']"));
				temp++;
			}
		}


		public void markCaseStatusToResolutionInprogress() {
			//markCaseStatus(resolutionInProg,"Resolution In Progress");
			util.clickUsingJs(By.xpath("(//div[@aria-label='Path Header']/ul/li/a[@data-tab-name='Resolution In Progress'])[last()]"));
			util.clickUsingJs(markCurrentStatus);
			util.waitForGenericToastMessage();

		}

		public void getBillAccountNumber() {
			util.clickUsingJs(details);
			util.waitFor(billAccountNumber, 5, true);
			billingAccountNumber = driver.findElement(billAccountNumber).getText();
			util.clickUsingJs(related);
		}


		public void goToAccountPage(String acountNameValue)
		{
			util.clickUsingJs(appLauncher);
			util.clickUsingJs(appSearch);
			util.enterText(appSearch, "Accounts");
			util.clickDropdownValue("Accounts");
			util.clickUsingJs(filter);
			util.clickDropdownValue("All Accounts - Business Accounts");
			util.enterText(searchList, acountNameValue);
			util.waitFor(By.xpath("//table[1]"), 5, true);
			util.enterKey();
			String path = "//a[text()=" + "'" + acountNameValue + "'" + "]";
			util.clickUsingJs(By.xpath(path));
		    util.waitForAccountPage();
		}

		public void selectAccountAsset(String minValue,String assetNameValue )
		{
			//util.scrollIntoElement(showAll);
		    driver.findElement(showAll).click();
			util.clickUsingJs(asset);
			util.clickUsingJs(quickfilter);
			util.clickUsingJs(assetinput);
			util.enterText(assetinput, assetNameValue);
			util.clickUsingJs(mininput);
			util.enterText(mininput, minValue);
			util.enterKey();
			String pat = "//a[text()=" + "'" + assetNameValue + "'" + "]";
			util.clickUsingJs(By.xpath(pat));
			util.waitForAssetPage();
			current= driver.getCurrentUrl();
		}


		public  void selectCase(String subjectValue) {

				util.clickUsingJs(quickfilter);
				util.clickUsingJs(subjectInput);
				util.enterText(subjectInput, subjectValue);
				util.enterKey();
				String Cat = "//a[text()=" + "'" + subjectValue + "'" + "]";
				util.openLink(By.xpath(Cat));
				util.waitForCasePage();

		}


		public boolean verifyTransactionDetailsForChangeMIN(String assetValue) {
			util.clickUsingJs(transactionDetails);
			System.out.println(util.getTextFromPage(assetID));
			System.out.println(util.getTextFromPage(MINNumber));
			System.out.println(util.getTextFromPage(transactionStatus));
			ArrayList<Boolean> check = new ArrayList<>();
			if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
				check.add(true);
			}
			check.add(util.isElementDisplayed(MINNumber));
			if (check.contains(false)) {
				System.out.println("Transaction details are verified");
				return false;
			}
			System.out.println("Transaction details are not verified");
			return true;
		}

		public  boolean verifyTransactionDetailsForSIMReplacement(String assetValue) {
			util.clickUsingJs(transactionDetails);
			System.out.println(util.getTextFromPage(assetID));
			System.out.println(util.getTextFromPage(MINNumber));
			System.out.println(util.getTextFromPage(simReplacementFee));
			ArrayList<Boolean> check = new ArrayList<>();
			if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)
					&& util.getTextFromPage(simReplacementFee).equals("0.00")) {
				check.add(true);
			}
			check.add(util.isElementDisplayed(MINNumber));
			if (check.contains(false)) {
				System.out.println("Transaction details are not populated correctly");
				return false;
			}
			System.out.println("Transaction details are verified");
			return true;
		}



		public  void verifyTransactionAsset() {

				JavascriptExecutor js = driver;
				js.executeScript("arguments[0].scroll(0,2500)", driver.findElement(relatedSection));
				if (!util.getTextFromPage(transactionAsset).equals("(0)")) {
					System.out.println("pass");
				}
				System.out.println("Transaction asset has been verified");

		}


		public  boolean verifyTransactionDetailsForConnectionScenarios(String assetValue, String transactionReasonValue,
				String transactiontype) {
			util.clickUsingJs(transactionDetails);
			util.clickUsingJs(editButton);
			if (transactiontype.contains("Reconnection")) {
				util.clickUsingJs(servicereq);
			} else {
				util.clickUsingJs(highLevelDisconnection);
			}
			util.clickDropdownValue(transactionReasonValue);
			util.clickUsingJs(saveRecord);
			ArrayList<Boolean> check = new ArrayList<>();
			if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
				check.add(true);
			}
			check.add(util.isElementDisplayed(MINNumber));
			if (check.contains(false)) {
				System.out.println("Transaction details are not populated correctly");
				return false;
			}
			System.out.println("Transaction details are verified");
			return true;
		}

		public void transactionActionForConnectionScenarios(String transactionType) {
			try {
				System.out.println("Click on Disconnection..");
				util.refreshPage();
				if (transactionType.contains("Termination")) {
					util.clickOnActionToolBarButton("QuoteActionToolbar", "Disconnect");

				} else {
					if (transactionType.contains("Reconnection")) {
						util.clickOnActionToolBarButton("QuoteActionToolbar", "Resume");
					} else {
						if (transactionType.contains("Temporary"))
							util.clickOnActionToolBarButton("QuoteActionToolbar", "Suspend");
					}
				}

				util.refreshSwitchToFrame();
				util.AttachFrame();
				util.clickUsingJs(doneButton);
				util.waitForCasePage();
			} catch (Exception e) {
			}
		}




		public void numberReservationCheck() {
			System.out.println("Click on Number Reservation..");
			util.clickOnActionToolBarButton("Quick Actions", "Reserve Numbers");
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.waitFor(By.xpath("//span[text()='Number/Pattern Search']"), 5, true);
			util.refreshSwitchToFrame();
			util.clickUsingJs(By.xpath("//span[text()='Number/Pattern Search']"));
			util.clickUsingJs(By.xpath("//p[text()='Next']"));
			util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")), "Regular");
			util.clickUsingJs(By.xpath("(//p[.='Search MIN'])[1]"));
			util.clickUsingJs(By.xpath("(//th/button)[1]"));
			util.clickUsingJs(By.xpath("//div[@id='StepMINSearchNo_nextBtn']"));
			util.clickUsingJs(By.xpath("(//p[text()='Next'])[3]"));
			util.AttachFrame();
			util.waitFor(By.xpath("//span[.='Number Reservation is successful.']"), 3, true);
			if (util.isElementDisplayed(By.xpath("//span[.='Number Reservation is successful.']"))) {
				util.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
			} else {
				for (int i = 0; i < 4; i++) {
					if (util.isElementDisplayed(By.xpath("//span[.='Number Reservation is successful.']"))) {
						util.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
						break;
					}
					util.AttachFrame();
					util.vlocityPreviousButton();
					util.AttachFrame();
					util.vlocityPreviousButton();
					util.AttachFrame();
					util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")), "Regular");
					driver.findElement(By.xpath("(//p[.='Search MIN'])[1]")).click();
					driver.findElement(By.xpath("(//th/button)[1]")).click();
					driver.findElement(By.xpath("//div[@id='StepMINSearchNo_nextBtn']")).click();
					driver.findElement(By.xpath("(//p[text()='Next'])[3]")).click();
				}
			}
			util.waitForQuotePage();
		}


		public void updateQuoteValidatyPeriod(Map<String, String> data) {
			util.waitFor(By.xpath("//span[.='Quotation Validity Period (Days)']"), 10, true);
			util.scrollIntoElement(By.xpath("//span[.='Quotation Validity Period (Days)']"));
			util.clickUsingJs(By.xpath("//button[@title='Edit Quotation Validity Period (Days)']"));
			util.enterText(
					driver.findElement(By.xpath(
							"//span[text()='Quotation Validity Period (Days)']/parent::label/following-sibling::input")),
					data.get("QuotationValidity"));
			util.clickUsingActions(By.xpath("//div[@class='active']//span[.='Quotation Validity Period (Days)']"));
			util.clickUsingJs(By.xpath("//button[@title='Save']"));
			util.waitFor(By.xpath("//button[@title='Save']"), 5, false);
		}


		public void ValidateCart() {
			util.clickOnActionToolBarButton("QuoteActionToolbar", "Validate Cart");
			util.waitFor(By.xpath("vlocity_cmt__OmniScriptUniversalPage | Salesforce"), 20, true);
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.clickUsingJs(goToQuote);
			util.waitForQuotePage();
		}


		public void changeQuoteStatustoAccepted() {
			util.ChangeStatus("Accepted");
		}

		public ArrayList<String> VerifyOrders() {
			util.clickUsingJs(related);
			util.clickUsingJs(ordersHeaderLink);
			return util.refreshOrders(60, 1);
		}

		public void requestSIMReplacement() {
			util.clickOnActionToolBarButton("Quick Actions", "SIM Replacement");
			util.clickUsingJs(doneButton);
			util.waitForCasePage();
		}
		public  void changeOwner(String ownerNameValue) {

				util.clickUsingJs(changeOwnerEdit);
				util.enterText(searchUser, ownerNameValue);
				util.clickUsingJs(By.xpath("//ul/li//div[@title='" + ownerNameValue + "']"));
				util.clickUsingJs(changeOwnerButton);
				Reporter.logWithScreenShot(util.waitForGenericToastMessage());

		}


		public  void click_availableDocuments() {
			util.scrollIntoElement(availableDocuments);
			util.moveToElement(availableDocuments);
			util.clickUsingActions(availableDocuments);
		}

		public  void click_moveAvailableDocuments() {
			util.clickUsingJs(moveDocumentArrow);
		}

		public  void goToCaseOrdersSearchPage(String caseURL) {
			String orderSearchPage = caseURL.replaceFirst("/view", "/related/Orders__r/view");
			driver.get(orderSearchPage);
		}

		public void verifyOrdersFromCasePage(String caseURL)
		{
			goToCaseOrdersSearchPage(caseURL);
		}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}
}
