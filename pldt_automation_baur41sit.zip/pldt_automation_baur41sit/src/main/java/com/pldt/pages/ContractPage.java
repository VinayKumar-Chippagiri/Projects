package com.pldt.pages;

import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.pldt.locators.ContractPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class ContractPage extends WebDriverBaseTestPage<WebDriverTestPage> implements ContractPageLocators {
	WebUtilities util = new WebUtilities();
	@FindBy(locator = Generate)
	private QAFWebElement generate;
	@FindBy(locator = Negotiating)
	private QAFWebElement negotiating;
	@FindBy(locator = Awaiting_Signature)
	private QAFWebElement awaiting_Signature;
	@FindBy(locator = Signed)
	private QAFWebElement signed;
	@FindBy(locator = Mark_Status_As_Complete)
	private QAFWebElement markStatusAsComplete;
	@FindBy(locator = Template_Select)
	private QAFWebElement TemplateSelect;
	@FindBy(locator = Check_In)
	private QAFWebElement checkIn;
	@FindBy(locator = Details)
	private QAFWebElement details;
	@FindBy(locator = Qoute)
	private QAFWebElement qoute;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getGenerate() {
		return generate;
	}

	public QAFWebElement getNegotiating() {
		return negotiating;
	}

	public QAFWebElement getAwaiting_Signature() {
		return awaiting_Signature;
	}

	public QAFWebElement getSigned() {
		return signed;
	}

	public QAFWebElement getMarkStatusAsComplete() {
		return markStatusAsComplete;
	}

	public QAFWebElement getTemplateSelect() {
		return TemplateSelect;
	}

	public QAFWebElement getCheckIn() {
		return checkIn;
	}

	public QAFWebElement getDetails() {
		return details;
	}

	public QAFWebElement getQoute() {
		return qoute;
	}

	public void ChangeTheStatusToAwaitingSignature() {
		// QAFWebElement MarkCurrentStatus =new
		// QAFExtendedWebElement(By.xpath("//span[text()='Mark as Current Status']"));
		getNegotiating().click();
		getMarkStatusAsComplete().click();
		// MarkCurrentStatus.click();
		getAwaiting_Signature().click();
	}

	// Created by Vinay to Generate Documents in the Contract Page .
	public void GenerateContractDocument(String Template) {
		getDetails().click();
		Reporter.logWithScreenShot("clicked on Details tab");
		util.scrollIntoElement(By.xpath("(//span[.='Contract Documents'])[last()]"));
		util.AttachFrame();
		try {
			util.clickUsingJs(By.xpath("//span[text()='Generate'][2]/ancestor::button"));
		} catch (Exception e) {
			util.clickUsingJs(By.xpath("//span[text()='Generate']/ancestor::button"));
		}
		util.waitFor(20);
		util.AttachFrame();
		util.selectOptionByPartialText(driver.findElement(By.xpath("//select[@id='template-select']")), Template);
		util.waitFor(15);
		Reporter.logWithScreenShot("Selected template " + Template);
		util.waitFor(By.xpath("//button[text()='Download Word']"), 40, true);
		util.waitFor(8);
		util.clickUsingJs(By.xpath("//button[text()='Download Word']"));
		util.waitFor(12);
		util.clickUsingJs(By.xpath("//button[text()='Check In']"));

	}

	public void GenerateContractDocwithcontact(String Template) {
		getDetails().click();
		Reporter.logWithScreenShot("clicked on Details tab");
		util.scrollIntoElement(By.xpath("(//span[.='Contract Documents'])[last()]"));
		util.AttachFrame();
		try {
			util.clickUsingJs(By.xpath("//span[text()='Generate'][2]/ancestor::button"));
		} catch (Exception e) {
			util.clickUsingJs(By.xpath("//span[text()='Generate']/ancestor::button"));
		}
		util.waitFor(20);
		util.AttachFrame();
		if (driver.findElement(By.xpath("//h1[contains(text(),'Contact Contract Person')]")).isDisplayed()) {
			String Authorized_Signatory = pageProps.getPropertyValue("Lead.fullName");
//			String Authorized_Signatory = data.get("Authorized Signatory");
			util.clickUsingJs(By.xpath("//input[contains(@name,'loopname')]"));
			util.enterTextUsingJs(By.xpath("//input[contains(@name,'loopname')]"), Authorized_Signatory);
			util.waitFor(5);
			util.clickUsingJs(By.xpath("//li[contains(text(),'" + Authorized_Signatory + "')]"));
			util.vlocityNextButton();
		}
		util.waitFor(20);
		util.AttachFrame();
		util.selectOptionByPartialText(driver.findElement(By.xpath("//select[@id='template-select']")), Template);
		util.waitFor(15);
		Reporter.logWithScreenShot("Selected template " + Template);
		util.waitFor(By.xpath("//button[text()='Download Word']"), 40, true);
		util.waitFor(8);
		util.clickUsingJs(By.xpath("//button[text()='Download Word']"));
		util.waitFor(12);
		util.clickUsingJs(By.xpath("//button[text()='Check In']"));

	}

	public void GoToQuote() {
		getDetails().click();
		util.clickButton(getQoute());
	}

	public void ChangeTheStatusToSigned() {
		Reporter.logWithScreenShot(util.ChangeStatus("Negotiating"));
		util.waitFor(5);
		util.scrollUp();
		Reporter.logWithScreenShot(util.ChangeStatus("Awaiting Signature"));
		util.waitFor(5);
		util.scrollUp();
		Reporter.logWithScreenShot(util.ChangeStatus("Signed"));
		util.waitFor(5);
		util.scrollUp();
	}

	// Created by Saisree for EMB Notification in contract
	public void verifyEBMnotify(Map<String, String> data) {
		util.waitFor(10);
		util.waitFor(By.xpath("//a[.='EBM Notification']"), 30, true);
		util.waitFor(8);
		util.clickUsingJs(By.xpath("//a[.='EBM Notification']"));
		util.waitFor(10);
		util.waitFor(By.xpath("//h1//span[.='EBM Notification']"), 30, true);

		String Owner = driver.findElement(By.xpath("//div[.='Assigned To']/following-sibling::div//div/span"))
				.getText();
		System.out.println(Owner);
		Validator.verifyThat("", Owner, Matchers.containsString(data.get("EBMOwner")));
		util.waitFor(5);
		String Discription = driver.findElement(By.xpath("//div[.='Comments']/following-sibling::div/span/span"))
				.getText();
		Validator.verifyThat("", Discription, Matchers.containsString(data.get("EBMDiscription")));

	}

	// Created by Saisree for EMB Notification in contract
	public void Changeassignandtaskcomplete(Map<String, String> data) {
		util.waitFor(By.xpath("//h1//span[.='EBM Notification']"), 30, true);
		util.clickUsingJs(By.xpath("//button[@title='Edit Assigned To']"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//span[contains(text(),'EBM Aftersales')]/following-sibling::a"));
		driver.findElement("//input[@aria-describedby='Assigned To']").sendKeys(data.get("EBMASmember"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("(//div[.='Rachel Briones'])[last()]"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//span[.='Save']"));
		util.waitFor(10);
		util.waitFor(By.xpath("//button/span[.='Mark Complete']"), 30, true);
		util.clickUsingJs(By.xpath("//button/span[.='Mark Complete']"));
		util.waitFor(3);
		Reporter.logWithScreenShot("EBM Notification Mark Complete");
	}

}
