package com.pldt.pages;

import java.util.Map;

import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.pldt.locators.AssetPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class AssetPage extends WebDriverBaseTestPage<WebDriverTestPage> implements AssetPageLocators {
	WebUtilities util = new WebUtilities();
	private static String assetName = null;
	private static String minNumber = null;
	String current = null;
	static String billingAccountNumber = null;
	public static By related = By.xpath("//span[text()='Related']");
	public static By showAll = By.xpath("//ul/following-sibling::div/a[contains(text(),'Show All')]");
	public static By asset = By.xpath("//ul/li//records-hoverable-link//slot/span[contains(text(),'Assets')]");
	public static By quickfilter = By.xpath("(//button[@title='Show quick filters'])");
	public static By assetinput = By.xpath("(//label[text()='Asset Name']/following::input)[1]");
	public static By mininput = By.xpath("(//label[text()='MIN']/following::input[@name='Asset-MIN__c'])");
	public static By details = By.xpath("//span[text()='Details']");
	public static By billAccountNumber = By
			.xpath("//span[text()='CRM Billing Account Number']/parent::div/following-sibling::div/span/span");
	public static By newButton = By.xpath("//div[text()='Change Owner']/ancestor::ul/li/a/div[text()='New']");
	private static By consigneeName = By
			.xpath("(//span[text()='Consignee Name']/following::input[@placeholder='Search Contacts...'])");
	private static By billingAccountName = By
			.xpath("//span[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");
	private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	private static By moveDocumentArrow = By.xpath("//span[text()='Move selection to Chosen']");
	private static By save = By.xpath("//button[@title='Save']");
	public static By subjectInput = By.xpath("(//label[text()='Subject']/following::input[1])[last()]");
	@FindBy(locator = Case_NewButton)
	private QAFWebElement CaseNewButton;
	@FindBy(locator = Cases_Btn)
	private QAFWebElement CasesButton;
	@FindBy(locator = quickfilterA)
	private QAFWebElement AccountQuickFilter;
	@FindBy(locator = assetinputA)
	private QAFWebElement AccountAssetInput;
	@FindBy(locator = mininputA)
	private QAFWebElement AccountMinInput;
	@FindBy(locator = APPLYBUTTON)
	private QAFWebElement applybutton;
	@FindBy(locator = CLOSE_FILTER)
	private QAFWebElement closefilterbtn;
	@FindBy(locator = relatedTab)
	private QAFWebElement relatedButton;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getCaseNewButton() {
		return CaseNewButton;
	}

	public QAFWebElement getCasesButton() {
		return CasesButton;
	}

	public QAFWebElement getAccountQuickFilter() {
		return AccountQuickFilter;
	}

	public QAFWebElement getAccountAssetInput() {
		return AccountAssetInput;
	}

	public QAFWebElement getAccountMinInput() {
		return AccountMinInput;
	}

	public QAFWebElement getApplybutton() {
		return applybutton;
	}

	public QAFWebElement getClosefilterbtn() {
		return closefilterbtn;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		AssetPage.assetName = assetName;
	}

	public String getMinNumber() {
		return minNumber;
	}

	public void setMinNumber(String minNumber) {
		AssetPage.minNumber = minNumber;
	}

	public QAFWebElement getRelatedButton() {
		return relatedButton;
	}

	public void clickNewCase() {
		util.scrollTillVisible(CaseNewButton);
		getCaseNewButton().click();
		Reporter.log("Clicked on New button..");
	}

	public void clickOnCases() {
		driver.navigate().refresh();
		getCasesButton().click();
		Reporter.log("Clicked on Cases section..");
	}

	public void clickOnAsset(String assetName, String minNum) {
		setAssetName(assetName);
		setMinNumber(minNum);
		getAccountQuickFilter().click();
		getAccountAssetInput().sendKeys(assetName);
		getAccountMinInput().sendKeys(minNum);
		getApplybutton().click();
		getClosefilterbtn().click();
		QAFWebElement AssetInRowOne = new QAFExtendedWebElement("//a[text()=" + "'" + assetName + "'" + "]");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Reporter.logWithScreenShot("Selected Asset..");
		AssetInRowOne.click();
		// util.waitFor(RelatedTab, 10, true);
		getRelatedButton().click();
		util.waitForAssetPage();
		current = driver.getCurrentUrl();
		Reporter.logWithScreenShot("Selected Asset..");
	}

	public void selectAccountAsset(String minValue, String assetNameValue) {
		// util.scrollIntoElement(showAll);
		driver.findElement(showAll).click();
		util.clickUsingJs(asset);
		util.clickUsingJs(quickfilter);
		util.clickUsingJs(assetinput);
		util.enterText(assetinput, assetNameValue);
		util.clickUsingJs(mininput);
		util.enterText(mininput, minValue);
		util.enterKey();
		String pat = "//a[text()=" + "'" + assetNameValue + "'" + "]";
		util.clickUsingJs(By.xpath(pat));
		util.waitForAssetPage();
		current = driver.getCurrentUrl();
	}

	public void getBillAccountNumber() {
		util.clickUsingJs(details);
		util.waitFor(billAccountNumber, 5, true);
		billingAccountNumber = driver.findElement(billAccountNumber).getText();
		util.clickUsingJs(related);
	}

	public void click_availableDocuments() {
		util.scrollIntoElement(availableDocuments);
		util.moveToElement(availableDocuments);
		util.clickUsingActions(availableDocuments);
	}

	public void goToAccountRelatedCaseSearchPage() {
		util.clickUsingJs(related);
		util.clickUsingJs(CasesButton);
	}

	public void click_moveAvailableDocuments() {
		util.clickUsingJs(moveDocumentArrow);
	}

	public void createNewCaseFromAsset(Map<String, String> data) {
		util.clickUsingJs(newButton);
		util.clickUsingJs(By.xpath("//*[text()='SMART Service Request']"));
		util.clickUsingJs(By.xpath("//span[.='Next']"));
		if (data.get("Transaction Type").contains("SIM Replacement")) {
			util.selectAndClickCaseSuggestedValue(consigneeName, data.get("Consignee Name"));
		}
		util.selectAndClickCaseSuggestedValue(billingAccountName, billingAccountNumber);
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Transaction Type");
		util.select("Case Origin");
		click_availableDocuments();
		click_moveAvailableDocuments();
		util.clickUsingJs(save);
//		String caseID = util.waitForGenericToastMessage().split(" ")[1];
		Reporter.logWithScreenShot(util.waitForGenericToastMessage());
		Reporter.log("Entered mandatory fields and case got created..");
//		return caseID;
	}

	public void selectCase(String subjectValue) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		util.clickUsingJs(quickfilter);
		util.waitFor(subjectInput, 10, true);
		util.clickUsingJs(subjectInput);
		util.enterTextUsingJs(subjectInput, subjectValue);
		util.enterKey();
		String Cat = "//a[text()=" + "'" + subjectValue + "'" + "]";
		util.openLink(By.xpath(Cat));
		util.waitForCasePage();
	}
}
