package com.pldt.pages;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class SyniverseLoginPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	@FindBy(locator = "xpath=//input[@name='username']")
	private QAFWebElement SyniverseUsername;
	@FindBy(locator = "xpath=//input[@name='password']")
	private QAFWebElement SyniversePassword;
	@FindBy(locator = "xpath=//div[@class='login__actions']//button")
	private QAFWebElement SyniverseLoginButton;
	@FindBy(locator = "id=onetrust-banner-sdk")
	private QAFWebElement CookieNoticeTable;
	@FindBy(locator = "id=onetrust-accept-btn-handler")
	private QAFWebElement AcceptAllCookiesButton;
	@FindBy(locator = "id=menu-item-phmnp_dashboard")
	private QAFWebElement DashboardLink;
	@FindBy(locator = "xpath=//select[@name='value(OperatorCode)']")
	private QAFExtendedWebElement SwitchNetworkDropdown;
	@FindBy(locator = "xpath=//input[@value='Submit']")
	private QAFWebElement SwitchNetworkSubmitButton;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
// TODO Auto-generated method stub
	}

	public QAFWebElement getSyniverseUsername() {
		return SyniverseUsername;
	}

	public QAFWebElement getSyniversePassword() {
		return SyniversePassword;
	}

	public QAFWebElement getSyniverseLoginButton() {
		return SyniverseLoginButton;
	}

	public QAFWebElement getCookieNoticeTable() {
		return CookieNoticeTable;
	}

	public QAFWebElement getAcceptAllCookiesButton() {
		return AcceptAllCookiesButton;
	}

	public QAFWebElement getDashboardLink() {
		return DashboardLink;
	}

	public QAFExtendedWebElement getSwitchNetworkDropdown() {
		return SwitchNetworkDropdown;
	}

	public QAFWebElement getSwitchNetworkSubmitButton() {
		return SwitchNetworkSubmitButton;
	}

// created by waseem
	public void LoginAsAdmin(Map<String, String> data) {
		driver.navigate().to("https://symphony.dalab.syniverse.com/login");
		AcceptAllCookies();
		getSyniverseUsername().sendKeys(data.get("Username"));
		getSyniversePassword().sendKeys(data.get("Password"));
		getSyniverseLoginButton().click();
	}

// created by waseem
	public void AcceptAllCookies() {
		if (getCookieNoticeTable().isDisplayed()) {
			getAcceptAllCookiesButton().click();
			Reporter.log("Cookies Accepted");
		}
	}

// created by waseem
	public void ClickOnDashboardLink() {
		getDashboardLink().click();
	}

//created by waseem
	public void SwitchNetwork() {
		((JavascriptExecutor) driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		driver.navigate().to("https://symphony.dalab.syniverse.com/phmnp/switchnetwork.do");
		util.selectBy(getSwitchNetworkDropdown(), "102 vSmart");
		getSwitchNetworkSubmitButton().click();
		util.waitFor(5);
	}
}