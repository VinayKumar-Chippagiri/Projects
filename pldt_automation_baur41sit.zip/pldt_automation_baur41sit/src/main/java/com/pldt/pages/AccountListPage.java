package com.pldt.pages;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;
import com.qmetry.qaf.automation.util.Reporter;

public class AccountListPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	TestDataBean bean = new TestDataBean();
	DateUtil date=new DateUtil();
	private final String URL_BUSINESS_ACCOUNT_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000018ZsmEAE";
	private final String URL_ALL_ACCOUNTS_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000017Z7IEAU";
	private final String URL_ALL_ACCOUNTS_BILLING_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000017evXEAQ";
	private final String URL_ALL_ACCOUNTS_EE_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000017lUiEAI";
	private final String URL_ALL_ACCOUNTS_SERVICE_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000017evYEAQ";
	private final String URL_BILLING_AGGREGATOR_PAOLO_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s000001IWqBEAW";
	private final String URL_MY_ACCOUNTS_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B2x000006W2rdEAC";
	private final String URL_ORG_ACCOUNT_HIERARCHY_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000016rh1EAA";
	private final String URL_RECENTLY_VIEWED_ACCOUNT_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B2x000001NAbnEAG";
	private final String URL_MIGRATED_ACCOUNTS_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s000000ujZXEAY";
	private static final By TITLE_ACCOUNT_IN_PANEL = By.xpath("//h1/div[text()='Account']");
	// @PageIdentifier
	@FindBy(locator = "xpath=//h1/span[text()='Accounts']")
	private QAFWebElement Accounts;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		//driver.navigate().to(URL_BUSINESS_ACCOUNT_TAB);
		driver.navigate().to(URL_BUSINESS_ACCOUNT_TAB);
	}

	public void openAccount(String AccountName) {
		driver.navigate().to(getAccountLink(AccountName));
		util.waituntil.until(ExpectedConditions.visibilityOfElementLocated(TITLE_ACCOUNT_IN_PANEL));
	}


	public String getAccountLink(String AccountName) {
//	driver.findElementByXPath("//input[@name='Account-search-input']").sendKeys(AccountName);
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys(AccountName);
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys(Keys.ENTER);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String accountViewURL = driver.findElement(By.xpath(String.format("//a[text()='%s']", AccountName)))
				.getAttribute("href");
		pageProps.getString(AccountName, accountViewURL);
		return accountViewURL;
	}
	
	
	public void clickNewButton() {
		util.clickUsingJs(By.xpath("(//li/a[@role='button']|//li/a[.='New'])[1]"));
		Reporter.log("Clicked on New button..");
	}
	
	public void fillAccountInformation()
	{
		bean.fillRandomData();
		util.type("CRM Account Number");
		String BillingAcName = bean.getFirstName()+"billingaccount";
		util.type("Account Name",BillingAcName);
		pageProps.setProperty("BillingAccountName", BillingAcName);
		util.type("Account Currency");
		util.select("LoB (Line of Business)");
		util.type("Parent Account");
		util.select("Parent Account Record Type");
		util.select("Status");
		util.type("Case Number");
	}
	
	public void fillCustomerProfile()
	{	
		bean.fillRandomData();
		String CompanyTradeName = bean.getFirstName()+"trade";
		util.type("Company Trade Name",CompanyTradeName);
		util.select("Industry");
		util.select("Industry Sub Type");
		util.select("Bill Frequency");
		util.select("Bill Dispatch Method");
		util.select("Bill Cycle");
		util.click("eSOA Enrollment");
		util.select("Contact");
		util.type("Company TIN");
		util.type("Personal TIN");
		util.select("Credit Class");
		util.select("Tax Exemption");
		util.select("Tax Exemption Rules");
		util.select("Tax Profile");
		String eSOA = bean.getOther()+"@gmail.com";
		util.type("eSOA Notification Email ID",eSOA);
	}
	
	public void fillSmartBillingInformation()
	{
		bean.fillRandomData();
		String AssigneeFirstName = bean.getFirstName();
		String AssigneeMiddleName = bean.getMiddleName();
		String AssigneeLastName = bean.getLastName();
	    util.selectAndClickSuggestedValue("Account Type Code");
		util.select("Account Payment Type");
		util.select("Subscription");
		util.type("Assignee/ CI First Name",AssigneeFirstName);
		util.type("Assignee/ CI Middle Name",AssigneeMiddleName);
		util.type("Assignee/ CI Last Name",AssigneeLastName);
		util.type("Credit Limit");
		util.select("THS Rating");
		util.select("VIP Code");
	}
	
	public void fillPLDTBillingInformation()
	{
		util.type("Corporate Individual");
		util.type("For the Account Of");
		util.select("For the Account Of - Biz Act");
	}
	public void fillContactPreferences()
	{	
		bean.fillRandomData();
		util.click("Email Notification");
		util.click("SMS Notification");
		util.click("Payment reminder callout");	
		String email = pageProps.getPropertyValue("BillingAccountName")+"@gmail.com";
		util.type("Notify Email ID", email);
		String notifyMobile= String.format("639%s",bean.getPhone_mobile().toString());
		notifyMobile = StringUtils.rightPad(notifyMobile, 12, "0");
		util.type("Notify Mobile No", notifyMobile);
	}
	
	public void fillBillingAddressInformation()
	{
		util.type("Billing Address Line 1");
		util.type("Billing Address Line 2");
		util.type("Billing Address Line 3");
		util.select("Billing Country");
		util.select("Billing State/Province");
		util.selectAndClickSuggestedValue("Billing City");
		util.selectAndClickSuggestedValue("BARANGAY");
		util.selectAndClickSuggestedValue("Billing Zip/Postal Code");
		util.type("Billing City BackEnd");
		util.type("BARANGAY_BackEnd");
		util.type("Billing Zip/Postal Code BackEnd");
	}
	public void fillSmartIntegrationUpdates()
	{
		util.select("SFDC Collection Status");
		util.select("SFDC THS Status");

	}
	public void fillLegacyInformationReference()
	{
		util.type("Legacy CSP Parent Account Number");
		util.type("Legacy CSP Parent Account Name");
		util.type("Legacy CSP Parent Account Type Code");
		util.type("Legacy CSP Parent Account ID");
	}
	public void fillServiceAccountInformation()
	{	
		bean.fillRandomData();
		String serviceName= bean.getFirstName()+"serviceaccount";
		util.type("Account Name",serviceName);
		pageProps.setProperty("ServiceAccountName", serviceName);
		util.type("CRM Account Number");
		util.select("Parent Account Record Type");
		util.select("Status");
		
	}
	public void fillServiceAddressInformation()
	{
		util.select("Country");
		util.typeIntoTextArea("Street");
		util.type("City");
		util.select("State/Province");
		util.type("Zip/Postal Code");
	}
	
	public void selectServiceAccountCountry()
	{
	    util.click("newService_country_XPATH");
	   	  // util.clickUsingJs(By.xpath("//*[text()='"+country+"']"));
	}
	
//	Created by Vinay to create Billing Account
	public void createBillingAccount()
	{
		fillAccountInformation();
		fillCustomerProfile();
		fillSmartBillingInformation();
		fillPLDTBillingInformation();
		fillContactPreferences();
		fillBillingAddressInformation();
		fillSmartIntegrationUpdates();
		fillLegacyInformationReference();
		//getSave().click();
		util.waitFor(By.xpath("(//span[text()='Save'])[last()]"), 10, true);
		Reporter.logWithScreenShot("Successfully Entered Billing account information");
		util.waitFor(3);
		util.clickButton(driver.findElement(By.xpath("(//span[text()='Save'])[last()]")));
		util.waitFor(By.xpath("(//span[text()='Save'])[last()]"), 30, false);
		util.waitForAccountPage();	
	}
}
