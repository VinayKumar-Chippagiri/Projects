package com.pldt.pages;

import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.pldt.locators.AddressAssignmentPageLocators;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class AddressAssignmentPage extends WebDriverBaseTestPage<WebDriverTestPage> implements AddressAssignmentPageLocators
{
	WebUtilities util = new WebUtilities();

	@FindBy (locator =SearchBillAccount)
	private QAFWebElement searchBillAccount;

	@FindBy (locator =BillAccountCheckBox)
	private QAFWebElement billAccountCheckBox;

	@FindBy (locator =SearchServiceAccount)
	private QAFWebElement searchServiceAccount;

	@FindBy (locator =ServiceAccountCheckBox)
	private QAFWebElement serviceAccountCheckBox;

	@FindBy (locator =Save)
	private QAFWebElement save;

	@Override
	protected void openPage(PageLocator locator, Object... args)
	{

	}
	public QAFWebElement getSearchBillAccount()
	{
		return searchBillAccount;
	}

	public QAFWebElement getBillAccountCheckBox() {
		return billAccountCheckBox;
	}

	public QAFWebElement getSearchServiceAccount() {
		return searchServiceAccount;
	}

	public QAFWebElement getServiceAccountCheckBox() {
		return serviceAccountCheckBox;
	}

	public QAFWebElement getSave() {
		return save;
	}

//	Created by Vinay to AssignBillingAccount in Address Assignment Screen
	public void AssignBillingAccount(String BillAccount)
	{

		String Billing = BillAccount.toLowerCase();
		//getSearchBillAccount().sendKeys(Billing);
		//util.clickUsingJs(By.xpath("//p[.='Billing Account']/following-sibling::input[@placeholder='Search Account']"));
		util.waitFor(By.xpath("(//p[normalize-space(text())='Billing Account']/following::input[1])"), 20, true);
		util.typeDataTo(getSearchBillAccount(), Billing);
	    try {
	    	if(driver.findElement(By.xpath("//h2[.='Sorry to interrupt']")).isDisplayed())
	    	{
	    	   util.clickUsingJs(By.xpath("//button//span[.='OK']"));
	    	}
		} catch (Exception e) {
			// TODO: handle exception
		}
	    try {
			if (driver.findElement(By.xpath("//span[text()='A Component Error has occurred!']")).isDisplayed()) {
				util.clickUsingJs(By.xpath("//button[@title='Close this window']"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		util.waitFor(5);
	    getBillAccountCheckBox().waitForVisible(10000);
	    util.waitFor(10);
		getBillAccountCheckBox().click();
//		QAFWebElement checkBox =new QAFExtendedWebElement("(//span[text()='Select Item 1'])[1]");
//		util.clickUsingJs(checkBox);


	}

//	Created by Vinay to AssignServiceAccount in Address Assignment Screen
	public void AssignServiceAccount(String ServiceAccount)
	{
		String Service = ServiceAccount.toLowerCase();
		//util.clickUsingJs(By.xpath("//p[contains(text(),'Installation')]/following-sibling::input[@placeholder='Search Account']"));

		util.typeDataTo(getSearchServiceAccount(), Service);
		try {
			if (driver.findElement(By.xpath("//h2[.='Sorry to interrupt']")).isDisplayed()) {
				util.clickUsingJs(By.xpath("//button//span[.='OK']"));
			}
		} catch (Exception e) {
		}
		try {
			if (driver.findElement(By.xpath("//span[text()='A Component Error has occurred!']")).isDisplayed()) {
				util.clickUsingJs(By.xpath("//button[@title='Close this window']"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		//getSearchServiceAccount().sendKeys(Service);
//		QAFWebElement checkBox =new QAFExtendedWebElement("(//span[text()='Select Item 1'])[2]");
//		util.clickUsingJs(checkBox);
		util.waitFor(5);
		 getServiceAccountCheckBox().waitForVisible(10000);
		  util.waitFor(10);
		getServiceAccountCheckBox().click();
		Reporter.logWithScreenShot(" Updated Billing and Service Accounts", MessageTypes.Info);
		getSave().click();
//		getSave().waitForNotVisible(5000);
		util.waitForCartPage();




	}

}
