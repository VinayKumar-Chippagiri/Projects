package com.pldt.pages;

import java.util.Map;

//import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.pldt.locators.DashboardPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;
import com.qmetry.qaf.automation.util.Reporter;

public class DashboardPage extends WebDriverBaseTestPage<WebDriverTestPage> implements DashboardPageLocators{
	WebUtilities util = new WebUtilities();
	Map<?, ?> map=null; 
	TestDataBean bean = new TestDataBean();
	DateUtil date=new DateUtil();
	@FindBy(locator = DASHBOARD_CREATE)
	private QAFWebElement dashboardCreate;
	@FindBy(locator=Dasboard_NEW)
	private QAFWebElement DashboardNew;
	@FindBy(locator = DASBOARD_SEARCH)
	private QAFWebElement searchInput;
	@FindBy(locator=Report_NEW)
	private QAFWebElement ReportNew;
	@FindBy(locator=Footer_Save)
	private QAFWebElement FooterSave;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	
	public QAFWebElement getSearchInput() {
		return searchInput;
	}
	
	public QAFWebElement getDashboardCreate() {
		return dashboardCreate;
	}
	
	public void clickCreateButton() {
		getDashboardCreate().click();
		util.waitForGenericToastMessage();
		
	}
	
	public QAFWebElement getDashboardNew()
	{
		return DashboardNew;
	}
	
	
	public void clickNewDashboard() {
		getDashboardNew().click();
		
	}
	
	public QAFWebElement getReportNew()
	{
		return ReportNew;
	}
	
	public void clickNewReport() {
		getReportNew().click();
		
	}
	
	public QAFWebElement getFooterSave()
	{
		return FooterSave;
	}
	
	public void clickFooterSave() {
		getFooterSave().click();
		
	}
	
	public void createNewDasboard() {
		bean.fillRandomData();
		util.waitFor(By.xpath("//h2[.='New Dashboard']"), 15, true);
		String Name = bean.getFirstName();
	      driver.switchTo().frame(0);
	      util.switchtoFrameAndType(By.xpath("//*[@id='dashboardNameInput']"), Name);
		driver.findElement(By.xpath("//*[@id='dashboardNameInput']")).sendKeys(Name);
		pageProps.setProperty("Dashboard.Name", Name);
		String Description = bean.getOther();
		driver.findElement(By.xpath("((//label[text()='Description']/following::div/input[1])|(//div/input[@id='dashboardDescriptionInput']))[1]")).sendKeys(Description);
		Reporter.logWithScreenShot("New Dashboard Name :" +Name);
		util.clickUsingJs(dashboardCreate);
		util.waitFor(dashboardCreate, 10, false);
	}
	
	public void editDasboard() {
		bean.fillRandomData();
		String Name = bean.getFirstName();
		util.switchtoFrameAndClick(By.xpath("(//button[.='Edit Dashboard name'])"));
		util.switchtoFrameAndType(By.xpath("//input[@id='edit-dashboard-title']"), Name);
		util.waitFor(3);
		Reporter.logWithScreenShot("Edited Dashboard Name :" +Name);
		System.out.println(Name);
		util.switchtoFrameAndClick(By.xpath("//button[normalize-space()='Save']"));
	
	}
	
	
	public void createNewReport() {
		bean.fillRandomData();
		String Name = bean.getFirstName();
		util.waitFor(By.xpath("//h2[.='Create Report']"), 10, true);
		util.waitFor(8);
	    util.switchtoFrameAndClick(By.xpath("(//span[text()='Report Type Name']/following::span/a[.='Accounts'])"));
	    util.waitFor(3);
	    util.switchtoFrameAndClick(By.xpath("(//button[.='Start Report'])"));
	    util.waitFor(By.xpath("(//button[.='Start Report'])"), 10, false);
	    util.switchtoFrameAndClick(By.xpath("(//a[.='All accounts'])"));
	    util.waitFor(3);
	    util.switchtoFrameAndClick(By.xpath("(//button[.='Refresh'])[last()]"));
	    util.waitFor(3);
	    util.switchtoFrameAndClick(By.xpath("(//button[.='Save & Run'])"));
	    util.waitFor(By.xpath("//h2[.='Save Report']"), 10, true);
	   util.switchtoFrameAndType(By.xpath("//input[@id='reportName']"), Name);
	  util.switchtoFrameAndClick(By.xpath("(//button[text()='Save'])[last()]"));
	   util.waitFor(FooterSave, 10, false);
	   Reporter.logWithScreenShot("Created New Report  :" +Name);	     
	}
	
	
	public void editReport() {
		bean.fillRandomData();
		String Name = bean.getFirstName();
		util.switchtoFrameAndClick(By.xpath("(//button[.='Edit'])"));
		util.waitFor(By.xpath("(//span[.='Report'])"), 10, true);
		util.switchtoFrameAndClick(By.xpath("//button[.='Edit Report Name']"));
		util.waitFor(3);
		util.switchtoFrameAndType(By.xpath("//input[@placeholder='Report Name']"), Name);
		Reporter.logWithScreenShot("Edited Report Name :" +Name);
		util.waitFor(3);
		util.switchtoFrameAndClick(By.xpath("(//button[contains(@class,'ReportSaveAction')])"));
		util.waitForGenericToastMessage();
	}

}
