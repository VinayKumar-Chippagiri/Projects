package com.pldt.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.apache.commons.lang.StringUtils;
//import org.apache.http.util.Asserts;
//import org.apache.poi.util.SystemOutLogger;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.locators.CasePageLocators;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;

public class CasePage extends WebDriverBaseTestPage<WebDriverTestPage> implements CasePageLocators {
	JavascriptExecutor executor = driver;
	WebUtilities util = new WebUtilities();
	LoginPage login = new LoginPage();
	AppCommons app = new AppCommons();
	NewCaseModal newcase = new NewCaseModal();
	HomePage home = new HomePage();
	CaseDetailsPage CD = new CaseDetailsPage();
	private static String CASEOWNER;
	private static String CASENUMBER;
	private static String CASEURL;
	private static String APPROVER;
	public int BSR;
	public static By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	public static By assetID = By.xpath("//span[.='Asset ID']/following::div[1]");
	public static By MINNumber = By.xpath("//span[.='MIN Number']/following::div[1]");
	public static By transactionStatus = By.xpath("//span[.='Transaction Status']/following::div[1]");
	public static By markCurrentStatus = By.xpath("//span[text()='Mark as Current Status']");
	private static By changeOwnerEdit = By.xpath("(//button[@title='Change Owner'])[last()]");
	private static By searchUser = By.xpath("//input[@placeholder='Search Users...']");
	private static By changeOwnerButton = By.xpath("//button[@name='change owner']");
	private static By simReplacementFee = By.xpath("//span[.='SIM Replacement Fee']/following::div[1]");
	private static By transactionAsset = By.xpath("(//span[text()='Transaction Asset'])[1]/following-sibling::span");
	private static By relatedSection = By.xpath("(//flexipage-record-home-scrollable-column)[3]");
	private static By doneButton = By.xpath("//p[.='Done']");
	private static By editButton = By.xpath("//button[text()='Edit'][@class='slds-button slds-button_brand']");
	private static By servicereq = By
			.xpath("(//label[text()='Services Requested']/following::button[@name='Services_Requested__c'])");
	private static By highLevelDisconnection = By.xpath(
			"(//label[text()='High Level Disconnection Reason']/following::button[@name='High_Level_Disconnection_Reason__c'])");
	private static By saveRecord = By.xpath("//button[@class='slds-button slds-button_brand'][@type='submit']");
	@FindBy(locator = "xpath=//div[@class='iframe-parent slds-template_iframe slds-card']//iframe")
	private QAFWebElement frame2;
	@FindBy(locator = Subject)
	private QAFWebElement CaseSubject;
	@FindBy(locator = Line_of_business)
	private QAFWebElement CaseLOB;
	@FindBy(locator = Type_of_cust_req)
	private QAFWebElement CaseTypeCustomerRequest;
	@FindBy(locator = Type)
	private QAFWebElement CaseType;
	@FindBy(locator = Case_origin)
	private QAFWebElement CaseOrigin;
	@FindBy(locator = Status)
	private QAFWebElement CaseStatus;
	@FindBy(locator = High_level_Trans_class)
	private QAFWebElement CaseHighLevelTransactionClassification;
	@FindBy(locator = Trans_type)
	private QAFWebElement CaseTransactionType;
	@FindBy(locator = Trans_sub_type)
	private QAFWebElement CaseTransactionSubType;
	@FindBy(locator = Trans_reason)
	private QAFWebElement CaseTransactionReason;
	@FindBy(locator = MIN_portin)
	private QAFWebElement CaseMINPortIn;
	@FindBy(locator = Current_provider)
	private QAFWebElement CaseCurrentProvider;
	@FindBy(locator = Rec_provider)
	private QAFWebElement CaseRecipientProvider;
	@FindBy(locator = Save)
	private QAFWebElement save;
	@FindBy(locator = SMARTSERREQ)
	private QAFWebElement smartserreq;
	@FindBy(locator = NEWCASE_NEXT)
	private QAFWebElement newcasenext;
	@FindBy(locator = Case_filter)
	private QAFWebElement casefilter;
	@FindBy(locator = Subject_inputBox)
	private QAFWebElement SubjectInputBox;
	@FindBy(locator = Apply_Btn)
	private QAFWebElement ApplyBtn;
	@FindBy(locator = Apply_Btn2)
	private QAFWebElement ApplyBtn2;
	@FindBy(locator = CLOSE_FILTER)
	private QAFWebElement close_filter;
	@FindBy(locator = caseInfo)
	private QAFWebElement CaseInfo;
	@FindBy(locator = caseOwner)
	private QAFWebElement CaseOwner;
	@FindBy(locator = Approver)
	private QAFWebElement approver;
	@FindBy(locator = casenumber)
	private QAFWebElement CaseNumber;
	@FindBy(locator = setupSearchBox)
	private QAFWebElement SetupSearchBox;
	@FindBy(locator = groupQueues)
	private QAFWebElement GroupQueueBtn;
	@FindBy(locator = groupName)
	private QAFWebElement GroupName;
	@FindBy(locator = queueUserName)
	private QAFWebElement QueueUserName;
	@FindBy(locator = userLoginBtn)
	private QAFWebElement UserLoginBtn;
	@FindBy(locator = frame)
	private QAFWebElement switchframe;
	@FindBy(locator = toastmsg)
	private QAFWebElement Message;
	@FindBy(locator = filterCase)
	private QAFWebElement FilterCaseIcon;
	@FindBy(locator = filterCaseSearch)
	private QAFWebElement FilterCaseSearchBox;
	@FindBy(locator = BulkSRsearch)
	private QAFWebElement FilterBSRSearchBox;
	@FindBy(locator = searchList)
	private QAFWebElement SearchList;
	@FindBy(locator = casecheckbox)
	private QAFWebElement CaseCheckBox;
	@FindBy(locator = caseAcceptbtn)
	private QAFWebElement CaseAcceptBtn;
	@FindBy(locator = ThreeDotQuickActionTool)
	private QAFWebElement threedotQuickActionTool;
	@FindBy(locator = eligibilityCheckBtn)
	private QAFWebElement EligibilityCheckBtn;
	@FindBy(locator = caseTitle)
	private QAFWebElement CaseTitle;
	@FindBy(locator = showMoreActions)
	private QAFWebElement ShowMoreActionIcon;
	@FindBy(locator = uploadBulk)
	private QAFWebElement UploadBulkOption;
	@FindBy(locator = customObjects)
	private QAFWebElement CustomObjects;
	@FindBy(locator = mnpPortabilityCheckBtn)
	private QAFWebElement MNPPortabilityCheckBtn;
	@FindBy(locator = updateExistingRec)
	private QAFWebElement UpdateExistingRecord;
	@FindBy(locator = matchBy)
	private QAFWebElement MatchBy;
	@FindBy(locator = csv)
	private QAFWebElement CSVOption;
	@FindBy(locator = chooseFile)
	private QAFWebElement ChooseFile;
	@FindBy(locator = importFileNextButton)
	private QAFWebElement ImportFileNextBtn;
	@FindBy(locator = editMappingFieldNextButton)
	private QAFWebElement EditMappingFieldNextBtn;
	@FindBy(locator = startImport)
	private QAFWebElement StartImport;
	@FindBy(locator = okButton)
	private QAFWebElement OkButton;
	@FindBy(locator = generateLOU)
	private QAFWebElement GenerateLOU;
	@FindBy(locator = successTitle)
	private QAFWebElement SuccessTitle;
	@FindBy(locator = backToCaseBtn)
	private QAFWebElement BackToCaseBtn;
	@FindBy(locator = nextArrow)
	private QAFWebElement NextArrow;
	@FindBy(locator = resolutionInProgress)
	private QAFWebElement ResolutionInProgress;
	@FindBy(locator = markStatusComplete)
	private QAFWebElement MarkStatusComplete;
	@FindBy(locator = transactionDetailsC)
	private QAFWebElement TransactionDetails;
	@FindBy(locator = generateUSC)
	private QAFWebElement GenerateUSC;
	@FindBy(locator = doneBtn)
	private QAFWebElement DoneBtn;
	@FindBy(locator = caseSectionNewcase)
	private QAFWebElement CaseSectionNewcase;
	@FindBy(locator = transAssetBtn)
	private QAFWebElement TransAssetBtn;
	@FindBy(locator = addNewRec)
	private QAFWebElement AddNewRec;
	@FindBy(locator = "//div[@class='vlc-control-wrapper ng-binding']//input[@name='loopname']")
	private QAFWebElement planame;
	@FindBy(locator = triggerCheckbox)
	private QAFWebElement TriggerCheckbox;
	@FindBy(locator = caseLookupField)
	private QAFWebElement CaseLookupField;
	@FindBy(locator = "//span[text()='Create SUN Infinity Assets']")
	private QAFWebElement CreateSunInfinityAsset;
	@FindBy(locator = "//div[contains(text(),'Back to Case')]")
	private QAFWebElement SUNBackToCaseBtn;
	@FindBy(locator = "xpath=//button[text()='OK']")
	private QAFWebElement SUNOkBtn;
	@FindBy(locator = "//span[text()='Move selection to Chosen']")
	private QAFWebElement moveDocumentArrow;
	@FindBy(locator = "//div[@class='vlc-control-wrapper ng-binding']//input[@name='loopname']")
	private QAFWebElement PlanName;
//	@FindBy(locator = availableDocuments)
//	private QAFWebElement AvailableDocuments;
	@FindBy(locator = editButton1)
	private QAFWebElement EditButton;
	@FindBy(locator = "//button[text()='Save Record']")
	private QAFWebElement SaveRecord;
	@FindBy(locator = "//label[text()='Offer Migration Type']/following::div/div/button[@name='Offer_Migration_Type__c']")
	private QAFWebElement OfferMigrationType;
//	@FindBy(locator = PlanName)
//	private QAFWebElement planName;
	@FindBy(locator = SelectPlanNextButton)
	private QAFWebElement selectPlanNextButton;
	@FindBy(locator = Listview)
	private QAFWebElement listview;
	@FindBy(locator = SearchInput)
	private QAFWebElement searchInput;
	@FindBy(locator = ViewRecord)
	private QAFWebElement viewRecord;
	@FindBy(locator = CreditNext)
	private QAFWebElement creditNext;
//	@FindBy(locator = ChangeOwnerEdit)
//	private QAFWebElement changeOwnerEdit;
//
//	@FindBy(locator = SearchUser)
//	private QAFWebElement searchUser;
//	@FindBy(locator = ChangeOwnerButton)
//	private QAFWebElement changeOwnerButton;
	@FindBy(locator = "//label[text()='Reason Code']/following::div/div/button[@name='Reason_Code__c']")
	private QAFWebElement ReasonCode;
	@FindBy(locator = "//label[text()='Transaction Status']/following-sibling::div//button")
	private QAFWebElement TransactionStatus;
	@FindBy(locator = casenumberToastmsg)
	private QAFWebElement CaseNumberToastmsg;
	@FindBy(locator = SaveEdit)
	private QAFWebElement saveedit;
	@FindBy(locator = "//label[text()='Alert Tag Level']/following::div/div/button[@name='Alert_Tag_Level__c']")
	private QAFWebElement AlertTagLevel;
	@FindBy(locator = "//label[text()='Alert Code Type']/following::div/div/button[@name='Alert_Code_Type__c']")
	private QAFWebElement AlertCodeType;
	@FindBy(locator = "//label[text()='Alert Code Action']/following::div/div/button[@name='Alert_Code_Action__c']")
	private QAFWebElement AlertCodeAction;

	@FindBy(locator = "//a[text()='Transaction']")
	private QAFWebElement Transaction;
	@FindBy(locator = accountField)
	private QAFWebElement AccountField;
	@FindBy(locator = adjustComponentLOVField)
	private QAFWebElement AdjustComponentLOVField;
	
	private static By TransactionType = By.xpath("//label[text()='Transaction Type']/following::div[2]//input");
	private static By TransactionSubType = By.xpath("//label[text()='Transaction Sub Type']/following::div[2]//input");
	private static By TransactionReason = By.xpath("//label[text()='Transaction Reason']/following::div[2]//input");

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getCaseSubject() {
		return CaseSubject;
	}

	public QAFWebElement getCaseLOB() {
		return CaseLOB;
	}

	public QAFWebElement getCaseTypeCustomerRequest() {
		return CaseTypeCustomerRequest;
	}

	public QAFWebElement getCaseType() {
		return CaseType;
	}

	public QAFWebElement getCaseOrigin() {
		return CaseOrigin;
	}

	public QAFWebElement getCaseStatus() {
		return CaseStatus;
	}

	public QAFWebElement getCaseHighLevelTransactionClassification() {
		return CaseHighLevelTransactionClassification;
	}

	public QAFWebElement getCaseTransactionType() {
		return CaseTransactionType;
	}

	public QAFWebElement getCaseTransactionSubType() {
		return CaseTransactionSubType;
	}

	public QAFWebElement getCaseTransactionReason() {
		return CaseTransactionReason;
	}

	public QAFWebElement getCaseMINPortIn() {
		return CaseMINPortIn;
	}

	public QAFWebElement getCaseCurrentProvider() {
		return CaseCurrentProvider;
	}

	public QAFWebElement getCaseRecipientProvider() {
		return CaseRecipientProvider;
	}

	public QAFWebElement getSave() {
		return save;
	}

	public QAFWebElement getSmartserreq() {
		return smartserreq;
	}

	public QAFWebElement getNewcasenext() {
		return newcasenext;
	}

	public QAFWebElement getCasefilter() {
		return casefilter;
	}

	public QAFWebElement getSubjectInputBox() {
		return SubjectInputBox;
	}

	public QAFWebElement getApplyBtn() {
		return ApplyBtn;
	}

	public QAFWebElement getCaseInfo() {
		return CaseInfo;
	}

	public QAFWebElement getCaseOwner() {
		return CaseOwner;
	}

	public QAFWebElement getapprover() {
		return approver;
	}

	public QAFWebElement getCaseNumber() {
		return CaseNumber;
	}

	public QAFWebElement getSetupSearchBox() {
		return SetupSearchBox;
	}

	public QAFWebElement getGroupQueueBtn() {
		return GroupQueueBtn;
	}

	public QAFWebElement getGroupName() {
		return GroupName;
	}

	public QAFWebElement getQueueUserName() {
		return QueueUserName;
	}

	public QAFWebElement getUserLoginBtn() {
		return UserLoginBtn;
	}

	public QAFWebElement getSwitchframe() {
		return switchframe;
	}

	public QAFWebElement getMessage() {
		return Message;
	}

	public QAFWebElement getClose_filter() {
		return close_filter;
	}

	public QAFWebElement getFilterCaseIcon() {
		return FilterCaseIcon;
	}

	public QAFWebElement getFilterCaseSearchBox() {
		return FilterCaseSearchBox;
	}

	public QAFWebElement getFilterBSRSearchBox() {
		return FilterBSRSearchBox;
	}

	public QAFWebElement getSearchList() {
		return SearchList;
	}

	public QAFWebElement getCaseCheckBox() {
		return CaseCheckBox;
	}

	public QAFWebElement getCaseAcceptBtn() {
		return CaseAcceptBtn;
	}

	public QAFWebElement getThreedotQuickActionTool() {
		return threedotQuickActionTool;
	}

	public QAFWebElement getEligibilityCheckBtn() {
		return EligibilityCheckBtn;
	}

	public QAFWebElement getCaseTitle() {
		return CaseTitle;
	}

	public String getAPPROVER() {
		return APPROVER;
	}

	public void setAPPROVER(String aPPROVER) {
		APPROVER = aPPROVER;
	}

	public String getCASEOWNER() {
		return CASEOWNER;
	}

	public void setCASEOWNER(String cASEOWNER) {
		CASEOWNER = cASEOWNER;
	}

	public String getCASENUMBER() {
		return CASENUMBER;
	}

	public void setCASENUMBER(String cASENUMBER) {
		CASENUMBER = cASENUMBER;
	}

	public QAFWebElement getShowMoreActionIcon() {
		return ShowMoreActionIcon;
	}

	public QAFWebElement getUploadBulkOption() {
		return UploadBulkOption;
	}

	public QAFWebElement getCustomObjects() {
		return CustomObjects;
	}

	public QAFWebElement getMNPPortabilityCheckBtn() {
		return MNPPortabilityCheckBtn;
	}

	public QAFWebElement getUpdateExistingRecord() {
		return UpdateExistingRecord;
	}

	public QAFWebElement getMatchBy() {
		return MatchBy;
	}

	public QAFWebElement getCSVOption() {
		return CSVOption;
	}

	public QAFWebElement getChooseFile() {
		return ChooseFile;
	}

	public QAFWebElement getImportFileNextBtn() {
		return ImportFileNextBtn;
	}

	public QAFWebElement getEditMappingFieldNextBtn() {
		return EditMappingFieldNextBtn;
	}

	public QAFWebElement getStartImport() {
		return StartImport;
	}

	public QAFWebElement getOkButton() {
		return OkButton;
	}

	public QAFWebElement getGenerateLOU() {
		return GenerateLOU;
	}

	public QAFWebElement getSuccessTitle() {
		return SuccessTitle;
	}

	public QAFWebElement getBackToCaseBtn() {
		return BackToCaseBtn;
	}

	public QAFWebElement getGenerateUSC() {
		return GenerateUSC;
	}

	public QAFWebElement getDoneBtn() {
		return DoneBtn;
	}

	public QAFWebElement getCaseSectionNewcase() {
		return CaseSectionNewcase;
	}

	public QAFWebElement getViewRecord() {
		return viewRecord;
	}

	public QAFWebElement getCreditNext() {
		return creditNext;
	}

	public void clickNewCase() {
		getCaseSectionNewcase().click();
		Reporter.log("Clicked on New button..");
	}
//	public QAFWebElement getAvailableDocuments() {
//		return AvailableDocuments;
//	}

	public QAFWebElement getMoveDocumentArrow() {
		return moveDocumentArrow;
	}

	public QAFWebElement getPlanName() {
		return PlanName;
	}

	public QAFWebElement getSelectPlanNextButton() {
		return selectPlanNextButton;
	}

	public QAFWebElement getListview() {
		return listview;
	}

	public QAFWebElement getSearchInput() {
		return searchInput;
	}

//	public QAFWebElement getChangeOwnerEdit() {
//		return changeOwnerEdit;
//	}
//
//	public QAFWebElement getSearchUser() {
//		return searchUser;
//	}
//
//	public QAFWebElement getChangeOwnerButton() {
//		return changeOwnerButton;
//	}
	public QAFWebElement getCaseNumberToastmsg() {
		return CaseNumberToastmsg;
	}

	public QAFWebElement getSaveedit() {
		return saveedit;
	}

	public void createNewCase() {
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.selectAndClickSuggestedValue("Transaction Type");
		util.selectAndClickSuggestedValue("Transaction Sub Type");
		util.select("Case Origin");
		util.select("Recipient Provider");
		getSave().click();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		getMessage().waitForNotVisible(200000);
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void SelectRecordType() {
		getSmartserreq().click();
		getNewcasenext().click();
		Reporter.log("Selected case record type as Smart Service Request..");
	}

	public void clickOnCaseByFiltering(String sub) {
		util.waitFor(casefilter, 10, true);
		getCasefilter().click();
		getSubjectInputBox().sendKeys(sub);
		if (getApplyBtn().isPresent()) {
			getApplyBtn().click();
		} else {
			ApplyBtn2.click();
		}
		getClose_filter().click();
		Reporter.logWithScreenShot("Created Case");
		QAFWebElement CaseInRowOne = new QAFExtendedWebElement("//a[text()=" + "'" + sub + "'" + "]/parent::span/a");
		util.waitFor(CaseInRowOne, 10, true);
		CaseInRowOne.click();
		Reporter.log("Opened created case by filtering case name..");
	}

	public void copyCaseOwnerNameAndNumber() {
		util.waitFor(By.xpath("//div[.='Case']"), 20, true);
		util.waitFor(By.xpath("//button[@title='Change Owner']/preceding::slot[1]/span"), 10, true);
		if (driver.findElements(By.xpath("//button[@title='Change Owner']/preceding::slot[1]/span")).size() > 0) {
			String CASEOWNER = driver.findElement(By.xpath("//button[@title='Change Owner']/preceding::slot[1]/span"))
					.getText();
			setCASEOWNER(CASEOWNER);
		} else {
			String CASEOWNER = driver.findElement(By.xpath("//button[@title='Change Owner']/preceding::slot[1]"))
					.getText();
			setCASEOWNER(CASEOWNER);
		}
		CASENUMBER = getCaseNumber().getText();
		setCASENUMBER(CASENUMBER);
		System.out.println(CASEOWNER);
		System.out.println(CASENUMBER);
		Reporter.log("Captured case owner and case number..");
	}

	public void openCaseOwnerAndRelatedUser() throws InterruptedException {
		util.clickUsingJs(By.xpath("(//div[@class='headerTrigger tooltip-trigger uiTooltip'])[last()]"));
		util.clickUsingJs(By.xpath("//a[@title='Setup']"));
		String winHandleBefore = driver.getWindowHandle();
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.enterText(getSetupSearchBox(), CASEOWNER);
		getSetupSearchBox().sendKeys(Keys.ENTER);
		getGroupQueueBtn().waitForPresent(10000);
		getGroupQueueBtn().click();
		getGroupName().click();
		util.switchtoFrameAndClick(By.xpath("//th[text()='Name']/following::tr[2]/th/a"));
		util.switchToLoginFrame();
		getUserLoginBtn().waitForVisible(30000);
		util.clickUsingJs(getUserLoginBtn());
		util.waitFor(By.xpath("//span[contains(text(),'Logged in as')]"), 25, true);
		Reporter.log("logged in with case owner..");
	}

	public void SelectCaseGroup(String grpName) {
		getFilterCaseIcon().click();
		getFilterCaseSearchBox().waitForVisible(10000);
		getFilterCaseSearchBox().sendKeys(grpName);
		QAFWebElement SelectDropdownEBG = new QAFExtendedWebElement("//mark[text()=" + "'" + grpName + "'" + "]");
		SelectDropdownEBG.waitForPresent(10000);
		SelectDropdownEBG.click();
		Reporter.log("Filtered case with case owner group..");
	}

	public void SelectBSRGroup(String grpName) {
		getFilterCaseIcon().click();
//		getFilterBSRSearchBox().sendKeys(grpName);
		QAFWebElement SelectDropdown = new QAFExtendedWebElement("//a/span[text()=" + "'" + grpName + "'" + "]");
		SelectDropdown.waitForPresent(10000);
		SelectDropdown.click();
		util.waitFor(10);
		Reporter.log("Filtered BSR with BSR group..");
	}

	// made chnage by vidya
	public void acceptCase() {
		util.waitFor(5);
		getSearchList().sendKeys(CASENUMBER);
		util.waitFor(8);
		getSearchList().sendKeys(Keys.ENTER);
		util.waitFor(5);
		QAFWebElement Checkbox = new QAFExtendedWebElement("//a[@title='" + CASENUMBER
				+ "']//ancestor::th//ancestor::tr//td//following-sibling::td//label[@class='slds-checkbox__label']//span[1]");
		util.scrollIntoElement(Checkbox);
		JavascriptExecutor js = driver;
		js.executeScript("arguments[0].scroll(0,8000)", Checkbox);
		util.waitFor(Checkbox, 20, true);
		util.clickUsingJs(Checkbox);
		getCaseAcceptBtn().click();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
	}

	public void clickOnCaseByCaseNumber() {
		util.waitFor(5);		
		getSearchList().sendKeys(CASENUMBER);
		util.waitFor(8);
		getSearchList().sendKeys(Keys.ENTER);
		QAFWebElement SelectCase = new QAFExtendedWebElement("//a[text()='" + CASENUMBER + "']");
		JavascriptExecutor js = driver;
		js.executeScript("arguments[0].scroll(0,8000)", SelectCase);
//		util.scrollIntoElement(SelectCase);
		util.waitFor(SelectCase, 60, true);
		util.waitFor(10);
		util.clickUsingJs(SelectCase);
		Reporter.logWithScreenShot("Opened created case by case number..");
		util.waitForCasePage();
	}

	public int clickOnBSRBySubject(String Subject, Map<String, String> data) {
		util.waitFor(5);
		getSearchList().sendKeys(Subject);
		util.waitFor(8);
		getSearchList().sendKeys(Keys.ENTER);
		BSR = driver.findElements(By.xpath("//span[text()='" + Subject + "']/ancestor::td/preceding-sibling::th//a"))
				.size();
		String bsr = String.valueOf(BSR);
		Validator.verifyThat("verify Quantity of BSR", bsr, Matchers.equalTo(data.get("Quantity")));
		System.out.println(BSR);
		return BSR;
	}

	public void ClickOnEligibilityCheckButton() {
		util.waitForCasePage();
		util.waitForCasePage();
		util.clickOnActionToolBarButton("Quick Actions", "Eligibility Check");
		util.waitFor(By.xpath("//title[contains(text(),'Lightning Experience | Salesforce')]"), 5, true);
		Reporter.log("On case page clicked on eligibility check button..");
	}

	public void ClickOnMNPPortabilityChecks() {
		util.waitForCasePage();
		CASEURL = driver.getCurrentUrl();
		util.waitFor(7);
		QAFWebElement RelatedSection = new QAFExtendedWebElement("//span[@title='MNPPortabilityChecks']/parent::a");
		List<WebElement> listOfSection = driver.findElements(By.xpath("//div[@class='container']/div"));
		System.out.println(listOfSection.size());
		JavascriptExecutor js = driver;
		for (WebElement element : listOfSection) {
			js.executeScript("arguments[0].scrollIntoView(true)", element);
			util.waitFor(1);
			if (RelatedSection.isPresent()) {
				util.waitFor(1);
				RelatedSection.click();
				QAFWebElement PortabilityChecks = new QAFExtendedWebElement("//table//tbody//tr//th//a");
				PortabilityChecks.waitForEnabled(15000);
				PortabilityChecks.click();
				Reporter.logWithScreenShot("Clicked on MNPPortablity check.. ");
				break;
			}
		}
		Reporter.log("In related section scrolled till MNPPortability Checks and clicked on that..");
	}

	public void VerifyEligibilityCheckbox() {
		String listOFAutoCheck = "InfinityGoldAutoCheck,PostpaidAutoCheck,WithinContractAutoCheck,NotBundleAutoCheck";
		String[] split = Arrays.stream(listOFAutoCheck.split(",")).map(String::trim).toArray(String[]::new);
		for (String AutoCheck : split) {
			System.out.println(AutoCheck);
			QAFWebElement Checks = new QAFExtendedWebElement(
					"//input[@name='" + AutoCheck + "__c' and @type='checkbox']");
			Checks.isSelected();
			Reporter.logWithScreenShot("Checked all checkboxes..");
		}
		new QAFExtendedWebElement("//span[text()='" + CASENUMBER + "']").click();
		// new QAFExtendedWebElement("//span[text()='00830499']").click();
	}

	// made change vidya
	public void ClickOnBulkUpload() {
		util.waitForCasePage();
		CASEURL = driver.getCurrentUrl();
		getCaseTitle().waitForPresent(10000);
		QAFWebElement showMoreAction = new QAFExtendedWebElement(
				By.xpath("(//div[@class='slds-grid primaryFieldRow']//div//ul//li[5]//button)[last()]"));
		if (showMoreAction.isPresent()) {
			util.clickUsingJs(showMoreAction);
		} else {
			util.clickUsingJs(By.xpath("//div[@class='slds-grid primaryFieldRow']//div//ul//li[5]//button"));
		}
		util.waitFor(getUploadBulkOption(), 10, true);
		getUploadBulkOption().waitForEnabled(10000);
		getUploadBulkOption().click();
		Reporter.log("On case page clicked on upload bulk file..");
		util.waitFor(By.xpath("//title[.='Data Import Wizard ~ salesforce.com']"), 5, true);
	}

	// made change by vidya
	public void manualEligibilityCheckPerform(String location) {
		Set<String> windows = driver.getWindowHandles();
		for (String handle : windows) {
			driver.switchTo().window(handle);
		}
		util.waitForBulkUploadPage();
		util.refreshSwitchToFrame();
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(MNPPortabilityCheckBtn);
		util.clickUsingJs(UpdateExistingRecord);
		Select s = new Select(MatchBy);
		s.selectByIndex(1);
		util.clickUsingJs(CSVOption);
		driver.findElement(chooseFile).sendKeys(location);
		Reporter.logWithScreenShot("Choosed file..");
		util.clickUsingJs(ImportFileNextBtn);
		util.clickUsingJs(EditMappingFieldNextBtn);
		util.clickUsingJs(StartImport);
		getOkButton().waitForVisible(15000);
		util.clickUsingJs(OkButton);
		util.waitFor(5);
		util.refreshSwitchToFrame();
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//a[text()='View Result']"));
		String uploadresult = driver.findElement(By.xpath("//th[text()='Records Failed']//following::tr/td[9]"))
				.getText();
		if (!uploadresult.equals("0")) {
			Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
		} else {
			Reporter.log("Performed Manual Eligibility check..");
			driver.navigate().to(CASEURL);
			util.waitForCasePage();
		}
	}

	public void afterUploadVerifyEligibilityCheckbox() {
		String listOFAutoCheck = "Active,FraudulentSubscriber,PortingActivity,PendingTransfer,OpenServiceOrders,OutstandingFinancialObligation,Blacklisted,Disputes";
		String[] split = Arrays.stream(listOFAutoCheck.split(",")).map(String::trim).toArray(String[]::new);
		for (String AutoCheck : split) {
			System.out.println(AutoCheck);
			QAFWebElement Checks = new QAFExtendedWebElement(
					"//input[@name='" + AutoCheck + "__c' and @type='checkbox']");
			Checks.isSelected();
			Reporter.logWithScreenShot("Checked all checkboxes..");
		}
		new QAFExtendedWebElement("//span[text()='" + CASENUMBER + "']").click();
		// new QAFExtendedWebElement("//span[text()='00830499']").click();
	}

	public void clickOnGenerateLOU() {
		util.waitForCasePage();
		util.clickOnActionToolBarButton("Quick Actions", "Generate LOU");
		util.waitForVlocityOmniScript();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//p[text()='Back to Case']"), 10, true);
		util.clickUsingJs(By.xpath("//p[text()='Back to Case']"));
		Reporter.log("In quick action toolbar clicked on Generate LOU..");
	}

	public void verifyTransactionAsset() {
		util.refreshPage();
		util.waitForCasePage();
		util.waitFor(relatedSection, 10, true);
		JavascriptExecutor js = driver;
		js.executeScript("arguments[0].scroll(0,2500)", driver.findElement(relatedSection));
		if (!util.getTextFromPage(transactionAsset).equals("(0)")) {
			System.out.println("pass");
		} else {
			Reporter.log("Transaction Asset is not created", MessageTypes.Fail);
		}
		System.out.println("Transaction asset has been verified");
	}

	public void scrolltoRelatedSection(String sectionname) {
		util.waitForCasePage();
		util.waitFor(5);
		QAFWebElement RelatedAttachmentSec = new QAFExtendedWebElement(
				"//span[@title=" + "'" + sectionname + "'" + "]/parent::a");
		List<WebElement> listOfSection = driver.findElements(By.xpath("//div[@class='container']/div"));
		System.out.println(listOfSection.size());
		JavascriptExecutor js = driver;
		for (WebElement element : listOfSection) {
			js.executeScript("arguments[0].scrollIntoView(true)", element);
			util.waitFor(1);
			if (RelatedAttachmentSec.isPresent()) {
				Reporter.logWithScreenShot("Verified sectionname is present..");
				break;
			}
		}
	}

	public void clickOnResolInProgress() {
		app.markCaseStatus(ResolutionInProgress);
		util.clickUsingJs(MarkStatusComplete);
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot("Made case status as resolution in progress..");
		getMessage().waitForNotVisible(200000);
	}

	public void requestSIMReplacement() {
		util.clickOnActionToolBarButton("Quick Actions", "SIM Replacement");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.clickUsingJs(doneButton);
		util.waitForCasePage();
	}

	public void clickOnGenerateUSC() {
		util.waitForCasePage();
		util.clickOnActionToolBarButton("Quick Actions", "Generate USC");
		util.waitForVlocityOmniScript();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//p[text()='Done']"));
		Reporter.log("In quick action toolbar clicked on Generate USC..");
	}

	public void verifyOrders(String sectionname, int ordercount) throws InterruptedException {
		QAFWebElement RelatedAttachmentSec = new QAFExtendedWebElement(
				"//span[@title=" + "'" + sectionname + "'" + "]/parent::a");
		RelatedAttachmentSec.waitForVisible(15000);
		RelatedAttachmentSec.click();
		app.refreshOrders(20, ordercount);
		Reporter.logWithScreenShot("Order is generated..");
	}

	public void clickOnCaseNoBulkMNPPotabilityCheck() {
		util.scrollTillVisible(By.xpath("//span[@title='MNPPortabilityChecks']/parent::a"));
		util.waitFor(5);
		QAFWebElement RelatedSection = new QAFExtendedWebElement("//span[@title='MNPPortabilityChecks']/parent::a");
		RelatedSection.click();
		new QAFExtendedWebElement("//a[text()='" + CASENUMBER + "']").click();
		// new QAFExtendedWebElement("//a[text()='00830365']").click();
		Reporter.log("Clicked on case number from MNPPortablilityCheck page..");
	}

	public void changeOwner(String ownerNameValue) {
		util.clickUsingJs(changeOwnerEdit);
		util.waitFor(By.xpath("//input[@placeholder='Search Users...']"), 10, true);
		util.enterText(searchUser, ownerNameValue);
		util.clickUsingJs(By.xpath("//ul/li//div[@title='" + ownerNameValue + "']"));
		util.clickUsingJs(changeOwnerButton);
		Reporter.logWithScreenShot(util.waitForGenericToastMessage());
	}

	// made change vidya
	public void bulkCreateTransAsset(String location) {
		String winHandleBefore = driver.getWindowHandle();
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.waitForBulkUploadPage();
		util.refreshSwitchToFrame();
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(TransAssetBtn);
		util.clickUsingJs(AddNewRec);
		util.clickUsingJs(CSVOption);
		driver.findElement(chooseFile).sendKeys(location);
		Reporter.logWithScreenShot("Choosed file..");
		util.clickUsingJs(ImportFileNextBtn);
		util.clickUsingJs(EditMappingFieldNextBtn);
		util.clickUsingJs(StartImport);
		getOkButton().waitForVisible(15000);
		util.clickUsingJs(OkButton);
		util.waitFor(3);
		util.refreshSwitchToFrame();
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//a[text()='View Result']"));
		String uploadresult = driver.findElement(By.xpath("//th[text()='Records Failed']//following::tr/td[9]"))
				.getText();
		if (!uploadresult.equals("0")) {
			Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
		} else {
			Reporter.log("Created Bulk transaction asset..");
			driver.navigate().to(CASEURL);
			util.waitForCasePage();
		}
	}

	public void click_moveAvailableDocuments() {
		util.clickUsingJs(moveDocumentArrow);
	}

	public void caseModification(Map<String, String> data) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.type("Remarks");
		// OfferMigrationType.click();
		if (data.get("Plan").contains("5G")) {
			// util.clickDropdownValue("Legacy to 5G");
			util.selectDropdownValue(OfferMigrationType, "Legacy to 5G");
		} else {
			// util.clickDropdownValue("Legacy to Legacy");
			util.selectDropdownValue(OfferMigrationType, "Legacy to Legacy");
		}
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// created by waseem to click on new case on Cases window
	public void ClickOnNewCaseOnCase() {
		List<WebElement> NewCaseButton = driver.findElements(By.xpath("//a[@title='New']"));
		for (WebElement element : NewCaseButton) {
			if (element.isDisplayed()) {
				element.click();
			}
		}
	}
//			private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	// took from aftersalespage
//			public void click_availableDocuments() {
//			util.scrollIntoElement(availableDocuments);
//			util.moveToElement(availableDocuments);
//			util.clickUsingActions(availableDocuments);
//			}
	// took from aftersalespage
//			public void click_moveAvailableDocuments() {
//			util.clickUsingJs(moveDocumentArrow);
//			}

	public void caseModification() {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		// util.scrollIntoElement(EditButton);
		// EditButton.click();
		util.clickUsingJs(EditButton);
		// util.type("Remarks/Comments");
		util.typeIntoTextArea("Remarks/Comments");
		// OfferMigrationType.click();
		util.clickUsingJs(OfferMigrationType);
		// util.clickDropdownValue("Legacy to Legacy");
		util.clickDropdownValue("Legacy to 5G");
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

//Nimesh
	public void changeStatustoResolutionInProgress() {
		QAFWebElement markStatus = new QAFExtendedWebElement(By.xpath("//span[text()='Mark as Current Stage']"));
		util.ChangeStatus(ResolutionInProgress, markStatus);
	}

	// Nimesh
	public void featurecasemodification(String FeaturesAvailable) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		// util.scrollIntoElement(EditButton);
		// EditButton.click();
		util.clickUsingJs(EditButton);
		util.type("Remarks");
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
//		driver.findElementByXPath("//span[@title='" + FeaturesAvailable + "']").click();
//		util.clickUsingJs(moveDocumentArrow);
//		util.waitFor(SaveRecord, 10, true);
//		util.clickUsingJs(SaveRecord);
		String[] split = Arrays.stream(FeaturesAvailable.split(",")).map(String::trim).toArray(String[]::new);

		for (String feature : split) {

			WebElement ele;
			switch (feature) {
			case "Roaming":
				ele = driver.findElement(By.xpath(
						"//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Roaming']"));
				ele.click();
				util.clickUsingJs(moveDocumentArrow);
				break;

			case "IDD":

				ele = driver.findElement(By.xpath(
						"//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='IDD']"));
				ele.click();
				util.clickUsingJs(moveDocumentArrow);
				break;

			case "Voice Outgoing":
				ele = driver.findElement(By.xpath(
						"//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Voice Outgoing']"));
				ele.click();
				util.clickUsingJs(moveDocumentArrow);
				break;

			case "Voice Incoming & Outgoing":
				ele = driver.findElement(By.xpath(
						"//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Voice Incoming & Outgoing']"));
				ele.click();
				util.clickUsingJs(moveDocumentArrow);
				break;

			case "SMS Outgoing":
				ele = driver.findElement(By.xpath(
						"//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='SMS Outgoing']"));
				ele.click();
				util.clickUsingJs(moveDocumentArrow);
				break;

			case "SMS Incoming & Outgoing":
				ele = driver.findElement(By.xpath(
						"//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='SMS Incoming & Outgoing']"));
				ele.click();
				util.clickUsingJs(moveDocumentArrow);
				break;

			case "Data":
				ele = driver.findElement(By.xpath(
						"//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Data']"));
				ele.click();
				util.clickUsingJs(moveDocumentArrow);
				break;

			default:

				System.out.println("Did not select any features");
				break;
			}
		}
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
	}

	public void acceptCase(String CaseID) {
		getListview().click();
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		// driver.findElement(By.xpath("//input[@class='slds-input default input uiInput
		// uiInputTextForAutocomplete uiInput--default
		// uiInput--input']")).sendKeys("SMART Enterprise Support");
		getFilterCaseSearchBox().sendKeys("SMART Enterprise Support");
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		driver.findElement(By.xpath("//mark[text()='SMART Enterprise Support']")).click();
		util.waitTillLoaderDissapear();
		getSearchInput().click();
		util.typeDataTo(getSearchInput(), CaseID);
		// getSearchInput().sendKeys(Subject);
		util.waitTillLoaderDissapear();
		// getSearchInput().sendKeys(Subject);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		getSearchInput().sendKeys(Keys.ENTER);
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		util.waitFor(By.xpath("(//span[@class='slds-checkbox--faux'])[2]"), 10, true);
		driver.findElement(By.xpath("(//span[@class='slds-checkbox--faux'])[2]")).click();
		driver.findElement(By.xpath("//div[@title='Accept']")).click();
		util.waitForGenericToastMessage();
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		getListview().click();
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		getFilterCaseSearchBox().sendKeys("My Cases");
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		driver.findElement(By.xpath("//mark[text()='My Cases']")).click();
		util.waitTillLoaderDissapear();
		String Case = "//a[text()='" + CaseID + "']";
		util.clickUsingJs(By.xpath(Case));
	}

	public void features(String features) {
		if (features.equalsIgnoreCase("Feature Activation")) {
			util.clickOnActionToolBarButton("Quick Actions", "Feature Activation");
//				try {
//					Thread.sleep(7000);
//				} catch (Exception e) {}
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
			util.refreshSwitchToFrame();
			util.AttachFrame();
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
			util.scrollTillVisible(By.xpath("//p[text()='Done']"));
			util.clickUsingJs(By.xpath("//p[text()='Done']"));
		} else {
			util.clickOnActionToolBarButton("Quick Actions", "Feature Deactivation");
//					try {
//						Thread.sleep(7000);
//					} catch (Exception e) {}
			util.refreshSwitchToFrame();
			util.AttachFrame();
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
			util.scrollTillVisible(By.xpath("//p[text()='Done']"));
			util.clickUsingJs(By.xpath("//p[text()='Done']"));
		}
	}

	public void createNewFA_FDCase(String billingAccountNumber) {
		util.selectAndClickCaseSuggestedValue(billingAccountName, billingAccountNumber);
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Transaction Type");
		// util.select("Transaction Sub Type");
		util.select("Case Origin");
		click_availableDocuments();
		click_moveAvailableDocuments();
		getSave().click();
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public boolean bulkUpload() {
		String winHandleBefore = driver.getWindowHandle();
		String path = System.getProperty("user.dir") + "\\resources\\testdata\\BulkFile.csv";
		util.waitForCasePage();
		util.waitFor(By.xpath("(//span[text()='Show more actions'])"), 10, true);
		util.waitFor(5);
		try {
			util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])"));
		} catch (Exception e) {
			util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[last()]"));
		}
		util.clickUsingJs(By.xpath("(//span[text()='Upload Bulk File'])[last()]"));
		util.waitFor(By.xpath("(//span[text()='Upload Bulk File'])[last()]"), 10, false);
		util.waitFor(5);
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		// Use the list of window handles to switch between windows
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.waitForBulkUploadPage();
		util.refreshPage();
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(By.xpath("//a[.='Transaction Assets']"));
		util.clickUsingJs(By.xpath("//a[.='Add new records']"));
		util.clickUsingJs(By.xpath("//span[@class='csvType uiOutputText']"));
		driver.findElement(By.xpath("//input[@name='file']")).sendKeys(path);
		util.clickUsingJs(By.xpath("//a[.='Next']"));
		util.clickUsingJs(By.xpath("//a[.='Next']"));
		util.clickUsingJs(By.xpath("//a[.='Start Import']"));
		util.clickUsingJs(By.xpath("//a[.='OK']"));
//				util.switchToLoginFrame();
//				util.waitFor(By.xpath("(//label[contains(text(),'Records Failed')]/following::td[1])"), 20, true);
//				String Records = util.getTextFromPage(By.xpath("(//label[contains(text(),'Records Failed')]/following::td[1])"));
//				if(Records.equalsIgnoreCase("0")) {
//					driver.close();
//					driver.switchTo().window(winHandleBefore);
//					return true;
//				}
//				else {
//					System.out.println("Records Failed");
//					return true;
//				}
		driver.close();
		driver.switchTo().window(winHandleBefore);
		return true;
	}

	// created by vidya
	private static By billingAccountName = By
			.xpath("//span[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");

	public void createRetentionNewCase(String billingAccountNumber) {
		util.selectAndClickCaseSuggestedValue(billingAccountName, billingAccountNumber);
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Transaction Type");
		util.select("Transaction Sub Type");
		util.select("Case Origin");
		click_availableDocuments();
		click_moveAvailableDocuments();
		getSave().click();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");

	// took from aftersalespage by vidya
	public void click_availableDocuments() {
		util.scrollIntoElement(availableDocuments);
		util.moveToElement(availableDocuments);
		util.clickUsingActions(availableDocuments);
	}

	public void requestRetention(String plan) {
		util.clickOnActionToolBarButton("Quick Actions", "Retention");
		util.refreshSwitchToFrame();
		util.waitFor(PlanName, 10, true);
		PlanName.click();
		util.typeDataTo(PlanName, plan);
		QAFWebElement planname = new QAFExtendedWebElement("//ul//li//a[contains(text(),'" + plan + "')]");
		planname.click();
		Reporter.logWithScreenShot("Selected plan..");
		util.AttachFrame();
		util.vlocityNextButton();
		Reporter.logWithScreenShot("Click on Retention button and selected plan in vlocity page..");
		util.waitFor(By.xpath("//title[text()='vlocity_cmt__HybridCPQ | Salesforce']"), 60, true);
	}

//	private static By billingAccountName = By.xpath("//span[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");
	public void createChangePlanNewCase(String billingAccountNumber) {
		// util.selectAndClickCaseSuggestedValue(billingAccountName,
		// billingAccountNumber);
//		 util.selectAndClickCaseSuggestedValueShowAll(billingAccountName,
//		 billingAccountNumber);
		util.selectAndClickCaseSuggestedValueShowAll("Billing Account");
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
//		util.select("Transaction Type");
//		util.select("Transaction Sub Type");
//		util.selectAndClickSuggestedValue("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		// util.selectAndClickSuggestedValue("Transaction Sub Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.select("Case Origin");
		// click_availableDocuments();
		// click_moveAvailableDocuments();
		getSave().click();
		util.waitTillLoaderDissapear();
		util.waitFor(10);
//		getMessage().waitForVisible(150000);
//		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void markCaseStatusToResolutionInprogress() {
		// markCaseStatus(resolutionInProg,"Resolution In Progress");
		util.clickUsingJs(By
				.xpath("(//div[@aria-label='Path Header']/ul/li/a[@data-tab-name='Resolution In Progress'])[last()]"));
		util.clickUsingJs(markCurrentStatus);
		util.waitForGenericToastMessage();
	}

	public boolean verifyTransactionDetailsForConnectionScenarios(String assetValue, String transactionReasonValue,
			String transactiontype, String caseOrigin) {
		util.clickUsingJs(transactionDetails);
		util.clickUsingJs(editButton);
		if (transactiontype.contains("Reconnection")) {
			if (!transactiontype.contains("Involuntary") && caseOrigin.contains("Internal User")) {
				util.clickUsingJs(servicereq);
				util.clickUsingJs(
						By.xpath("(//lightning-base-combobox-item[@data-value='" + transactionReasonValue + "'])"));
			}
		} else {
			if (caseOrigin.contains("Internal User")) {
				util.clickUsingJs(highLevelDisconnection);
				util.clickUsingJs(
						By.xpath("(//lightning-base-combobox-item[@data-value='" + transactionReasonValue + "'])"));
			}
		}
		util.clickUsingJs(saveRecord);
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		if (caseOrigin.contains("Internal User")) {
			check.add(util.isElementDisplayed(MINNumber));
		}
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public void numberReservationCheck() {
		System.out.println("Click on Number Reservation..");
		util.clickOnActionToolBarButton("Quick Actions", "Reserve Numbers");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//span[text()='Number/Pattern Search']"), 5, true);
		util.refreshSwitchToFrame();
		util.clickUsingJs(By.xpath("//span[text()='Number/Pattern Search']"));
		util.clickUsingJs(By.xpath("//p[text()='Next']"));
		util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")), "Regular");
		// util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")),
		// "Special Vanity");
		util.waitFor(By.xpath("(//p[.='Search MIN'])[1]"), 10, true);
		util.clickUsingJs(By.xpath("(//p[.='Search MIN'])[1]"));
		util.clickUsingJs(By.xpath("(//th/button)[1]"));
		util.clickUsingJs(By.xpath("//div[@id='StepMINSearchNo_nextBtn']"));
		util.clickUsingJs(By.xpath("(//p[text()='Next'])[3]"));
		util.AttachFrame();
		util.waitFor(By.xpath("//span[.='Number Reservation is successful.']"), 13, true);
		if (util.isElementDisplayed(By.xpath("//span[.='Number Reservation is successful.']"))) {
			util.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
		} else {
			for (int i = 0; i < 4; i++) {
				if (util.isElementDisplayed(By.xpath("//span[.='Number Reservation is successful.']"))) {
					util.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
					break;
				}
				util.AttachFrame();
				util.vlocityPreviousButton();
				util.AttachFrame();
				util.vlocityPreviousButton();
				util.AttachFrame();
				util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")), "Regular");
				driver.findElement(By.xpath("(//p[.='Search MIN'])[1]")).click();
				driver.findElement(By.xpath("(//th/button)[1]")).click();
				driver.findElement(By.xpath("//div[@id='StepMINSearchNo_nextBtn']")).click();
				driver.findElement(By.xpath("(//p[text()='Next'])[3]")).click();
			}
		}
		util.waitForQuotePage();
	}

	public String getIDFromNotificationText() {
		util.waitFor(By.xpath("//*[@data-aura-class='forceToastMessage']"), 15, true);
		String text = util.getTextFromPage(By.xpath("//*[@data-aura-class='forceActionsText']"));
		return text.split(" ")[1];
	}

	// vidya
	public void createSUNInfinityAsset() throws InterruptedException {
		util.waitForCasePage();
		util.clickOnActionToolBarButton("Quick Actions", "Create SUN Infinity Assets");
		util.waitForVlocityOmniScript();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		QAFWebElement spinner = new QAFExtendedWebElement(
				"//div[@class='slds-spinner--brand slds-spinner slds-spinner--large']");
		spinner.waitForNotVisible(150000);
		util.waitFor(By.xpath("//div[contains(text(),'Back to Case')]"), 10, true);
		util.clickUsingJs(By.xpath("//div[contains(text(),'Back to Case')]"));
		if (SUNOkBtn.isDisplayed()) {
			util.clickUsingJs(SUNOkBtn);
		}
		Reporter.log("Created SUN Infinity Asset..");
	}

	public void redirectCaseByClickOnCaseNo() {
		new QAFExtendedWebElement("//a[text()='" + CASENUMBER + "']").click();
		// new QAFExtendedWebElement("//a[text()='00830365']").click();
		Reporter.log("Clicked on case number..");
		util.waitForCasePage();
	}

	// made change vidya
	public void SUNInfinityEligibilityCheckPerform(String location) {
		String winHandleBefore = driver.getWindowHandle();
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.waitForBulkUploadPage();
		util.refreshPage();
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(MNPPortabilityCheckBtn);
		util.clickUsingJs(AddNewRec);
		Select s = new Select(CaseLookupField);
		s.selectByIndex(0);
		TriggerCheckbox.click();
		util.clickUsingJs(CSVOption);
		driver.findElement(chooseFile).sendKeys(location);
		Reporter.logWithScreenShot("Choosed file..");
		util.clickUsingJs(ImportFileNextBtn);
		util.clickUsingJs(EditMappingFieldNextBtn);
		util.clickUsingJs(StartImport);
		getOkButton().waitForVisible(15000);
		util.clickUsingJs(OkButton);
		util.waitFor(3);
		util.refreshSwitchToFrame();
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//a[text()='View Result']"));
		String uploadresult = driver.findElement(By.xpath("//th[text()='Records Failed']//following::tr/td[9]"))
				.getText();
		if (!uploadresult.equals("0")) {
			Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
		} else {
			Reporter.log("Perform Eligibility check..");
			driver.navigate().to(CASEURL);
			util.waitForCasePage();
		}
	}

	public String retriveCaseNumberFromURL() {
		String URL = driver.getCurrentUrl();
		String CaseNumber = StringUtils.substringBetween(URL, "Case/", "/view");
		return CaseNumber;
	}
//			private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	// took from aftersalespage
//			public void click_availableDocuments() {
//			util.scrollIntoElement(availableDocuments);
//			util.moveToElement(availableDocuments);
//			util.clickUsingActions(availableDocuments);
//			}
	// took from aftersalespage
//			public void click_moveAvailableDocuments() {
//			util.clickUsingJs(moveDocumentArrow);
//			}

//Nimesh
	public void requestChangePlan(String Plan, String Addons) {
		util.clickOnActionToolBarButton("Quick Actions", "Change Of Plan");
		// util.clickUsingJs(doneButton);
		// util.waitForCasePage();
		util.refreshSwitchToFrame();
		util.clickUsingJs(getPlanName());
		util.typeDataTo(getPlanName(), Plan);
		// util.clickUsingJs(By.xpath("//ul//li//*[text()='" + Plan + "']"));
		QAFWebElement planname = new QAFExtendedWebElement(By.xpath("//ul//li//a[contains(text(),'" + Plan + "')]"));
		util.waitTillLoaderDissapear();
		planname.click();
		getSelectPlanNextButton().waitForEnabled(10);
		util.clickUsingJs(getSelectPlanNextButton());
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 60, false);
		if (Plan.contains("5G")) {
			util.waitFor(By.xpath("//title[text()='vlocity_cmt__HybridCPQ | Salesforce']"), 40, true);
			util.waitForCartPage();
			util.refreshSwitchToFrame();
			util.AttachFrame();
			addAddonsto5GPlans(Addons);
			util.clickUsingJs(getViewRecord());
		}
		util.waitForQuotePage();
		// util.waitFor(By.xpath("(//div[contains(@class,'profilePicWrapper
		// ')]/following::h1/div[.='Quote'])[1]"), 80, true);
		try {
			Thread.sleep(10000);
			// util.refreshPage();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void goToCaseOrdersSearchPage(String caseURL) {
		String orderSearchPage = caseURL.replaceFirst("/view", "/related/Orders__r/view");
		driver.get(orderSearchPage);
	}

	public void verifyOrdersFromCasePage(String caseURL) {
		goToCaseOrdersSearchPage(caseURL);
	}

	public void addAddonsto5GPlans(String Addons) {
		util.clickUsingJs(By.xpath("(//button[@class='slds-button slds-button_icon-small'])[4]"));
		String[] split = Arrays.stream(Addons.split(",")).map(String::trim).toArray(String[]::new);
		for (String Addon : split) {
			System.out.println("Add Addons to 5G Plan | " + Addon);
			driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).sendKeys(Addon);
			String selectAddon = "//div[text()='" + Addon + "']";
			util.clickUsingJs(By.xpath(selectAddon));
			util.waitForCartPageToastMessage();
			util.waitFor(By.xpath("//div[@class='cpq-product-name-block cpq-item-child-product-name-wrapper']"), 10,
					true);
			// util.clickDropdownValue(selectAddon);
			driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).clear();
		}
	}

	public boolean verifyTransactionDetailsForChangeMIN(String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		System.out.println(util.getTextFromPage(transactionStatus));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			System.out.println("Transaction details are verified");
			return false;
		}
		System.out.println("Transaction details are not verified");
		return true;
	}

	public boolean verifyTransactionDetailsForSIMReplacement(String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		System.out.println(util.getTextFromPage(simReplacementFee));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)
				&& util.getTextFromPage(simReplacementFee).equals("0.00")) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public void transactionActionForConnectionScenarios(String transactionType) {
		try {
			System.out.println("Click on Disconnection..");
			util.refreshPage();
			if (transactionType.contains("Termination")) {
				util.clickOnActionToolBarButton("Quick Actions", "Disconnect");
			} else {
				if (transactionType.contains("Reconnection")) {
					util.clickOnActionToolBarButton("Quick Actions", "Resume");
				} else {
					if (transactionType.contains("Temporary"))
						util.clickOnActionToolBarButton("Quick Actions", "Suspend");
				}
			}
			util.waitForVlocityOmniScript();
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.clickUsingJs(doneButton);
			util.waitForCasePage();
		} catch (Exception e) {
		}
	}

	public void changeDevice() {
		util.clickOnActionToolBarButton("Quick Actions", "Change of Device");
		util.waitForVlocityOmniScript();
		util.waitForCasePage();
		util.waitFor(10);
	}

	// Created by Saisree for Aftersales Treatment
	public void createNewCaseAfterSalesTreatment(String BillingAccount) {
		util.selectAndClickCaseSuggestedValueShowAll("Billing Account");
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.select("Case Origin");
		getSave().click();
		getMessage().waitForVisible(150000);
		CASENUMBER = getCaseNumberToastmsg().getText();
		setCASENUMBER(CASENUMBER);
		System.out.println(CASENUMBER);
		Reporter.logWithScreenShot(getMessage().getText());
		getMessage().waitForNotVisible(200000);
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	// Created by Saisree for Aftersales Treatment
	public void caseModificationfortreatment(String Asset, String AssetID, Map<String, String> data) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		util.clickUsingJs(EditButton);
		if ((Objects.nonNull(data.get("Asset ID")))) {
			util.typeIntoTextArea("Asset ID");
			util.waitFor(8);
			util.clickUsingJs(
					driver.findElement(By.xpath("//span[text()='Show All Results for \"" + AssetID + "\"']")));
			util.waitFor(By.xpath("(//a[.='" + Asset + "'])[last()]"), 20, true);
			util.clickUsingJs(By.xpath("(//a[.='" + Asset + "'])[last()]"));
		}
		util.waitFor(3);
		if (data.get("Transaction Type").contains("Add / Edit THS Exemption(Billing Account Level)")) {
			util.selectAndClickCaseSuggestedValueShowAll("THS Exempt Reason");
		}
		if (data.get("Transaction Type").contains("Change Assignee")) {
			util.typeIntoTextArea("Assignee First Name");
			util.typeIntoTextArea("Assignee Last Name");
		}
		if ((Objects.nonNull(data.get("Remarks/Comments")))) {
			util.typeIntoTextArea("Remarks/Comments");
		}
		if (data.get("Transaction Type").contains("Lift Assertive Cure")) {
			util.selectDropdownValue(ReasonCode, data.get("Reason Code"));
			Reporter.logWithScreenShot("Update Transaction Details");
		} else if (data.get("Transaction Sub Type").contains("ESoA Enrolment")) {
			util.selectAndClickSuggestedValue("Bill Dispatch Method");
			// util.clickCheckbox("Password Protected");
			util.clickUsingJs(By.xpath("//input[@name=\"Password_Protected__c\"]"));
			util.typeIntoTextArea("eSOA Notification Email ID");
			Reporter.logWithScreenShot("Update Transaction Details");
		} else if (data.get("Transaction Sub Type").contains("ESoA Un-enrolment")) {
			util.selectAndClickSuggestedValue("Bill Dispatch Method");
		}
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		util.waitFor(10);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by Saisree for Aftersales Treatment
	public void CheckingTransactionID(String caseURL, Map<String, String> data, String User) {
		String TransactionSearchPage = caseURL.replaceFirst("/view", "/related/Transaction__r/view");
		driver.get(TransactionSearchPage);
		util.waitFor(By.xpath("//div/a[contains(@class,'slds-truncate')]"), 20, true);
		util.refreshPage();
		util.waitFor(10);
		String Transaction = "//div/a[contains(@class,'slds-truncate')]";
		List<WebElement> elements = driver.findElements(By.xpath(Transaction));
		int Transactioncount = elements.size();
		System.out.println(Transactioncount);
		int i;
		util.waitFor(5);
		for (i = 1; i <= Transactioncount; i++) {
			util.clickUsingJs(
					By.xpath("(//div/a[contains(@class,'slds-truncate')])[" + i + "]"));
			int count = 0;
			while (count <= 5) {
				util.waitFor(10);
				util.waitFor(By.xpath("//h1/div[(text()='Transaction')]"), 60, true);
				util.refreshPage();
				util.waitFor(10);
				util.waitFor(By.xpath("//h1/div[(text()='Transaction')]"), 60, true);
				String TransactionSta = driver.findElement(By.xpath(
						"//span[text()='Transaction Status']/parent::*/following-sibling::div//lightning-formatted-text"))
						.getText();
				count++;
				if (TransactionSta == "Successful") {
					break;
				}
			}
			String TransactionStaS = driver.findElement(By.xpath(
					"//span[text()='Transaction Status']/parent::*/following-sibling::div//lightning-formatted-text"))
					.getText();
			if (TransactionStaS != "Successful") {
				login.logoutCurrentUser();
				driver.get(TransactionSearchPage);
				util.waitFor(By.xpath("//div/a[contains(@class,'slds-truncate')]"), 20,
						true);
				util.refreshPage();
				util.waitFor(5);
				util.clickUsingJs(By.xpath("//div/a[contains(@class,'slds-truncate')]"));
				util.waitFor(By.xpath("//h1/div[(text()='Transaction')]"), 60, true);
				util.waitFor(5);
				util.clickUsingJs(
						By.xpath("//span[text()='Transaction Status']/parent::*/following-sibling::div/button"));
				util.waitFor(5);
				util.scrollIntoElement(By.xpath("//label[text()='Transaction Status']/following-sibling::div//button"));
				util.clickUsingJs(TransactionStatus);
				util.waitFor(5);
				util.clickUsingJs(By.xpath("//*[@title='" + data.get("TransactionStatus") + "']"));
				util.clickUsingJs(By.xpath("(//button[.='Save'])[last()]"));
				util.waitFor(By.xpath("//div/a[contains(@class,'slds-truncate')]"), 30,
						true);
				Reporter.logWithScreenShot("Update Transaction Status");
				home.SwitchToUser(User, "Case owner");
				driver.get(TransactionSearchPage);
				util.waitFor(By.xpath("//div/a[contains(@class,'slds-truncate')]"), 20,
						true);
				util.refreshPage();
				util.waitFor(5);
				util.clickUsingJs(By.xpath("//div/a[contains(@class,'slds-truncate')]"));
				util.waitFor(By.xpath("//h1/div[(text()='Transaction')]"), 60, true);
				util.waitFor(5);

			}
			Reporter.logWithScreenShot("Transaction Status is successful");
			String TransactionStatuS = driver.findElement(By.xpath(
					"//span[text()='Transaction Status']/parent::*/following-sibling::div//lightning-formatted-text"))
					.getText();
			Validator.verifyTrue(TransactionStatuS.equalsIgnoreCase("Successful"),
					" Transaction Status is not successful", "Transaction Status is successful");
		}
	}

	public void AddDocumentsRequiredForTreatment(Map<String, String> data) {
		CASENUMBER = getCaseNumber().getText();
		setCASENUMBER(CASENUMBER);
		util.clickUsingJs(By.xpath("//a[contains(@data-label,'Documents Required')]"));
		util.waitFor(3);
		util.scrollIntoElement(By.xpath("(//button[text()='Edit'])[2]"));
		util.clickUsingJs(By.xpath("(//button[text()='Edit'])[2]"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//span[contains(@title,'" + data.get("Documents") + "')]"));
		util.clickUsingJs(By.xpath("//button[@title='Move selection to Chosen']//lightning-primitive-icon"));
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
		util.waitForGenericToastMessage();
		util.refreshPage();
	}

	// Created by Saisree for Aftersales Treatment
	public void changeOwnerForTreatment(String ownerNameValue, Map<String, String> data) {
		util.clickUsingJs(changeOwnerEdit);
		util.waitFor(By.xpath("//input[@placeholder='Search Users...']"), 10, true);
		if (!data.get("Type Of Owner").contains("Users")) {
			util.clickUsingJs(By.xpath("//a[contains(@aria-label,'Search owners...')]/lightning-icon"));
			util.waitFor(3);
			util.clickUsingJs(By.xpath("//span[.='" + data.get("Type Of Owner") + "']"));

		}
		util.enterText(By.xpath("//input[@placeholder='Search Queues...']"), ownerNameValue);
		util.waitFor(5);
		util.clickUsingJs(By.xpath("//ul/li//div[@title='" + ownerNameValue + "']"));
		util.clickUsingJs(changeOwnerButton);
		Reporter.logWithScreenShot(util.waitForGenericToastMessage());
	}

	// Created by Saisree for Aftersales Treatment
	public void openCaseOwnerAndRelatedUserforTreatment(Map<String, String> data) throws InterruptedException {
		util.clickUsingJs(By.xpath("(//div[@class='headerTrigger  tooltip-trigger uiTooltip'])[last()]"));
		util.clickUsingJs(By.xpath("//a[@title='Setup']"));
		String winHandleBefore = driver.getWindowHandle();
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		driver.switchTo().window(tabs.get(tabs.size() - 1));

		util.enterText(getSetupSearchBox(), data.get("Change Owner"));
		getSetupSearchBox().sendKeys(Keys.ENTER);
		getGroupQueueBtn().waitForPresent(10000);
		getGroupQueueBtn().click();
		util.clickUsingJs(By.xpath("//a[text()='" + data.get("Change Owner") + "']"));
		util.switchtoFrameAndClick(By.xpath("//th[text()='Name']/following::tr[3]/th/a"));
		util.waitFor(5);
		util.switchtoFrameAndClick(By.xpath("//th/following::tr[4]/th/a[.='Marjorie Legion']"));
		util.switchToLoginFrame();
		getUserLoginBtn().waitForVisible(30000);
		util.clickUsingJs(getUserLoginBtn());
		util.waitFor(By.xpath("//span[contains(text(),'Logged in as')]"), 25, true);
		Reporter.log("logged in with case owner..");
	}

	// Created by Saisree for Aftersales Treatment
	public void AddCreditArrangement(Map<String, String> data) {
		util.waitFor(By.xpath("//h1[.='Credit Arrangement Details']"), 90, true);
		util.refreshPage();
		util.waitFor(5);
		Reporter.logWithScreenShot("Credit Arrangements Page 1");
		util.clickUsingJs(creditNext);
		util.waitFor(5);
		util.clickUsingActions(By.xpath("//div[@class='slds-form-element__control']"));
		util.waitFor(3);
		util.clickUsingActions(By.xpath("//span[.='" + data.get("Credit Arrangement Reason") + "']"));
		util.waitFor(3);
		util.typeIntoTextArea("Remarks");
		util.clickUsingJs(By.xpath("//span[.='Lifting']/preceding-sibling::span"));
		driver.findElement(By.xpath("//input[@id=//label[normalize-space(text())='Number of Installments']/@for]"))
				.clear();
		util.typeIntoTextArea("Number of Installments");
		util.typeIntoTextArea("Promise Date");
		Reporter.logWithScreenShot("Credit Arrangements Page 2");
		util.clickUsingJs(creditNext);
		util.waitFor(10);
		Reporter.logWithScreenShot("Installments");
		util.clickUsingJs(creditNext);
		Reporter.logWithScreenShot("");
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//span[text()='Done']"));
		util.waitFor(3);
		util.waitForCasePage();
	}

	// Created by Saisree for Aftersales CaseManagement
	public void createNewCaseAfterSalesCaseManagement(String BillingAccount) {
		util.selectAndClickSuggestedValue("Billing Account");
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.selectAndClickSuggestedValue("Transaction Type");
		util.selectAndClickSuggestedValue("Transaction Sub Type");
		util.select("Transaction Entry");
		util.select("Case Origin");
		util.type("Adjustment Amount");
		getSave().click();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		getMessage().waitForNotVisible(200000);
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	// Created by Saisree for Aftersales CaseManagement
	public void ValidateCaseOwner(String user) {
		util.refreshPage();
		util.waitForCasePage();
		util.waitFor(By.xpath("//div[.='Case']"), 20, true);
		util.waitFor(By.xpath("//button[@title='Change Owner']/preceding::slot[1]/span"), 30, true);
		if (driver.findElements(By.xpath("//button[@title='Change Owner']/preceding::slot[1]/span")).size() > 0) {
			String CASEOWNER = driver.findElement(By.xpath("//button[@title='Change Owner']/preceding::slot[1]/span"))
					.getText();
			setCASEOWNER(CASEOWNER);
		} else {
			String CASEOWNER = driver.findElement(By.xpath("//button[@title='Change Owner']/preceding::slot[1]"))
					.getText();
			setCASEOWNER(CASEOWNER);
		}
		Validator.verifyThat("verify Case Owner", CASEOWNER, Matchers.equalTo(user));
		System.out.println(CASEOWNER);
		CASENUMBER = getCaseNumber().getText();
		setCASENUMBER(CASENUMBER);
		Reporter.log("Captured case owner");
	}

	// Created by Saisree for Aftersales CaseManagement
	public void SubmitForApproval() {
		util.clickUsingJs(By.xpath("//button[.='Submit for Approval']"));
		util.waitFor(3);
		util.typeIntoTextArea("Comments");
		util.clickUsingJs(By.xpath("//button/span[.='Submit']"));
		util.waitForGenericToastMessage();
	}

	// Created by Saisree for Aftersales CaseManagement
	public void CheckingApprovalUser(String caseURL, Map<String, String> data) {
		String ApprovalHistory = caseURL.replaceFirst("/view", "/related/ProcessSteps/view");
		driver.get(ApprovalHistory);
		util.waitFor(By.xpath("//h1[.='Approval History']"), 30, true);
//		String Approver = util.getTextFromPage(By.xpath("(//span[.='Pending']/parent::td/following-sibling::td//a)[1]"));
//		setAPPROVER(Approver);
		APPROVER = getapprover().getText();
		System.out.println(APPROVER);
		Reporter.log("Approval History");
	}

	// Created by Saisree for Aftersales CaseManagement
	public void ApproveCaseFromNotifications() {
		util.clickUsingJs(By.xpath("//div[@class='unsNotificationsCounter']/button"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//span[contains(text(),'" + CASENUMBER + "')]"));
		util.waitFor(By.xpath("//div[.='Approve']"), 30, true);
		util.clickUsingJs(By.xpath("//div[.='Approve']"));
		util.waitFor(3);
		util.typeIntoTextArea("Comments");
		util.clickUsingJs(By.xpath("//button/span[.='Approve']"));
//		util.waitFor(By.xpath("//span[.='Approved']"), 30, true);
		Reporter.log("Case Approved by the user");
	}

	// Created by Saisree for Aftersales CaseManagement
	public void ApproveCaseFromAprrovehistory(String caseURL, Map<String, String> data) {
		String ApprovalHistory = caseURL.replaceFirst("/view", "/related/ProcessSteps/view");
		driver.get(ApprovalHistory);
		util.waitFor(By.xpath("//h1[.='Approval History']"), 30, true);
		util.clickUsingJs(By.xpath("(//div[.='Approve'])[last()]"));
		util.waitFor(3);
		util.typeIntoTextArea("Comments");
		util.clickUsingJs(By.xpath("//button/span[.='Approve']"));
		util.waitForGenericToastMessage();
		Reporter.log("Case Approved by the user");
	}

	// Created by Saisree for Aftersales CaseManagement
	public void ApproveCaseFromItemstoApprove() {
		util.clickUsingJs(By.xpath("//a[.='" + CASENUMBER + "']"));
		util.waitFor(3);
		util.waitFor(By.xpath("//div[.='Approve']"), 30, true);
		util.clickUsingJs(By.xpath("//div[.='Approve']"));
		util.waitFor(3);
		util.typeIntoTextArea("Comments");
		util.clickUsingJs(By.xpath("//button/span[.='Approve']"));
//			util.waitFor(By.xpath("//span[.='Approved']"), 30, true);
		Reporter.log("Case Approved by the user");
	}

	// Created by Vinay for Aftersales CaseManagement
	public void RejectCaseFromItemstoApprove() {
		util.clickUsingJs(By.xpath("//a[.='" + CASENUMBER + "']"));
		util.waitFor(3);
		util.waitFor(By.xpath("//div[.='Reject']"), 30, true);
		util.clickUsingJs(By.xpath("//div[.='Reject']"));
		util.waitFor(3);
		util.typeIntoTextArea("Comments", "RejectComments");
		util.clickUsingJs(By.xpath("//button/span[.='Reject']"));
//					util.waitFor(By.xpath("//span[.='Approved']"), 30, true);
		Reporter.log("Case Rejected by the user");
	}

	public void UnbilledAdjustment(Map<String, String> data) {
		util.waitFor(5);
		util.refreshPage();
		util.waitFor(By.xpath("//h1[.='Unbilled Adjustments']"), 30, true);
		util.waitFor(5);
		util.clickUsingActions(By.xpath("//input[@placeholder='Select Component']/parent::div"));
		util.waitFor(5);
		util.clickUsingActions(By.xpath("(//*[contains(text(),'" + data.get("Component") + "')])"));
		util.waitFor(3);
		util.clickUsingActions(By.xpath("//span[.='Adjustment Reason']/ancestor::div/following-sibling::div//input"));
		util.waitFor(3);
		util.clickUsingActions(By.xpath("(//*[contains(text(),'" + data.get("Adjustment Reason") + "')])"));
		util.waitFor(3);
		QAFWebElement Contact = new QAFExtendedWebElement(
				"//input[@id=//label[normalize-space(text())='Contact No']/@for]");
		Contact.click();
		Robot robot;
		try {
			robot = new Robot();
			String TypeThis = "7866786576";
			char TypeLetter;
			Integer i;

			for (i = 0; i < TypeThis.length(); i++) {
				TypeLetter = TypeThis.charAt(i);

				switch (TypeLetter) {
				case '0':
					robot.keyPress(KeyEvent.VK_0);
					robot.keyRelease(KeyEvent.VK_0);
					break;
				case '1':
					robot.keyPress(KeyEvent.VK_1);
					robot.keyRelease(KeyEvent.VK_1);
					break;
				case '2':
					robot.keyPress(KeyEvent.VK_2);
					robot.keyRelease(KeyEvent.VK_2);
					break;
				case '3':
					robot.keyPress(KeyEvent.VK_3);
					robot.keyRelease(KeyEvent.VK_3);
					break;
				case '4':
					robot.keyPress(KeyEvent.VK_4);
					robot.keyRelease(KeyEvent.VK_4);
					break;
				case '5':
					robot.keyPress(KeyEvent.VK_5);
					robot.keyRelease(KeyEvent.VK_5);
					break;
				case '6':
					robot.keyPress(KeyEvent.VK_6);
					robot.keyRelease(KeyEvent.VK_6);
					break;
				case '7':
					robot.keyPress(KeyEvent.VK_7);
					robot.keyRelease(KeyEvent.VK_7);
					break;
				case '8':
					robot.keyPress(KeyEvent.VK_8);
					robot.keyRelease(KeyEvent.VK_8);
					break;
				case '9':
					robot.keyPress(KeyEvent.VK_9);
					robot.keyRelease(KeyEvent.VK_9);
					break;
				}

			}
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		util.clickUsingActions(By.xpath("//span[.='Charge Type']/ancestor::div/following-sibling::div//input"));
		util.waitFor(3);
		util.clickUsingActions(By.xpath("(//*[contains(text(),'" + data.get("Charge Type") + "')])"));
		util.typeIntoTextArea("Dispute Amount");
		util.typeIntoTextArea("Remarks");
		Reporter.log("Unbilled Adjustment");
		util.clickUsingJs(creditNext);
		util.waitFor(8);
		util.waitFor(By.xpath("//p[.='Update Case Successfully']"), 60, true);
		String message = driver.findElement(By.xpath("//p[.='Update Case Successfully']")).getText();
		System.out.println(message);
		Validator.verifyThat("verify Quote Line Items", message, Matchers.equalTo("Update Case Successfully"));
		Reporter.log("Unbilled Adjustment is Successfull");
		util.clickUsingJs(By.xpath("//span[.='Done']"));
		util.waitForCasePage();
	}

	// Created by Vinay to Perform Update Service Contract.
	public void updateServiceContract() {
		System.out.println("Click on Update Service Contract....");
		util.clickOnActionToolBarButton("Quick Actions", "Update Service Contract");
		util.waitForVlocityOmniScript();
		util.waitFor(3);
		util.AttachFrame();
		util.clickUsingJs(doneButton);
		util.waitForCasePage();
	}

	// Created by Nimesh to capture CaseNumber From Toast Message
	public void getCaseNumberFromToastMessage() {
		String ToastMessage = driver.findElement(By.xpath("//*[@data-aura-class='forceToastMessage']")).getText();
		String CaseNumber = StringUtils.substringBetween(ToastMessage, "Case ", " was");
		String CaseNUMBER = CaseNumber.replace('"', ' ');
		pageProps.setProperty("CaseNumber", CaseNUMBER);
	}

	// Created by Vinay to Upload File
	public void uploadFile(String path) {
		System.out.println("Click on Upload File....");
		util.scrollIntoElement(By.xpath("(//a[@title='Upload Files'])"));
		QAFWebElement uploadFileBtn = new QAFExtendedWebElement(
				By.xpath("(//li[contains(@class,'slds-button slds-button--neutral')])[last()]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", uploadFileBtn);
		js.executeScript("arguments[0].dispatchEvent(new MouseEvent('dblclick', { bubbles: true }));", uploadFileBtn);
		util.clickUsingJs(By.xpath("(//li[contains(@class,'slds-button slds-button--neutral')])[last()]"));
		util.waitFor(3);
		driver.findElement(By.xpath("(//li[contains(@class,'slds-button slds-button--neutral')])[last()]")).click();
//		util.switchtoFrameAndClick(By.xpath("(//li[contains(@class,'slds-button slds-button--neutral')])[last()]"));

		Robot rb;
		try {
			rb = new Robot();
			rb.delay(3000);
			// keep file path in the clipboard
			StringSelection ss = new StringSelection(path);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

			// CTRL+V
			rb.keyPress(KeyEvent.VK_CONTROL); // Press on CTRL key
			rb.keyPress(KeyEvent.VK_V); // Press on V key

			rb.keyRelease(KeyEvent.VK_CONTROL);
			rb.keyRelease(KeyEvent.VK_V);

			// ENTER
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		util.waitFor(By.xpath("//h2[text()='Upload Files']"), 10, true);
		Reporter.logWithScreenShot("File is Uploaded");
		util.clickUsingJs(By.xpath("//button/span[.='Done']"));
	}

	// Created by Vinay to Adjust Credit and Debit Amounts
	public void adjustCreditandDebitAmounts(Map<String, String> data) {
		util.scrollIntoElement(By.xpath("(//span[.='Revenue and Adjustment Information'])"));
		util.clickUsingJs(By.xpath("//button[@title='Edit Case Total Debit  Amount']"));
		util.waitFor(5);
		driver.findElement(By.xpath("(//label[text()='Case Total Debit  Amount']/following::input)[1]")).clear();
		driver.findElement(By.xpath("(//label[text()='Case Total Debit  Amount']/following::input)[1]"))
				.sendKeys(data.get("DebitAmount"));
		util.waitFor(10);
		driver.findElement(By.xpath("(//label[text()='Case Total Credit  Amount']/following::input)[1]")).clear();
		driver.findElement(By.xpath("(//label[text()='Case Total Credit  Amount']/following::input)[1]"))
				.sendKeys(data.get("CreditAmount"));
		util.waitFor(5);
		driver.findElement(By.xpath("(//label[text()='Case Total Credit  Amount'])")).click();
		util.waitFor(5);
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
		util.waitFor(By.xpath("//button[text()='Save']"), 40, false);
	}

	
	
	// Created by Vidya for Aftersales CaseManagement Bulk
	public void createNewCaseCaseManagementBulk(Map<String, String> data) {
		util.type("Subject", data);
		util.select(data, "Line of Business");
		util.select(data, "Type of Customer Request");
		util.select(data, "Type");
		util.select(data, "High Level Transaction Classification");
		util.selectAndClickCaseSuggestedValueShowAll(TransactionType, data.get("Transaction Type"));
		util.selectAndClickCaseSuggestedValueShowAll(TransactionSubType, data.get("Transaction Sub Type"));
		util.selectAndClickCaseSuggestedValueShowAll(TransactionReason, data.get("Transaction Reason"));
		util.select(data, "Transaction Entry");
		util.select(data, "Case Origin");
		util.type("Adjustment Amount", data);
		if ((Objects.nonNull(data.get("Contact Name")))) {
			util.click("(//label[.='Contact Name']/following::input)[1]");
			util.selectAndClickCaseSuggestedValueShowAll(By.xpath("(//label[.='Contact Name']/following::input)[1]"),
                    data.get("Contact Name"));
		}
		getSave().click();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		getCaseNumberFromToastMessage();
		getMessage().waitForNotVisible(200000);
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	// Created by Vidya for Aftersales CaseManagement Bulk file upload
	public void BulkFileUploadCaseManagement(String location) {
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		// Use the list of window handles to switch between windows
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.waitForBulkUploadPage();
		util.refreshSwitchToFrame();

		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(By.xpath("//a[.='Transaction']"));
		util.clickUsingJs(AddNewRec);
		util.waitFor(3);
		Select s = new Select(AccountField);
		s.selectByIndex(2);
		Select s1 = new Select(AdjustComponentLOVField);
		s1.selectByIndex(2);
		util.waitFor(3);
		util.clickUsingJs(CSVOption);
		driver.findElement(chooseFile).sendKeys(location);
		Reporter.logWithScreenShot("Choosed file..");
		util.clickUsingJs(ImportFileNextBtn);
		util.clickUsingJs(EditMappingFieldNextBtn);
		util.clickUsingJs(StartImport);
		getOkButton().waitForVisible(15000);
		util.clickUsingJs(OkButton);
		util.waitFor(5);
		util.refreshSwitchToFrame();
		util.waitFor(3);
//		util.clickUsingJs(By.xpath("//a[text()='View Result']"));
		String uploadresult = driver.findElement(By.xpath("//th[text()='Records Failed']//following::tr/td[9]"))
				.getText();
		if (!uploadresult.equals("0")) {
			Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
		} else {
			Reporter.log("Perform Eligibility check..");
			driver.navigate().to(CASEURL);
			util.waitForCasePage();
		}
	}

	public void UploadFileRelatedSection() {
		String path;
		QAFWebElement RelatedSection = new QAFExtendedWebElement("//span[@title='Files']/parent::a");
		List<WebElement> listOfSection = driver.findElements(By.xpath("//div[@class='container']/div"));
		System.out.println(listOfSection.size());
		path = System.getProperty("user.dir") + "\\resources\\testdata\\Temp.csv";
		JavascriptExecutor js = driver;
		for (WebElement element : listOfSection) {
			js.executeScript("arguments[0].scrollIntoView(true)", element);
			util.waitFor(1);
			if (RelatedSection.isPresent()) {
				driver.findElement(By.xpath("(//input[@type='file'])[1]")).sendKeys(path);
				util.waitFor(5);
				util.clickUsingJs(By.xpath("//button[.='Done']"));
				util.waitForGenericToastMessage();
				Reporter.logWithScreenShot("Uploaded the file");
				break;
			}
		}
		util.clickUsingJs(By.xpath("//a[.='More']"));
		util.clickUsingJs(By.xpath("(//a[.='Generate Certificate'])[last()]"));
		util.waitFor(5);
		util.waitFor(By.xpath("//button[.='Send Email']"), 30, true);
		util.clickUsingJs(By.xpath("//button[.='Send Email']"));
		util.waitFor(4);
		Reporter.logWithScreenShot("Email Sent");
	}

	public void UpdateAssetIdRemark(String AssetID) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(5);
		driver.findElement(By.xpath("(//label[text()='Asset ID']/following::input)[1]")).click();
		driver.findElement(By.xpath("(//label[text()='Asset ID']/following::input)[1]")).sendKeys(AssetID);
		driver.findElement(By.xpath("(//label[text()='Asset ID']/following::input)[1]")).click();
		util.clickUsingJs(
				By.xpath("(//lightning-primitive-icon/following::span[contains(text(),'Show All Results for')])[1]"));
		util.waitFor(By.xpath("(//h2[text()='Asset ID'])"), 20, true);
		util.clickUsingJs(By.xpath("(//h2[.='Assets']/following::tbody/tr/td/a)[1]"));
		util.type("Remarks");
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by Vidya for adding billing account and service ID
	public void AddBillingAccountAndServiceID(Map<String, String> data) {
		util.waitFor(By.xpath("//button[@name='Case.Add_Billing_Account']"), 30, true);
		util.clickUsingJs(By.xpath("//button[@name='Case.Add_Billing_Account']"));
		util.waitFor(7);
		QAFWebElement searchField = new QAFExtendedWebElement("//input[@placeholder='search...']");
		searchField.click();
		searchField.sendKeys(data.get("BillingAccountName"));
		searchField.sendKeys(Keys.ENTER);
		util.waitFor(3);
		driver.findElement(By.xpath("//div[@date-rec-name='" + data.get("BillingAccountName") + "']")).click();
		QAFWebElement NextBtn = new QAFExtendedWebElement("//button[text()='Next']");
		NextBtn.click();
		util.waitFor(5);
		searchField.click();
		searchField.sendKeys(data.get("ServiceID"));
		searchField.sendKeys(Keys.ENTER);
		util.waitFor(3);
		util.clickUsingJs(By.xpath(
				"//div[@class='slds-media slds-listbox__option slds-listbox__option_entity slds-listbox__option_has-meta']"));
		NextBtn.click();
		util.waitFor(5);
		NextBtn.click();
		util.waitFor(3);
		NextBtn.click();
		Reporter.logWithScreenShot("Billing account and service ID populated");
	}

	// Created by vidya to verify Bulk service request
	public void VerifyBulkServiceReq() {
		util.waitFor(5);
		util.scrollIntoElement(By.xpath("//li[@title='Bulk Service Request']//a"));
		util.waitFor(By.xpath("//li[@title='Bulk Service Request']//a"), 30, true);
		driver.findElement(By.xpath("//li[@title='Bulk Service Request']//a")).click();
		util.waitFor(3);
		QAFWebElement BulkServiceReq = new QAFExtendedWebElement(
				"//table//span[@title='Bulk Service Request Name']//following::tr[@class='slds-hint-parent']");
		BulkServiceReq.isPresent();
		Reporter.logWithScreenShot("Bulk Service Request is present");
	}

	// Created By Vidya for performing modify action from quote actions toolbar
	public void Modify() {
		util.waitFor(By.xpath("//h1[.='Prevalidation']"), 30, true);
		QAFWebElement Prevalidationtext = new QAFExtendedWebElement(
				"//div[@class='slds-form-element slds-form-container slds-text-block']//pre");
		String ValidationText = Prevalidationtext.getText();
		Reporter.logWithScreenShot(ValidationText);
		util.clickUsingJs(By.xpath("(//button[.='Next'])[last()]"));
	//	util.clickUsingJs(By.xpath("(//h2[.='Primary Services']/following::table[1]//span[.='Select Item 1'])[2]"));
		Reporter.logWithScreenShot("Modify action performed");
//		util.clickUsingJs(By.xpath("(//button[.='Next'])[last()]"));
		QAFWebElement quoteText = new QAFExtendedWebElement("//div[.='Quote']");
		quoteText.waitForVisible(40000);
		util.waitForQuotePage();
	}

	public void createNewCaseAfterSalesCaseManagementESoA(Map<String, String> data) {
		// util.selectAndClickSuggestedValue("Billing Account");
		util.selectAndClickCaseSuggestedValueShowAll("Billing Account");
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
		getMessage().waitForVisible(150000);
		String ToastMessage = driver.findElement(By.xpath("//*[@data-aura-class='forceToastMessage']")).getText();
		String CaseNumber = StringUtils.substringBetween(ToastMessage, "Case ", " was");
		String CaseNUMBER = CaseNumber.replace('"', ' ').trim();
		pageProps.setProperty("CaseNumber", CaseNUMBER);
		Reporter.logWithScreenShot(getMessage().getText());
		getMessage().waitForNotVisible(200000);
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void MoveTransactionStatusToSuccessful(String caseURL) {
		String TransactionSearchPage = caseURL.replaceFirst("/view", "/related/Transaction__r/view");
		driver.get(TransactionSearchPage);
		util.waitFor(By.xpath("(//h1[.='Transaction'])[1]"), 30, true);
		String TransactionUrl = driver.getCurrentUrl();
		String NoOfTransaction = "//tbody//tr//th[@data-label='Transaction Id']//a";
		List<WebElement> elements = driver.findElements(By.xpath(NoOfTransaction));
		int Transactioncount = elements.size();
		int Count = 1;
		System.out.println(Transactioncount);
		for (int i = 1; i <= Transactioncount; i++) {
			util.waitFor(By.xpath("(//h1[.='Transaction'])[1]"), 30, true);
			util.waitFor(6);
			util.clickUsingJs(
					By.xpath("(//tbody//tr//th[@data-label='Transaction Id']//a)[" + i + "]"));

			for (int j = 1; j <= Count; j++) {
				util.waitFor(By.xpath("(//div[.='Transaction'])[last()]"), 30, true);
				util.refreshPage();
				util.waitFor(By.xpath("(//div[.='Transaction'])[last()]"), 30, true);
				util.waitFor(5);
				String Status = driver.findElement(By.xpath(
						"//span[text()='Transaction Status']/parent::*/following-sibling::div//lightning-formatted-text"))
						.getText();
				if (Status.equalsIgnoreCase("Successful")) {
					break;
				}

				util.clickUsingJs(By.xpath("(//button[@title='Edit Transaction Status'])[1]"));
				util.clickUsingJs(By.xpath("//label[.='Transaction Status']/following::button[1]"));
				QAFExtendedWebElement DropDownelement = new QAFExtendedWebElement(
	                    "xpath=//lightning-base-combobox-item[@data-value='Successful']|//a[@title='Successful']");
	            util.clickUsingJs(DropDownelement);
	            QAFExtendedWebElement saveButton = new QAFExtendedWebElement(By.xpath("//button[@name='SaveEdit']"));
	            saveButton.click();
				util.waitFor(By.xpath("(//button[.='Save'])[last()]"), 20, false);

			}
			util.goToURL(TransactionUrl);
			util.waitFor(3);
		}
		Reporter.logWithScreenShot("Verified that trasaction status is changed to successful");
	}

	// Created by Saisree For R5 after sales
	public void createIPCNewCase(Map<String, String> data) {
		util.selectAndClickCaseSuggestedValueShowAll("Contact Name");
		util.selectAndClickCaseSuggestedValueShowAll("Reporter Name");
		util.waitFor(4);
		util.typeIntoTextArea("Additional Contact Details");
		util.select("Preferred Contact Method");
		util.select("Line of Business");
		util.waitFor(3);
		util.select("Type of Customer Request");
		if (data.get("Record Type").contains("ICT Complaint")) {
			util.select("Type of Customer Complaint");
		}
		util.select("Type");
		util.select("Pillar");
		util.select("Service");
		util.select("Site Name");
		util.selectAndClickCaseSuggestedValueShowAll("High Level Transaction Classification");
		util.select("Case Origin");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Reason");
		util.select("Billable");
		util.select("Impact");
		util.select("Urgency");
		util.select("SMAX Status");
		util.select("Current Assignment");
		if (data.get("Transaction Type").contains("Egress / Pull out")) {
			util.type("Circuit ID");
		}
		if (Objects.nonNull(data.get("Type of Request"))) {
			util.select("Type of Request");
		}
		if (data.get("Transaction Type").contains("Low Temperature")||data.get("Transaction Type").contains("Server Configuration and testing")) {
			driver.findElement(By.xpath(
					"//legend[.='Escalation Time']/following-sibling::div//input[@id=//label[normalize-space(text())='Date']/@for]"))
					.sendKeys(data.get("Escalation Time"));
		}
		driver.findElement(By.xpath(
				"//legend[.='Concern Received Time']/following-sibling::div//input[@id=//label[normalize-space(text())='Date']/@for]"))
				.sendKeys(data.get("Concern Received Time"));
		util.type("Subject");
		util.scrollIntoElement(
				By.xpath("//div[@aria-label='Description']//div[contains(@class,'slds-rich-text-area')]"));
		util.clickUsingJs(By.xpath("//div[@aria-label='Description']//div[contains(@class,'slds-rich-text-area')]"));
		driver.findElement(By.xpath("//div[@aria-label='Description']//div[contains(@class,'slds-rich-text-area')]"))
				.sendKeys(data.get("Description"));
		util.waitFor(5);
		getSave().click();
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
		CASENUMBER = getCaseNumberToastmsg().getText();
		setCASENUMBER(CASENUMBER);
		System.out.println(CASENUMBER);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	// Created by Saisree For R5 after sales
	public void createTaskinFeed(Map<String, String> data) {
		util.clickUsingJs(By.xpath("(//button[@title='More Tabs'])[2]"));
		util.clickUsingJs(By.xpath("//span[.='Feed']"));
		util.waitFor(5);
		util.clickUsingJs(By.xpath("(//span[.='New Task'])[1]"));
		util.waitFor(By.xpath("//h1[.='Alert Code Tagging Request']"), 30, true);
		driver.findElement("(//input[@id=//label[normalize-space(text())='Subject']/@for])[1]")
				.sendKeys(data.get("Task_Subject"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("(//span[@title='" + data.get("Task_Subject") + "'])[last()]"));
		util.waitFor(3);
		util.type("Due Date");
		util.clickUsingJs(By.xpath("(//span[.='Save']/parent::button)[last()]"));
		Reporter.logWithScreenShot("Task in Feed is Created");
	}

	public void CheckSMAXTerminationRequest() {
		util.clickUsingJs(By.xpath("//button[@title='Edit SMAX Termination Request Created']"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//input[@name='SMAX_Termination_Request_Created__c']"));
		util.select("Support Group Tier 2");
		util.waitFor(3);
		getSaveedit().click();
		Reporter.logWithScreenShot("Check SMAX Termination Request and update tier 2");

	}

	public void FillSolution(Map<String, String> data) {
		util.clickUsingJs(By.xpath("//button[@title='Edit Solution']"));
		util.waitFor(3);
		driver.findElement(By.xpath("//span[.='Solution']/parent::span/following-sibling::div//div[@role='textbox']"))
				.sendKeys(data.get("Solution"));
		util.select("Completion Code");
		util.waitFor(3);
		getSaveedit().click();
		Reporter.logWithScreenShot("Fill Solution and update completion code status");

	}

	// Created by Saisree For R5 after sales
	public void createR5AfterSalesNewCase(Map<String, String> data) {
		util.selectAndClickSuggestedValue("Contact Name");
		util.select("Line of Business");
		util.waitFor(3);
		util.select("Type of Customer Request");
		util.select("Type");
		util.selectAndClickSuggestedValue("High Level Transaction Classification");
		util.select("Case Origin");
		util.selectAndClickSuggestedValue("Transaction Type");
		util.selectAndClickSuggestedValue("Transaction Sub Type");
		util.selectAndClickSuggestedValue("Transaction Reason");
		util.type("Payment Date");
		util.type("Subject");
		util.waitFor(5);
		getSave().click();
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	// Created by Saisree For R4 after sales
	public void createAfterSalesNewCase() {
		util.select("Line of Business");
		util.waitFor(3);
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Case Origin");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Reason");
//                util.selectAndClickSuggestedValue(CASENUMBER);
		util.type("Subject");
		util.waitFor(5);
		getSave().click();
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	// Created by Saisree For R4 after sales
	public void createNewCasetypeTechnical(Map<String, String> data) {
		util.select("Line of Business");
		util.waitFor(3);
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Case Origin");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Reason");
//                util.selectAndClickSuggestedValue(CASENUMBER);
		util.type("Subject");
		util.waitFor(5);
		getSave().click();
		util.waitTillLoaderDissapear();
		util.waitFor(10);
		if (driver.findElement(By.xpath("//strong[.='Review the errors on this page.']")).isDisplayed()) {
			util.selectAndClickCaseSuggestedValueShowAll("Billing Account");
			util.type("Service ID");
			util.waitFor(5);
			util.clickUsingJs(By.xpath(
					"//lightning-primitive-icon/following::span[contains(text(),'" + data.get("Service ID") + "')]"));
			util.waitFor(5);
			util.clickUsingJs(By.xpath("//a[.='" + data.get("Plan") + "']"));
			util.waitFor(3);
			util.type("Customer Email Address");
			util.type("Customer Mobile Number");
			util.type("Customer Landline Number");
			getSave().click();
			util.waitTillLoaderDissapear();
		}
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void CheckNegativeScenarios() {
		util.ChangeStatus("Document Pending");
		Validator.verifyThat("Verify lead status not changed to Document Pending", util.waitForGenericToastMessage(),
				Matchers.containsString("some errors"));
		try {
			util.refreshPage();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath(
					"(//h2/span[@title='Quick Actions']/ancestor::header/parent::div/following-sibling::div[contains(@class,'body--inner')]//iframe[1])[last()]")));
			driver.switchTo().defaultContent();
			driver.switchTo().frame(driver.findElement(By.xpath(
					"(//h2/span[@title='Quick Actions']/ancestor::header/parent::div/following-sibling::div[contains(@class,'body--inner')]//iframe[1])[last()]")));
			util.jsLooseClick(By.xpath("//div[@id='action-container']/i[@class='icon icon-v-menu2']"));
			util.jsLooseClick(By.xpath("//div[@id='action-container']//*[text()='MODIFY']"));
		} catch (Exception e) {

		}
	}

	// Created by Saisree for Aftersales CaseManagement
	public void createNewCaseAfterSalesCaseManagement(Map<String, String> data) {
		util.selectAndClickCaseSuggestedValueShowAll("Billing Account");
		if ((Objects.nonNull(data.get("Contact Name")))) {
			util.click("(//label[.='Contact Name']/following::input)[1]");
			util.selectAndClickCaseSuggestedValueShowAll("Contact Name");
		}
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.select("Case Origin");
		if (data.get("High Level Transaction Classification").contains("Bill Adjustment")) {
			util.select("Transaction Entry");
			util.type("Adjustment Amount");
		}
		if (data.get("Transaction Type").contains("Increase/ Decrease in Credit Limit")) {
			util.type("Requested Credit Limit");
		}
		if ((Objects.nonNull(data.get("Modification Reason")))) {
			util.select("Modification Reason");
		}
		getSave().click();
		getMessage().waitForVisible(150000);
		CASENUMBER = getCaseNumberToastmsg().getText();
		setCASENUMBER(CASENUMBER);
		System.out.println(CASENUMBER);
		Reporter.logWithScreenShot(getMessage().getText());
		getMessage().waitForNotVisible(200000);
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	// Created by Saisree for Aftersales Alert code
	public void caseModificationforAlertcode(Map<String, String> data) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(5);
		util.clickUsingJs(AlertTagLevel);
		util.waitFor(3);
		util.clickUsingJs(By.xpath("(//span[text()='" + data.get("Alert Tag Level") + "'])[last()]"));
		util.clickUsingJs(AlertCodeType);
		util.waitFor(3);
		util.clickUsingJs(By.xpath("(//span[text()='" + data.get("Alert Code Type") + "'])[last()]"));
		util.clickUsingJs(AlertCodeAction);
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//span[@title='" + data.get("Alert Code Action") + "']"));
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		util.waitFor(10);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by Saisree for Aftersales Create Alert code request
	public void CreateAlertcoderequest(String caseURL, Map<String, String> data) {
		String Alertcoderequest = caseURL.replaceFirst("/view", "/related/Alert_Code_Tagging_Request__r/view");
		driver.get(Alertcoderequest);
		util.waitFor(By.xpath("//h1[.='Alert Code Tagging Request']"), 30, true);
		util.clickUsingJs(By.xpath("//button[.='New']"));
		util.waitFor(By.xpath("//h2[.='New Alert Code Tagging Request']"), 30, true);
		newcase.SelectRecordType(data.get("Record Type Alert"));
		util.selectAndClickCaseSuggestedValueShowAll("Alert Code");
//                util.enterText(driver.findElement(By.xpath("//input[@name='Expiration_Date__c']")),
//                        date.getDate(30, "MM/dd/yyyy"));
		util.clickUsingJs(By.xpath("//button[@name='SaveEdit']"));
		util.waitForGenericToastMessage();

		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	public void AddBillingAccountforCreate(Map<String, String> data) {
		util.refreshPage();
		util.waitAndClickUsingJavaScript("pldt.casepage.addbillingaccount.btn", "Add Billing Account");
		util.waitFor(By.xpath("//input[contains(@name,'Service_Address')]"), 60, true);
		if (data.get("Transaction Sub Type").contains("Request for Promo/ Program/ Campaign")) {
			String inputpromoinfo = "//input[@name='Promo_Campaign_Info']";
			util.enterText(By.xpath(inputpromoinfo), data.get("Transaction Sub Type"));
		}
		String inputboxserviceaddress = "//input[contains(@name,'Service_Address')]";
		util.enterText(By.xpath(inputboxserviceaddress), data.get("Service Address"));
		String inputboxbillingaddress = "//input[contains(@name,'Billing_Address')]";
		util.enterText(By.xpath(inputboxbillingaddress), data.get("Billing Address"));
		String inputbox = "(//label[text()='New Product']/following::input)[1]";
		util.waitFor(3);
		util.enterText(By.xpath(inputbox), data.get("New Product"));
		util.waitFor(5);
		String xpathproduct = pageProps.getString("pldt.casepage.autosuggestdropdown.lnk");
		util.waitAndClickUsingJavaScript(String.format(xpathproduct, data.get("New Product")), "New Product");
		if (data.get("Billing Account Number").contains("SKIP")) {
			if (driver.findElement(By.xpath("//span[@class='slds-checkbox_off']")).isDisplayed()) {
				util.waitAndClickUsingJavaScript("pldt.casepage.existingbillaccount.btn",
						"Existing Billing Acc button");
			}
			String inputboxbillaccount = "(//label[text()='Billing Account']/following::input)[1]";
			util.waitFor(8);
			String BillingAccountName = data.get("Billing_AccountName");
			util.enterText(By.xpath(inputboxbillaccount), BillingAccountName);
			util.waitFor(3);
			driver.findElement(By.xpath("(//label[text()='Billing Account']/following::input)[1]")).click();
			util.clickUsingJs(By.xpath("//div[@date-rec-name='" + data.get("Billing_AccountName") + "']"));
			util.waitFor(3);
		}
		String New_Bandwidth = "//input[contains(@name,'New_Bandwidth')]";
		util.enterText(By.xpath(New_Bandwidth), data.get("New Bandwidth"));
		QAFWebElement VanityNumberField = driver.findElement(By.xpath("//select[@name='Vanity_Number']"));
		Select select = new Select(VanityNumberField);
		select.selectByVisibleText(data.get("Vanity Number"));
		QAFWebElement NextBTN = driver.findElement(By.xpath("//button[contains(text(),'Next')]"));
		NextBTN.click();
		util.waitFor(5);
		NextBTN.click();
		util.waitFor(By.xpath("//button[contains(text(),'Next')]"), 20, false);
	}

	// Created By Nimesh
	public void caseModificationforTHS(String Asset, String AssetID, Map<String, String> data) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		util.clickUsingJs(EditButton);
		util.typeIntoTextArea("Asset ID");
		util.waitFor(8);
		util.clickUsingJs(driver.findElement(By.xpath("//span[text()='Show All Results for \"" + AssetID + "\"']")));
		util.waitFor(By.xpath("(//a[.='" + Asset + "'])[last()]"), 20, true);
		util.clickUsingJs(By.xpath("(//a[.='" + Asset + "'])[last()]"));
		util.waitFor(3);
		
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		util.waitFor(10);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by saisree for Bulk Service Request.
	public void OpenImportCase(Map<String, String> data, int i) {
		util.waitFor(5);
		System.out.println(i);
		QAFWebElement SelectBSR = new QAFExtendedWebElement(
				"(//span[text()='" + data.get("Subject") + "']/ancestor::td/preceding-sibling::th//a)[" + i + "]");
//		util.scrollIntoElement(SelectBSR);
		util.waitFor(SelectBSR, 20, true);
		util.waitFor(5);
		util.clickUsingJs(By.xpath(
				"(//span[text()='" + data.get("Subject") + "']/ancestor::td/preceding-sibling::th//a)[" + i + "]"));
		util.waitFor(5);
		Reporter.logWithScreenShot("Opened created BSR by BSR Name..");
		util.waitFor(20);
		util.refreshPage();
		util.waitFor(15);
		String Status = driver
				.findElement(By.xpath(
						"//span[text()='Import Status']/parent::div/following-sibling::div//lightning-formatted-text"))
				.getText();
		System.out.println(Status);
		util.waitFor(5);
		int x = 1;
		while (x <= 20) {
			String status = driver.findElement(By.xpath(
					"//span[text()='Import Status']/parent::div/following-sibling::div//lightning-formatted-text"))
					.getText();
			System.out.println(status);
			if (!status.equalsIgnoreCase("success")) {
				util.waitFor(30);
				util.refreshPage();
				util.waitFor(30);
			}
			x++;
		}

		util.clickUsingJs(
				By.xpath("//span[text()='Import Case Number']/parent::div/following-sibling::div//slot/span"));
		util.waitForCasePage();
	}

	public void CreateBillingAccountformCase(Map<String, String> data) {
		util.waitFor(By.xpath("((//span[.='Accounts'])[2]/ancestor::div/following-sibling::div//button)[1]"), 60, true);
		util.scrollIntoElement(By.xpath("((//span[.='Accounts'])[2]/ancestor::div/following-sibling::div//button)[1]"));
		util.waitFor(5);
		util.clickUsingJs(By.xpath("((//span[.='Accounts'])[2]/ancestor::div/following-sibling::div//button)[1]"));
		util.waitFor(8);
		util.clickUsingActions(By.xpath("(//div[.='New Billing'])[2]"));
		//util.clickUsingJs(By.xpath("(//div[.='New Billing'])[2]"));
		util.waitFor(5);
		util.waitFor(By.xpath("//h2[.='New Account: Billing']"), 60, true);
		driver.findElement(By.xpath("//input[@id=//label[span[normalize-space(text())='Account Name']]/@for]"))
				.sendKeys(data.get("BillingAccountUnique"));
		util.select("LoB (Line of Business)");
		util.selectAndClickSuggestedValue("Account Type Code");
		util.selectAndClickSuggestedValue("Bill Cycle");
		util.selectAndClickSuggestedValue("Smart Tax Profile");
		util.type("eSOA Notification Email ID");
		util.type("Assignee/ CI First Name");
		util.type("Assignee/ CI Middle Name");
		util.type("Assignee/ CI Last Name");
		util.type("Notify Email ID");
		util.type("Notify Mobile No");
		util.select("Billing State/Province");
		util.type("Billing Address Line 1");
		util.selectAndClickSuggestedValue("Billing City");
		util.waitFor(3);
		util.selectAndClickSuggestedValue("BARANGAY");
		util.waitFor(3);
		util.selectAndClickSuggestedValue("Billing Zip/Postal Code");
		util.waitFor(3);
		util.clickUsingJs(By.xpath("(//span[text()='Save'])[last()]"));
		util.waitForGenericToastMessage();
		Reporter.logWithScreenShot("Billing Account Created");
		util.waitFor(3);
		util.clickUsingJs(By.xpath("(//span[.='Accounts'])[2]"));
		util.waitFor(8);
		util.clickUsingJs(By.xpath("(//a[.='" + data.get("BillingAccountUnique") + "'])[last()]"));
		util.waitFor(By.xpath("//p[.='Account Record Type']"), 60, true);
		Reporter.logWithScreenShot("Billing Account Created :" + data.get("BillingAccountUnique"));
	}

	// Created by Vidya for adding billing account and service ID for VAS Activation
	public void AddBillingAccountAndServiceIDVASActivation(Map<String, String> data) {
		util.waitFor(By.xpath("//button[@name='Case.Add_Billing_Account']"), 30, true);
		util.clickUsingJs(By.xpath("//button[@name='Case.Add_Billing_Account']"));
		util.waitFor(7);
		QAFWebElement searchField = new QAFExtendedWebElement("//input[@placeholder='search...']");
		searchField.click();
		searchField.sendKeys(data.get("BillingAccountName"));
		searchField.sendKeys(Keys.ENTER);
		util.waitFor(3);
		driver.findElement(By.xpath("//div[@date-rec-name='" + data.get("BillingAccountName") + "']")).click();
		QAFWebElement NextBtn = new QAFExtendedWebElement("//button[text()='Next']");
		NextBtn.click();
		util.waitFor(5);
		searchField.click();
		searchField.sendKeys(data.get("ServiceID"));
		searchField.sendKeys(Keys.ENTER);
		util.waitFor(3);
		util.clickUsingJs(By.xpath(
				"//div[@class='slds-media slds-listbox__option slds-listbox__option_entity slds-listbox__option_has-meta']"));
		QAFWebElement PreferredDateofActivation = new QAFExtendedWebElement(
				"//input[@name='Preferred_Date_of_Activation']");
		QAFWebElement PreferredDateofDeactivation = new QAFExtendedWebElement(
				"//input[@name='Preferred_Date_of_Deactivation']");
		QAFWebElement VASFeaturetoActivate = new QAFExtendedWebElement("//input[@name='VAS_Feature_to_Activate']");
		QAFWebElement VASFeaturetoDeactivate = new QAFExtendedWebElement("//input[@name='VAS_Feature_to_Deactivate']");				
		if(data.get("Transaction Sub Type").equalsIgnoreCase("VAS/Feature Deactivation"))
		{
			util.clickUsingJs(PreferredDateofDeactivation);
			PreferredDateofDeactivation.sendKeys(data.get("Preferred_Date_of_Deactivation"));
			VASFeaturetoDeactivate.sendKeys(data.get("VAS_Feature_to_Deactivate"));
		}
		else {
			util.clickUsingJs(PreferredDateofActivation);
			PreferredDateofActivation.sendKeys(data.get("Preferred_Date_of_Activation"));
			VASFeaturetoActivate.sendKeys(data.get("VAS_Feature_to_Activate"));
		}		
		NextBtn.click();
		util.waitFor(5);
		NextBtn.click();
		util.waitFor(3);
			Reporter.logWithScreenShot("Billing account and service ID populated");
		}

}