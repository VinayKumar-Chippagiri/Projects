package com.pldt.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class QuoteListPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	WebUtilities util = new WebUtilities();
	private QAFWebElement UserNameSelect;
	private QAFWebElement dropdownValueSelect;
	private QAFWebElement	getSearchInput;
	private QAFWebElement showMore;


	@FindBy(locator="xpath=//a/span[.='Quotes']")
	private QAFWebElement Quotes;
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

	public String getQuoteLink(String QuoteName) {
//		driver.findElementByXPath("//input[@name='Account-search-input']").sendKeys(AccountName);
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys(QuoteName);
		util.waitFor(3);
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys(Keys.ENTER);
		return null;
}

	public void SwitchToAccount(String accountname) {
		util.clickUsingJs(By.xpath("(//lightning-primitive-icon)[1]"));
		getSearchInput = new QAFExtendedWebElement(By.xpath("//input[@placeholder='Search...']"));
		getSearchInput.sendKeys(accountname);
		showMore = new QAFExtendedWebElement(By.xpath("//lightning-formatted-rich-text[@class='primary slds-truncate query-line-clamp no-icon slds-rich-text-editor__output']"));
		showMore.click();
		Reporter.logWithScreenShot("Opened account..");
	}
}
