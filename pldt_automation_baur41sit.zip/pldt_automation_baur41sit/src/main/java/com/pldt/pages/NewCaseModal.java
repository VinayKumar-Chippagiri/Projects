package com.pldt.pages;

import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.pldt.elements.Button;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;
import com.qmetry.qaf.automation.util.Reporter;

public class NewCaseModal extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	Map<?, ?> map = null;
	TestDataBean bean = new TestDataBean();
	DateUtil date = new DateUtil();
	private static String CASENUMBER;
	// static final String caseSectionNewcase ="xpath=//div[text()='Change
	// Owner']/ancestor::ul/li/a/div[text()='New']";
	static final String SocialMediaRecordType = "xpath=//span[text()='Social Media Record Type']";
	static final String ICTInquiry = "xpath=//span[text()='ICT  Inquiry']";
	static final String ICTComplaint = "xpath=//span[text()='ICT Complaint']";
	static final String ICTServiceRequest = "xpath=//span[text()='ICT Service Request']";
	static final String PLDTComplaint = "xpath=//span[text()='PLDT Complaint']";
	static final String PLDTInquiry = "xpath=//span[text()='PLDT Inquiry']";
	static final String PLDTServiceRequest = "xpath=//span[text()='PLDT Service Request']";
	static final String SmartComplaint = "xpath=//span[text()='SMART Complaint']";
	static final String SmartInquiry = "xpath=//span[text()='SMART Inquiry']";
	static final String SmartServiceRequest = "xpath=//span[text()='SMART Service Request']";
	static final String Save = "xpath=//button[text()='Save']";
	static final String NEWCASE_NEXT = "xpath=//span[.='Next']";
	static final String MoveDocumentArrow = "xpath=//button[@title='Move selection to Chosen']";
	private static By accountName = By
			.xpath("//span[text()='Account Name']/following::div[1]//input[@placeholder='Search Accounts...']");
	private static By contactName = By
			.xpath("//label[text()='Contact Name']/following::div[1]//input[@placeholder='Search Contacts...']");
	private static By consigneeName = By
			.xpath("//span[text()='Consignee Name']/following::div[1]//input[@placeholder='Search Contacts...']");
	private static By billingAccountName = By
			.xpath("//span[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");
	private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	static final String toastmsg = "xpath=//span[@class='toastMessage slds-text-heading--small forceActionsText']";
	// @FindBy(locator = caseSectionNewcase)
//	private QAFWebElement CaseSectionNewcase;
	@FindBy(locator = SocialMediaRecordType)
	private QAFWebElement socialMediaRecordType;
	@FindBy(locator = ICTInquiry)
	private QAFWebElement iCTInquiry;
	@FindBy(locator = ICTComplaint)
	private QAFWebElement iCTComplaint;
	@FindBy(locator = ICTServiceRequest)
	private QAFWebElement iCTServiceRequest;
	@FindBy(locator = PLDTComplaint)
	private QAFWebElement pLDTComplaint;
	@FindBy(locator = PLDTInquiry)
	private QAFWebElement pLDTInquiry;
	@FindBy(locator = PLDTServiceRequest)
	private QAFWebElement pLDTServiceRequest;
	@FindBy(locator = SmartComplaint)
	private QAFWebElement smartComplaint;
	@FindBy(locator = SmartInquiry)
	private QAFWebElement smartInquiry;
	@FindBy(locator = SmartServiceRequest)
	private QAFWebElement smartServiceRequest;
	@FindBy(locator = Save)
	private QAFWebElement save;
	@FindBy(locator = NEWCASE_NEXT)
	private QAFWebElement newcasenext;
	@FindBy(locator = MoveDocumentArrow)
	private QAFWebElement moveDocumentArrow;
	@FindBy(locator = toastmsg)
	private QAFWebElement Message;

	private static By TransactionType = By.xpath("//label[text()='Transaction Type']/following::div[2]//input");
	private static By TransactionSubType = By.xpath("//label[text()='Transaction Sub Type']/following::div[2]//input");
	private static By TransactionReason = By.xpath("//label[text()='Transaction Reason']/following::div[2]//input");

	public static String getPldtcomplaint() {
		return PLDTComplaint;
	}

	public QAFWebElement getSocialMediaRecordType() {
		return socialMediaRecordType;
	}

	public QAFWebElement getiCTInquiry() {
		return iCTInquiry;
	}

	public QAFWebElement getiCTComplaint() {
		return iCTComplaint;
	}

	public QAFWebElement getiCTServiceRequest() {
		return iCTServiceRequest;
	}

	public QAFWebElement getpLDTComplaint() {
		return pLDTComplaint;
	}

	public QAFWebElement getpLDTInquiry() {
		return pLDTInquiry;
	}

	public QAFWebElement getpLDTServiceRequest() {
		return pLDTServiceRequest;
	}

	public QAFWebElement getSmartComplaint() {
		return smartComplaint;
	}

	public QAFWebElement getSmartInquiry() {
		return smartInquiry;
	}

	public QAFWebElement getSmartServiceRequest() {
		return smartServiceRequest;
	}

	public QAFWebElement getSave() {
		return save;
	}

	public QAFWebElement getNewcasenext() {
		return newcasenext;
	}

	public QAFWebElement getMessage() {
		return Message;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public void SelectRecordType() {
		getSmartServiceRequest().click();
		getNewcasenext().click();
		Reporter.log("Selected case record type as Smart Service Request..");
	}

	public void createNewCase(String AccountName, String ContactName, String ConsigneeName,
			String billingAccountNumber) {
		util.selectAndClickCaseSuggestedValue(accountName, AccountName);
		util.selectAndClickCaseSuggestedValue(contactName, ContactName);
		util.selectAndClickCaseSuggestedValue(consigneeName, ConsigneeName);
		util.selectAndClickCaseSuggestedValue(billingAccountName, billingAccountNumber);
		util.type("Subject");
		util.typeIntoTextArea("Description");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Transaction Type");
		util.select("Transaction Sub Type");
		util.select("Transaction Reason");
		util.select("Product");
		util.clickCheckbox("Manual Deactivation");
		util.select("Priority");
		util.select("Case Origin");
		util.select("Status");
		util.typeIntoTextArea("Transaction Description");
		util.type("Number of lines/services");
		util.type("Case Cancellation Reason");
		util.type("MIN for Port In");
		util.select("Current Provider");
		util.select("Recipient Provider");
		util.type("Other One time Fee");
		util.type("Waiver of Move fee");
		util.type("Adjustment Amount");
		util.select("Transaction Entry");
		util.type("Requested Credit Limit");
		click_availableDocuments();
		click_moveAvailableDocuments();
		util.type("Period");
		util.type("Preferred Billing Currency");
		util.type("Delivery Address");
		util.type("Preferred Add-on");
		util.type("Preferred Billing Currency");
		util.typeIntoTextArea("Required Asset and Contract Information");
		util.typeIntoTextArea("Technical Information");
		util.type("Invoice Number");
		util.type("Web Email");
		getSave().click();
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void click_availableDocuments() {
		util.scrollIntoElement(availableDocuments);
		util.moveToElement(availableDocuments);
		util.clickUsingActions(availableDocuments);
	}

	public void click_moveAvailableDocuments() {
		util.clickUsingJs(moveDocumentArrow);
	}

	private static By billingAccountname = By
			.xpath("//label[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");

	public void createRetentionNewCase(String billingAccountNumber, String transactionType, String transactionSubType) {
		util.selectAndClickCaseSuggestedValueShowAll(billingAccountname, billingAccountNumber);
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.selectAndClickCaseSuggestedValueShowAll(TransactionType, transactionType);
		util.waitFor(3);
		util.selectAndClickCaseSuggestedValueShowAll(TransactionSubType, transactionSubType);
		util.select("Case Origin");
		util.clickUsingJs(getSave());
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void SelectRecordType(String RecordType) {
		util.waitFor(5);
		driver.findElement(By.xpath("(//span[text()='" + RecordType + "'])[last()]")).click();
		new Button().click("Next");
		Reporter.log("Selected Case Record Type as " + RecordType + "..");
	}

	public void createAfterSalesNewCase() {
		util.select("Line of Business");
		util.waitFor(3);
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Reason");
		util.selectAndClickSuggestedValue(CASENUMBER);
		util.type("Subject");
		util.waitFor(5);
		getSave().click();
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public String getCaseErrorMessage() {
		String errorMessage = driver
				.findElement("//div[@class='genericNotification']/following::ul[@class='errorsList']/li").getText();
		System.out.println(errorMessage);
		return errorMessage;

	}

	public void createNew_PLDT_Service_Request_Case() {
		// util.selectAndClickSuggestedValue("Contact Name");
		util.selectAndClickCaseSuggestedValueShowAll("Contact Name");
		// util.selectAndClickSuggestedValue("Billing Account");
		util.selectAndClickCaseSuggestedValueShowAll("Billing Account");
		util.select("Line of Business");
		util.waitFor(3);
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.waitFor(5);
//		util.selectAndClickSuggestedValue("Transaction Type");
//		util.selectAndClickSuggestedValue("Transaction Sub Type");
//		util.selectAndClickSuggestedValue("Transaction Reason");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Reason");
		util.select("Case Origin");
		util.type("Subject");
		util.waitFor(5);
		// getSave().click();
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
//		String notify = driver.findElement(By.xpath("//*[@data-aura-class='forceToastMessage']")).getText();
//		String CaseNumber = StringUtils.substringBetween(notify, "Case ", " was");
//		System.out.println(CaseNumber);
//		pageProps.setProperty("CaseNumber", CaseNumber);
		String ToastMessage = driver.findElement(By.xpath("//*[@data-aura-class='forceToastMessage']")).getText();
		String CaseNumber = StringUtils.substringBetween(ToastMessage, "Case ", " was");
		String CaseNUMBER = CaseNumber.replace('"', ' ');
		pageProps.setProperty("CaseNumber", CaseNUMBER);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void CreatingNewCase(Map<String, String> data) {
		if (Objects.nonNull(data.get("BillingAccountName"))) {
			util.selectAndClickCaseSuggestedValueShowAll(billingAccountname,data.get("BillingAccountNumber"));
		}
		if (Objects.nonNull(data.get("Contact Name"))) {
			util.selectAndClickCaseSuggestedValueShowAll(contactName, data.get("Contact Name"));
		}
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.selectAndClickCaseSuggestedValueShowAll(TransactionType, data.get("Transaction Type"));
		util.waitFor(5);
		util.selectAndClickCaseSuggestedValueShowAll(TransactionSubType, data.get("Transaction Sub Type"));
		util.waitFor(5);
		if (Objects.nonNull(data.get("Transaction Reason"))) {
			util.selectAndClickCaseSuggestedValueShowAll(TransactionReason, data.get("Transaction Reason"));
			util.waitFor(5);
		}
		util.select("Case Origin");
//		click_availableDocuments();
//		click_moveAvailableDocuments();
		util.clickUsingJs(getSave());
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	// Created by Vinay For ICT Service Request
	public void createNewCaseForICT(Map<String, String> data) {
		bean.fillRandomData();
		util.waitFor(2);
		if ((Objects.nonNull(data.get("Contact Name")))) {
			util.click("(//label[.='Contact Name']/following::input)[1]");
			util.selectAndClickCaseSuggestedValueShowAll(By.xpath("(//label[.='Contact Name']/following::input)[1]"),
					data.get("Contact Name"));
		}
		util.waitFor(2);
		if ((Objects.nonNull(data.get("Reporter Name")))) {
			util.click("(//label[.='Reporter Name']/following::input)[1]");
			util.selectAndClickCaseSuggestedValueShowAll(By.xpath("(//label[.='Reporter Name']/following::input)[1]"),
					data.get("Contact Name"));
		}
		util.typeIntoTextArea("Additional Contact Details");
		util.select("Line of Business");
		util.waitFor(3);
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("Pillar");
		util.select("Service");
		util.select("Site Name");
		util.selectAndClickCaseSuggestedValueShowAll("High Level Transaction Classification");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Sub Type");
		util.selectAndClickCaseSuggestedValueShowAll("Transaction Reason");
		util.select("Billable");
		util.select("Impact");
		if ((Objects.nonNull(data.get("Urgency")))) {
			util.clickUsingJs(By.xpath("//label[.='Urgency']/following::button[contains(@id,'combobox-button')][1]"));
			util.waitFor(3);
			driver.findElement(By.xpath("(//lightning-base-combobox-item[@role='option']//span[@title='"
					+ data.get("Urgency") + "'])[last()]")).click();
		}
		util.select("SMAX Status");
		util.type("Subject");
		if ((Objects.nonNull(data.get("Description")))) {
			util.scrollIntoElement(
					By.xpath("//div[@aria-label='Description']//div[contains(@class,'slds-rich-text-area')]"));
			util.clickUsingJs(
					By.xpath("//div[@aria-label='Description']//div[contains(@class,'slds-rich-text-area')]"));
			driver.findElement(
					By.xpath("//div[@aria-label='Description']//div[contains(@class,'slds-rich-text-area')]"))
					.sendKeys(data.get("Description"));
		}
		if ((Objects.nonNull(data.get("Concern Received Time")))) {
			driver.findElement(By.xpath("(//legend[.='Concern Received Time']/following::input)[1]"))
					.sendKeys(data.get("Concern Received Time"));
			util.clickUsingActions(By.xpath("(//legend[.='Concern Received Time'])"));
		}
		util.type("Payment Date", date.getDate(365, "MM/dd/yyyy"));
		util.waitFor(5);
		getSave().click();
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void SelectNewCaseType(String RecordType) {
		util.waitFor(5);
		QAFWebElement recordtypebtn = new QAFExtendedWebElement(
				By.xpath("//div[@class='actionBody']//span[text()='" + RecordType + "']"));
		recordtypebtn.click();
		new Button().click("Next");
		Reporter.log("Selected Case Record Type as " + RecordType + "..");
	}

}
