package com.pldt.pages;

import java.util.Map;
import java.util.Objects;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class CaseListPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	static String billingAccountNumber = null;
	// public static By quickfilter = By.xpath("(//button[@title='Show quick
	// filters'])");
	static String caseListPage = null;
	public static By quickfilter = By.xpath("(//button[@title='Show quick filters'])[last()]");
	public static By newButton = By.xpath("(//button[text()='New'])[last()]");
	private static By consigneeName = By
			.xpath("(//label[text()='Consignee Name']/following::input[@placeholder='Search Contacts...'])");
	private static By billingAccountName = By
			.xpath("//label[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");
	private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	private static By moveDocumentArrow = By.xpath("//span[text()='Move selection to Chosen']");
	private static By save = By.xpath("//button[text()='Save']");
	public static By subjectInput = By.xpath("(//label[text()='Subject']/following::input[1])[last()]");
	public static By caseInput = By.xpath("(//label[text()='Case']/following::input[1])[last()]");
	static final String caseSectionNewcase = "xpath=(//button[.='New'])";
	static final String Listview = "xpath=//button[contains(@title,'Select a List View')]";
	//static final String caseSectionNewcase = "xpath=//div[text()='Change Owner']/ancestor::ul/li/a/div[text()='New']";
	static final String filterCaseSearch = "xpath=//input[@class='slds-input default input uiInput uiInputTextForAutocomplete uiInput--default uiInput--input']";
	static final String SearchInput = "xpath=//input[@placeholder='Search this list...']";
	private static By transactionType = By.xpath("(//label[text()='Transaction Type']/following::input)[1]");
	private static By transactionSubType = By.xpath("(//label[text()='Transaction Sub Type']/following::input)[1]");
	private static By transactionReason = By.xpath("(//label[text()='Transaction Reason']/following::input)[1]");
	public static By QuoteNameInput = By.xpath("(//label[text()='Quote Name']/following::input[1])[last()]");
	QAFExtendedWebElement QuickFiltersCaseRecordType = new QAFExtendedWebElement(
			By.xpath("//input[@name='Case-RecordType.Name']"));
	QAFExtendedWebElement QuickFilterstransactionTypeInput = new QAFExtendedWebElement(
			By.xpath("//input[@name='Case-Case_Transaction_Type__r.Name']"));
	QAFExtendedWebElement QuickFilterstransactionSubTypeInput = new QAFExtendedWebElement(
			By.xpath("//input[@name='Case-Case_Transaction_Sub_Type__r.Name']"));
	QAFExtendedWebElement QuickFiltersStatusOpenChk = new QAFExtendedWebElement(
			By.xpath("(//input[@name='Case-Status' and @value='Open']//following::span)[1]"));
	QAFExtendedWebElement QuickFiltersOwnerInput = new QAFExtendedWebElement(
			By.xpath("//input[@name='Case-Owner.Name']"));
	QAFExtendedWebElement QuickFiltersApplybtn = new QAFExtendedWebElement(By.xpath("//button[@title='Apply']"));
	QAFExtendedWebElement QuickFiltersSubject = new QAFExtendedWebElement(By.xpath("//input[@name='Case-Subject']"));

	@FindBy(locator = caseSectionNewcase)
	private QAFWebElement CaseSectionNewcase;
	@FindBy(locator = Listview)
	private QAFWebElement listview;
	@FindBy(locator = filterCaseSearch)
	private QAFWebElement FilterCaseSearchBox;
	@FindBy(locator = SearchInput)
	private QAFWebElement searchInput;

	public QAFWebElement getCaseSectionNewcase() {
		return CaseSectionNewcase;
	}

	public QAFWebElement getListview() {
		return listview;
	}

	public QAFWebElement getFilterCaseSearchBox() {
		return FilterCaseSearchBox;
	}

	public QAFWebElement getSearchInput() {
		return searchInput;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public void cleanUpCase(String Subject, String RMUser) {
		caseListPage = driver.getCurrentUrl();
		String subject = "(//a[@title='" + Subject + "'])";
		if (util.isElementDisplayed(By.xpath(subject))) {
//			 pages.getLoginpage().logoutCurrentUser();
			new LoginPage().logoutCurrentUser();
			driver.get(caseListPage);
			String showActions = "(//a[@title='" + Subject + "']/following::td/span/div/a[@role='button'])[1]";
			util.clickUsingJs(By.xpath("//a[@title='Delete']"));
			util.waitFor(By.xpath("//span[normalize-space()='Delete']"), 10, true);
			util.clickUsingJs(By.xpath("//span[normalize-space()='Delete']"));
			util.waitForGenericToastMessage();
//			 pages.getHomepage().switchToAnyUser(RMUser);
			new HomePage().switchToAnyUser(RMUser);
			driver.get(caseListPage);
		} else {
			util.clickUsingJs(newButton);
		}
	}

	public void createNewCaseFromAsset(Map<String, String> data) {
		util.clickUsingJs(newButton);
		util.waitFor(3);
		util.scrollIntoElement(By.xpath("(//*[text()='SMART Service Request'])[last()]"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("(//*[text()='SMART Service Request'])[last()]"));
		util.clickUsingJs(By.xpath("//span[.='Next']"));
		util.waitFor(5);
		if (data.get("Transaction Type").contains("SIM Replacement")) {
			util.selectAndClickCaseSuggestedValueShowAll(By.xpath("(//label[.='Consignee Name']/following::input)[1]"), data.get("Consignee Name"));
		}
		if ((Objects.nonNull(data.get("Contact Name")))) {
			util.click("(//label[.='Contact Name']/following::input)[1]");
//			util.selectAndClickCaseSuggestedValue(By.xpath("(//label[.='Contact Name']/following::input)[1]"), data.get("Contact Name"));
			util.selectAndClickCaseSuggestedValueShowAll(By.xpath("(//label[.='Contact Name']/following::input)[1]"),
					data.get("Contact Name"));
		}
		if ((Objects.nonNull(data.get("Billing Account")))) {
			util.selectAndClickCaseSuggestedValueShowAll("Billing Account");
		}else {
		util.selectAndClickCaseSuggestedValueShowAll(billingAccountName, pageProps.getString("billingAccountNumber"));
		}
		util.waitFor(3);
		util.type("Subject");
		util.waitFor(3);
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.waitFor(3);
//		util.selectAndClickCaseSuggestedValue(transactionType, data.get("Transaction Type"));
//		util.selectAndClickCaseSuggestedValue(transactionSubType, data.get("Transaction SubType"));
//		util.selectAndClickCaseSuggestedValue(transactionReason, data.get("Transaction Reason"));
		util.selectAndClickCaseSuggestedValueShowAll(transactionType, data.get("Transaction Type"));
		util.waitFor(3);
		util.selectAndClickCaseSuggestedValueShowAll(transactionSubType, data.get("Transaction SubType"));
//		util.selectAndClickCaseSuggestedValueShowAll(transactionReason, data.get("Transaction Reason"));
		util.select("Case Origin");
//		click_availableDocuments();
//		click_moveAvailableDocuments();
		Reporter.logWithScreenShot(util.clickUsingJs(save).toString());
		Reporter.logWithScreenShot(util.waitForGenericToastMessage());
		if (util.isElementDisplayed(By.xpath("//*[@data-aura-class='forceToastMessage']"))) {
			Reporter.log("Entered mandatory fields and case got created..");
			Reporter.logWithScreenShot("", MessageTypes.Pass);
		} else {
			Reporter.log("Not Entered Mandatory Fields ,So Case is not Created");
			Reporter.logWithScreenShot("", MessageTypes.Fail);
		}
	}

	public void click_availableDocuments() {
		util.scrollIntoElement(availableDocuments);
		util.moveToElement(availableDocuments);
		util.clickUsingActions(availableDocuments);
	}

	public void click_moveAvailableDocuments() {
		util.clickUsingJs(moveDocumentArrow);
	}

	public void selectCase(String subjectValue) {
		util.refreshPage();
		util.clickUsingJs(quickfilter);
		util.waitFor(subjectInput, 5, true);
		util.clickUsingJs(subjectInput);
		util.enterTextUsingJs(subjectInput, subjectValue);
		// util.enterKey();
		util.waitFor(5);
		util.clickUsingJs(By.xpath("//button[text()='Apply']"));
		util.waitFor(5);
		String Cat = "(//span[@title='" + subjectValue + "'])/ancestor::table//div//a";
		util.openLink(By.xpath(Cat));
		Reporter.log("Opened created case by filtering case name..");
		util.waitForCasePage();
	}

	public void clickNewCaseButton() {
		util.waitFor(10);
		getCaseSectionNewcase().click();
		Reporter.log("Clicked on New button..");
	}

	public void acceptCase(String CaseType, String CaseID) {
		getListview().click();
		util.waitFor(2);
		// driver.findElement(By.xpath("//input[@class='slds-input default input uiInput
		// uiInputTextForAutocomplete uiInput--default
		// uiInput--input']")).sendKeys("SMART Enterprise Support");
		getFilterCaseSearchBox().sendKeys(CaseType);
		util.waitFor(5);
		driver.findElement(By.xpath("//mark[text()='" + CaseType + "']")).click();
		util.waitTillLoaderDissapear();
		getSearchInput().click();
		util.waitFor(3);
		util.refreshPage();
		util.typeDataTo(getSearchInput(), CaseID);
		// getSearchInput().sendKeys(Subject);
		util.waitTillLoaderDissapear();
		// getSearchInput().sendKeys(Subject);
		util.waitFor(3);
		getSearchInput().sendKeys(Keys.ENTER);
		util.waitFor(8);
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		util.waitFor(3);
		util.waitFor(By.xpath("(//a[@title='" + CaseID + "'])[1]"), 20, true);
		util.waitFor(By.xpath("(//span[contains(@class,'checkbox--faux')])[last()]"), 10, true);
		util.clickUsingJs(By.xpath("(//span[contains(@class,'checkbox--faux')])[last()]"));
		driver.findElement(By.xpath("//div[@title='Accept']")).click();
		util.waitForGenericToastMessage();
		util.waitFor(3);
		getListview().click();
		util.waitFor(2);
		getFilterCaseSearchBox().sendKeys("My Cases");
		util.waitFor(8);
		driver.findElement(By.xpath("//mark[text()='My Cases']")).click();
		util.waitTillLoaderDissapear();
		util.waitFor(3);
		util.typeDataTo(getSearchInput(), CaseID);
		// getSearchInput().sendKeys(Subject);
		util.waitTillLoaderDissapear();
		// getSearchInput().sendKeys(Subject);
		util.waitFor(3);
		getSearchInput().sendKeys(Keys.ENTER);
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		util.waitFor(3);
		String Case = "//a[text()='" + CaseID + "']";
		util.clickUsingJs(By.xpath(Case));
	}

	// Created by Vinay to create Case using Arguments
	public void createNewCaseFromAsset_selectArguments(Map<String, String> data) {
		util.clickUsingJs(newButton);
		util.clickUsingJs(By.xpath("//*[text()='SMART Service Request']"));
		util.clickUsingJs(By.xpath("//span[.='Next']"));
//		util.selectAndClickCaseSuggestedValue(billingAccountName, pageProps.getString("billingAccountNumber"));
		util.selectAndClickCaseSuggestedValueShowAll(billingAccountName, pageProps.getString("billingAccountNumber"));
//		util.type("Subject", data.get("Subject2"));
		driver.findElement(By.xpath("((//label[text()='Subject'])[last()]/following::input)[1]"))
				.sendKeys(data.get("Subject2"));
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		String HLTC = data.get("High Level Transaction Classification2");
		driver.findElement(By.xpath("(//label[text()='High Level Transaction Classification']/following::button)[1]"))
				.click();
//		driver.findElement(By.xpath("//a[@title='" + HLTC + "']")).click();
		util.clickUsingJs(
				By.xpath("//lightning-base-combobox-item[@data-value='" + HLTC + "']|//a[@title='" + HLTC + "']"));
//		util.select("High Level Transaction Classification",data.get("High Level Transaction Classification2"));
		util.waitFor(2);
		util.selectAndClickCaseSuggestedValueShowAll(transactionType, data.get("Transaction Type2"));
		util.waitFor(2);
		util.selectAndClickCaseSuggestedValueShowAll(transactionSubType, data.get("Transaction SubType"));
		util.waitFor(2);
		util.selectAndClickCaseSuggestedValueShowAll(transactionReason, data.get("Transaction Reason"));
		util.waitFor(2);
		util.select("Case Origin");
//		click_availableDocuments();
//		click_moveAvailableDocuments();
		Reporter.logWithScreenShot(util.clickUsingJs(save).toString());
		Reporter.logWithScreenShot(util.waitForGenericToastMessage());
		if (util.isElementDisplayed(By.xpath("//*[@data-aura-class='forceToastMessage']"))) {
			Reporter.log("Entered mandatory fields and case got created..");
			Reporter.logWithScreenShot("", MessageTypes.Pass);
		} else {
			Reporter.log("Not Entered Mandatory Fields ,So Case is not Created");
			Reporter.logWithScreenShot("", MessageTypes.Fail);
		}
	}

	// Created by Nimesh to Select Case by passing Case Number
	public void selectCaseUsingCaseNo(String CaseNumber) {

		util.clickUsingJs(quickfilter);
		util.waitFor(caseInput, 5, true);
		util.clickUsingJs(caseInput);
		String Case = CaseNumber.trim();
		util.waitFor(5);
		util.enterTextUsingJs(caseInput, Case);
		util.clickUsingJs(By.xpath("//button[@title='Apply']"));
		util.waitFor(5);
		util.refreshPage();
		util.waitFor(10);
		String Cat = "((//span[text()=" + "'" + Case + "'" + "])[last()])/ancestor::a";
		util.clickUsingJs(By.xpath(Cat));
		Reporter.log("Opened created case by filtering case Number..");
		util.waitForCasePage();
	}

	public void FilterCaseUsingCaseNo(String CaseID) {
		getListview().click();
		util.waitFor(2);
		getFilterCaseSearchBox().sendKeys("SMART Enterprise Support");
		util.waitFor(5);
		driver.findElement(By.xpath("//mark[text()='SMART Enterprise Support']")).click();
		util.waitTillLoaderDissapear();
		getSearchInput().click();
		util.waitFor(3);
		util.refreshPage();
		util.typeDataTo(getSearchInput(), CaseID);
		util.waitTillLoaderDissapear();
		util.waitFor(3);
		getSearchInput().sendKeys(Keys.ENTER);
		util.waitFor(8);
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		util.waitFor(3);
		String Cat = "//a[text()=" + "'" + CaseID + "'" + "]";
		util.waitFor(By.xpath(Cat), 20, true);
		util.openLink(By.xpath(Cat));
		Reporter.log("Opened created case by filtering case Number..");
		util.waitForCasePage();
	}

	public void acceptCase(String CaseID, Map<String, String> data) {
		getListview().click();
		util.waitFor(2);
		// driver.findElement(By.xpath("//input[@class='slds-input default input uiInput
		// uiInputTextForAutocomplete uiInput--default
		// uiInput--input']")).sendKeys("SMART Enterprise Support");
		getFilterCaseSearchBox().sendKeys(data.get("CaseFilter"));
		util.waitFor(5);
		driver.findElement(By.xpath("//mark[text()='" + data.get("CaseFilter") + "']")).click();
		util.waitTillLoaderDissapear();
		getSearchInput().click();
		util.waitFor(3);
		util.refreshPage();
		util.typeDataTo(getSearchInput(), CaseID);
		// getSearchInput().sendKeys(Subject);
		util.waitTillLoaderDissapear();
		// getSearchInput().sendKeys(Subject);
		util.waitFor(3);
		getSearchInput().sendKeys(Keys.ENTER);
		util.waitFor(8);
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		util.waitFor(3);
		util.waitFor(By.xpath("(//a[@title='" + CaseID.trim() + "'])[1]"), 20, true);
		util.waitFor(By.xpath("(//span[contains(@class,'checkbox--faux')])[last()]"), 10, true);
		util.clickUsingJs(By.xpath("(//span[contains(@class,'checkbox--faux')])[last()]"));
		driver.findElement(By.xpath("//div[@title='Accept']")).click();
		util.waitForGenericToastMessage();
		util.waitFor(3);
		getListview().click();
		util.waitFor(2);
		getFilterCaseSearchBox().sendKeys("My Cases");
		util.waitFor(2);
		driver.findElement(By.xpath("//mark[text()='My Cases']")).click();
		util.waitTillLoaderDissapear();
		util.waitFor(3);
		util.typeDataTo(getSearchInput(), CaseID.trim());
		// getSearchInput().sendKeys(Subject);
		util.waitTillLoaderDissapear();
		// getSearchInput().sendKeys(Subject);
		util.waitFor(3);
		getSearchInput().sendKeys(Keys.ENTER);
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		util.waitFor(3);
		String Case = "//a[text()='" + CaseID.trim() + "']";
		util.clickUsingJs(By.xpath(Case));
	}

	public String FilterCaseOnAsset(String subjectValue) {
		util.clickUsingJs(quickfilter);
		util.waitFor(subjectInput, 5, true);
		util.clickUsingJs(subjectInput);
		util.enterTextUsingJs(subjectInput, subjectValue);
		util.enterKey();
		QAFExtendedWebElement CloseFiltersBtn = new QAFExtendedWebElement(By.xpath("//button[@title='Close Filters']"));
		CloseFiltersBtn.click();
		String CaseID = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a")).getText();
		return CaseID;
	}

	public String FilterCaseOnAccount(Map<String, String> data) {
		util.clickUsingJs(quickfilter);
		util.waitFor(5);
		if (QuickFiltersCaseRecordType.isPresent() && QuickFiltersCaseRecordType.isDisplayed()) {
			QuickFiltersCaseRecordType.clear();
			QuickFiltersCaseRecordType.sendKeys(data.get("Record_Type"));
			util.waitFor(2);
		}
		if (QuickFilterstransactionTypeInput.isPresent() && QuickFilterstransactionTypeInput.isDisplayed()) {
			QuickFilterstransactionTypeInput.clear();
			QuickFilterstransactionTypeInput.sendKeys(data.get("Transaction Type"));
			util.waitFor(2);
		}
		if (QuickFilterstransactionSubTypeInput.isPresent() && QuickFilterstransactionSubTypeInput.isDisplayed()) {
			QuickFilterstransactionSubTypeInput.clear();
			QuickFilterstransactionSubTypeInput.sendKeys(data.get("Transaction Sub Type"));
			util.waitFor(2);
		}
		QuickFiltersStatusOpenChk.click();
		util.waitFor(2);
		if (QuickFiltersSubject.isPresent() && QuickFiltersSubject.isDisplayed()) {
			QuickFiltersSubject.clear();
			QuickFiltersSubject.sendKeys(data.get("Subject"));
			util.waitFor(2);
		}
		QuickFiltersOwnerInput.clear();
		QuickFiltersOwnerInput.sendKeys(ConfigurationManager.getBundle().getPropertyValue("Owner"));
		util.waitFor(2);
		QuickFiltersApplybtn.click();
		util.waitFor(5);
		QAFExtendedWebElement CloseFiltersBtn = new QAFExtendedWebElement(By.xpath("//button[@title='Close Filters']"));
		CloseFiltersBtn.click();
		util.waitFor(4);
		util.refreshPage();
		util.waitFor(10);
		String CaseID = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a//span")).getText();
		return CaseID;
	}

	public String FilterQuote(String subjectValue) {
		util.clickUsingJs(quickfilter);
		util.waitFor(QuoteNameInput, 5, true);
		util.clickUsingJs(QuoteNameInput);
		util.enterTextUsingJs(QuoteNameInput, subjectValue);
		util.enterKey();
		QAFExtendedWebElement CloseFiltersBtn = new QAFExtendedWebElement(By.xpath("//button[@title='Close Filters']"));
		CloseFiltersBtn.click();
		String QuoteName = new QAFExtendedWebElement(By.xpath("(//tbody//tr/th//a)[last()]")).getText();
		return QuoteName;
	}
	// Created By nimesh for Finding the case 
	public void SearchCaseUsingCaseNo(String CaseType, String CaseID) {
		getListview().click();
		util.waitFor(2);
		getFilterCaseSearchBox().sendKeys(CaseType);
		util.waitFor(5);
		driver.findElement(By.xpath("//mark[text()='" + CaseType + "']")).click();
		util.waitTillLoaderDissapear();
		getSearchInput().click();
		util.waitFor(3);
		util.refreshPage();
		util.typeDataTo(getSearchInput(), CaseID);
		util.waitTillLoaderDissapear();
		// getSearchInput().sendKeys(Subject);
		util.waitFor(3);
		getSearchInput().sendKeys(Keys.ENTER);
		util.waitFor(8);
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		util.waitFor(3);
		util.waitFor(By.xpath("(//a[@title='" + CaseID + "'])[1]"), 20, true);
		// util.waitTillLoaderDissapear();
		String Case = "//a[text()='" + CaseID + "']";
		util.clickUsingJs(By.xpath(Case));
	}

	
}
