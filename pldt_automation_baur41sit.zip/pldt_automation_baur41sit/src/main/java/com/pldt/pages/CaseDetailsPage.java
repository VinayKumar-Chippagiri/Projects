package com.pldt.pages;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.TestDataBean;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.report.Report;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
import com.pldt.elements.*;

public class CaseDetailsPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	TestDataBean bean = new TestDataBean();
	DateUtil date = new DateUtil();
	AppCommons app = new AppCommons();
	public static By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	public static By assetID = By.xpath("//span[.='Asset ID']/following::div[1]");
	public static By MINNumber = By.xpath("//span[.='MIN Number']/following::div[1]");
	public static By transactionStatus = By.xpath("//span[.='Transaction Status']/following::div[1]");
	public static By markCurrentStatus = By.xpath("//span[text()='Mark as Current Status']");
	private static By changeOwnerEdit = By.xpath("//button[@title='Change Owner']");
	private static By searchUser = By.xpath("//input[@placeholder='Search Users...']");
	private static By changeOwnerButton = By.xpath("//button[@name='change owner']");
	private static By simReplacementFee = By.xpath("//span[.='SIM Replacement Fee']/following::div[1]");
	private static By transactionAsset = By.xpath("(//span[text()='Transaction Asset'])[1]/following-sibling::span");
	private static By relatedSection = By.xpath("(//flexipage-record-home-scrollable-column)[3]");
	private static By doneButton = By.xpath("//p[.='Done']");
	private static By editButton = By.xpath("//button[text()='Edit'][@class='slds-button slds-button_brand']");
	private static By servicereq = By
			.xpath("(//label[text()='Services Requested']/following::button[@name='Services_Requested__c'])");
	private static By highLevelDisconnection = By.xpath(
			"(//label[text()='High Level Disconnection Reason']/following::button[@name='High_Level_Disconnection_Reason__c'])");
	private static By saveRecord = By.xpath("//button[@class='slds-button slds-button_brand'][@type='submit']");
	static final String PlanName = "xpath=//span[contains(text(),'Plan Name')]/parent::label/parent::div/input";
	static final String SelectPlanNextButton = "xpath=//*[text()='Next']";
	static final String transactionDetailsC = "xpath=//a[text()='Transaction Details']";
	static final String ViewRecord = "xpath=//button[@title='View Record']";
	static final String Showmoreactions = "xpath=//span[.='Show more actions']/ancestor::button";
	static final String documentsrequired = "xpath=//a[contains(@data-label,'Documents Required')]";
	static final String bulkservicerequest = "xpath=//a[contains(@data-label,'Bulk Service Request')]";
	@FindBy(locator = bulkservicerequest)
	private QAFWebElement BulkServiceRequest;
	@FindBy(locator = transactionDetailsC)
	private QAFWebElement TransactionDetails;
	@FindBy(locator = "//button[text()='Edit'][@class='slds-button slds-button_brand']")
	private QAFWebElement EditButton;
	@FindBy(locator = "//label[text()='Offer Migration Type']/following::div/div/button[@name='Offer_Migration_Type__c']")
	private QAFWebElement OfferMigrationType;
	@FindBy(locator = "//button[text()='Save Record']")
	private QAFWebElement SaveRecord;
	@FindBy(locator = PlanName)
	private QAFWebElement planName;
	@FindBy(locator = documentsrequired)
	private QAFWebElement DocumentsRequired;
	@FindBy(locator = SelectPlanNextButton)
	private QAFWebElement selectPlanNextButton;
	@FindBy(locator = ViewRecord)
	private QAFWebElement viewRecord;
	@FindBy(locator = Showmoreactions)
	private QAFWebElement ShowMoreactions;
	@FindBy(locator = "//button[@title='Move selection to Chosen']")
	private QAFWebElement moveDocumentArrow;
	@FindBy(locator = "//div[@class='vlc-control-wrapper ng-binding']//input[@name='loopname']")
	private QAFWebElement planname;
	// added by vidya
	@FindBy(locator = "//span[@title='Quotes']/parent::a/following::a[2]")
	private QAFWebElement quoteLink;
	@FindBy(locator = "//button[text()='Save']")
	private QAFWebElement SaveButton;
	@FindBy(locator = "//a[text()='Documents Required']")
	private QAFWebElement documentRequired;
	@FindBy(locator = "//span[text()='Available']/following-sibling::div/ul/li[1]")
	private QAFWebElement availableDocuments;
	private static By availableDocumentss = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");

	public QAFWebElement getPlanName() {
		return planName;
	}

	public QAFWebElement getSelectPlanNextButton() {
		return selectPlanNextButton;
	}

	public QAFWebElement getViewRecord() {
		return viewRecord;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public boolean verifyTransactionDetailsForChangeMIN(String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		System.out.println(util.getTextFromPage(transactionStatus));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			System.out.println("Transaction details are verified");
			return false;
		}
		System.out.println("Transaction details are not verified");
		return true;
	}

	public boolean verifyTransactionDetailsForSIMReplacement(String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		System.out.println(util.getTextFromPage(simReplacementFee));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)
				&& util.getTextFromPage(simReplacementFee).equals("0.00")) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public boolean verifyTransactionDetailsForChangeofDevice(String assetValue) {
		util.clickUsingJs(transactionDetails);
		util.waitFor(5);
		System.out.println(util.getTextFromPage(assetID));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)
				&& util.getTextFromPage(simReplacementFee).equals("0.00")) {
			check.add(true);
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public boolean verifyTransactionDetailsForSIMActivation(Map<String, String> data, String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (data.get("Case Origin").contains("Internal User")) {
			util.clickUsingJs(editButton);
			util.waitFor(By.xpath("//label[text()='ICCID']/following::input[@name='ICCID__c']"), 20, true);
			driver.findElement(By.xpath("//label[text()='ICCID']/following::input[@name='ICCID__c']"))
					.sendKeys(data.get("ICCID"));
			driver.findElement(By.xpath("//label[text()='MIN']/following::input[@name='MIN__c']"))
					.sendKeys(data.get("MINNumber"));
			util.clickUsingJs(saveRecord);
		}
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public boolean verifyTransactionDetailsForConnectionScenarios(String assetValue, String transactionReasonValue,
			String transactiontype, String caseOrigin) {
		util.clickUsingJs(transactionDetails);
		util.clickUsingJs(editButton);
		if (transactiontype.contains("Reconnection")) {
			if (!transactiontype.contains("Involuntary") && caseOrigin.contains("Internal User")) {
				util.clickUsingJs(servicereq);
				util.clickUsingJs(
						By.xpath("(//lightning-base-combobox-item[@data-value='" + transactionReasonValue + "'])"));
			}
		} else {
			if (caseOrigin.contains("Internal User")) {
				util.clickUsingJs(highLevelDisconnection);
				util.clickUsingJs(
						By.xpath("(//lightning-base-combobox-item[@data-value='" + transactionReasonValue + "'])"));
			}
		}
		util.clickUsingJs(saveRecord);
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		if (caseOrigin.contains("Internal User")) {
			check.add(util.isElementDisplayed(MINNumber));
		}
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public void transactionActionForConnectionScenarios(String transactionType) {
		try {
			System.out.println("Click on Disconnection..");
			util.refreshPage();
			if (transactionType.contains("Termination")) {
				util.clickOnActionToolBarButton("Quick Actions", "Disconnect");
			} else {
				if (transactionType.contains("Reconnection")) {
					util.clickOnActionToolBarButton("Quick Actions", "Resume");
				} else {
					if (transactionType.contains("Temporary"))
						util.clickOnActionToolBarButton("Quick Actions", "Suspend");
				}
			}
			util.waitForVlocityOmniScript();
//			util.refreshSwitchToFrame();
			util.waitFor(10);
			util.AttachFrame();
			util.clickUsingJs(doneButton);
			util.waitForCasePage();
		} catch (Exception e) {
		}
	}

	public void markCaseStatusToResolutionInprogress() {
		// markCaseStatus(resolutionInProg,"Resolution In Progress");
		util.clickUsingJs(By.xpath("(//a[@data-tab-name='Resolution In Progress'])[last()]"));
		util.clickUsingJs(markCurrentStatus);
		util.waitFor(3);
		util.waitForGenericToastMessage();
	}

	public void verifyTransactionAsset() {
		util.refreshPage();
		util.waitForCasePage();
		util.waitFor(relatedSection, 10, true);
		JavascriptExecutor js = driver;
		js.executeScript("arguments[0].scroll(0,2500)", driver.findElement(relatedSection));
		util.waitFor(5);
		util.refreshPage();
		util.waitFor(5);
		if (!util.getTextFromPage(transactionAsset).equals("(0)")) {
			System.out.println("pass");
		} else {
			Reporter.log("Transaction Asset is not created", MessageTypes.Fail);
		}
		System.out.println("Transaction asset has been verified");
	}

	public void requestSIMReplacement() {
		util.clickOnActionToolBarButton("Quick Actions", "SIM Replacement");
		util.waitForVlocityOmniScript();
		util.waitFor(3);
		util.AttachFrame();
		util.clickUsingJs(doneButton);
		util.waitForCasePage();
	}

	public void requestSIMActivation() {
		util.clickOnActionToolBarButton("Quick Actions", "SIM Activation");
		util.waitForVlocityOmniScript();
		util.AttachFrame();
		util.clickUsingJs(doneButton);
		util.waitForCasePage();
	}

	public void changeOwner(String ownerNameValue) {
		util.clickUsingJs(changeOwnerEdit);
		util.waitFor(By.xpath("//input[@placeholder='Search Users...']"), 10, true);
		util.enterText(searchUser, ownerNameValue);
		util.clickUsingJs(By.xpath("//ul/li//div[@title='" + ownerNameValue + "']"));
		util.clickUsingJs(changeOwnerButton);
		Reporter.logWithScreenShot(util.waitForGenericToastMessage());
	}

	public boolean bulkUpload(Map<String, String> data) {
		String winHandleBefore = driver.getWindowHandle();
		String path;
		if (!data.get("Transaction Type").contains("SIM Activation")) {
			path = System.getProperty("user.dir") + "\\resources\\testdata\\BulkFile (1).csv";
		} else {
			path = System.getProperty("user.dir") + ".\\resources\\testdata\\Bulk_Transaction Asset_SIM Activation.csv";
		}
		util.waitForCasePage();
		util.waitFor(By.xpath("(//span[text()='Show more actions'])"), 10, true);
		util.waitFor(5);
		try {
			util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])"));
		} catch (Exception e) {
			util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[last()]"));
		}
		util.waitFor(By.xpath("(//span[text()='Upload Bulk File'])[last()]"), 10, true);
		util.clickUsingJs(By.xpath("(//span[text()='Upload Bulk File'])[last()]"));
		util.waitFor(By.xpath("(//span[text()='Upload Bulk File'])[last()]"), 10, false);
		util.waitFor(5);
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		// Use the list of window handles to switch between windows
		if ((tabs.size()) > 1) {
			driver.switchTo().window(tabs.get(tabs.size() - 1));
			util.waitForBulkUploadPage();
			util.refreshPage();
		} else {
			util.waitForBulkUploadPage();
			driver.switchTo().defaultContent();
			driver.switchTo().frame(driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[1]")));
		}
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(By.xpath("//a[.='Transaction Assets']"));
		util.clickUsingJs(By.xpath("//a[.='Add new records']"));
		util.clickUsingJs(By.xpath("//span[@class='csvType uiOutputText']"));
		driver.findElement(By.xpath("//input[@name='file']")).sendKeys(path);
		util.clickUsingJs(By.xpath("//a[.='Next']"));
		util.clickUsingJs(By.xpath("//a[.='Next']"));
		util.clickUsingJs(By.xpath("//a[.='Start Import']"));
		util.clickUsingJs(By.xpath("//a[.='OK']"));
		util.waitFor(30);
//	util.switchToLoginFrame();
//	util.waitFor(By.xpath("(//label[contains(text(),'Records Failed')]/following::td[1])"), 20, true);
//	String Records = util.getTextFromPage(By.xpath("(//label[contains(text(),'Records Failed')]/following::td[1])"));
//	if(Records.equalsIgnoreCase("0")) {
//		driver.close();
//		driver.switchTo().window(winHandleBefore);
//		return true;
//	}
//	else {
//		System.out.println("Records Failed");
//		return true;
//	}
		Reporter.logWithScreenShot("bulkUpload");
		if ((tabs.size()) > 1) {
			driver.close();
			driver.switchTo().window(winHandleBefore);
		}
		return true;
	}

	public void CloseCurrenttab() {
		String winHandleBefore = driver.getWindowHandle();
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		if ((tabs.size()) > 1) {
			driver.close();
			driver.switchTo().window(winHandleBefore);
		}
	}

	public void caseModification(Map<String, String> data, String MigrationType) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		if (!data.get("Case Origin").equalsIgnoreCase("Bulk")) {
			util.type("Remarks");
		}
		util.selectDropdownValue(OfferMigrationType, MigrationType);
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	public void requestRetention(String plan, Map<String, String> data) {
		if (data.get("Transaction Type").equalsIgnoreCase("Brand Migration")) {
			util.clickOnActionToolBarButton("Quick Actions", "Brand Migration");
		} else {
			util.clickOnActionToolBarButton("Quick Actions", "Retention");
		}
		util.refreshSwitchToFrame();
		if (!data.get("Case Origin").equalsIgnoreCase("Bulk")) {
			util.waitFor(planname, 10, true);
			planname.waitForEnabled(10000);
			planname.click();
			util.typeDataTo(planname, plan);
			QAFWebElement planname = new QAFExtendedWebElement("//ul//li//a[contains(text(),'" + plan + "')]");
			planname.click();
			Reporter.logWithScreenShot("Selected plan..");
			util.AttachFrame();
			util.vlocityNextButton();
			Reporter.logWithScreenShot("Click on Retention button and selected plan in vlocity page..");
		}
		QAFWebElement spinner = new QAFExtendedWebElement(
				"//div[@class='slds-spinner--brand slds-spinner slds-spinner--large']");
		spinner.waitForNotVisible(100000);
		util.AttachFrame();
		util.vlocityNextButton();
		util.waitForCasePage();
	}

	public void caseModification(String MigrationType, Map<String, String> data) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		// util.scrollIntoElement(EditButton);
		// EditButton.click();
		util.clickUsingJs(EditButton);
		// util.type("Remarks/Comments");
		if (!data.get("Case Origin").equalsIgnoreCase("Bulk")) {
			util.typeIntoTextArea("Remarks/Comments");
		}
		// util.typeIntoTextArea("Remarks/Comments");
		util.selectDropdownValue(OfferMigrationType, MigrationType);
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	public void requestChangePlan(String Plan, String Addons, Map<String, String> data) {
		util.clickOnActionToolBarButton("Quick Actions", "Change Of Plan");
		// util.clickUsingJs(doneButton);
		// util.waitForCasePage();
		util.waitFor(5); // new
		util.refreshSwitchToFrame();
		util.waitFor(2);
		util.AttachFrame(); // new
		if (!data.get("Case Origin").equalsIgnoreCase("Bulk")) {
			util.clickUsingJs(getPlanName());
			util.typeDataTo(getPlanName(), Plan);
			// util.clickUsingJs(By.xpath("//ul//li//*[text()='" + Plan + "']"));
			QAFWebElement planname = new QAFExtendedWebElement(
					By.xpath("//ul//li//a[contains(text(),'" + Plan + "')]"));
			util.waitTillLoaderDissapear();
			planname.click();
			util.AttachFrame();
			getSelectPlanNextButton().waitForEnabled(10);
			util.clickUsingJs(getSelectPlanNextButton());
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 60, false);
			util.waitFor(5);
			util.AttachFrame();
			util.vlocityNextButton(); /// NEW
			util.waitForCasePage();
			util.waitFor(3);
			navigateToQuoteFromCase();
		} else {
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 60, false);
			util.waitFor(5);
			util.AttachFrame();
			// util.vlocityNextButton(); /// NEW
			getSelectPlanNextButton().waitForEnabled(10);
			util.clickUsingJs(getSelectPlanNextButton());
			util.waitForCasePage();
			util.waitFor(3);
			navigateToQuoteFromCase();
		}

		if (Plan.contains("5G")) {
			QuoteDetailsPage quote = new QuoteDetailsPage();
			CartPage cart = new CartPage();
			quote.modifyProductsbyduplicates(data);
			util.waitFor(By.xpath("//title[text()='vlocity_cmt__HybridCPQ | Salesforce']"), 20, true);
			util.waitForCartPage();
			util.refreshSwitchToFrame();
			util.AttachFrame();
			if (!Plan.contains("BYOD")) {
				addAddonsto5GPlans(Addons);
			}
			util.waitFor(10);
			cart.SaveWorkingCart();
			util.waitFor(5);
			util.waitForQuotePage();
			util.waitFor(10);
			if (util.isElementDisplayed(
					By.xpath("(//span[text()='Quote Name'])[1]/following::div/span/span[text()='Working Cart']"))) {
				cart.WorkingCartConfigure();
			}
		}
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void addAddonsto5GPlans(String Addons) {
		util.clickUsingJs(By.xpath("(//button[@class='slds-button slds-button_icon-small'])[4]"));
		String[] split = Arrays.stream(Addons.split(",")).map(String::trim).toArray(String[]::new);
		for (String Addon : split) {
			System.out.println("Add Addons to 5G Plan | " + Addon);
			driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).sendKeys(Addon);
			String selectAddon = "//div[text()='" + Addon + "']";
			util.clickUsingJs(By.xpath(selectAddon));
			util.waitForCartPageToastMessage();
			util.waitFor(By.xpath("//div[@class='cpq-product-name-block cpq-item-child-product-name-wrapper']"), 10,
					true);
			// util.clickDropdownValue(selectAddon);
			driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).clear();
		}
	}

	public void featurecasemodification(String FeaturesAvailable) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		// util.scrollIntoElement(EditButton);
		// EditButton.click();
		util.clickUsingJs(EditButton);
		util.type("Remarks");
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		driver.findElement(By.xpath("//span[@title='" + FeaturesAvailable + "']")).click();
		util.clickUsingJs(moveDocumentArrow);
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
	}

	public void features(String features) {
		if (features.equalsIgnoreCase("Feature Activation")) {
			util.clickOnActionToolBarButton("Quick Actions", "Feature Activation");
//	try {
//		Thread.sleep(7000);
//	} catch (Exception e) {}
//	util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 50, false);
			util.refreshSwitchToFrame();
			util.AttachFrame();
//	util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 50, false);
			util.scrollTillVisible(By.xpath("//p[text()='Done']"));
			util.waitFor(5);
			util.clickUsingJs(By.xpath("//p[text()='Done']"));
		} else {
			util.clickOnActionToolBarButton("Quick Actions", "Feature Deactivation");
//		try {
//			Thread.sleep(7000);
//		} catch (Exception e) {}
			util.waitFor(5);
			util.refreshSwitchToFrame();
			util.AttachFrame();
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 50, false);
			util.scrollTillVisible(By.xpath("//p[text()='Done']"));
			util.clickUsingJs(By.xpath("//p[text()='Done']"));
		}
	}

	// created by Vidya
	public void navigateToQuoteFromCase() {
		util.waitFor(relatedSection, 10, true);
//		util.clickUsingJs(By.xpath("(//button[@title='More Tabs'])[last()]"));
//		util.clickUsingJs(By.xpath("//span[text()='Related']"));
		JavascriptExecutor js = driver;
		js.executeScript("arguments[0].scroll(0,6000)", driver.findElement(relatedSection));
		util.waitFor(10);
		util.waitFor(quoteLink, 10, true);
		quoteLink.isPresent();
		util.clickUsingJs(quoteLink);
		util.waitForQuotePage();
	}

	public void selectRequiredDocument() {
		util.waitFor(5);
		documentRequired.click();
		util.waitFor(By.xpath("(//button[text()='Edit'][@class='slds-button slds-button_brand'])[last()]"), 30, true);
		util.clickUsingJs(By.xpath("(//button[text()='Edit'][@class='slds-button slds-button_brand'])[last()]"));
		util.moveToElement(availableDocumentss);
		util.clickUsingJs(By.xpath("//div[@class='slds-dueling-list__options']//ul//li[last()]//div"));
		util.clickUsingJs(By.xpath("//button[@title='Move selection to Chosen']"));
		util.waitFor(SaveButton, 10, true);
		util.clickUsingJs(SaveButton);
		util.waitForGenericToastMessage();
	}

	// Created by Vinay to Perform Single Service Transfer
	public void performSingleServiceTransfer(Map<String, String> data, String NewAccount_No) {
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		util.clickUsingJs(EditButton);
		util.clickUsingJs(By.xpath("//span[.='AR Clearence Check']"));
		util.waitFor(2);
		if ((Objects.nonNull(data.get("Credit Check")))) {
			util.clickUsingJs(By.xpath("//span[.='Credit Check']"));
		}
		driver.findElement(By.xpath("(//label[.='New Billing Account']/following::input)[1]")).click();
		driver.findElement(By.xpath("(//label[.='New Billing Account']/following::input)[1]")).sendKeys(NewAccount_No);
		driver.findElement(By.xpath("(//label[.='New Billing Account']/following::input)[1]")).click();
		util.clickUsingJs(
				By.xpath("(//lightning-primitive-icon/following::span[contains(text(),'Show All Results for')])[1]"));
		util.waitFor(By.xpath("(//h2[text()='New Billing Account'])"), 20, true);
		if (NewAccount_No.matches("^[0-9]*$")) {
			util.clickUsingJs(By.xpath("(//span[.='" + NewAccount_No + "']/preceding::td[1]//a)[last()]"));
		} else {
			util.clickUsingJs(By.xpath("(//a[.='" + NewAccount_No + "'])[last()]"));
		}
		util.typeIntoTextArea("Remarks/Comments");
		if ((Objects.nonNull(data.get("PTF Waived Off")))) {
			util.clickUsingJs(By.xpath("//span[.='PTF Waived Off']"));
		}
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(By.xpath("//button[text()='Save Record']"));
		util.waitFor(SaveRecord, 30, false);

	}

	// Created by Vinay to Verify the Billing Account
	public void verifyBillingAccount(String NewBillingAccount) {
		String billingAccount = driver
				.findElement(By.xpath("(//div/span[.='Billing Account']/following::span[@id='window'])")).getText();
		Reporter.log("Billing Account" + billingAccount + "");
		Validator.verifyThat(billingAccount, Matchers.equalTo(NewBillingAccount));
	}

	// Created by Vinay to check the status of Transaction.
	public void verifyTransaction() {
		util.clickUsingJs(By.xpath("(//span[.='Transaction Id']/following::tbody/tr/th/span/a)[1]"));
		util.waitFor(By.xpath("(//span[.='Transaction Information'])"), 20, true);
		int count = 1;
		Boolean synced = false;
		Reporter.logWithScreenShot("Checking Transaction Status", MessageTypes.Info);
		while (count <= 30) {
			util.waitFor(30);
			util.refreshPage();
			waitForPageToLoad();
			util.waitFor(By.xpath("(//span[.='Transaction Status']/following::lightning-formatted-text)[1]"), 30, true);
			Reporter.logWithScreenShot("Transaction Status");
			if (driver.findElement(By.xpath("(//span[.='Transaction Status']/following::lightning-formatted-text)[1]"))
					.getText().equalsIgnoreCase("Successful")) {
				synced = true;
				break;
			}
			System.out.println(driver
					.findElement(By.xpath("(//span[.='Transaction Status']/following::lightning-formatted-text)[1]"))
					.getText());
			count++;
		}
	}

	// Created by Vinay to Verify Service End Date
	public void verfifyServiceEndDate(String serviceEndDate) {
		util.refreshPage();
		util.waitForPageToLoad();
		util.waitForAssetPage();
		String serviceDate = driver
				.findElement(By.xpath("(//span[.='Service End Date']/following::lightning-formatted-text)[1]"))
				.getText();
		Validator.verifyThat(serviceDate, Matchers.equalTo(serviceEndDate));
		util.waitFor(5);

	}

	// Created by Vinay to Verify Transaction Details for update service Contract
	public void verifyTransactionDetailsForUpdateServiceContract(String MINNumber, String serviceEndDate) {
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(5);
		driver.findElement(By.xpath("(//label[text()='Asset ID']/following::input)[1]")).click();
		driver.findElement(By.xpath("(//label[text()='Asset ID']/following::input)[1]")).sendKeys(MINNumber);
		driver.findElement(By.xpath("(//label[text()='Asset ID']/following::input)[1]")).click();
		util.clickUsingJs(
				By.xpath("(//lightning-primitive-icon/following::span[contains(text(),'Show All Results for')])[1]"));
		util.waitFor(By.xpath("(//h2[text()='Asset ID'])"), 20, true);
		if (MINNumber.matches("^[0-9]*$")) {
			util.clickUsingJs(By.xpath("(//h2[.='Assets']/following::tbody/tr/td/a)[1]"));
		} else {
			util.clickUsingJs(By.xpath("(//a[.='" + MINNumber + "'])[last()]"));
		}
		driver.findElement(By.xpath("(//label[text()='New Contract  End Date']/following::input)[1]"))
				.sendKeys(serviceEndDate);
		driver.findElement(By.xpath("(//label[text()='New Contract  End Date']/following::input)[1]"))
				.sendKeys(Keys.ENTER);
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		util.waitFor(SaveRecord, 30, false);
	}

	// Created by Vinay to add Billing Account in Case page
	public void addBillingAccount(Map<String, String> data) {
		util.clickUsingJs(By.xpath("//button[.='Add Billing Account']"));
		util.waitFor(By.xpath("(//h2[.='Add Billing Account'])"), 10, true);
		driver.findElement(By.xpath("(//label[text()='Billing Account']/following::input)"))
				.sendKeys(data.get("Billing Account"));
		driver.findElement(By.xpath("(//label[text()='Billing Account']/following::input)")).click();
		util.clickUsingJs(By.xpath("(//ul/li/div[contains(@date-rec-name,'" + data.get("Billing Account") + "')])"));
		util.clickUsingJs(By.xpath("(//button[.='Next'])[last()]"));
		util.waitFor(By.xpath("(//h2[.='Add Billing Account'])"), 10, true);
		util.waitFor(By.xpath("(//label[text()='Service ID']/following::input)"), 20, true);
		driver.findElement(By.xpath("(//label[text()='Service ID']/following::input)"))
				.sendKeys(data.get("Service ID"));
		driver.findElement(By.xpath("(//label[text()='Service ID']/following::input)")).click();
		util.clickUsingJs(By.xpath("(//span[.='" + data.get("assetName") + "']/parent::div)"));
		util.clickUsingJs(By.xpath("(//button[.='Next'])[last()]"));
		util.waitFor(By.xpath("(//h2[.='Add Billing Account'])"), 10, true);
		util.waitFor(By.xpath("(//span[text()='New Billing Frequency']"), 20, true);
		util.selectBy(driver.findElement(By.xpath("(//span[text()='New Billing Frequency']/following::select)")),
				data.get("NewBillingFrequency"));
		driver.findElement(By.xpath("(//span[text()='Requested Start Date']/following::input)[1]"))
				.sendKeys(data.get("RequestedStartDate"));
		driver.findElement(By.xpath("(//span[text()='Requested Start Date']/following::input)[1]"))
				.sendKeys(Keys.ENTER);
		util.clickUsingJs(By.xpath("(//button[.='Next'])[last()]"));
		util.waitFor(By.xpath("(//h2[.='Add Billing Account'])"), 10, true);
		util.clickUsingJs(By.xpath("(//button[.='Next'])[last()]"));
		util.waitForCasePage();
	}

	// Created by Vinay to verify TransactionDescription
	public void ValidateTransactionDescription(String TransactionDescription) {
		util.waitFor(5);
		util.scrollIntoElement(By.xpath("(//div/span[text()='Transaction Description'])"));
		String transactionDescription = driver
				.findElement(By
						.xpath("(//div/span[text()='Transaction Description']/following::lightning-formatted-text)[1]"))
				.getText();
		Validator.verifyThat(transactionDescription, Matchers.equalTo(TransactionDescription));
		util.waitFor(5);
	}

	// Created by Vinay to verify TransactionDescription
	public void ValidateDescription(String Description) {
		util.waitFor(5);
		util.scrollIntoElement(By.xpath("(//div/span[text()='Description'])"));
		String description = driver
				.findElement(
						By.xpath("((//div/span[text()='Description'])/following::lightning-formatted-rich-text)[1]"))
				.getText();
		Validator.verifyThat(description, Matchers.equalTo(Description));
		util.waitFor(5);
	}

	// Created by Vinay to add Notes
	public void AddingNotes() {
		bean.fillRandomData();
		String Subject = bean.getFirstName();
		String Desc = bean.getMiddleName();
		Button b = new Button();
		util.waitFor(5);
		b.clickUsingJavaScript("New");
		util.waitFor(By.xpath("(//div/input[@placeholder='Untitled Note'])"), 10, true);
		util.scrollIntoElement(By.xpath("//input[contains(@id,'input')]"));
//			driver.findElement(By.xpath("(//div/input[@placeholder='Untitled Note'])")).click();
		util.waitFor(5);
		try {
			driver.findElement(By.xpath("(//div/input[@placeholder='Untitled Note'])")).sendKeys(Subject);
		} catch (Exception e) {
			driver.findElement(By.xpath("//input[contains(@id,'input')]")).sendKeys(Subject);
		}
		driver.findElement(By.xpath("(//p/parent::div[@data-placeholder='Enter a note...'])")).sendKeys(Desc);
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//button[.='Done']"));
		util.waitFor(By.xpath("//button[.='Done']"), 20, false);
	}

	// Created by Vinay to add Billing Account in Case
	public void AddingBillingAccountinCase(String BillingAccount) {
		util.clickUsingJs(By.xpath("(//button[.='Edit Billing Account'])"));
		util.waitFor(By.xpath("(//label[.='Billing Account']/following::input)[1]"), 15, true);
		driver.findElement(By.xpath("(//label[.='Billing Account']/following::input)[1]")).sendKeys(BillingAccount);
		util.clickUsingJs(
				By.xpath("(//lightning-primitive-icon/following::span[contains(text(),'Show All Results for')])[1]"));
		util.waitFor(By.xpath("(//h2[text()='Accounts'])"), 20, true);
		if (BillingAccount.matches("^[0-9]*$")) {
			util.clickUsingJs(By.xpath("(//h2[.='Accounts']/following::tbody/tr/td/a)[1]"));
		} else {
			util.clickUsingJs(By
					.xpath("//a[.='" + BillingAccount + "']|(//span[.='" + BillingAccount + "']/ancestor::tr//a)[1]"));
		}
		util.waitFor(5);
//			util.selectAndClickSuggestedValue("Billing Account");
		util.clickUsingJs(SaveButton);
		util.waitFor(SaveButton, 20, false);
	}

	// Created by Vinay to Perform Single Billing Account Transfer
	public void performSingleBillingAccountTransfer(String NewAccount_No) {
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		util.clickUsingJs(EditButton);
		util.clickUsingJs(By.xpath("//span[.='AR Clearence Check']"));
		driver.findElement(By.xpath("(//label[text()='New Customer']/following::input)[1]")).click();
		driver.findElement(By.xpath("(//label[text()='New Customer']/following::input)[1]")).sendKeys(NewAccount_No);
		driver.findElement(By.xpath("(//label[text()='New Customer']/following::input)[1]")).click();
		util.clickUsingJs(
				By.xpath("(//lightning-primitive-icon/following::span[contains(text(),'Show All Results for')])[1]"));
		util.waitFor(By.xpath("(//h2[text()='New Customer'])"), 20, true);
		if (NewAccount_No.matches("^[0-9]*$")) {
			util.clickUsingJs(By.xpath("(//span[.='" + NewAccount_No + "']/preceding::td[1]//a)[last()]"));
		} else {
			util.clickUsingJs(By.xpath("(//th[@title='Account Name']/following::tr/td/a)"));
		}
		util.typeIntoTextArea("Remarks/Comments");
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		util.waitFor(SaveRecord, 30, false);

	}

	// Created by Vinay to verify Case Status
	public void verfifyCaseOwner(String owner) {
		util.refreshPage();
		util.waitForPageToLoad();
		util.waitForCasePage();
		util.scrollIntoElement(By.xpath("(//span[.='Case Information'])"));
		String caseOwner = driver.findElement(By.xpath("(//span[.='Case Owner']/following::slot/span)[1]")).getText();
		Validator.verifyThat(caseOwner, Matchers.equalTo(owner));
		util.waitFor(5);
	}

	// Created by Vinay to Update Support Group Tier 2 in SMAX Information
	public void updateSupportGroupTier2inSMAXInformation() {
		util.scrollIntoElement(By.xpath("//span[.='SMAX Information']"));
		util.clickUsingJs(By.xpath("//button[.='Edit Support Group Tier 2']"));
		util.select("Support Group Tier 2");
		util.clickUsingJs(SaveButton);
		util.waitForGenericToastMessage();
	}

	// Created by Vinay to Provide the Case cancellation reason
	public void casecancellationreason() {
		util.scrollIntoElement(By.xpath("//span[.='Case Cancellation Reason']"));
		util.clickUsingJs(By.xpath("//button[.='Edit Case Cancellation Reason']"));
		util.waitFor(By.xpath("(//label[.='Case Cancellation Reason']/following::input)[1]"), 15, true);
		util.type("Case Cancellation Reason");
		util.clickUsingActions(By.xpath("(//label[.='Case Cancellation Reason'])"));
		util.clickUsingJs(By.xpath("(//button[contains(@name,'Save')])"));
		util.waitFor(By.xpath("(//button[contains(@name,'Save')])"), 10, false);
	}

	// Created by Vinay to verify Case Status
	public void verfifyCaseStatus(String status) {
		util.refreshPage();
		util.waitForPageToLoad();
		util.waitForCasePage();
		String caseStatus = driver
				.findElement(By.xpath("(((//div/p[text()='Status'])[last()])/following::lightning-formatted-text)[1]"))
				.getText();
		Validator.verifyThat(caseStatus, Matchers.equalTo(status));
		util.waitFor(5);
	}

	// Created By Vidya for Changing Case Status
	public void ChangeCaseStatus(String CaseStatus) {
		util.clickUsingJs(By.xpath("(//a[@data-tab-name='" + CaseStatus + "'])[last()]"));
		util.clickUsingJs(markCurrentStatus);
		util.waitFor(3);
		util.waitForGenericToastMessage();
		Reporter.logWithScreenShot("Case Status changed");
	}

	// Created by Saisree to Add the BillingAccount for CaseMgmt in AfterSales(R4)
	public void AddBillingAccountforVASFeatureDeactivation(Map<String, String> data) {
		util.refreshPage();
		util.waitForCasePage();
		try {

			util.waitAndClickUsingJavaScript("pldt.casepage.addbillingaccount.btn", "Add Billing Account");
		} catch (Exception e) {

			util.clickUsingJs(ShowMoreactions);
			util.waitFor(3);
			util.clickUsingJs(By.xpath("//a[@name='Case.Add_Billing_Account']"));
		}
		util.waitFor(By.xpath("//div[contains(@class,'slds-form-element')]//input[contains(@placeholder,'search')]"),
				60, true);
		String inputbox = "//div[contains(@class,'slds-form-element')]//input[contains(@placeholder,'search')]";
		util.waitFor(8);
		util.enterText(By.xpath(inputbox), data.get("Billing Account"));
		util.waitFor(5);
		util.clickUsingJs(By.xpath(inputbox));
		driver.findElement(By.xpath(inputbox)).sendKeys(Keys.ENTER);
		String xpathBillingAccount = pageProps.getString("pldt.casepage.addbillingaccountname.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathBillingAccount, data.get("Billing Account")),
				"Billing Account Name");
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(8);
		util.enterText(By.xpath(inputbox), data.get("Service ID"));
		util.waitFor(5);
		driver.findElement(inputbox).sendKeys(Keys.ENTER);
		util.clickUsingJs(By.xpath(inputbox));
		String xpathasset = pageProps.getString("pldt.casepage.asset.lnk");
		util.waitAndClickUsingJavaScript(String.format(xpathasset, data.get("Plan")), "Plan");
		util.waitFor(5);
		String Date = "//input[contains(@name,'Preferred_Date_of_Deactivation')]";
		util.enterText(By.xpath(Date), data.get("Date"));
		String VAS = "//input[contains(@name,'VAS_Feature_to_Deactivate')]";
		util.enterText(By.xpath(VAS), data.get("VAS"));
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(8);
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(10);
		util.refreshPage();
		util.waitForCasePage();
	}

	// Created by Saisree to Verify Bulk Service Request in afterSales(R4)
	public void VerifyBulkServiceRequest() {
		util.waitFor(8);
		util.scrollIntoElement(driver.findElement(By.xpath("//span[text()='Transaction Status']")));
		util.waitAndClickUsingJavaScript(BulkServiceRequest, "Bulk Service Request");
		util.waitFor(5);
		String bulkrequest = driver
				.findElement(By.xpath("(((//a/span[.='Bulk Service Requests'])[last()])/following::span)[1]"))
				.getText();
		Validator.verifyThat("", bulkrequest, Matchers.containsString("1"));
		util.waitAndClickUsingJavaScript("pldt.casepage.bulkservicerequest.lnk", "Bulk Request View all");

	}

	// Created by Saisree to Verify Bulk Service Request in afterSales(R4)
	public void VerifyBulkServiceRequestFromRelated(String caseURL) {
		util.waitFor(5);
		String Bulkrequestpage = caseURL.replaceFirst("/view", "/related/Bulk_Service_Requests__r/view");
		driver.get(Bulkrequestpage);

//			util.scrollIntoElement(driver.findElement(By.xpath("//span[text()='Transaction Status']")));
//			util.waitAndClickUsingJavaScript(BulkServiceRequest, "Bulk Service Request");
		util.waitFor(5);
		QAFWebElement Status = new QAFExtendedWebElement(
				"xpath=(//span[.='Show Actions'])[last()]/ancestor::td/preceding-sibling::th//a");
		Validator.verifyTrue(Status.isPresent(), "Bulk service request not Created", "Bulk service request Created");
		String bulkrequestname = driver
				.findElement(By.xpath("(//span[.='Show Actions'])[last()]/ancestor::td/preceding-sibling::th//a"))
				.getText();
		Reporter.logWithScreenShot(bulkrequestname);
//			util.waitAndClickUsingJavaScript("pldt.casepage.bulkservicerequest.lnk", "Bulk Request View all");
	}

	// Created by Saisree to Add the Required Documents in AfterSales(R4)
	public void AddDocumentsRequired() {
		util.waitAndClickUsingJavaScript(DocumentsRequired, "Documents Required");
		util.waitFor(3);
		util.waitAndClickUsingJavaScript("pldt.casepage.edit.btn", "Edit");
		util.waitAndClickUsingJavaScript("pldt.casepage.document.lnk", "Document");
		util.waitAndClickUsingJavaScript("pldt.casepage.documentrightarrow.btn", "Document Right Arrow");
		Reporter.logWithScreenShot("DocumentsRequired");
		util.waitAndClickUsingJavaScript("pldt.casepage.save.btn", "Save");
		util.waitForGenericToastMessage();
		util.refreshPage();
//			util.ChangeStatus("Document Pending");
	}

	// Created by Vinay to verify Case Status
	public void verifyCaseStatus(String status) {
		util.refreshPage();
		util.waitForPageToLoad();
		util.waitForCasePage();
		String caseStatus = driver.findElement(By.xpath("(//div/p[.='Status']/following::lightning-formatted-text)[1]"))
				.getText();
		Validator.verifyThat(caseStatus, Matchers.equalTo(status));
		util.waitFor(5);
		util.scrollUp();
		Reporter.logWithScreenShot("Case Status");
	}

//Created By Nimesh
	public void verifyCaseOwner(String CaseOwner) {
		util.refreshPage();
		util.waitForPageToLoad();
		util.waitForCasePage();
		util.scrollTillVisible(By.xpath("//span[@id='window']"));
		String caseOwner = driver.findElement(By.xpath("//span[@id='window']")).getText();
		Validator.verifyThat(caseOwner, Matchers.equalTo(CaseOwner));
		util.waitFor(5);
		Reporter.logWithScreenShot("Case Owner");

	}

	// Created By Nimesh
	public void verifyTransactionDescription(String Description) {
		util.refreshPage();
		util.waitForPageToLoad();
		util.waitForCasePage();
		util.scrollTillVisible(By.xpath("//span[text()='Transaction Description']"));
		String TransactionDescription = driver.findElement(By.xpath(
				"(//span[text()='Transaction Description']/following::div/span[@class='test-id__field-value slds-form-element__static slds-grow word-break-ie11 is-read-only'])[1]"))
				.getText();
		Validator.verifyThat(TransactionDescription, Matchers.equalTo(Description));
		util.waitFor(5);
		Reporter.logWithScreenShot("Transaction Description");

	}

//created By nimesh 
	public void AddBillingAccounts_ModifyBillDispatch(Map<String, String> data) {
		util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[1]"));
		util.waitFor(By.xpath("(//span[text()='Add Billing Account'][@class='slds-truncate'])"), 30, true);
		util.clickUsingJs(By.xpath("(//span[text()='Add Billing Account'][@class='slds-truncate'])"));
		util.waitFor(5);
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).click();
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).sendKeys(data.get("Billing Account1"));
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).sendKeys(Keys.ENTER);
		util.waitFor(3);
		driver.findElement(By.xpath("//div[@date-rec-name='" + data.get("Billing Account1") + "']")).click();
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(5);
		util.waitFor(By.xpath("(//span[text()='New Bill Suppression']/following::select[@class='slds-select'])[1]"), 20,
				true);
		driver.findElement(
				By.xpath("(//span[text()='New Bill Suppression']/following::select[@class='slds-select'])[1]")).click();
		driver.findElement(By.xpath("//*[text()='" + data.get("New Bill Suppression1") + "']")).click();
		driver.findElement(
				By.xpath("(//span[text()='New Bill Suppression']/following::select[@class='slds-select'])[1]")).click();
		driver.findElement(
				By.xpath("(//span[text()='CBS Effective Bill Date']/following::select[@class='slds-select'])[1]"))
				.click();
		driver.findElement(By.xpath("//*[text()='" + data.get("CBS Effective Bill Date1") + "']")).click();
		driver.findElement(
				By.xpath("(//span[text()='CBS Effective Bill Date']/following::select[@class='slds-select'])[1]"))
				.click();
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(5);
		util.clickUsingJs(By.xpath("(//span[@class='slds-checkbox_faux'])[last()]"));
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(3);
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).click();
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).sendKeys(data.get("Billing Account2"));
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).sendKeys(Keys.ENTER);
		util.waitFor(3);
		driver.findElement(By.xpath("//div[@date-rec-name='" + data.get("Billing Account2") + "']")).click();
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(By.xpath("(//span[text()='New Bill Suppression']/following::select[@class='slds-select'])[1]"), 20,
				true);
		driver.findElement(
				By.xpath("(//span[text()='New Bill Suppression']/following::select[@class='slds-select'])[1]")).click();
		driver.findElement(By.xpath("//*[text()='" + data.get("New Bill Suppression2") + "']")).click();
		driver.findElement(
				By.xpath("(//span[text()='New Bill Suppression']/following::select[@class='slds-select'])[1]")).click();
		driver.findElement(
				By.xpath("(//span[text()='CBS Effective Bill Date']/following::select[@class='slds-select'])[1]"))
				.click();
		driver.findElement(By.xpath("//*[text()='" + data.get("CBS Effective Bill Date2") + "']")).click();
		driver.findElement(
				By.xpath("(//span[text()='CBS Effective Bill Date']/following::select[@class='slds-select'])[1]"))
				.click();
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(2);
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(2);
		util.clickUsingJs(By.xpath("//button[text()='Finish']"));
	}

	// Created By Nimesh
	public void verifyBulkServiceRequest() {
		util.waitForCasePage();
		String CaseURL = pageProps.getPropertyValue("CaseURL");
		String BulkServiceRequest = CaseURL.replaceFirst("/view", "/related/Bulk_Service_Requests__r/view");
		driver.get(BulkServiceRequest);
		util.waitFor(By.xpath("(//h1[@title='Bulk Service Requests'])[last()]"), 20, true);
		String NoOfBulkServiceRequest = "//th[@data-label='Bulk Service Request Name']";
		List<WebElement> elements = driver.findElements(By.xpath(NoOfBulkServiceRequest));
		int BulkServiceRequestCount = elements.size();
		System.out.println(BulkServiceRequestCount);
		pageProps.setProperty("BulkServiceRequest", BulkServiceRequestCount);
		Reporter.logWithScreenShot("Verified that there are "+BulkServiceRequestCount+" Bulk Service Request", MessageTypes.Info);
	}

	// Created By Nimesh
	public void updateBulkServiceRequest_ModifyBillDispatch(Map<String, String> data) {
		for (int i = 1; i <= 2; i++) {
			util.waitForCasePage();
			String CaseURL = pageProps.getPropertyValue("CaseURL");
			String BulkServiceRequest = CaseURL.replaceFirst("/view", "/related/Bulk_Service_Requests__r/view");
			driver.get(BulkServiceRequest);
			util.waitFor(By.xpath("(//h1[@title='Bulk Service Requests'])[last()]"), 20, true);
			util.clickUsingJs(By.xpath("(//th[@data-label='Bulk Service Request Name']//child::div[@class='slds-grid']/a)[" + i + "]"));
			util.waitFor(By.xpath("//div[text()='Bulk Service Request']"), 20, true);
			util.clickUsingJs(By.xpath("//button[@title='Edit Bill Suppression']"));
			util.waitFor(3);
			util.clickUsingJs(By.xpath(
					"(//button[@class=\"slds-combobox__input slds-input_faux slds-combobox__input-value\"])[2]"));
			util.clickUsingJs(By.xpath("//*[text()='" + data.get("New Bill Suppression" + i + "") + "']"));
			util.clickUsingJs(By.xpath("//button[text()='Save']"));
			util.waitFor(5);
			Reporter.logWithScreenShot("Updated BSR", MessageTypes.Info);
			util.goToURL(pageProps.getPropertyValue("CaseURL"));
		}
	}

	// Created By Nimesh
	public void validateCase() {
		util.refreshPage();
		util.waitForCasePage();
		util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[last()]"));
		util.waitFor(2);
		util.clickUsingJs(By.xpath("(//span[text()='Validate'][@class='slds-truncate'])"));
		util.waitFor(2);
		util.waitFor(By.xpath("//h2[text()='Validate']"), 20, true);
		util.clickUsingJs(By.xpath("(//span[@class='slds-checkbox_faux'])[last()]"));
		util.waitFor(2);
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(10);
		util.waitFor(By.xpath("//button[text()='Finish']"), 20, true);
		util.clickUsingJs(By.xpath("//button[text()='Finish']"));
		Reporter.logWithScreenShot("Validated", MessageTypes.Info);
		util.waitFor(By.xpath("//h2[text()='Validate']"), 20, false);
	}

	// Created By Nimesh
	public void AddBillingAccounts_ModifyBillingAdd(Map<String, String> data) {
		util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[1]"));
		util.waitFor(2);
		util.waitFor(By.xpath("(//span[text()='Add Billing Account'][@class='slds-truncate'])"), 30, true);
		util.clickUsingJs(By.xpath("(//span[text()='Add Billing Account'][@class='slds-truncate'])"));
		util.waitFor(5);
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).click();
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).sendKeys(data.get("Billing Account"));
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).sendKeys(Keys.ENTER);
		util.waitFor(3);
		driver.findElement(By.xpath("//div[@date-rec-name='" + data.get("Billing Account") + "']")).click();
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(5);
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).click();
		util.waitFor(3);
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).sendKeys(data.get("Service ID"));
		util.waitFor(5);
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).sendKeys(Keys.ENTER);
		util.clickUsingJs(By.xpath(("(//lightning-primitive-icon/following::span[contains(text(),'Show All Results for "
				+ "\"" + data.get("Service ID") + "\"" + "')])[last()]").replace("\\", "")));
		util.waitFor(5);
		driver.findElement(By.xpath("//a[@title='" + data.get("AssetName") + "']")).click();
		// util.selectAndClickCaseSuggestedValueShowAll("Service ID");
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(5);
		driver.findElement(By.xpath("//input[@name='New_Billing_Address_Line_1']")).click();
		driver.findElement(By.xpath("//input[@name='New_Billing_Address_Line_1']"))
				.sendKeys(data.get("Billing Address Line 1"));
		driver.findElement(By.xpath("//input[@name='New_Billing_Address_Line_2']")).click();
		driver.findElement(By.xpath("//input[@name='New_Billing_Address_Line_2']"))
				.sendKeys(data.get("Billing Address Line 2"));
		driver.findElement(By.xpath("//select[@name='New_Billing_Country']")).click();
		driver.findElement(By.xpath("//*[text()='" + data.get("New Billing Country") + "']")).click();
		driver.findElement(By.xpath("//select[@name='New_Billing_Country']")).click();
		driver.findElement(By.xpath("//select[@name='New_Billing_State_Province']")).click();
		driver.findElement(By.xpath("//*[text()='" + data.get("New Billing State Province") + "']")).click();
		driver.findElement(By.xpath("//select[@name='New_Billing_State_Province']")).click();
		util.waitFor(2);
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(By.xpath("//select[@name='New_Billing_City']"), 20, true);
		driver.findElement(By.xpath("//select[@name='New_Billing_City']")).click();
		driver.findElement(By.xpath("//*[text()='" + data.get("New Billing City") + "']")).click();
		driver.findElement(By.xpath("//select[@name='New_Billing_City']")).click();
		util.scrollIntoElement(By.xpath("//input[@name='New_Billing_Barangay']"));
		driver.findElement(By.xpath("//input[@name='New_Billing_Barangay']")).click();
		driver.findElement(By.xpath("//input[@name='New_Billing_Barangay']"))
				.sendKeys(data.get("New Billing Barangay"));
		driver.findElement(By.xpath("//input[@name='New_Billing_Zip_Postal_Code']")).click();
		driver.findElement(By.xpath("//input[@name='New_Billing_Zip_Postal_Code']"))
				.sendKeys(data.get("New Billing Zip Postal Code"));
		util.waitFor(2);
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(By.xpath("(//span[@class='slds-checkbox_faux'])[last()]"), 20, true);
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(5);
	}

	// Created By Nimesh
	public void updateBulkServiceRequest_ModifyBillingAdd(Map<String, String> data) {
		util.waitForCasePage();
		String CaseURL = pageProps.getPropertyValue("CaseURL");
		String BulkServiceRequest = CaseURL.replaceFirst("/view", "/related/Bulk_Service_Requests__r/view");
		driver.get(BulkServiceRequest);
		util.waitFor(By.xpath("(//h1[@title='Bulk Service Requests'])[last()]"), 20, true);
	//	util.clickUsingJs(By.xpath("(//td[@class='slds-cell-edit cellContainer']/span/a)[1]"));
		util.clickUsingJs(By.xpath("(//td[@data-label='Billing Account Number'])[1]//child::div[@class='slds-grid']/a"));
		//th/lightning-primitive-cell-factory/span/div/lightning-primitive-custom-cell/force-lookup/div/records-hoverable-link/div/a[@class="flex-wrap-ie11 slds-truncate"]
		util.waitFor(By.xpath("//div[text()='Account']"), 20, true);
		util.waitFor(5);
		util.scrollDown();
		util.scrollIntoElement(By.xpath("//button[@title='Edit Billing Country']"));
		util.clickUsingJs(By.xpath("//button[@title='Edit Billing Country']"));
		util.waitFor(2);
		util.select("Billing Country");
		util.scrollIntoElement(By.xpath("//span[text()='Billing Address']"));
		util.select("Billing State/Province");
		if (driver.findElement(By.xpath("(//button[@title='Clear Selection'])[2]")).isEnabled()) {
			util.clickUsingJs(By.xpath("(//button[@title='Clear Selection'])[2]"));
			util.waitFor(3);
		}
		util.scrollIntoElement(By.xpath("//label[text()='Bill Frequency']"));
		util.waitFor(5);
		util.selectAndClickSuggestedValue("Billing City");
		if (driver.findElement(By.xpath("(//button[@title='Clear Selection'])[3]")).isEnabled()) {
			util.clickUsingJs(By.xpath("(//button[@title='Clear Selection'])[3]"));
			util.waitFor(3);
		}
		util.scrollIntoElement(By.xpath("//label[text()='Bill Suppression']"));
		util.waitFor(5);
		util.selectAndClickSuggestedValue("BARANGAY");
		if (driver.findElement(By.xpath("(//button[@title='Clear Selection'])[4]")).isEnabled()) {
			util.clickUsingJs(By.xpath("(//button[@title='Clear Selection'])[4]"));
			util.waitFor(3);
		}
		util.scrollIntoElement(By.xpath("//label[text()='Corporate Individual']"));
		util.waitFor(5);
		util.selectAndClickSuggestedValue("Billing Zip/Postal Code");
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
		util.waitFor(5);
		Reporter.logWithScreenShot("Updated Billing Address", MessageTypes.Info);
		util.goToURL(pageProps.getPropertyValue("CaseURL"));
	}

	// Created By Nimesh
	public void AddBillingAccounts_CSA(Map<String, String> data) {
		util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[1]"));
		util.waitFor(By.xpath("(//span[text()='Add Billing Account'][@class='slds-truncate'])"), 30, true);
		util.clickUsingJs(By.xpath("(//span[text()='Add Billing Account'][@class='slds-truncate'])"));
		util.waitFor(5);
		util.waitFor(By.xpath("//h2[text()='Add Billing Account']"), 20, true);
		driver.findElement(By.xpath("//select[@name='Action']")).click();
		driver.findElement(By.xpath("//*[text()='" + data.get("Action") + "']")).click();
		util.waitFor(3);
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).click();
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).sendKeys(data.get("Billing Account Included"));
		util.waitFor(10);
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).click();
		util.waitFor(3);
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).sendKeys(Keys.ENTER);
		util.waitFor(6);
//		driver.findElement(By.xpath(("//lightning-primitive-icon/following::span[contains(text(),'" + "\""
//				+ data.get("Billing Account Included") + "\"" + "')]").replace("\\", "")));
		driver.findElement(By
				.xpath(("(//lightning-primitive-icon/following::span[contains(text(),'Show All Results for')])[last()]")
						.replace("\\", "")))
				.click();
		util.waitFor(By.xpath("(//a[@title='" + data.get("Billing Account Included") + "'])[last()]"), 20, true);
		driver.findElement(By.xpath("(//a[@title='" + data.get("Billing Account Included") + "'])[last()]")).click();
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(By.xpath("(//span[@class='slds-checkbox_faux'])[last()]"), 20, true);
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.clickUsingJs(By.xpath("//button[text()='Finish']"));
	}

	// created By Nimesh
	public void UpdateCSAInformation() {
		util.refreshPage();
		util.waitForCasePage();
		util.scrollIntoElement(By.xpath("(//span[text()='CSA Information'])[last()]"));
		util.clickUsingJs(By.xpath("//button[@title='Edit Bill Run Date']"));
		util.waitFor(2);
		util.select("Bill Run Date");
		Reporter.logWithScreenShot("Updated Bill Run Date");
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
		util.waitFor(5);
	}

	// Created By Nimesh
	public void AddBillingAccounts_RevenueAdjustment(Map<String, String> data) {
		util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[1]"));
		util.waitFor(5);
		util.waitFor(By.xpath("(//span[text()='Add Billing Account'][@class='slds-truncate'])"), 30, true);
		util.clickUsingJs(By.xpath("(//span[text()='Add Billing Account'][@class='slds-truncate'])"));
		util.waitFor(5);
		//  (//button[text()='Add Billing Account'][@name='Case.Add_Billing_Account'])
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).click();
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).sendKeys(data.get("Billing Account"));
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).sendKeys(Keys.ENTER);
		util.waitFor(10);
		driver.findElement(By.xpath("(//input[@type='text'])[last()]")).sendKeys(Keys.ENTER);
		util.waitFor(2);
		driver.findElement(By.xpath("//a[@title='" + data.get("Billing Account") + "']")).click();
		Reporter.logWithScreenShot("Billing Account");
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(5);
		driver.findElement(By.xpath("//select[@name='transactionEntry']")).click();
		driver.findElement(By.xpath("//*[text()='" + data.get("Transaction Entry") + "']")).click();
		driver.findElement(By.xpath("//select[@name='transactionEntry']")).click();

		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).click();
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).sendKeys(data.get("Service ID"));
		util.waitFor(5);
		driver.findElement(By.xpath("(//input[@type='search'])[last()]")).sendKeys(Keys.ENTER);
		util.waitFor(4);
		driver.findElement(By.xpath("//div[@role='option']")).click();
//		util.scrollIntoElement(By.xpath("//span[text()='"+data.get("Service ID Name")+"']"));
//		driver.findElement(By.xpath("//span[text()='"+data.get("Service ID Name")+"']")).click();
		util.waitFor(5);
		driver.findElement(By.xpath("//select[@name='billRunDate']")).click();
		driver.findElement(By.xpath("//*[text()='" + data.get("Bill Run Date") + "']")).click();
		driver.findElement(By.xpath("//input[@name='baseAmount']")).click();
		driver.findElement(By.xpath("//input[@name='baseAmount']")).clear();
		driver.findElement(By.xpath("//input[@name='baseAmount']")).sendKeys(data.get("BaseAmount"));
		driver.findElement(By.xpath("//input[@name='taxAmount']")).click();
		driver.findElement(By.xpath("//input[@name='taxAmount']")).clear();
		driver.findElement(By.xpath("//input[@name='taxAmount']")).sendKeys(data.get("TaxAmount"));
		Reporter.logWithScreenShot("Filled Necessary Details");
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(5);
		util.waitFor(By.xpath("(//span[@class='slds-checkbox_faux'])[last()]"), 20, true);
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(5);
	}

	// Created By Nimesh
	public void submitforApproval(Map<String, String> data) {
		util.waitForCasePage();
		util.clickUsingJs(By.xpath("//button[text()='Submit for Approval']"));
		util.waitFor(By.xpath("//h2[text()='Submit for Approval']"), 10, true);
		driver.findElement(By.xpath("//textarea[@role='textbox']")).click();
		driver.findElement(By.xpath("//textarea[@role='textbox']")).sendKeys(data.get("ApprovalComment"));
		Reporter.logWithScreenShot("Approval Comment");
		util.clickUsingJs(By.xpath("//span[text()='Submit']"));
		util.waitFor(By.xpath("//h2[text()='Submit for Approval']"), 20, false);
	}

	// Created By Nimesh
	public void checkCaseHistory() {
		util.waitForCasePage();
		String CaseURL = pageProps.getPropertyValue("CaseURL");
		String CaseHistory = CaseURL.replaceFirst("/view", "/related/Histories/view");
		driver.get(CaseHistory);
		util.waitFor(By.xpath("//h1[@title='Case History']"), 20, true);
		String LatestStatus = driver
				.findElement(By.xpath("(//th[@data-label='Date'])[1]/following::td[1]/lightning-primitive-cell-factory/span"))
				.getText();
		System.out.println(LatestStatus);
		Validator.verifyThat(LatestStatus, Matchers.equalTo("Record locked."));
		Reporter.logWithScreenShot("Case History");
	}

	// Created By Nimesh
	public void checkApprovalHistory() {
		util.waitFor(relatedSection, 10, true);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scroll(0,6000)", driver.findElement(relatedSection));
		util.waitFor(10);
		util.waitFor(By.xpath("//span[@title='Approval History']/parent::a/following::a[2]"), 10, true);
		util.clickUsingJs(By.xpath("//span[@title='Approval History']/parent::a/following::a[2]"));
		util.waitFor(By.xpath("//h1[@title='Approval History']"), 20, true);
		Reporter.logWithScreenShot("Approval History");
	}

	// Created By Nimesh
	public void rejectCase(Map<String, String> data) {
		util.waitFor(By.xpath("//span[@title='Items to Approve']"), 20, true);
		String CaseNumber = pageProps.getPropertyValue("CaseNumber");
		util.clickUsingJs(By.xpath("//a[text()='" + CaseNumber.trim() + "']"));
		util.waitFor(By.xpath("//div[text()='Approval Request']"), 20, true);
		util.clickUsingJs(By.xpath("//div[text()='Reject']"));
		util.waitFor(By.xpath("//h2[text()='Reject Case']"), 20, true);
		driver.findElement(By.xpath("//textarea[@role='textbox']")).sendKeys(data.get("Reject Comment"));
		Reporter.logWithScreenShot("Rejected Case Comment");
		util.clickUsingJs(By.xpath("//span[text()='Reject']"));
		util.waitFor(3);
		util.waitFor(By.xpath("//h2[text()='Reject Case']"), 20, false);
		Reporter.logWithScreenShot("Rejected Case");
	}

	public void ApproveCase(Map<String, String> data) {
		util.waitFor(By.xpath("//span[@title='Items to Approve']"), 20, true);
		String CaseNumber = pageProps.getPropertyValue("CaseNumber");
		util.clickUsingJs(By.xpath("//a[text()='" + CaseNumber.trim() + "']"));
		util.waitFor(By.xpath("//div[text()='Approval Request']"), 20, true);
		util.clickUsingJs(By.xpath("//div[text()='Approve']"));
		util.waitFor(By.xpath("//h2[text()='Approve Case']"), 20, true);
		driver.findElement(By.xpath("//textarea[@role='textbox']")).sendKeys(data.get("Approve Comment"));
		Reporter.logWithScreenShot("Approve Case Comment");
		util.clickUsingJs(By.xpath("//span[text()='Approve']"));
		util.waitFor(3);
		util.waitFor(By.xpath("//h2[text()='Approve Case']"), 20, false);
		Reporter.logWithScreenShot("Approved Case");
	}

//	public void verifyRevenueDetails(String Description) {
//		util.refreshPage();
//		util.waitForPageToLoad();
//		util.waitForCasePage();
//		util.scrollTillVisible(By.xpath("//span[text()='Revenue Details']"));
//		String TransactionDescription = driver.findElement(By.xpath("(//span[text()='Transaction Description']/following::div/span[@class='test-id__field-value slds-form-element__static slds-grow word-break-ie11 is-read-only'])[1]")).getText();
//		Validator.verifyThat(TransactionDescription, Matchers.equalTo(Description));
//		util.waitFor(5);
//		Reporter.logWithScreenShot("Transaction Description");
//		
//	}
	public void updateBulkServiceRequest_RevenueAdjustment(Map<String, String> data) {
		util.waitForCasePage();
		String CaseURL = pageProps.getPropertyValue("CaseURL");
		String BulkServiceRequest = CaseURL.replaceFirst("/view", "/related/Bulk_Service_Requests__r/view");
		driver.get(BulkServiceRequest);
		util.waitFor(By.xpath("(//h1[@title='Bulk Service Requests'])[last()]"), 20, true);
		util.clickUsingJs(By.xpath("(//th[@class='slds-cell-edit cellContainer'])[last()]/span/a"));
		util.waitFor(By.xpath("//span[text()='Billing Account Fulfiller Information']"), 20, true);
		util.scrollIntoElement(By.xpath("//button[@title='Edit Adjustment Received Date']"));
		util.clickUsingJs(By.xpath("//button[@title='Edit Adjustment Received Date']"));
		// util.clickUsingJs(By.xpath("//input[@name='Adjustment_Received_Date__c']"));
		driver.findElement(By.xpath("//input[@name='Adjustment_Received_Date__c']"))
				.sendKeys(data.get("Adjustment_Received_Date"));
		driver.findElement(By.xpath("//input[@name='Invoice_Text__c']")).sendKeys(data.get("Invoice_Text"));
		driver.findElement(By.xpath("//input[@name='Description__c']")).sendKeys(data.get("Description"));
		util.waitFor(6);
		util.scrollIntoElement(By.xpath("(//label[.='Adjustment Reason']/following::button)[1]"));
		util.clickUsingJs(By.xpath("(//label[.='Adjustment Reason']/following::button)[1]"));
//		driver.findElement(By.xpath("(//label[.='Adjustment Reason']/following::button)[1]")).click();
		util.waitFor(5);
		driver.findElement(
				By.xpath("//lightning-base-combobox-item[@data-value='" + data.get("Adjustment Reason") + "']"))
				.click();
		util.waitFor(2);
		util.selectAndClickCaseSuggestedValueShowAll("Brand/Service Name");
//		driver.findElement(By.xpath("(//button[@class='slds-combobox__input slds-input_faux slds-combobox__input-value'])[last()]")).click();
//		driver.findElement(By.xpath("//input[@class='slds-combobox__input slds-input']")).click();
//		driver.findElement(By.xpath("//input[@class='slds-combobox__input slds-input']")).sendKeys(data.get("Brand/Service Name"));
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
	}

	public void validateCase_RevenueAdjustment() {
		util.refreshPage();
		util.waitForCasePage();
		util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[last()]"));
		util.waitFor(2);
		util.clickUsingJs(By.xpath("(//span[text()='Validate'][@class='slds-truncate'])"));
		util.waitFor(2);
		util.waitFor(By.xpath("//h2[text()='Validate']"), 20, true);
		Reporter.logWithScreenShot("Validation");
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(By.xpath("//h2[text()='Validate']"), 20, false);
	}

	// Created by Saisree to Add the BillingAccount for CaseMgmt in AfterSales(R4)
	public void AddBillingAccountforChangeVariant(Map<String, String> data) {
		util.refreshPage();
		util.waitForCasePage();
		try {
			util.clickUsingJs(ShowMoreactions);
			util.waitFor(3);
			util.clickUsingJs(By.xpath("//a[@name='Case.Add_Billing_Account']"));
		} catch (Exception e) {

			util.waitAndClickUsingJavaScript("pldt.casepage.addbillingaccount.btn", "Add Billing Account");
		}
		util.waitFor(By.xpath("//div[contains(@class,'slds-form-element')]//input[contains(@placeholder,'search')]"),
				60, true);
		String inputbox = "//div[contains(@class,'slds-form-element')]//input[contains(@placeholder,'search')]";
		util.waitFor(8);
		util.enterText(By.xpath(inputbox), data.get("Billing Account"));
		util.waitFor(5);
		util.clickUsingJs(By.xpath(inputbox));
		driver.findElement(inputbox).sendKeys(Keys.ENTER);
		String xpathBillingAccount = pageProps.getString("pldt.casepage.addbillingaccountname.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathBillingAccount, data.get("Billing Account")),
				"Billing Account Name");
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(8);
		util.enterText(By.xpath(inputbox), data.get("Service ID"));
		util.waitFor(5);
		driver.findElement(inputbox).sendKeys(Keys.ENTER);
		util.clickUsingJs(By.xpath(inputbox));
		String xpathasset = pageProps.getString("pldt.casepage.asset.lnk");
		util.waitAndClickUsingJavaScript(String.format(xpathasset, data.get("Plan")), "Plan");
		util.waitFor(5);
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(8);
		QAFExtendedWebElement TargetedCurrency = driver
				.findElement(By.xpath("//select[@name='TargetedCurrency_ChangeVariant']"));
		String Currency = data.get("Currency");
		util.selectBy(TargetedCurrency, Currency);
		String Price = "//input[contains(@name,'TargetedPrice_ChangeVariant')]";
		util.enterText(By.xpath(Price), data.get("Targeted Price"));
		String New_Bandwidth = "//input[contains(@name,'Requested_Bandwidth')]";
		util.enterText(By.xpath(New_Bandwidth), data.get("Bandwidth"));
		String Date = "//input[contains(@name,'Requested_Start_Date')]";
		util.enterText(By.xpath(Date), data.get("Date"));
		String Variant = "//input[contains(@name,'New_Variant')]";
		util.enterText(By.xpath(Variant), data.get("Variant"));
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(8);
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(By.xpath("//b[contains(text(),'Bulk Service Request')]"), 60, true);
		util.clickUsingJs(By.xpath("//button[.='Finish']"));
		util.waitFor(8);
		util.refreshPage();
		util.waitForCasePage();

	}

	// Created by Saisree to Add the BillingAccount for Modify in AfterSales(R4)
	public void AddBillingAccountforModify(Map<String, String> data) {
		util.refreshPage();
		util.waitForCasePage();
		try {
			util.waitAndClickUsingJavaScript("pldt.casepage.addbillingaccount.btn", "Add Billing Account");
		} catch (Exception e) {
			util.clickUsingJs(ShowMoreactions);
			util.waitFor(3);
			util.clickUsingJs(By.xpath("//a[@name='Case.Add_Billing_Account']"));
		}
		util.waitFor(By.xpath("//div[contains(@class,'slds-form-element')]//input[contains(@placeholder,'search')]"),
				60, true);
		String inputbox = "//div[contains(@class,'slds-form-element')]//input[contains(@placeholder,'search')]";
		util.waitFor(8);
		util.enterText(By.xpath(inputbox), data.get("Billing Account"));
		util.waitFor(5);
		util.clickUsingJs(By.xpath(inputbox));
		driver.findElement(inputbox).sendKeys(Keys.ENTER);
		String xpathBillingAccount = pageProps.getString("pldt.casepage.addbillingaccountname.btn");
		util.waitAndClickUsingJavaScript(String.format(xpathBillingAccount, data.get("Billing Account")),
				"Billing Account Name");
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(8);
		util.enterText(By.xpath(inputbox), data.get("Service ID"));
		util.waitFor(5);
		driver.findElement(inputbox).sendKeys(Keys.ENTER);
		util.clickUsingJs(By.xpath(inputbox));
		String xpathasset = pageProps.getString("pldt.casepage.asset.lnk");
		util.waitAndClickUsingJavaScript(String.format(xpathasset, data.get("Plan")), "Plan");
		util.waitFor(5);
		if (data.get("Transaction Sub Type").contains("SIM")) {
			String Devices = "//input[contains(@name,'Numberofdevices')]";
			util.enterText(By.xpath(Devices), data.get("No Of Devices"));
			QAFWebElement OTF = driver.findElement(By.xpath("//select[@name='OTF']"));
			Select select = new Select(OTF);
			select.selectByVisibleText("Yes");
			util.waitFor(3);
			QAFWebElement Currency = driver.findElement(By.xpath("//select[@name='Currency']"));
			Select select1 = new Select(Currency);
			select1.selectByVisibleText("PHP - Philippine Peso");
			String OTFamount = "//input[contains(@name,'OTFAmount')]";
			util.waitFor(3);
			util.enterText(By.xpath(OTFamount), data.get("OTF Amount"));
			util.waitFor(3);
			QAFWebElement OTFWaive = driver.findElement(By.xpath("//select[@name='OTFWaive']"));
			Select select3 = new Select(OTFWaive);
			select3.selectByVisibleText("Yes");
		}
		if (data.get("Transaction Sub Type").contains("Enrollment / Modification of Plan")) {
			String Current = "//input[contains(@name,'Current_Plan')]";
			util.enterText(By.xpath(Current), data.get("Current Plan"));
			String NewPlan = "//input[contains(@name,'New_Plan')]";
			util.enterText(By.xpath(NewPlan), data.get("New Plan"));
		}
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(5);
		if (data.get("Transaction Sub Type").contains("Change Variant")) {
			util.waitFor(3);
			QAFWebElement Currency = driver.findElement(By.xpath("//select[@name='TargetedCurrency_ChangeVariant']"));
			Select select1 = new Select(Currency);
			select1.selectByVisibleText("PHP - Philippine Peso");
			String TargetPrice = "//input[contains(@name,'TargetedPrice_ChangeVariant')]";
			util.waitFor(3);
			util.enterText(By.xpath(TargetPrice), data.get("TargetPrice"));
			util.waitFor(3);
			String Bandwidth = "//input[contains(@name,'Requested_Bandwidth')]";
			util.waitFor(3);
			util.enterText(By.xpath(Bandwidth), data.get("Bandwidth"));
			util.waitFor(3);
			String Startdate = "//input[contains(@name,'Requested_Start_Date')]";
			util.waitFor(3);
			util.enterText(By.xpath(Startdate), data.get("Requested Start Date"));
			util.waitFor(3);
			String NewVariant = "//input[contains(@name,'New_Variant')]";
			util.waitFor(3);
			util.enterText(By.xpath(NewVariant), data.get("NewVariant"));
			util.waitFor(3);
		}
		if (Objects.nonNull(data.get("Request Waiver"))) {
			String OTFAmount = "//input[@name='OTF_Amount']";
			util.enterText(By.xpath(OTFAmount), data.get("OTF Amount"));
			QAFWebElement CurrencyField = driver.findElement(By.xpath("//select[@name='Currency_Picklist']"));
			Select select = new Select(CurrencyField);
			select.selectByVisibleText(data.get("Currency"));
			QAFWebElement waiverField = driver.findElement(By.xpath("//select[@name='RequestWaiver_Picklist']"));
			Select selects = new Select(waiverField);
			selects.selectByVisibleText(data.get("Request Waiver"));
		}
		if (!data.get("Transaction Sub Type").contains("SIM")) {
			util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		}
		util.waitFor(5);

		if (!data.get("Transaction Sub Type").contains("Enrollment / Modification of Plan")) {
			util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		}
		if ((Objects.nonNull(data.get("Request Waiver"))) | (Objects.nonNull(data.get("OTF Waive")))
				| (Objects.nonNull(data.get("NewVariant")))) {
			util.waitFor(8);
			util.clickUsingJs(By.xpath("//button[text()='Finish']"));
		}
	}

	// Created by Saisree to Request Modify pre-validations in AfterSales(R4)
	public void RequestModify(Map<String, String> data, String value) {
		util.clickOnActionToolBarButton("Quick Actions", value);
		util.waitFor(By.xpath("//pre[contains(text(),'successfully verified')]"), 60, true);
		util.waitAndClickUsingJavaScript("pldt.casepage.prevalidationnext.btn", "Next");
		if (data.get("Transaction Sub Type").contains("Re-rating of MRC")) {
			String xpathasset = pageProps.getString("pldt.casepage.primaryservice.btn");
			util.waitAndClickUsingJavaScript(String.format(xpathasset, data.get("Plan")), "Plan");
			util.waitAndClickUsingJavaScript("pldt.casepage.prevalidationnext.btn", "Next");
		}
		if (data.get("Transaction Sub Type").contains("SIM")) {
			util.clickUsingJs(By.xpath("(//span[.='Like to Like Replacement']/preceding-sibling::span)[2]"));
			util.waitFor(3);
			util.waitAndClickUsingJavaScript("pldt.casepage.prevalidationnext.btn", "Next");
			util.waitForOrderPage();
		}
		if (data.get("Transaction Sub Type").contains("Change Variant")) {
			// util.clickUsingJs(By.xpath("(//label/span[.='To Plans']/following::input)"));
			driver.findElement(By.xpath("(//label/span[.='To Plans']/following::input)")).click();
			util.waitFor(3);
			util.clickUsingJs(By.xpath("(//ul/li/div/span/span[.='" + data.get("NewVariant") + "'])"));
			util.waitAndClickUsingJavaScript("pldt.casepage.prevalidationnext.btn", "Next");
			try {
				util.waitFor(By.xpath("//button[.='Continue']"), 60, true);
				util.clickUsingJs(By.xpath("//button[.='Continue']"));
			} catch (Exception e) {
			}
			util.waitFor(By.xpath("//span[.='View Quote']"), 60, true);
			util.clickUsingJs(By.xpath("//span[.='View Quote']"));
		}
//
//		if ((!data.get("Transaction Sub Type").contains("SIM"))
//				& (!data.get("Transaction Sub Type").contains("VAS/Feature Deactivation"))) {
//			util.waitForQuotePage();
//		}
		if ((data.get("Transaction Sub Type").contains("VAS/Feature Deactivation"))) {
			util.clickUsingJs(By.xpath("(//span[@class='slds-checkbox_faux'])[last()]"));
			util.waitFor(5);
			util.waitAndClickUsingJavaScript("pldt.casepage.prevalidationnext.btn", "Next");
			Reporter.logWithScreenShot("Plan");
		}
		
	}

	// Created by Saisree to Request Modify pre-validations in AfterSales(R4)
	public void RequestModifyForModifyNetwork(Map<String, String> data, String value) {
		util.clickOnActionToolBarButton("Quick Actions", value);
		util.waitFor(By.xpath("//pre[contains(text(),'successfully verified')]"), 60, true);
		util.waitAndClickUsingJavaScript("pldt.casepage.prevalidationnext.btn", "Next");
		Reporter.logWithScreenShot("Service Information");
		QAFWebElement Status = new QAFExtendedWebElement("xpath=//span[.='Service Modification']");
		Validator.verifyTrue(Status.isPresent(), "Case Transaction Type is not Service Modification",
				"Case Transaction Type is Service Modification");
		QAFWebElement Statu = new QAFExtendedWebElement("xpath=//span[.='Modify Network']");
		Validator.verifyTrue(Status.isPresent(), "Case Transaction subType is not Modify Network",
				"Case Transaction Type is not Modify Network");
		util.clickUsingJs(By.xpath("//button[contains(text(),'Next')]"));
		util.waitFor(By.xpath("//button[.='Done']"), 90, true);
		util.clickUsingJs(By.xpath("//button[.='Done']"));
	}

	// Created by Saisree for Adding Billing Account in AfterSales(R4).
	public void AddBillingAccountforCreate(Map<String, String> data) {
		util.refreshPage();
		util.waitAndClickUsingJavaScript("pldt.casepage.addbillingaccount.btn", "Add Billing Account");
		util.waitFor(By.xpath("//input[contains(@name,'Service_Address')]"), 60, true);
		if (data.get("Transaction Sub Type").contains("Request for Promo/ Program/ Campaign")) {
			String inputpromoinfo = "//input[@name='Promo_Campaign_Info']";
			util.enterText(By.xpath(inputpromoinfo), data.get("Transaction Sub Type"));
		}
		String inputboxserviceaddress = "//input[contains(@name,'Service_Address')]";
		util.enterText(By.xpath(inputboxserviceaddress), data.get("Service Address"));
		String inputboxbillingaddress = "//input[contains(@name,'Billing_Address')]";
		util.enterText(By.xpath(inputboxbillingaddress), data.get("Billing Address"));
		String inputbox = "(//div[contains(@class,'slds-m-bottom_x-small')]//input[contains(@id,'combobox-input')])[2]";
		util.waitFor(3);
		util.enterText(By.xpath(inputbox), data.get("New Product"));
		util.waitFor(5);
		// driver.findElementByXPath(inputbox).sendKeys(Keys.ENTER);
		// String xpathproduct = pageProps.getString("pldt.casepage.newproduct.lnk");
		// util.waitAndClickUsingJavaScript(String.format(xpathproduct,data.get("New
		// Product")),"New Product");
		String xpathproduct = pageProps.getString("pldt.casepage.autosuggestdropdown.lnk");
		util.waitAndClickUsingJavaScript(String.format(xpathproduct, data.get("New Product")), "New Product");
		if (data.get("Billing Account Number").contains("SKIP")) {
			if (driver.findElement("//span[@class='slds-checkbox_off']").isDisplayed()) {
				util.waitAndClickUsingJavaScript("pldt.casepage.existingbillaccount.btn",
						"Existing Billing Acc button");
			}
			String inputboxbillaccount = "(//div[contains(@class,'slds-m-bottom_x-small')]//input[contains(@id,'combobox-input')])[2]";
			util.waitFor(3);
			String BillingAccountName = pageProps.getPropertyValue("Billing_AccountName");
			util.enterText(By.xpath(inputboxbillaccount), BillingAccountName);
			String xpathbillaccount = pageProps.getString("pldt.casepage.autosuggestdropdown.lnk");
			util.waitAndClickUsingJavaScript(String.format(xpathbillaccount, BillingAccountName),
					"Billing AccountName");
			util.waitFor(3);
		}
		String New_Bandwidth = "//input[contains(@name,'New_Bandwidth')]";
		util.enterText(By.xpath(New_Bandwidth), data.get("New Bandwidth"));
		QAFWebElement VanityNumberField = driver.findElement(By.xpath("//select[@name='Vanity_Number']"));
		Select select = new Select(VanityNumberField);
		select.selectByVisibleText("Standard");
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
		util.waitFor(5);
		util.waitAndClickUsingJavaScript("pldt.casepage.next.btn", "Next Button");
	}

	public void caseModificationTIN(String TIN, String Remark) {
		util.scrollDown();
		util.waitFor(10);
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(10);
		QAFWebElement NewCompanyTINInput = new QAFExtendedWebElement(By.xpath("//input[@name='New_TIN__c']"));
		QAFWebElement RemarksInput = new QAFExtendedWebElement(By.xpath("//textarea[@name='Remarks_Comments__c']"));
		QAFWebElement SaveRecordbtn = new QAFExtendedWebElement(
				By.xpath("//div[@class='slds-m-top_medium']//button[@type='submit']"));
		NewCompanyTINInput.sendKeys(TIN);
		util.waitFor(5);
		RemarksInput.sendKeys(Remark);
		RemarksInput.sendKeys(Keys.TAB);
		util.waitFor(SaveRecordbtn, 10, true);
		util.clickUsingJs(SaveRecordbtn);
		util.waitFor(5);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by waseem for ChangeBusiness test case
	public void caseModificationChangeBusiness(String TIN, String Remark) {
		util.scrollDown();
		util.waitFor(10);
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(10);
		QAFWebElement NewCompanyTradeName = new QAFExtendedWebElement(
				By.xpath("//input[@name='Company_Trade_Name__c']"));
		QAFWebElement RemarksInput = new QAFExtendedWebElement(By.xpath("//textarea[@name='Remarks_Comments__c']"));
		QAFWebElement SaveRecordbtn = new QAFExtendedWebElement(
				By.xpath("//div[@class='slds-m-top_medium']//button[@type='submit']"));
		NewCompanyTradeName.sendKeys(TIN);
		util.waitFor(5);
		RemarksInput.sendKeys(Remark);
		RemarksInput.sendKeys(Keys.TAB);
		util.waitFor(SaveRecordbtn, 10, true);
		util.clickUsingJs(SaveRecordbtn);
		util.waitFor(5);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by waseem for THSRating test case
	public void caseModificationTHSRating(Map<String, String> data) {
		util.scrollDown();
		util.waitFor(10);
		util.clickUsingJs(TransactionDetails);
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(10);
		QAFWebElement AssetID = new QAFExtendedWebElement(
				By.xpath("//label[text()='Asset ID']//following::input[@role='combobox']"));
		QAFWebElement suggestedAssetID = new QAFExtendedWebElement(
				By.xpath("//*[@title='" + data.get("Asset ID") + "']"));
		QAFWebElement SaveRecordbtn = new QAFExtendedWebElement(
				By.xpath("//div[@class='slds-m-top_medium']//button[@type='submit']"));
		util.select("New THS Rating");
		AssetID.sendKeys(data.get("Asset ID"));
		util.waitFor(6);
		suggestedAssetID.click();
		util.waitFor(SaveRecordbtn, 10, true);
		util.clickUsingJs(SaveRecordbtn);
		util.waitFor(5);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by waseem for Modify Bill Cycle test case
	public void caseModificationBillCycle(Map<String, String> data) {
		util.scrollDown();
		util.waitFor(15);
		util.clickUsingJs(TransactionDetails);
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(10);
		QAFWebElement AssetID = new QAFExtendedWebElement(
				By.xpath("//label[text()='Asset ID']//following::input[@role='combobox']"));
		QAFWebElement suggestedAssetID = new QAFExtendedWebElement(
				By.xpath("//*[@title='" + data.get("Asset ID") + "']"));
		QAFWebElement NewBillCycle = new QAFExtendedWebElement(
				By.xpath("//label[text()='New Bill Cycle']//following::input[@role='combobox']"));
		QAFWebElement suggestedNewBillCycle = new QAFExtendedWebElement(
				By.xpath("//*[@title='" + data.get("New Bill Cycle") + "']"));
		QAFWebElement SaveRecordbtn = new QAFExtendedWebElement(
				By.xpath("//div[@class='slds-m-top_medium']//button[@type='submit']"));
		AssetID.sendKeys(data.get("Asset ID"));
		util.waitFor(6);
		suggestedAssetID.click();
		NewBillCycle.sendKeys(data.get("New Bill Cycle"));
		util.waitFor(6);
		suggestedNewBillCycle.click();
		util.waitFor(SaveRecordbtn, 10, true);
		util.clickUsingJs(SaveRecordbtn);
		util.waitFor(5);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by waseem for Modify Bill Cycle test case
	public void caseModificationVIPCode(Map<String, String> data) {
		util.scrollDown();
		util.waitFor(10);
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(10);
//		QAFWebElement AssetID= new QAFExtendedWebElement(By.xpath("//label[text()='Asset ID']//following::input[@role='combobox']"));
//		QAFWebElement suggestedAssetID= new QAFExtendedWebElement(By.xpath("//*[@title='"+data.get("Asset ID")+"']"));
		QAFWebElement NewVIPCode = new QAFExtendedWebElement(
				By.xpath("//label[text()='New VIP Code']//following::input[@role='combobox']"));
		QAFWebElement suggestedNewVIPCode = new QAFExtendedWebElement(
				By.xpath("//*[@title='" + data.get("New VIP Code") + "']"));
		QAFWebElement SaveRecordbtn = new QAFExtendedWebElement(
				By.xpath("//div[@class='slds-m-top_medium']//button[@type='submit']"));
//		AssetID.sendKeys(data.get("Asset ID"));
		util.waitFor(12);
//		suggestedAssetID.click();
		NewVIPCode.sendKeys(data.get("New VIP Code"));
		util.waitFor(12);
		suggestedNewVIPCode.click();
		util.waitFor(12);
		util.clickUsingJs(SaveRecordbtn);
		util.waitFor(12);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by waseem for Modify Corporate Change Assignee test case
	public void caseModificationChangeAssignee(Map<String, String> data) {
		util.scrollDown();
		util.waitFor(10);
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(10);
		QAFWebElement AssetID = new QAFExtendedWebElement(
				By.xpath("//label[text()='Asset ID']//following::input[@role='combobox']"));
		QAFWebElement suggestedAssetID = new QAFExtendedWebElement(
				By.xpath("//*[@title='" + data.get("Asset ID") + "']"));
		QAFWebElement AssigneeFirstName = new QAFExtendedWebElement(By.xpath("//input[@name='First_Name__c']"));
		QAFWebElement AssigneeMiddleName = new QAFExtendedWebElement(By.xpath("//input[@name='Middle_Name__c']"));
		QAFWebElement AssigneeLastName = new QAFExtendedWebElement(By.xpath("//input[@name='Last_Name__c']"));
		QAFWebElement Remarks = new QAFExtendedWebElement(By.xpath("//textarea[@name='Remarks_Comments__c']"));
		QAFWebElement SaveRecordbtn = new QAFExtendedWebElement(
				By.xpath("//div[@class='slds-m-top_medium']//button[@type='submit']"));
		AssetID.sendKeys(data.get("Asset ID"));
		util.waitFor(12);
		suggestedAssetID.click();
		AssigneeFirstName.sendKeys("FirstName");
		AssigneeMiddleName.sendKeys("MiddleName");
		AssigneeLastName.sendKeys("LastName");
		Remarks.sendKeys(data.get("Subject"));
		util.waitFor(SaveRecordbtn, 10, true);
		util.clickUsingJs(SaveRecordbtn);
		util.waitFor(15);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by waseem for Modify Transfer of service test case
	public void caseModificationTransService(Map<String, String> data) {
		util.scrollDown();
		util.waitFor(10);
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(15);
		QAFWebElement AssetID = new QAFExtendedWebElement(
				By.xpath("//label[text()='Asset ID']//following::input[@role='combobox']"));
		QAFWebElement suggestedAssetID = new QAFExtendedWebElement(
				By.xpath("//*[@title='" + data.get("Asset ID") + "']"));
		QAFWebElement NewBillingAC = new QAFExtendedWebElement(
				By.xpath("//label[text()='New Billing Account']//following::input[@role='combobox']"));
		String billingAcName = ConfigurationManager.getBundle().getPropertyValue("BillingAccountName");
		QAFWebElement suggestedNewBillingAC = new QAFExtendedWebElement(
				By.xpath("//*[@title='" + billingAcName + "']"));
		QAFWebElement Remarks = new QAFExtendedWebElement(By.xpath("//textarea[@name='Remarks_Comments__c']"));
		QAFWebElement SaveRecordbtn = new QAFExtendedWebElement(
				By.xpath("//div[@class='slds-m-top_medium']//button[@type='submit']"));
		QAFWebElement creditChkBtn = new QAFExtendedWebElement(
				By.xpath("//span[text()='Credit Check']//following::input[@name='Credit_Check__c']"));
		QAFWebElement ARClearenceChk = new QAFExtendedWebElement(
				By.xpath("//span[text()='AR Clearence Check']//following::input[@name='AR_Clearence_Check__c']"));
		QAFWebElement PTFWaivedOff = new QAFExtendedWebElement(
				By.xpath("//span[text()='PTF Waived Off']//following::input[@name='PTF_Waived_Off__c']"));
		AssetID.sendKeys(data.get("Asset ID"));
		util.waitFor(12);
		suggestedAssetID.click();
		util.waitFor(6);
//		creditChkBtn.click();
		util.waitFor(6);
		ARClearenceChk.click();
		util.waitFor(6);
		NewBillingAC.sendKeys(billingAcName);
		util.waitFor(12);
		suggestedNewBillingAC.click();
//		util.waitFor(6);
//		PTFWaivedOff.click();
		util.waitFor(6);
		Remarks.sendKeys(data.get("Subject"));
		util.waitFor(SaveRecordbtn, 10, true);
		util.clickUsingJs(SaveRecordbtn);
		util.waitFor(15);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by waseem for Modify Transfer of Owner test case
	public void caseModificationTransOwner(Map<String, String> data) {
		util.scrollDown();
		util.waitFor(10);
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.waitFor(15);
		QAFWebElement AssetID = new QAFExtendedWebElement(
				By.xpath("//label[text()='Asset ID']//following::input[@role='combobox']"));
		QAFWebElement suggestedAssetID = new QAFExtendedWebElement(
				By.xpath("//*[@title='" + data.get("Asset ID") + "']"));
		QAFWebElement NewBillingAC = new QAFExtendedWebElement(
				By.xpath("//label[text()='New Billing Account']//following::input[@role='combobox']"));
		String billingAcName = ConfigurationManager.getBundle().getPropertyValue("BillingAccountName");
		QAFWebElement suggestedNewBillingAC = new QAFExtendedWebElement(
				By.xpath("//*[@title='" + billingAcName + "']"));
		QAFWebElement Remarks = new QAFExtendedWebElement(By.xpath("//textarea[@name='Remarks_Comments__c']"));
		QAFWebElement SaveRecordbtn = new QAFExtendedWebElement(
				By.xpath("//div[@class='slds-m-top_medium']//button[@type='submit']"));
		QAFWebElement creditChkBtn = new QAFExtendedWebElement(
				By.xpath("//span[text()='Credit Check']//following::input[@name='Credit_Check__c']"));
		QAFWebElement ARClearenceChk = new QAFExtendedWebElement(
				By.xpath("//span[text()='AR Clearence Check']//following::input[@name='AR_Clearence_Check__c']"));
		QAFWebElement PTFWaivedOff = new QAFExtendedWebElement(
				By.xpath("//span[text()='PTF Waived Off']//following::input[@name='PTF_Waived_Off__c']"));
		AssetID.sendKeys(data.get("Asset ID"));
		util.waitFor(12);
		suggestedAssetID.click();
		util.waitFor(6);
		creditChkBtn.click();
		util.waitFor(6);
		ARClearenceChk.click();
		util.waitFor(6);
		NewBillingAC.sendKeys(billingAcName);
		util.waitFor(12);
		suggestedNewBillingAC.click();
		util.waitFor(6);
		// PTFWaivedOff.click();
		// util.waitFor(6);
		Remarks.sendKeys(data.get("Subject"));
		util.waitFor(SaveRecordbtn, 10, true);
		util.clickUsingJs(SaveRecordbtn);
		util.waitFor(15);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// Created by waseem for Change TIN (Business) test case
	public void markCaseStatusToResolved() {
		// markCaseStatus(resolutionInProg,"Resolution In Progress");
		util.clickUsingJs(By.xpath("//a[@title='Resolved']"));
		util.clickUsingJs(markCurrentStatus);
		util.waitFor(3);
		util.waitForGenericToastMessage();
	}

	// Created by waseem for get case owner
	public String getCaseOwner() {
		QAFWebElement CaseOwner = new QAFExtendedWebElement(By.xpath(
				"(//span[text()='Case Information']//following::span[text()='Case Owner']//following::a//span)[1]"));
		return CaseOwner.getText();

	}

	// Created by waseem to close the status
	public void markCaseStatusToClosed() {
		util.clickUsingJs(By.xpath("(//a[@data-tab-name='Closed'])[last()]"));
		util.clickUsingJs(markCurrentStatus);
		util.waitFor(5);
		util.waitForGenericToastMessage();
	}

	// Created by Saisree to Import Bulk File.
	public void ImportBulkFile(String lookupfieldvalue, String path, Map<String, String> data) {
		util.waitFor(5);
		QAFWebElement Customobjectslink = new QAFExtendedWebElement(By.xpath("//a[text()='Custom objects']"));
		QAFWebElement BulkServiceRequestslink = new QAFExtendedWebElement(
				By.xpath("//a[text()='Bulk Service Requests']"));
		QAFWebElement Addnewrecordlink = new QAFExtendedWebElement(By.xpath("//a[text()='Add new records']"));
		QAFWebElement selectlookupfield = new QAFExtendedWebElement(By.xpath(
				"//span[text()='Which Account field in your file do you want to match against to set the Billing Account Number lookup field?']//following::select"));

		QAFWebElement CSV = new QAFExtendedWebElement(By.xpath("(//span[text()='CSV']//ancestor::a)[1]"));
		QAFWebElement fileinput = new QAFExtendedWebElement(By.xpath("//input[@name='file']"));
		QAFWebElement nextButton = new QAFExtendedWebElement(By.xpath("//a[text()='Next']"));
		QAFWebElement Unmapped = new QAFExtendedWebElement(By.xpath("//td[@title='Unmapped']"));
		QAFWebElement StartImportbutton = new QAFExtendedWebElement(By.xpath("//a[text()='Start Import']"));
		QAFWebElement OkButton = new QAFExtendedWebElement(By.xpath("//a[text()='OK']"));
		Customobjectslink.click();
		util.waitFor(4);
		BulkServiceRequestslink.click();
		util.waitFor(4);
		Addnewrecordlink.click();
		util.waitFor(4);
		util.selectOptionByPartialText(selectlookupfield, lookupfieldvalue);
		util.waitFor(4);
		if (Objects.nonNull(data.get("VIPCode"))) {
			QAFWebElement selectVIPCode = new QAFExtendedWebElement(By.xpath(
					"//span[text()='Which VIP Code LOV field in your file do you want to match against to set the VIP Code lookup field?']//following::select"));
			util.selectOptionByPartialText(selectVIPCode, data.get("VIPCode"));
		}
		if (Objects.nonNull(data.get("TaxProfile"))) {
			QAFWebElement selectTaxProfile = new QAFExtendedWebElement(By.xpath(
					"//span[text()='Which Tax Profile LOV field in your file do you want to match against to set the Tax Profile lookup field?']//following::select"));
			util.selectOptionByPartialText(selectTaxProfile, data.get("TaxProfile"));
		}
		if (Objects.nonNull(data.get("BillCycleCode"))) {
			QAFWebElement selectTaxProfile = new QAFExtendedWebElement(By.xpath(
					"//span[text()='Which Bill Cycle LOV field in your file do you want to match against to set the Bill Cycle lookup field?']//following::select"));
			util.selectOptionByPartialText(selectTaxProfile, data.get("BillCycleCode"));
		}
		if (Objects.nonNull(data.get("BillDispatch"))) {
			QAFWebElement selectTaxProfile = new QAFExtendedWebElement(By.xpath(
					"//span[text()='Which Bill Dispatch Method LOV field in your file do you want to match against to set the Bill Dispatch Method lookup field?']//following::select"));
			util.selectOptionByPartialText(selectTaxProfile, data.get("BillDispatch"));
		}
		util.waitFor(4);
		util.scrollUp();
		util.waitFor(4);
		CSV.click();
		util.waitFor(4);
		fileinput.sendKeys(path);
		util.waitFor(10);
		nextButton.click();
		util.waitFor(15);
//				boolean Unmappedfiled = Unmapped.isDisplayed() && Unmapped.isPresent();
		// Validator.verifyTrue(Unmapped.isPresent(), "please check unmmaped filed
		// present", "All fields are mapped");
		nextButton.click();
		util.waitFor(8);
		StartImportbutton.click();
		util.waitFor(4);
		OkButton.click();
		util.waitFor(20);
		util.refreshPage();
		util.waitFor(10);

		QAFWebElement Status = new QAFExtendedWebElement(
				By.xpath("((//div[@class='pbBody'])[last()]//tbody//tr//td)[last()]"));
		Validator.verifyThat("I verify Batch status", Status.getText(), Matchers.equalTo("Completed"));
		app.mouseMover();

	}

	// Created by Vinay to modify FCR Details
	public void modifyFCRDetails(Map<String, String> data) {
		util.scrollIntoElement(By.xpath("(//span[.='SMAX Information'])"));
		util.clickUsingJs(By.xpath("//span[.='Edit FCR']/parent::button"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("(//span[.='FCR'])[last()]"));
		util.clickUsingJs(By.xpath("(//label[.='FCR Status']/following::button)[1]"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath(
				"((//lightning-base-combobox-item[@data-value='Unsuccessful'])[last()]|(//span[@title='Unsuccessful']))"));
		util.typeIntoTextArea("FCR status remarks");
		util.waitFor(By.xpath("//button[text()='Save']"), 10, true);
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
		util.waitFor(By.xpath("//button[text()='Save']"), 30, false);

	}

	// Created by Vinay to change Current Assignment
	public void changeCurrentAssignment(Map<String, String> data) {
		util.scrollIntoElement(By.xpath("(//span[.='SMAX Information'])"));
		util.clickUsingJs(By.xpath("(//button[@title='Edit Current Assignment'])"));
		util.waitFor(3);
		util.select("Current Assignment");
		util.waitFor(By.xpath("//button[text()='Save']"), 10, true);
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
		util.waitFor(By.xpath("//button[text()='Save']"), 30, false);
	}

	// Created by Vinay to modify Alert Details
	public void modifyAlertDetais(Map<String, String> data) {
		util.clickUsingJs(transactionDetails);
		util.clickUsingJs(editButton);
		util.select("Alert Tag Level");
		util.select("Alert Code Type");
		util.select("Alert Code Action");
		util.waitFor(3);
		util.clickUsingJs(saveRecord);
		util.waitFor(SaveRecord, 8, false);
	}

	// Created by Vinay to Create New Alert
	public void createNewAlert(Map<String, String> data) {
		bean.fillRandomData();
		util.waitFor(By.xpath("(//h2[text()='New Alert Code'])"), 20, true);
		String AlertCodeName = bean.getFirstName();
		pageProps.setProperty("AlertCodeName", AlertCodeName);
		driver.findElement(By.xpath("(//label[text()='Alert Code Name']/following::input)")).sendKeys(AlertCodeName);
		driver.findElement(By.xpath("(//label[text()='Description']/following::textarea)")).sendKeys(bean.getOther());
		util.select("Line Of Business");
		util.clickUsingJs(SaveButton);
		util.waitForGenericToastMessage();
	}

	// Created By Nimesh
	public void email() {
		util.waitForCasePage();
		util.clickUsingJs(By.xpath("//a[text()='More']"));
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//a[text()='Email']"));
		util.waitFor(5);
		util.clickUsingJs(By.xpath("//span[text()='Send']"));
	}

	// Created By Nimesh
	public void updateCaseDetail(Map<String, String> data) {
		util.waitForCasePage();
		// CASE INFORMATION
		util.scrollIntoElement(By.xpath("//button[@title='Edit Additional Contact Details']"));
		util.clickUsingJs(By.xpath("//button[@title='Edit Additional Contact Details']"));
		util.typeIntoTextArea("Additional Contact Details");
		util.select("Pillar");
		util.select("Service");
		util.select("Site Name");
		util.select("Case Origin");
		util.typeIntoTextArea("Circuit ID");
		util.select("Billable");
		util.select("Impact");
		util.select("Urgency");
		// SMAX Infromation
		util.select("SMAX Status");
		util.select("Support Group Tier 2");
		util.select("Type of Request");
		// System Information
		util.waitFor(3);
		util.enterText(driver.findElement(By.xpath("(//input[@name='Concerned_Received_Time__c'])[1]")),
				data.get("Concern Received Time"));
		util.waitFor(10);
		util.clickUsingJs(By.xpath("//button[text()='Save']"));
		util.waitFor(10);
	}
	
	//Created by Vinay to Verify Transaction Details for Involuntary Suspension
	public void verifyTransactionDetailsForInvoluntary(Map<String,String>data) {
		util.clickUsingJs(transactionDetails);
		util.clickUsingJs(editButton);
		util.waitFor(By.xpath("(//label[text()='Reason Code']/following::button[contains(@name,'Reason')])"), 10, true);
		util.clickUsingJs(By.xpath("(//label[text()='Reason Code']/following::button[contains(@name,'Reason')])"));
		util.clickUsingJs(By.xpath("(//lightning-base-combobox-item[@data-value='" + data.get("Reason Code") + "'])"));
		util.typeIntoTextArea("Remarks/Comments");
		util.clickUsingJs(saveRecord);
		util.waitFor(SaveRecord, 10, false);
		
	}

	// Created by Vidya for selecting multiple checkbox in Modify action
	public void RequestModifyMultiplecheck(Map<String, String> data, String value) {
		util.clickOnActionToolBarButton("Quick Actions", value);
		util.waitFor(By.xpath("//pre[contains(text(),'successfully verified')]"), 60, true);
		util.waitAndClickUsingJavaScript("pldt.casepage.prevalidationnext.btn", "Next");
		String checkboxXpath = "//span[@class='slds-checkbox_faux']";
		List<WebElement> elements = driver.findElements(By.xpath(checkboxXpath));
		elements.forEach(v -> v.click());
		util.waitFor(5);
		util.waitAndClickUsingJavaScript("pldt.casepage.prevalidationnext.btn", "Next");
		Reporter.logWithScreenShot("Plan");
	}

}
