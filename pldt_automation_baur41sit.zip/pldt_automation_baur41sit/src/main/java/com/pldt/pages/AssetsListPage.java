package com.pldt.pages;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.annotations.PageIdentifier;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AssetsListPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	String current = null;
	public static By showAll = By.xpath("//ul/following-sibling::div/a[contains(text(),'Show All')]");
	public static By asset = By.xpath("//ul/li//records-hoverable-link//slot/span[contains(text(),'Assets')]");
	public static By quickfilter = By.xpath("(//button[@title='Show quick filters'])");
	public static By assetinput = By.xpath("(//label[text()='Asset Name']/following::input)[1]");
	public static By mininput = By.xpath("(//label[text()='MIN']/following::input[@name='Asset-MIN__c'])");
	public static By linenumber = By
			.xpath("(//label[text()='Line Number']/following::input[@name='Asset-vlocity_cmt__LineNumber__c'])");
	WebUtilities util = new WebUtilities();
	private final String URL_ACCOUNT_TAB = pageProps.getString("baseurl") + "o/Asset/list";
	@PageIdentifier
	@FindBy(locator = "xpath=//h1/span[text()='Accounts']")
	private QAFWebElement Accounts;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		driver.navigate().to(URL_ACCOUNT_TAB);
	}

	public void openAsset(String AssetName, String minValue, boolean filter) {
		if (filter) {
			util.clickUsingJs(quickfilter);
			util.clickUsingJs(assetinput);
			util.enterText(assetinput, AssetName);
			util.clickUsingJs(mininput);
			util.enterText(mininput, minValue);
			util.enterKey();
			util.waitFor(5);
			String pat = "(//a//span[text()=" + "'" + AssetName + "'" + "])[1]";
			util.clickUsingJs(By.xpath(pat));
			util.waitForAssetPage();
			current = driver.getCurrentUrl();
		} else {
			driver.navigate().to(getAssetLink(AssetName));
			util.waituntil.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1/div[text()='Asset']")));
		}
	}

	public void openAssetForDevice(String AssetName, String LineNumber, boolean filter) {
		if (filter) {
			util.clickUsingJs(quickfilter);
			util.clickUsingJs(assetinput);
			util.enterText(assetinput, AssetName);
			util.clickUsingJs(linenumber);
			util.enterText(linenumber, LineNumber);
			util.enterKey();
			util.waitFor(5);
			String pat = "//a[text()=" + "'" + AssetName + "'" + "]";
			util.clickUsingJs(By.xpath(pat));
			util.waitForAssetPage();
			current = driver.getCurrentUrl();
		} else {
			driver.navigate().to(getAssetLink(AssetName));
			util.waituntil.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1/div[text()='Asset']")));
		}
	}

	public String getAssetLink(String AssetName) {
		driver.findElement(By.xpath("//input[@name='Asset-search-input']")).sendKeys(AssetName);
		driver.findElement(By.xpath("//input[@name='Asset-search-input']")).sendKeys(Keys.ENTER);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String assetViewURL = driver.findElement(By.xpath(String.format("//a[text()='%s']", AssetName)))
				.getAttribute("href");
		return assetViewURL;
	}

	//created by Vidya
	public void openAssetforEEAccount(String AssetName, String minValue, String SFServiceID, boolean filter) {
		URL uri = null;
		try {
			uri = new URL(driver.getCurrentUrl());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (filter) {
			util.clickUsingJs(quickfilter);
			util.clickUsingJs(assetinput);
			util.enterText(assetinput, AssetName);
			if (pageProps.getPropertyValue("accountRecType").equalsIgnoreCase("Enterprise Extension")) {
				util.goToURL("https://" + uri.getHost() + "/lightning/r/Asset/" + SFServiceID + "/view");

			} else {
				util.clickUsingJs(mininput);
				util.enterText(mininput, minValue);
				util.enterKey();
				util.waitFor(5);
				String pat = "(//a//span[text()=" + "'" + AssetName + "'" + "])[1]";
				util.clickUsingJs(By.xpath(pat));
			}
			util.waitForAssetPage();
			current = driver.getCurrentUrl();
		} else {
			driver.navigate().to(getAssetLink(AssetName));
			util.waituntil.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1/div[text()='Asset']")));
		}
	}

}
