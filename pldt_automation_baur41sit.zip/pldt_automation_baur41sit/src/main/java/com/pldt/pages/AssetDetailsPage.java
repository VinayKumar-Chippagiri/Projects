package com.pldt.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class AssetDetailsPage extends WebDriverBaseTestPage<WebDriverTestPage> {

	WebUtilities util = new WebUtilities();
	static String billingAccountNumber = null;

	public static By details = By.xpath("//a[text()='Details']");
	public static By billAccountNumber = By
			.xpath("//span[text()='CRM Billing Account Number']/parent::div/following-sibling::div/span");
	public static By related = By.xpath("//a[text()='Related']");

	@Override
	protected void openPage(PageLocator locator, Object... args) {
	}

	public void getBillAccountNumber() {
		util.clickUsingJs(details);
		util.waitFor(billAccountNumber, 5, true);
		billingAccountNumber = driver.findElement(billAccountNumber).getText();
		pageProps.setProperty("billingAccountNumber", billingAccountNumber);
		util.clickUsingJs(related);
	}

	public void clickOnRelated(String LinkName) {
		driver.navigate().to(getAccountViewPage(LinkName));
//		util.waituntil.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[@title='" + LinkName + "']")));
	}

	private String getAccountViewPage(String linkName) {
		return driver.getCurrentUrl().replaceFirst("view", "related/" + linkName + "/view");

	}

	public String getCRMBillingAccountNumber() {
		QAFWebElement CRMBillingAccountNumber = new QAFExtendedWebElement(By.xpath(
				"(//span[text()='Account Information']//following::span[text()='CRM Billing Account Number']//following::lightning-formatted-text)[1]"));
		return CRMBillingAccountNumber.getText();
	}

	public String getBillingAccount() {
		QAFWebElement BillingAccount = new QAFExtendedWebElement(By.xpath(
				"(//span[text()='Account Information']//following::span[text()='Billing Account']//following::a//span)[1]"));
		return BillingAccount.getText();
	}

	public String getParentAccountRecordType() {
		QAFWebElement RecordType = new QAFExtendedWebElement(By.xpath(
				"(//span[text()='Account Information']//following::span[text()='Parent Account Record Type']//following::lightning-formatted-text)[1]"));
		return RecordType.getText();
	}

	public String getServiceAccount() {
		QAFWebElement ServiceAccount = new QAFExtendedWebElement(By.xpath(
				"(//span[text()='Account Information']//following::span[text()='Service Account']//following::a//span)[1]"));
		return ServiceAccount.getText();
	}
}
