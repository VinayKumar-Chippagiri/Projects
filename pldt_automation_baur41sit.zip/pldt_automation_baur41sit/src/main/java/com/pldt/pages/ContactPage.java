package com.pldt.pages;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;

import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.locators.ContactPageLocators;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;
import com.qmetry.qaf.automation.util.Reporter;

public class ContactPage extends WebDriverBaseTestPage<WebDriverTestPage> implements ContactPageLocators {
	WebUtilities util = new WebUtilities();
	Map<?, ?> map = null;
	TestDataBean bean = new TestDataBean();
	DateUtil date = new DateUtil();

	/*
	 * public ContactPage() { bean.fillRandomData(); }
	 */
	@FindBy(locator = CONTACT_SALUTATION)
	private QAFWebElement contactSalutation;
	@FindBy(locator = CONTACT_FIRST_NAME)
	private QAFWebElement contactFirstName;
	@FindBy(locator = CONTACT_MID_NAME)
	private QAFWebElement contactMidName;
	@FindBy(locator = CONTACT_LAST_NAME)
	private QAFWebElement contactLastName;
	@FindBy(locator = CONTACT_SUFFIX)
	private QAFWebElement contactSuffix;
	@FindBy(locator = CONTACT_ACCOUNT_NAME)
	private QAFWebElement contactAccountName;
	@FindBy(locator = CONTACT_TITLE)
	private QAFWebElement contactTitle;
	@FindBy(locator = CONTACT_ROLE)
	private QAFWebElement contactRole;
	@FindBy(locator = CONTACT_PARTNER)
	private QAFWebElement contactPartner;
	@FindBy(locator = CONTACT_STATUS)
	private QAFWebElement contactStatus;
	@FindBy(locator = CONTACT_CURENCY)
	private QAFWebElement contactCurency;
	@FindBy(locator = CONTACT_PHONE)
	private QAFWebElement contactPhone;
	@FindBy(locator = CONTACT_MOBILE)
	private QAFWebElement contactMobile;
	@FindBy(locator = CONTACT_OTHER_PHONE)
	private QAFWebElement contactOtherPhone;
	@FindBy(locator = CONTACT_HOME_PHONE)
	private QAFWebElement contactHomePhone;
	@FindBy(locator = CONTACT_FAX)
	private QAFWebElement contactFax;
	@FindBy(locator = CONTACT_BIRTHDATE)
	private QAFWebElement contactBirthdate;
	@FindBy(locator = CONTACT_GENDER)
	private QAFWebElement contactGender;
	@FindBy(locator = CONTACT_CIVIL_STATUS)
	private QAFWebElement contactCivilStatus;
	@FindBy(locator = CONTACT_DRIVERS_LICENSE_NUMBER)
	private QAFWebElement contactDriversLicenseNumber;
	@FindBy(locator = CONTACT_TAX_ID)
	private QAFWebElement contactTaxId;
	@FindBy(locator = CONTACT_EMAIL)
	private QAFWebElement contactEmail;
	@FindBy(locator = CONTACT_EMPLOYEE)
	private QAFWebElement contactEmployee;
	@FindBy(locator = CONTACT_EMPLOYER)
	private QAFWebElement contactEmployer;
	@FindBy(locator = CONTACT_EMPLOYMENT_STATUS)
	private QAFWebElement contactEmploymentStatus;
	@FindBy(locator = CONTACT_DEPARTMENT)
	private QAFWebElement contactDepartment;
	@FindBy(locator = CONTACT_MAILING_ADDRESS)
	private QAFWebElement contactMailingAddress;
	@FindBy(locator = CONTACT_MAILING_COUNTRY)
	private QAFWebElement contactMailingCountry;
	@FindBy(locator = CONTACT_MAILING_STREET)
	private QAFWebElement contactMailingStreet;
	@FindBy(locator = CONTACT_MAILING_CITY)
	private QAFWebElement contactMailingCity;
	@FindBy(locator = CONTACT_MAILING_STATE_PROVINCE)
	private QAFWebElement contactMailingStateProvince;
	@FindBy(locator = CONTACT_MAILING_ZIP_POSTAL_CODE)
	private QAFWebElement contactMailingZipPostalCode;
	@FindBy(locator = CONTACT_OTHER_ADDRESS)
	private QAFWebElement contactOtherAddress;
	@FindBy(locator = CONTACT_OTHER_COUNTRY)
	private QAFWebElement contactOtherCountry;
	@FindBy(locator = CONTACT_OTHER_STREET)
	private QAFWebElement contactOtherStreet;
	@FindBy(locator = CONTACT_OTHER_CITY)
	private QAFWebElement contactOtherCity;
	@FindBy(locator = CONTACT_OTHER_STATE_PROVINCE)
	private QAFWebElement contactOtherStateProvince;
	@FindBy(locator = CONTACT_OTHER_ZIP_POSTAL_CODE)
	private QAFWebElement contactOtherZipPostalCode;
	@FindBy(locator = CONTACT_WEBSITE)
	private QAFWebElement contactWebsite;
	@FindBy(locator = CONTACT_ASSISTANT)
	private QAFWebElement contactAssistant;
	@FindBy(locator = CONTACT_ASST_PHONE)
	private QAFWebElement contactAsstPhone;
	@FindBy(locator = CONTACT_LEAD_SOURCE)
	private QAFWebElement contactLeadSource;
	@FindBy(locator = CONTACT_CUSTOMER_SENTIMENT)
	private QAFWebElement contactCustomerSentiment;
	@FindBy(locator = CONTACT_SALESFORCE_EMAIL_OPT_OUT)
	private QAFWebElement contactSalesforceEmailOptOut;
	@FindBy(locator = CONTACT_PARDOT_EMAIL_OPT_OUT)
	private QAFWebElement contactPardotEmailOptOut;
	@FindBy(locator = CONTACT_DO_NOT_CALL)
	private QAFWebElement contactDoNotCall;
	@FindBy(locator = CONTACT_DATA_PRIVACY_POLICY_ACCEPTANCE)
	private QAFWebElement contactDataPrivacyPolicyAcceptance;
	@FindBy(locator = CONTACT_LEAD_GEN_PRIVACY_NOTICE_CONSENT)
	private QAFWebElement contactLeadGenPrivacyNoticeConsent;
	@FindBy(locator = CONTACT_SALES_ENGAGEMENT_CONSENT)
	private QAFWebElement contactSalesEngagementConsent;
	@FindBy(locator = CONTACT_ANALYTICS_CONSENT)
	private QAFWebElement contactAnalyticsConsent;
	@FindBy(locator = CONTACT_MARKETING_CONSENT)
	private QAFWebElement contactMarketingConsent;
	@FindBy(locator = CONTACT_SERVICE_OUTBOUND_ACTIVITIES_CONSENT)
	private QAFWebElement contactServiceOutboundActivitiesConsent;
	@FindBy(locator = CONTACT_CUSTOMER_PORTAL_CONSENT)
	private QAFWebElement contactCustomerPortalConsent;
	@FindBy(locator = CONTACT_AUTOMATED_FEEDBACK_FOR_REPAIR)
	private QAFWebElement contactAutomatedFeedbackForRepair;
	@FindBy(locator = CONTACT_INSIGHT_GENERATION)
	private QAFWebElement contactInsightGeneration;
	@FindBy(locator = CONTACT_DATA_STORAGE_AFTER_END_OF_CONTRACT)
	private QAFWebElement contactDataStorageAfterEndOfContract;
	@FindBy(locator = CONTACT_EVENTS_CONSENT)
	private QAFWebElement contactEventsConsent;
	@FindBy(locator = CONTACT_BILLING_PLATFORM_CONSENT)
	private QAFWebElement contactBillingPlatformConsent;
	@FindBy(locator = CONTACT_SURVEY_CONSENT)
	private QAFWebElement contactSurveyConsent;
	@FindBy(locator = CONTACT_RETENTION_AUTOMATED_NOTIFICATION)
	private QAFWebElement contactRetentionAutomatedNotification;
	@FindBy(locator = CONTACT_SERVICE_ADVISORIES)
	private QAFWebElement contactServiceAdvisories;
	@FindBy(locator = CONTACT_USAGE_ANALYSIS)
	private QAFWebElement contactUsageAnalysis;
	@FindBy(locator = CONTACT_LEGACY_SFDC_CONTACT_ID)
	private QAFWebElement contactLegacySfdcContactId;
	@FindBy(locator = CONTACT_LEGACY_CSP_CONTACT_ID)
	private QAFWebElement contactLegacyCspContactId;
	@FindBy(locator = CONTACT_LEGACY_SIEBEL_CONTACT_ID)
	private QAFWebElement contactLegacySiebelContactId;
	@FindBy(locator = CONTACT_LEGACY_SAP_B1_CONTACT_ID)
	private QAFWebElement contactLegacySapB1ContactId;
	@FindBy(locator = CONTACT_LEGACY_DATA_MIGRATION_SOURCE_SYSTEM)
	private QAFWebElement contactLegacyDataMigrationSourceSystem;
	@FindBy(locator = CONTACT_CANCEL_BUTTON)
	private QAFWebElement contactCancelButton;
	@FindBy(locator = CONTACT_SAVE_NEW_BUTTON)
	private QAFWebElement contactSaveNewButton;
	@FindBy(locator = CONTACT_SAVE)
	private QAFWebElement contactSave;
	@FindBy(locator = CONTACT_NEW)
	private QAFWebElement contactNew;

	public QAFWebElement getContactNew() {
		return contactNew;
	}

	public void clickNewContact() {
		getContactNew().click();
	}

	@FindBy(locator = AccCONTACT_NEW)
	private QAFWebElement AccContact;

	public QAFWebElement getAccContactNew() {
		return AccContact;
	}

	public void clickNewAccContact() {
		getAccContactNew().click();
	}

	public void clickSaveButton() {
		getContactSave().click();
		util.waitForGenericToastMessage();

	}

	@FindBy(locator = CONTACT_ACCOUNT_LIST)
	private QAFWebElement contactAccountList;

	public QAFWebElement getContactSalutation() {
		return contactSalutation;
	}

	public QAFWebElement getContactFirstName() {
		return contactFirstName;
	}

	public QAFWebElement getContactMidName() {
		return contactMidName;
	}

	public QAFWebElement getContactLastName() {
		return contactLastName;
	}

	public QAFWebElement getContactSuffix() {
		return contactSuffix;
	}

	public QAFWebElement getContactAccountName() {
		return contactAccountName;
	}

	public QAFWebElement getContactTitle() {
		return contactTitle;
	}

	public QAFWebElement getContactRole() {
		return contactRole;
	}

	public QAFWebElement getContactPartner() {
		return contactPartner;
	}

	public QAFWebElement getContactStatus() {
		return contactStatus;
	}

	public QAFWebElement getContactCurency() {
		return contactCurency;
	}

	public QAFWebElement getContactPhone() {
		return contactPhone;
	}

	public QAFWebElement getContactMobile() {
		return contactMobile;
	}

	public QAFWebElement getContactOtherPhone() {
		return contactOtherPhone;
	}

	public QAFWebElement getContactHomePhone() {
		return contactHomePhone;
	}

	public QAFWebElement getContactFax() {
		return contactFax;
	}

	public QAFWebElement getContactBirthdate() {
		return contactBirthdate;
	}

	public QAFWebElement getContactGender() {
		return contactGender;
	}

	public QAFWebElement getContactCivilStatus() {
		return contactCivilStatus;
	}

	public QAFWebElement getContactDriversLicenseNumber() {
		return contactDriversLicenseNumber;
	}

	public QAFWebElement getContactTaxId() {
		return contactTaxId;
	}

	public QAFWebElement getContactEmail() {
		return contactEmail;
	}

	public QAFWebElement getContactEmployee() {
		return contactEmployee;
	}

	public QAFWebElement getContactEmployer() {
		return contactEmployer;
	}

	public QAFWebElement getContactEmploymentStatus() {
		return contactEmploymentStatus;
	}

	public QAFWebElement getContactDepartment() {
		return contactDepartment;
	}

	public QAFWebElement getContactMailingAddress() {
		return contactMailingAddress;
	}

	public QAFWebElement getContactMailingCountry() {
		return contactMailingCountry;
	}

	public QAFWebElement getContactMailingStreet() {
		return contactMailingStreet;
	}

	public QAFWebElement getContactMailingCity() {
		return contactMailingCity;
	}

	public QAFWebElement getContactMailingStateProvince() {
		return contactMailingStateProvince;
	}

	public QAFWebElement getContactMailingZipPostalCode() {
		return contactMailingZipPostalCode;
	}

	public QAFWebElement getContactOtherAddress() {
		return contactOtherAddress;
	}

	public QAFWebElement getContactOtherCountry() {
		return contactOtherCountry;
	}

	public QAFWebElement getContactOtherStreet() {
		return contactOtherStreet;
	}

	public QAFWebElement getContactOtherCity() {
		return contactOtherCity;
	}

	public QAFWebElement getContactOtherStateProvince() {
		return contactOtherStateProvince;
	}

	public QAFWebElement getContactOtherZipPostalCode() {
		return contactOtherZipPostalCode;
	}

	public QAFWebElement getContactWebsite() {
		return contactWebsite;
	}

	public QAFWebElement getContactAssistant() {
		return contactAssistant;
	}

	public QAFWebElement getContactAsstPhone() {
		return contactAsstPhone;
	}

	public QAFWebElement getContactLeadSource() {
		return contactLeadSource;
	}

	public QAFWebElement getContactCustomerSentiment() {
		return contactCustomerSentiment;
	}

	public QAFWebElement getContactSalesforceEmailOptOut() {
		return contactSalesforceEmailOptOut;
	}

	public QAFWebElement getContactPardotEmailOptOut() {
		return contactPardotEmailOptOut;
	}

	public QAFWebElement getContactDoNotCall() {
		return contactDoNotCall;
	}

	public QAFWebElement getContactDataPrivacyPolicyAcceptance() {
		return contactDataPrivacyPolicyAcceptance;
	}

	public QAFWebElement getContactLeadGenPrivacyNoticeConsent() {
		return contactLeadGenPrivacyNoticeConsent;
	}

	public QAFWebElement getContactSalesEngagementConsent() {
		return contactSalesEngagementConsent;
	}

	public QAFWebElement getContactAnalyticsConsent() {
		return contactAnalyticsConsent;
	}

	public QAFWebElement getContactMarketingConsent() {
		return contactMarketingConsent;
	}

	public QAFWebElement getContactServiceOutboundActivitiesConsent() {
		return contactServiceOutboundActivitiesConsent;
	}

	public QAFWebElement getContactCustomerPortalConsent() {
		return contactCustomerPortalConsent;
	}

	public QAFWebElement getContactAutomatedFeedbackForRepair() {
		return contactAutomatedFeedbackForRepair;
	}

	public QAFWebElement getContactInsightGeneration() {
		return contactInsightGeneration;
	}

	public QAFWebElement getContactDataStorageAfterEndOfContract() {
		return contactDataStorageAfterEndOfContract;
	}

	public QAFWebElement getContactEventsConsent() {
		return contactEventsConsent;
	}

	public QAFWebElement getContactBillingPlatformConsent() {
		return contactBillingPlatformConsent;
	}

	public QAFWebElement getContactSurveyConsent() {
		return contactSurveyConsent;
	}

	public QAFWebElement getContactRetentionAutomatedNotification() {
		return contactRetentionAutomatedNotification;
	}

	public QAFWebElement getContactServiceAdvisories() {
		return contactServiceAdvisories;
	}

	public QAFWebElement getContactUsageAnalysis() {
		return contactUsageAnalysis;
	}

	public QAFWebElement getContactLegacySfdcContactId() {
		return contactLegacySfdcContactId;
	}

	public QAFWebElement getContactLegacyCspContactId() {
		return contactLegacyCspContactId;
	}

	public QAFWebElement getContactLegacySiebelContactId() {
		return contactLegacySiebelContactId;
	}

	public QAFWebElement getContactLegacySapB1ContactId() {
		return contactLegacySapB1ContactId;
	}

	public QAFWebElement getContactLegacyDataMigrationSourceSystem() {
		return contactLegacyDataMigrationSourceSystem;
	}

	public QAFWebElement getContactCancelButton() {
		return contactCancelButton;
	}

	public QAFWebElement getContactSaveNewButton() {
		return contactSaveNewButton;
	}

	public QAFWebElement getContactSave() {
		return contactSave;
	}

	public QAFWebElement getcontactAccountList() {
		return contactAccountList;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public void enterAccountName(String accountName) {
		map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
		util.enterText(getContactAccountName(), accountName);
		getcontactAccountList().findElement(By.xpath("//[@title='" + map.get("accountName") + "']")).click();
	}

	public void contactInformation() {
		bean.fillRandomData();
		// util.select("Salutation");
		util.select("Salutation", bean.RandomSalutation());
		// util.type("First Name");
		String Contact_FirstName = bean.getFirstName();
		util.type("First Name", Contact_FirstName);
		pageProps.setProperty("Contact.Name", Contact_FirstName);
		// util.type("Middle Name");
		String Contact_MiddleName = bean.getMiddleName();
		util.type("Middle Name", Contact_MiddleName);
		// util.type("Last Name");
		String Contact_LastName = bean.getLastName();
		util.type("Last Name", Contact_LastName);
		// util.type("Suffix");
		String Contact_Suffix = bean.getSuffix();
		util.type("Suffix", Contact_Suffix);

		String contactName = Contact_FirstName + " " + Contact_MiddleName + " " + Contact_LastName + " "
				+ Contact_Suffix;
		Map<String, Object> map = (Map<String, Object>) pageProps.getObject("testdata");
		String contactRole = (String) map.get("Contact Roles");

		if (contactRole.equalsIgnoreCase("Bill Recipient")) {
			pageProps.setProperty("contact.BillRecipient", contactName);
		} else if (contactRole.equalsIgnoreCase("Delivery Recipient - Smart")) {
			pageProps.setProperty("contact.DeliveryRecipient", contactName);
		} else if (contactRole.equalsIgnoreCase("Technical")) {
			pageProps.setProperty("contact.Technical", contactName);
		}
			// enterAccountName("Account Name");
			util.waitFor(3);
//			util.selectAndClickCaseSuggestedValueShowAll("Account Name");
			util.waitFor(3);
			util.select("Contact Roles");
			util.waitFor(3);
			util.type("Title");
			util.click("Partner");
			util.select("Status");
			// util.select("Contact Currency");
		
	}

	public void contactNumbers() {
		bean.fillRandomData();
		String contact_personalPhoneNum = String.format("639%s", bean.getPhone_mobile().toString());
		contact_personalPhoneNum = StringUtils.rightPad(contact_personalPhoneNum, 12, "0");
		util.type("Mobile", contact_personalPhoneNum);
		util.type("Phone", contact_personalPhoneNum);
		if (!(pageProps.getPropertyValue("accountRecType").equalsIgnoreCase("Enterprise Extension"))) {
		util.type("Other Phone", contact_personalPhoneNum);
		util.type("Home Phone", contact_personalPhoneNum);
		}
		util.type("Fax", contact_personalPhoneNum);

	}

	public void personalInformation() {
		bean.fillRandomData();
//		util.type("Birthdate");
		util.enterText(contactBirthdate, DateUtil.getDate(-7120, "MM/dd/yyyy"));
		util.select("Sex");
		if (!(pageProps.getPropertyValue("accountRecType").equalsIgnoreCase("Enterprise Extension"))) {
		util.type("Civil Status");
		}
		QAFExtendedWebElement Drivers = new QAFExtendedWebElement(
				"xpath=//input[@name='vlocity_cmt__DriversLicenseNumber__c']");
		String licence = Long.toString(bean.getNumber());
		Drivers.sendKeys(licence);
//		util.type("Driver's License Number");
		// util.type("Email");
		String contactEmail = pageProps.getPropertyValue("Contact.Name") + "@gmail.com";
		util.type("Email", contactEmail);
		String taxid = Long.toString(bean.getPhone_mobile());
		taxid = StringUtils.rightPad(taxid, 9, "0");
		util.type("Tax ID", taxid);
		if ((pageProps.getPropertyValue("accountRecType").equalsIgnoreCase("Enterprise Extension"))) {
			util.select("Nationality");
		}

	}

	public void employeeDetails() {
		util.click("Employee");
//		enterAccountName("Employer");
		util.select("Employment Status");
		util.type("Department");

	}

	public void addressInformation() {
		util.type("Mailing Address");
		util.select("Mailing Country");
		util.type("Mailing Street");
		util.type("Mailing City");
		util.select("Mailing State/Province");
		util.type("Mailing Zip/Postal Code");
		util.type("Other Address");
		util.select("Other Country");
		util.typeIntoTextArea("Other Street");
		util.type("Other City");
		util.select("Other State/Province");
		util.type("Other Zip/Postal Code");

	}

	public void additionalInformation() {
		bean.fillRandomData();
		String Contact_CompanyWebsite = "wwww." + pageProps.getPropertyValue("Contact.Name") + ".com";
		util.type("Web Site", Contact_CompanyWebsite);
		if (!(pageProps.getPropertyValue("accountRecType").equalsIgnoreCase("Enterprise Extension"))) {
		util.type("Assistant", bean.getOther());
		String assit_personalPhoneNum = String.format("639%s", bean.getPhone_mobile().toString());
		assit_personalPhoneNum = StringUtils.rightPad(assit_personalPhoneNum, 12, "0");
		util.type("Asst. Phone", assit_personalPhoneNum);
		util.select("Lead Source");
		
		util.select("Customer Sentiment");
		}
	}

	public void consentManagement() {
		util.click("Salesforce Email Opt Out");
		util.click("Pardot Email Opt Out");
		util.click("Do Not Call");
		util.click("Data Privacy Policy Acceptance");
		util.click("Lead Gen Privacy Notice Consent");
		util.click("Sales Engagement Consent");

	}

	public void marketingConsentManagement() {
		util.click("Analytics Consent");
		util.click("Marketing Consent");
		util.click("Service Outbound Activities Consent");
		util.click("Automated Feedback for Repair");
		util.click("Insight Generation");
		util.click("Data Storage After End of Contract");
		util.click("Events Consent");
		util.click("Billing Platform Consent");
		util.click("Survey Consent");
		util.click("Retention Automated Notification");
		util.click("Customer Portal Consent");
		util.click("Service Advisories");
		util.click("Usage Analysis");

	}

	public void legacySystemNumbers() {
		util.type("Legacy SFDC Contact Id");
		util.type("Legacy CSP Contact ID");
		util.type("Legacy Siebel Contact ID");
		util.type("Legacy SAP B1 Contact ID");
		util.type("Legacy Data Migration Source System");

	}

	public void fillContactForm() {
		contactInformation();
		contactNumbers();
		personalInformation();
		employeeDetails();
//		addressInformation();
		additionalInformation();
//		consentManagement();
//		marketingConsentManagement();
//		legacySystemNumbers();
	}

	public void filterContact(String Type) {
		PageLib p = new PageLib();
		p.getCaseListPage().getListview().click();
		util.waitFor(2);
		p.getCaseListPage().getFilterCaseSearchBox().sendKeys(Type);
		util.waitFor(5);
		driver.findElement(By.xpath("//mark[text()='" + Type + "']")).click();
		util.waitTillLoaderDissapear();
	}

	public void openContact(String Name) {
		util.clickUsingJs(By.xpath("//a[.='" + Name + "']"));
		util.waitForContactPage();
	}

	public void editTitle() {
		bean.fillRandomData();
		util.scrollIntoElement(By.xpath("//span[.='Title']"));
		util.clickUsingJs(By.xpath("(//button[@title='Edit Title'])"));
		util.waitFor(By.xpath("//input[@name='Title']"), 10, true);
		util.waitFor(3);
		String Name = bean.getFirstName();
		driver.findElement(By.xpath("(//label[text()='Title']/following::input)[1]")).sendKeys(Name);
		Reporter.logWithScreenShot("New Title :" + Name);
		util.waitFor(3);
		util.clickUsingActions(By.xpath("(//label[.='Title'])"));

	}
}
