package com.pldt.pages;

import java.util.Map;

import org.openqa.selenium.interactions.Actions;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SyniverseDisconnectPage extends SyniverseHomePage {
	WebUtilities util = new WebUtilities();
	@FindBy(locator = "xpath=//div[@id='dropmenudiv']/a[text()='Disconnect Request']")
	private QAFWebElement DisconnectRequestLink;
	@FindBy(locator = "xpath=//input[@name='value(sOwnerId)']")
	private QAFWebElement OwnerID;
	@FindBy(locator = "xpath=//input[@name='value(sRegistrationCode)']")
	private QAFWebElement BRN;
	@FindBy(locator = "xpath=//input[@name='value(sSubscriberNumber)']")
	private QAFWebElement PortingNumber;
	@FindBy(locator = "xpath=//input[@name='value(FromSubDate)']")
	private QAFWebElement SubmissionDateFrom;
	@FindBy(locator = "xpath=//input[@name='value(ToSubDate)']")
	private QAFWebElement SubmissionDateTo;
	@FindBy(locator = "xpath=//select[@name='value(SortBy)']")
	private QAFExtendedWebElement SortBy;
	@FindBy(locator = "xpath=//input[@value='Search']")
	private QAFWebElement SearchButton;
	@FindBy(locator = "xpath=//input[@value='Reset']")
	private QAFWebElement ResetButton;
	@FindBy(locator = "xpath=//input[@name='value(method1)' and @value='Answer']")
	private QAFWebElement AnswerButton;
	@FindBy(locator = "xpath=//input[@name='downloadCSV']")
	private QAFWebElement DownloadAsCSVButton;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getDisconnectRequestLink() {
		return DisconnectRequestLink;
	}

	public QAFWebElement getOwnerID() {
		return OwnerID;
	}

	public QAFWebElement getBRN() {
		return BRN;
	}

	public QAFWebElement getPortingNumber() {
		return PortingNumber;
	}

	public QAFWebElement getSubmissionDateFrom() {
		return SubmissionDateFrom;
	}

	public QAFWebElement getSubmissionDateTo() {
		return SubmissionDateTo;
	}

	public QAFExtendedWebElement getSortBy() {
		return SortBy;
	}

	public QAFWebElement getSearchButton() {
		return SearchButton;
	}

	public QAFWebElement getResetButton() {
		return ResetButton;
	}

	public QAFWebElement getAnswerButton() {
		return AnswerButton;
	}

	public QAFWebElement getDownloadAsCSVButton() {
		return DownloadAsCSVButton;
	}

	public void ClickDisconnectRequest() {
		Actions action = new Actions(driver);
		action.moveToElement(getRPLink()).perform();
		getDisconnectRequestLink().click();
	}

	public void DisconnectRequest(Map<String, String> data) {
		getPortingNumber().sendKeys(data.get("PortingNumber"));
		getSubmissionDateFrom().sendKeys(data.get("SubmissionDateFrom"));
		getSubmissionDateTo().sendKeys(data.get("SubmissionDateTo"));
		util.selectBy(getSortBy(), data.get("SortBy"));
		getSearchButton().click();
	}
}
