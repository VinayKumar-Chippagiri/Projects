package com.pldt.pages;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.enums.WaitFor;
import com.pldt.lib.PageLib;
import com.pldt.locators.CartPageLocators;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.JSONUtil;
import com.qmetry.qaf.automation.util.Reporter;
import org.openqa.selenium.support.ui.Select;

public class CartPage extends WebDriverBaseTestPage<WebDriverTestPage> implements CartPageLocators {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	@FindBy(locator = SelectPriceList)
	private QAFWebElement selectPriceList;
	@FindBy(locator = EnterpricePHPprice)
	private QAFWebElement enterpricePHPprice;
	@FindBy(locator = ProductSearchBox)
	private QAFWebElement productSearchBox;
	@FindBy(locator = AddToCart)
	private QAFWebElement addToCart;
	@FindBy(locator = RecurringCharges)
	private QAFWebElement recurringCharges;
	@FindBy(locator = EditPriceBtn)
	private QAFWebElement editPriceBtn;
	@FindBy(locator = AdjustmentDropdown)
	private QAFWebElement adjustmentDropdown;
	@FindBy(locator = SelectAmount)
	private QAFWebElement selectAmount;
	@FindBy(locator = EnterAmount)
	private QAFWebElement enterAmount;
	@FindBy(locator = Apply)
	private QAFWebElement apply;
	@FindBy(locator = ViewRecord)
	private QAFWebElement viewRecord;
	@FindBy(locator = DeviceConfigurationBtn)
	private QAFWebElement deviceConfigurationBtn;
	@FindBy(locator = ConfigureDevice)
	private QAFWebElement configureDevice;
	@FindBy(locator = Apply)
	private QAFWebElement apply1;
	@FindBy(locator = DeviceArrow)
	private QAFWebElement deviceArrow;
	@FindBy(locator = DeviceCapacity)
	private QAFWebElement deviceCapacity;
	@FindBy(locator = RecurringCharges2)
	private QAFWebElement recurringCharges2;
	@FindBy(locator = RecurringTotal2)
	private QAFWebElement recurringTotal2;
	@FindBy(locator = Menu)
	private QAFWebElement menu;
	@FindBy(locator = AddChildProduct)
	private QAFWebElement addChildVideo;
	@FindBy(locator = SearchChildProduct)
	private QAFWebElement searchChildProduct;
	@FindBy(locator = AddChildProduct2)
	private QAFWebElement addChildProduct2;
	@FindBy(locator = DetailIconMenu)
	private QAFWebElement detailIconMenu;
	@FindBy(locator = SearchDevice)
	private QAFWebElement searchDevice;
	@FindBy(locator = SelectDeviceSuggestion)
	private QAFWebElement selectDeviceSuggestion;
	@FindBy(locator = ConfigureDeviceDrop)
	private QAFWebElement configureDeviceDrop;
	@FindBy(locator = DeletePlan)
	private QAFWebElement deletePlan;
	@FindBy(locator = ConfirmDelete)
	private QAFWebElement confirmDelete;
	@FindBy(locator = PaymentType)
	private QAFWebElement paymentType;
	@FindBy(locator = PaymentType2)
	private QAFWebElement paymentType2;
	@FindBy(locator = EnterSmartPricePricing)
	private QAFWebElement enterSmartPricePricing;
	@FindBy(locator = EnterEnterprisePHPPricing)
	private QAFWebElement enterEnterprisePHPPricing;
	@FindBy(locator = ConfigureDeviceDropDown)
	private QAFWebElement configureDeviceDropDown;
	@FindBy(locator = ConfigureDevicePlan)
	private QAFWebElement configureDevicePlan;
	@FindBy(locator = ConfigureDevicePlan2)
	private QAFWebElement configureDevicePlan2;
	@FindBy(locator = DevicePaymentType)
	private QAFWebElement devicePaymentType;
	@FindBy(locator = DevicePaymentType2)
	private QAFWebElement devicePaymentType2;
	@FindBy(locator = DeviceCapacity3)
	private QAFWebElement deviceCapacity3;
	@FindBy(locator = DeviceCapacity2)
	private QAFWebElement deviceCapacity2;
	@FindBy(locator = DeviceColor)
	private QAFWebElement deviceColor;
	@FindBy(locator = DeviceColor2)
	private QAFWebElement deviceColor2;
	@FindBy(locator = Close)
	private QAFWebElement close;
	@FindBy(locator = DeviceRecurringChareges)
	private QAFWebElement deviceRecurringChareges;
	@FindBy(locator = DeviceOneTimeCharges)
	private QAFWebElement deviceOneTimeCharges;
	@FindBy(locator = PlanRecurringTotal)
	private QAFWebElement planRecurringTotal;
	@FindBy(locator = PlanOneTimeTotal)
	private QAFWebElement planOneTimeTotal;
	@FindBy(locator = DeviceRecurringTotal)
	private QAFWebElement deviceRecurringTotal;
	@FindBy(locator = DeviceOneTimeTotal)
	private QAFWebElement deviceOneTimeTotal;
	@FindBy(locator = SearchDevice2)
	private QAFWebElement searchDevice2;
	@FindBy(locator = PlanConfig)
	private QAFWebElement planConfig;
	@FindBy(locator = UpdateAccount)
	private QAFWebElement updateAccount;
	@FindBy(locator = SearchBillAccount)
	private QAFWebElement searchBillAccount;
	@FindBy(locator = BillAccountCheckBox)
	private QAFWebElement billAccountCheckBox;
	@FindBy(locator = SearchServiceAccount)
	private QAFWebElement searchServiceAccount;
	@FindBy(locator = ServiceAccountCheckBox)
	private QAFWebElement serviceAccountCheckBox;
	@FindBy(locator = Save)
	private QAFWebElement save;

	public QAFWebElement getSearchBillAccount() {
		return searchBillAccount;
	}

	public QAFWebElement getSearchServiceAccount() {
		return searchServiceAccount;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
	}

	public QAFWebElement getSelectPriceList() {
		return selectPriceList;
	}

	public QAFWebElement getEnterpricePHPprice() {
		return enterpricePHPprice;
	}

	public QAFWebElement getProductSearchBox() {
		return productSearchBox;
	}

	public QAFWebElement getAddToCart() {
		return addToCart;
	}

	public QAFWebElement getRecurringCharges() {
		return recurringCharges;
	}

	public QAFWebElement getEditPriceBtn() {
		return editPriceBtn;
	}

	public QAFWebElement getAdjustmentDropdown() {
		return adjustmentDropdown;
	}

	public QAFWebElement getSelectAmount() {
		return selectAmount;
	}

	public QAFWebElement getEnterAmount() {
		return enterAmount;
	}

	public QAFWebElement getApply() {
		return apply;
	}

	public QAFWebElement getViewRecord() {
		return viewRecord;
	}

	public QAFWebElement getDeviceConfigurationBtn() {
		return deviceConfigurationBtn;
	}

	public QAFWebElement getConfigureDevice() {
		return configureDevice;
	}

	public QAFWebElement getApply1() {
		return apply1;
	}

	public QAFWebElement getDeviceArrow() {
		return deviceArrow;
	}

	public QAFWebElement getDeviceCapacity() {
		return deviceCapacity;
	}

	public QAFWebElement getRecurringCharges2() {
		return recurringCharges2;
	}

	public QAFWebElement getRecurringTotal2() {
		return recurringTotal2;
	}

	public QAFWebElement getMenu() {
		return menu;
	}

	public QAFWebElement getAddChildVideo() {
		return addChildVideo;
	}

	public QAFWebElement getSearchChildProduct() {
		return searchChildProduct;
	}

	public QAFWebElement getAddChildProduct2() {
		return addChildProduct2;
	}

	public QAFWebElement getDetailIconMenu() {
		return detailIconMenu;
	}

	public QAFWebElement getSearchDevice() {
		return searchDevice;
	}

	public QAFWebElement getSelectDeviceSuggestion() {
		return selectDeviceSuggestion;
	}

	public QAFWebElement getConfigureDeviceDrop() {
		return configureDeviceDrop;
	}

	public QAFWebElement getDeletePlan() {
		return deletePlan;
	}

	public QAFWebElement getConfirmDelete() {
		return confirmDelete;
	}

	public QAFWebElement getPaymentType() {
		return paymentType;
	}

	public QAFWebElement getPaymentType2() {
		return paymentType2;
	}

	public QAFWebElement getEnterSmartPricePricing() {
		return enterSmartPricePricing;
	}

	public QAFWebElement getEnterEnterprisePHPPricing() {
		return enterEnterprisePHPPricing;
	}

	public QAFWebElement getConfigureDeviceDropDown() {
		return configureDeviceDropDown;
	}

	public QAFWebElement getConfigureDevicePlan() {
		return configureDevicePlan;
	}

	public QAFWebElement getConfigureDevicePlan2() {
		return configureDevicePlan2;
	}

	public QAFWebElement getDevicePaymentType() {
		return devicePaymentType;
	}

	public QAFWebElement getDevicePaymentType2() {
		return devicePaymentType2;
	}

	public QAFWebElement getDeviceCapacity3() {
		return deviceCapacity3;
	}

	public QAFWebElement getDeviceCapacity2() {
		return deviceCapacity2;
	}

	public QAFWebElement getDeviceColor() {
		return deviceColor;
	}

	public QAFWebElement getDeviceColor2() {
		return deviceColor2;
	}

	public QAFWebElement getClose() {
		return close;
	}

	public QAFWebElement getDeviceRecurringChareges() {
		return deviceRecurringChareges;
	}

	public QAFWebElement getDeviceOneTimeCharges() {
		return deviceOneTimeCharges;
	}

	public QAFWebElement getPlanRecurringTotal() {
		return planRecurringTotal;
	}

	public QAFWebElement getPlanOneTimeTotal() {
		return planOneTimeTotal;
	}

	public QAFWebElement getDeviceRecurringTotal() {
		return deviceRecurringTotal;
	}

	public QAFWebElement getDeviceOneTimeTotal() {
		return deviceOneTimeTotal;
	}

	public QAFWebElement getSearchDevice2() {
		return searchDevice2;
	}

	public QAFWebElement getPlanConfig() {
		return planConfig;
	}

	public QAFWebElement getUpdateAccount() {
		return updateAccount;
	}

	public QAFWebElement getBillAccountCheckBox() {
		return billAccountCheckBox;
	}

	public QAFWebElement getServiceAccountCheckBox() {
		return serviceAccountCheckBox;
	}

	public QAFWebElement getSave() {
		return save;
	}
//	Created by Vinay to Add Second ProductsToCart in Working Cart
//	public void QuickActionsAddProductsToCart(Map<String, String> data) {
//		util.refreshSwitchToFrame();
//		util.AttachFrame();
//		util.typeDataTo(getProductSearchBox(), data.get("SecondPlanName").toString());
//		getProductSearchBox().sendKeys(Keys.BACK_SPACE);
//		util.typeDataTo(getProductSearchBox(),
//				data.get("SecondPlanName").toString().charAt(data.get("SecondPlanName").toString().length() - 1) + "");
//		util.clickUsingJs(By.xpath("//span[text()='" + data.get("SecondPlanName").toString().trim()
//				+ "']/parent::*/parent::*/following-sibling::div//button"));
//		util.waitForCartPageToastMessage();
//		util.waitFor(15);
////		addAddonsto5GPlans(data.get("Addons"));
////		util.waitForCartPageToastMessage();
//		util.refreshSwitchToFrame();
//		util.AttachFrame();
//		util.clickUsingJs(By.xpath("//button[@title='Save Working Cart']"));
//		util.waitFor(By.xpath("//h1//span[.='Working Cart']"), 20, true);
//		if (util.isElementDisplayed(By.xpath("//h1//span[.='Working Cart']"))) {
//			util.clickUsingJs(By.xpath("//span[.='Parent Quote']/following::div[1]/span//a"));
//		} else {
//			util.waitForQuotePage();
//		}
//	}

	public void ConfigureCart(Map<String, String> data) {
		util.clickUsingJs(By.xpath("//div[text()='Price List']//parent::div/button"));
		util.clickUsingJs(By.xpath("//span[text()='SMART Price List']"));
		util.typeDataTo(getProductSearchBox(), data.get("Plan").toString());
		getProductSearchBox().sendKeys(Keys.BACK_SPACE);
		util.typeDataTo(getProductSearchBox(),
				data.get("Plan").toString().charAt(data.get("Plan").toString().length() - 1) + "");
		util.clickUsingJs(By.xpath("//span[text()='" + data.get("Plan").toString().trim()
				+ "']/parent::*/parent::*/following-sibling::div//button"));
		util.waitForCartPageToastMessage();
		util.clickUsingJs(getDeviceArrow());
		util.clickUsingJs(driver.findElement(By.xpath("//*[@step='any']")));
		driver.findElement(By.xpath("//*[@step='any']")).clear();
		util.enterTextUsingJs(driver.findElement(By.xpath("//*[@step='any']")), data.get("Order Quantity").toString());
		driver.findElement(By.xpath("//*[@step='any']")).sendKeys(Keys.BACK_SPACE);
		util.typeDataTo(driver.findElement(By.xpath("//*[@step='any']")),
				data.get("Order Quantity").toString().charAt(data.get("Order Quantity").toString().length() - 1) + "");
		util.waitForCartPageToastMessage();
		AddChildDevice(data.get("DeviceName").toString(), data.get("paymentType").toString(),
				data.get("DeviceCapcity").toString(), data.get("DeviceColor").toString());
		if (data.get("Plan").contains("5G") && data.get("SecondDevice").contains("Y")) {
			AddChildDevice2(data.get("SecondDeviceName").toString(), data.get("SecondpaymentType").toString(),
					data.get("SecondDeviceCapcity").toString(), data.get("SecondDeviceColor").toString());
			addAddonsto5GPlans(data.get("Addons"), data);
			DiscountOn5GPlan(data.get("DiscountOnPlanMSF"));
		}
		clickOnViewRecord();
	}

	public void DiscountOn5GPlan(String DicountedPrice) {
		util.clickUsingJs(By.xpath("(//span[@class='cpq-underline'])[1]/span/span"));
		util.clickUsingJs(By.xpath("(//button[@title='Change Price'])[1]"));
		changePrice(DicountedPrice);
	}

	public void DiscountOnDevice(String DicountedPrice) {
		util.scrollIntoElement(By.xpath(
				"//span[text()='Devices']/following::div[contains(@class,'cpq-item-base-product-currency')][5]"));
		util.clickUsingActions(By.xpath(
				"//span[text()='Devices']/following::div[contains(@class,'cpq-item-base-product-currency')][5]"));
		util.clickUsingJs(By.xpath("(//button[@title='Change Price'])[4]"));
		changePrice(DicountedPrice);
	}

	public void changePrice(String DicountedPrice) {
		util.clickUsingJs(By.xpath("//button[@id='cpq-custom-adjustment-view-button']"));
		util.clickUsingJs(By.xpath("//span[contains(text(),'Override')]"));
		driver.findElement(By.xpath("//input[@id='adjustment-input-01']")).sendKeys(DicountedPrice);
		util.clickUsingJs(By.xpath("//button[text()[contains(.,'Apply')]]"));
		util.waitFor(By.xpath("//button[text()[contains(.,'Apply')]]"), 10, false);
		try {
			driver.findElement(By.xpath("//button[contains(text(),'Close')]")).click();
//			util.clickUsingJs(By.xpath("//button[contains(text(),'Close')]"));
		} catch (Exception e) {
		}
		util.waitFor(5);
	}

	public void addAddonsto5GPlans(String Addons, Map<String, String> data) {
		try {
			if (data.get("Plan").contains("BYOD")) {
				String s = driver.findElement(By.xpath("(//span[.='Toggle'])[3]/parent::*//*[local-name()='svg']"))
						.getAttribute("class");
				if (s.contains("cpq-fix-slds-close-switch")) {
					util.clickUsingJs(
							driver.findElement(By.xpath("(//button[@class='slds-button slds-button_icon-small'])[2]")));
					System.out.println("Click on device arrow");
				}

			} else {
				String s = driver.findElement(By.xpath("(//span[.='Toggle'])[6]/parent::*//*[local-name()='svg']"))
						.getAttribute("class");
				if (s.contains("cpq-fix-slds-close-switch")) {
					util.clickUsingJs(
							driver.findElement(By.xpath("(//button[@class='slds-button slds-button_icon-small'])[4]")));
					System.out.println("Click on device arrow");
				}
			}
		} catch (Exception e) {
		}
		String[] split = Arrays.stream(Addons.split(",")).map(String::trim).toArray(String[]::new);
		for (String Addon : split) {
			System.out.println("Add Addons to 5G Plan | " + Addon);

			if (data.get("Plan").contains("BYOD")) {
				util.waitFor(10);
				driver.findElement(By.xpath("(//input[@placeholder='Search'])[3]")).sendKeys(Addon);
			} else {
				util.waitFor(5);
				driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).sendKeys(Addon);
			}
			String selectAddon = "//div[text()='" + Addon + "']";
			util.clickUsingJs(By.xpath(selectAddon));
			util.waitForCartPageToastMessage();
			util.waitFor(By.xpath("//div[@class='cpq-product-name-block cpq-item-child-product-name-wrapper']"), 10,
					true);
			// util.clickDropdownValue(selectAddon);
			util.waitFor(10);
			if (data.get("Plan").contains("BYOD")) {
				util.waitFor(10);
				driver.findElement(By.xpath("(//input[@placeholder='Search'])[3]")).clear();
			} else {
				util.waitFor(5);
				driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).clear();
			}
			util.waitFor(10);
		}
	}

	public void clickOnViewRecord() {
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//button[@title='View Record']"));
		driver.switchTo().defaultContent();
		util.waitForOpportunityPage();
	}
	
	public void AddBroChildDevice(String deviceName) {
		try {
			addDeviceToPlan(deviceName);
			util.waitFor(25);
		} catch (Exception e2) {
		}
	}

	public void AddChildDevice(String deviceName, String paymentType, String capacity, String color) {
		try {
			addDeviceToPlan(deviceName);
			util.waitFor(25);
			deviceConfiguration();
		} catch (Exception e2) {
		}
		try {
			if (!paymentType.isEmpty())
				selectDevicePaymentType(paymentType);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			if (!capacity.isEmpty())
				selectDeviceCapacity(capacity);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (!color.isEmpty())
				selectColor(color);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AppUtils.cartPageSaveButton();
		util.waitFor(5);
//		try {
//			QAFWebElement e = new QAFExtendedWebElement(By.xpath("//div[@class='slds-col slds-align-middle']/h2"));
//			e.waitForNotVisible(10000);
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		util.clickUsingJs(By
//				.xpath("//div[@class='cpq-product-container']//*[local-name()='svg'][@alt=\"close\"]/parent::button"));
	}

	public void AddChildDevice2(String deviceName, String paymentType, String capacity, String color) {
		try {
			addDeviceToPlan(deviceName);
			deviceConfiguration2();
		} catch (Exception e2) {
		}
		try {
			if (!paymentType.isEmpty())
				selectDevicePaymentType(paymentType);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			if (!capacity.isEmpty())
				selectDeviceCapacity(capacity);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (!color.isEmpty())
				selectColor(color);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			QAFWebElement e = new QAFExtendedWebElement(By.xpath("//div[@class='slds-col slds-align-middle']/h2"));
			e.waitForNotVisible(10000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		AppUtils.cartPageSaveButton();
		util.waitFor(5);
//		util.clickUsingJs(By
//				.xpath("//div[@class='cpq-product-container']//*[local-name()='svg'][@alt=\"close\"]/parent::button"));
	}

	public void selectDeviceCapacity(String capacity) {
		System.out.println("Select Device Capacity | " + capacity);
		try {
			try {
//				util.selectBy(driver.findElement(By.xpath("//select[@name='productconfig_field_1_1']")), capacity);
				util.selectBy(
						driver.findElement(By.xpath("//form//label[contains(.,'Capacity')]//following::select[1]")),
						capacity);
			} catch (Exception e) {
				util.selectBy(driver.findElement(By.xpath(
						"//form[@name='productconfig']//label[text()[normalize-space(.)='Capacity']]//following::select[1]")),
						capacity);
			}
			util.waitForCartPageToastMessage();
			util.waitElementtoBecomeInvisble();
			util.waitFor(10);
		} catch (Exception e) {
		}
	}

	public void selectDevicePaymentType(String paymentType) {
		System.out.println("Select Payment type | " + paymentType);
		try {
			util.selectBy(driver.findElement(By.xpath(
					"//form[@name='productconfig']//label[text()[normalize-space(.)='Device Payment Type']]//following::select[1]")),
					paymentType);
		} catch (Exception e) {
			util.selectBy(
					driver.findElement(
							By.xpath("//form//label[contains(.,'Device Payment Type')]//following::select[1]")),
					paymentType);
		}
		util.waitForCartPageToastMessage();
	}

	public void selectColor(String color) {
		System.out.println("Select device color | " + color);
		util.scrollIntoElement(By.xpath("//form//label[contains(.,'Color')]//following::select[1]"));
		try {
			util.selectBy(driver.findElement(By.xpath("//form//label[contains(.,'Color')]//following::select[1]")),
					color);
		} catch (Exception e) {
			util.selectBy(driver.findElement(By.xpath(
					"//form[@name='productconfig']//label[text()[normalize-space(.)='Color']]//following::select[1]")),
					color);
		}
//		util.waitElementtoBecomeInvisble();
//		util.waitForCartPageToastMessage();
		util.waitFor(8);
	}

	public void deviceConfiguration() {
		System.out.println("Configure device...");
		util.clickUsingJs(By.xpath(
				"(//button[@class='slds-button slds-button_icon-border-filled cpq-item-actions-dropdown-button'])[2]"));
		util.waitFor(By.xpath("(//span[contains(.,'Configure')])[2]"), 10, true);
		driver.findElement(By.xpath("(//span[contains(.,'Configure')])[2]")).click();
	}

	public void deviceConfiguration2() {
		System.out.println("Configure device...");
		util.clickUsingJs(By.xpath(
				"(//button[@class='slds-button slds-button_icon-border-filled cpq-item-actions-dropdown-button'])[3]"));
		driver.findElement(By.xpath("(//span[contains(.,'Configure')])[3]")).click();
	}

	@SuppressWarnings("static-access")
	public void addDeviceToPlan(String deviceName) {
		System.out.println("Add device to plan | " + deviceName);
		try {
			String s = driver.findElement(By.xpath("(//span[.='Toggle'])[2]/parent::*//*[local-name()='svg']"))
					.getAttribute("class");
			if (s.contains("cpq-fix-slds-close-switch")) {
				util.clickUsingJs(
						driver.findElement(By.xpath("(//button[@class='slds-button slds-button_icon-small'])[1]")));
				System.out.println("Click on device arrow");
			}
		} catch (Exception e) {
		}
		driver.findElement(By.xpath("(//input[@placeholder='Search'])[2]")).sendKeys(deviceName);
		System.out.print(deviceName);
		driver.findElement(By.xpath("(//input[@placeholder='Search'])[2]")).sendKeys(Keys.BACK_SPACE);
		driver.findElement(By.xpath("(//input[@placeholder='Search'])[2]"))
				.sendKeys(deviceName.substring(deviceName.length() - 1));
		String selectDev = "//div[text()='" + deviceName + "']";
		util.clickUsingJs(By.xpath(selectDev));
		util.waitForCartPageToastMessage();
		driver.findElement(By.xpath("//input[@type='search']")).clear();
	}

	public void UpdateAccounts() {
		getPlanConfig().click();
		getUpdateAccount().click();
		driver.switchTo().defaultContent();
	}

	// Created by Vinay to click on particular Update Accounts when there is more
	// than one plan
	public void UpdateAccounts(Map<String, String> data) {
		// getPlanConfig().click();
		// util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(5);
		String product = data.get("Plan");
		String planxpath = "//button[contains(@title,'" + product + "')]";
		String actions = planxpath + "/following::button[@title='Show Actions']";
		String updateAccount = "(//button[contains(@title,'" + product
				+ "')]/following::button[@title='Show Actions']/following::a[normalize-space()='Update Account'])[1]";
		util.scrollIntoElement(By.xpath(updateAccount));
		util.waitFor(5);
		util.clickUsingJs(By.xpath(actions));
		util.clickUsingJs(By.xpath(updateAccount));
//		getUpdateAccount().click();
		driver.switchTo().defaultContent();
		util.waitForAddressAssignmentPage();
	}

//	Created by Vinay to click on  particular Update Accounts when there is more than one plan
	public void SecondUpdateAccounts(Map<String, String> data) {
		// getPlanConfig().click();
		util.AttachFrame();
		util.waitFor(5);
		String product = data.get("SecondPlanName");
		String planxpath = "//button[contains(@title,'" + product + "')]";
		String actions = planxpath + "/following::button[@title='Show Actions']";
		String updateAccount = "(//button[contains(@title,'" + product
				+ "')]/following::button[@title='Show Actions']/following::a[normalize-space()='Update Account'])[1]";
		util.scrollIntoElement(By.xpath(updateAccount));
		util.waitFor(5);
		util.clickUsingJs(By.xpath(updateAccount));
//		getUpdateAccount().click();
		driver.switchTo().defaultContent();
	}

	// Created by Vinay to Configure the workingCart to save the Modified Products
	// in NR32SIT
	public void WorkingCartConfigure() {
		util.waitFor(By.xpath("//button[text()='Configure']"), 15, true);
		util.clickUsingJs(By.xpath("//button[text()='Configure']"));
		util.waitForWorkingCartPage();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//button[@title='Save Working Cart']"));
	}

	// Created by Vinay to Click on both SaveWorkingCart and View Record button as
	// we need
	public void SaveWorkingCart() {
		// util.waitFor(8);
		util.refreshSwitchToFrame();
		util.AttachFrame();
		if (util.isElementDisplayed(By.xpath("//h1[text()='Working Cart']"))) {
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.clickUsingJs(By.xpath("//button[@title='Save Working Cart']"));
		} else {
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.clickUsingJs(By.xpath("//button[@title='View Record']"));
		}
	}

	public void ViewRecord() {
		util.refreshSwitchToFrame();
		util.AttachFrame();
		if (!util.clickUsingJs(By.xpath("//button[@title='View Record']"))) {
			System.out.println("Not clicked on view record");
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.clickUsingJs(By.xpath("//button[@title='View Record']"));
		}
	}

	// Created by Vinay to click on particular plan down arrow when there is more
	// than one plan
	public void clickPlanDownArrow(Map<String, String> data) {
		util.refreshSwitchToFrame();
		util.waitFor(5);
		util.AttachFrame();
		String product = data.get("Plan");
		String planxpath = "//button[contains(@title,'" + product + "')]";
		String actions = "(//button[contains(@title,'" + product + "')]/following::button[@title='Show Actions'])[1]";
		util.waitFor(8);
		util.clickUsingJs(By.xpath(actions));
	}

	// Created by Vinay to click on particular plan down arrow when there is more
	// than one plan
	public void clickSecondPlanDownArrow(Map<String, String> data) {
		util.refreshSwitchToFrame();
		util.waitFor(5);
		util.AttachFrame();
		String product = data.get("SecondPlanName");
		String planxpath = "//button[contains(@title,'" + product + "')]";
		String actions = "(//button[contains(@title,'" + product + "')]/following::button[@title='Show Actions'])[1]";
		util.clickUsingJs(By.xpath(actions));
	}

	// Created by vidya
	public void cartPageSaveButton() {
		util.clickUsingJs(By.xpath("//button[@type='submit']"));
		util.waitFor(By.xpath("//div[@class='slds-spinner_container']"), 30, false);
	}

	public void AddDevice_To_Product_And_Configure(String product, String deviceName, String capacity, String color) {
		// BYOD products not required to add device
		if (!product.contains("BYOD")) {
			Reporter.logWithScreenShot("Add device to plan | " + deviceName);
			try {
				util.refreshSwitchToFrame();
				// util.waitForCartPage();
				util.waitFor(By.xpath("//title[text()='vlocity_cmt__HybridCPQ | Salesforce']"), 10, true);
				util.AttachFrame();
				String planxpath = "//button[contains(@title,'" + product + "')]";
				String DevicebtnXpth = planxpath + "//following::div[@class='cpq-product-cart-item-child'][1]"
						+ "//following::span[contains(@title,'Device')]//preceding-sibling::button";
				driver.findElement(By.xpath(DevicebtnXpth)).click();
				String placeholder = DevicebtnXpth + "//following::input[@placeholder='Search'][1]";
				String[] arrayOfDevices = deviceName.split(";");
				for (String Device : arrayOfDevices) {
					driver.findElement(By.xpath(placeholder)).sendKeys(Device);
					driver.findElement(By.xpath(placeholder)).sendKeys(Keys.BACK_SPACE);
					driver.findElement(By.xpath(placeholder)).sendKeys(Device.substring(Device.length() - 1));
					String selectDev = "//div[text()='" + Device + "']";
					util.clickUsingJs(By.xpath(selectDev));
					Thread.sleep(6000);
					util.waitForCartPageToastMessage();
					// driver.findElementByXPath(placeholder).click();
					driver.findElement(By.xpath(placeholder)).clear();
					DeviceConfiguration(deviceName);
					selectingDeviceCapacity(capacity);
//					Thread.sleep(8000);
					Reporter.logWithScreenShot("Selected device capacity as | " + capacity);
					selectingColor(color);
//					Thread.sleep(10000);
					Reporter.logWithScreenShot("Selected device color as | " + color);
					cartPageSaveButton();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// done by waseem
	public void DeviceConfiguration(String deviceName) {
		String ShowActionsXpath = "//span[contains(@title,'" + deviceName
				+ "')]//following::button[@title=\"Show Actions\"][1]";
		String ConfigXpath = "//span[contains(@title,'" + deviceName
				+ "')]//following::button[@title='Show Actions'][1]//following::li[normalize-space(.)='Configure']//a";
		System.out.println("Configure device...");
		util.clickUsingJs(By.xpath(ShowActionsXpath));
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		List<WebElement> config = driver.findElements(By.xpath(ConfigXpath));
		for (WebElement element : config) {
			if (element.isDisplayed()) {
				element.click();
				break;
			}
		}
	}

	// created by waseem
	public void AddProduct_To_Cart(String productName) {
		try {
			util.refreshSwitchToFrame();
			util.waitForCartPage();
			util.AttachFrame();
			String[] arrayOfProducts = productName.split(";");
			for (String Product : arrayOfProducts) {
				QAFExtendedWebElement searchBox = new QAFExtendedWebElement(
						"//div[@class='slds-grid slds-grid_vertical cpq-left-sidebar scroll']//div[2]//input");
				searchBox.sendKeys(Product);
				Thread.sleep(5000);
				String addtocartButton = "//span[@class='slds-tile__title slds-truncate cpq-product-name' and text()='"
						+ Product + "']//following::button[1]";
				driver.findElement(By.xpath(addtocartButton)).click();
				Thread.sleep(15000);
				searchBox.clear();
				Thread.sleep(3000);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// created by waseem
	public void add_ValueAddedSolution_To_Product_InCart(String product, String ADDEDSOLUTION, String capacity,
			String color) {
		// BYOD products not required to add device
		System.out.println("Add Value Added Solution to Product | " + ADDEDSOLUTION);
		try {
			util.refreshSwitchToFrame();
			util.waitForCartPage();
			util.AttachFrame();
			// driver.findElementByXPath("//button[contains(@title,'"+plan+"')]").click();
			String planxpath = "//button[contains(@title,'" + product + "')]";
			String AddedSolutionbtnXpth = planxpath + "//following::div[@class='cpq-product-cart-item-child'][1]"
					+ "//following::span[contains(@title,'Value Added Solution')]//preceding-sibling::button";
			driver.findElement(By.xpath(AddedSolutionbtnXpth)).click();
			String placeholder = AddedSolutionbtnXpth + "//following::input[@placeholder='Search'][1]";
			String[] arrayOfDevices = ADDEDSOLUTION.split(";");
			for (String AddSolution : arrayOfDevices) {
				driver.findElement(By.xpath(placeholder)).sendKeys(AddSolution);
				driver.findElement(By.xpath(placeholder)).sendKeys(Keys.BACK_SPACE);
				driver.findElement(By.xpath(placeholder)).sendKeys(AddSolution.substring(AddSolution.length() - 1));
				String selectDev = "//div[text()='" + AddSolution + "']";
				util.clickUsingJs(By.xpath(selectDev));
				Thread.sleep(6000);
				util.waitForCartPageToastMessage();
				driver.findElement(By.xpath(placeholder)).clear();
				DeviceConfiguration(AddSolution);
				selectDeviceCapacity(capacity);
				Thread.sleep(10000);
				selectColor(color);
				Thread.sleep(10000);
				util.clickUsingJs(By.xpath(
						"//div[@class='cpq-product-container']//*[local-name()='svg'][@alt=\"close\"]/parent::button"));
				Thread.sleep(8000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// created by waseem
	public void add_Accessories_To_Product_InCart(String product, String Accessories, String capacity, String color) {
		// BYOD products not required to add device
		System.out.println("Add Accessories to Product | " + Accessories);
		try {
			util.refreshSwitchToFrame();
			util.waitForCartPage();
			util.AttachFrame();
			// driver.findElementByXPath("//button[contains(@title,'"+plan+"')]").click();
			String planxpath = "//button[contains(@title,'" + product + "')]";
			String AccessoriesbtnXpth = planxpath + "//following::div[@class='cpq-product-cart-item-child'][1]"
					+ "//following::span[contains(@title,'Accessories')]//preceding-sibling::button";
			driver.findElement(By.xpath(AccessoriesbtnXpth)).click();
			String placeholder = AccessoriesbtnXpth + "//following::input[@placeholder='Search'][1]";
			String[] arrayOfAccessories = Accessories.split(";");
			for (String Access : arrayOfAccessories) {
				driver.findElement(By.xpath(placeholder)).sendKeys(Access);
				driver.findElement(By.xpath(placeholder)).sendKeys(Keys.BACK_SPACE);
				driver.findElement(By.xpath(placeholder)).sendKeys(Access.substring(Access.length() - 1));
				String selectDev = "//div[text()='" + Access + "']";
				util.clickUsingJs(By.xpath(selectDev));
				Thread.sleep(6000);
				util.waitForCartPageToastMessage();
				driver.findElement(By.xpath(placeholder)).clear();
				DeviceConfiguration(Access);
				selectDeviceCapacity(capacity);
				Thread.sleep(10000);
				selectColor(color);
				Thread.sleep(10000);
				util.clickUsingJs(By.xpath(
						"//div[@class='cpq-product-container']//*[local-name()='svg'][@alt=\"close\"]/parent::button"));
				Thread.sleep(8000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// created by waseem
	public void add_AddONS_To_Product_InCart(String product, String Add_Ons, String capacity, String color) {
		// BYOD products not required to add device
		System.out.println("Add Add_Ons to Product | " + Add_Ons);
		try {
			util.refreshSwitchToFrame();
			util.waitForCartPage();
			util.AttachFrame();
			// driver.findElementByXPath("//button[contains(@title,'"+plan+"')]").click();
			String planxpath = "//button[contains(@title,'" + product + "')]";
			String AccessoriesbtnXpth = planxpath + "//following::div[@class='cpq-product-cart-item-child'][1]"
					+ "//following::span[contains(@title,'Add ons')]//preceding-sibling::button";
			driver.findElement(By.xpath(AccessoriesbtnXpth)).click();
			String placeholder = AccessoriesbtnXpth + "//following::input[@placeholder='Search'][1]";
			String[] arrayOfAdd_Ons = Add_Ons.split(";");
			for (String AddOns : arrayOfAdd_Ons) {
				driver.findElement(By.xpath(placeholder)).sendKeys(AddOns);
				driver.findElement(By.xpath(placeholder)).sendKeys(Keys.BACK_SPACE);
				driver.findElement(By.xpath(placeholder)).sendKeys(AddOns.substring(AddOns.length() - 1));
				String selectDev = "//div[text()='" + AddOns + "']";
				util.clickUsingJs(By.xpath(selectDev));
				Thread.sleep(6000);
				util.waitForCartPageToastMessage();
				driver.findElement(By.xpath(placeholder)).clear();
				DeviceConfiguration(AddOns);
				selectDeviceCapacity(capacity);
				Thread.sleep(10000);
				selectColor(color);
				Thread.sleep(10000);
				util.clickUsingJs(By.xpath(
						"//div[@class='cpq-product-container']//*[local-name()='svg'][@alt=\"close\"]/parent::button"));
				Thread.sleep(8000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectingDeviceCapacity(String capacity) {
		System.out.println("Select Device Capacity | " + capacity);
		try {
			util.selectBy(driver.findElement(By.xpath("//form//label[contains(.,'Capacity')]//following::select[1]")),
					capacity);
		} catch (Exception e) {
			util.selectBy(driver.findElement(By.xpath(
					"//form[@name='productconfig']//label[text()[normalize-space(.)='Capacity']]//following::select[1]")),
					capacity);
		}
//		util.waitForCartPageToastMessage();
	}

	public void selectingColor(String color) {
		System.out.println("Select device color | " + color);
		try {
			util.selectBy(driver.findElement(By.xpath("//form//label[contains(.,'Color')]//following::select[1]")),
					color);
		} catch (Exception e) {
			util.selectBy(driver.findElement(By.xpath(
					"//form[@name='productconfig']//label[text()[normalize-space(.)='Color']]//following::select[1]")),
					color);
			e.printStackTrace();
		}
//		util.waitForCartPageToastMessage();
	}

	// Created by Krishna
	public void verify_ProductStructure_In_Cart(String product) {
		util.AttachFrame();
		Object[][] jsondata = JSONUtil.getJsonArrayOfMaps("resources/testdata/Product Structure.json");
		for (Object[] element2 : jsondata) {
			Map data = (Map) element2[0];
			if (data.containsKey(product)) {
				String prodoctStructure = (String) data.get(product);
				String[] prodoctStructurevalue = prodoctStructure.split(",");
				for (String productName : prodoctStructurevalue) {
					try {
						QAFWebElement element = new QAFExtendedWebElement(
								"xpath=//button[contains(@title,'Product Name: " + productName
										+ "')]|//span[contains(@class,'cpq-item') and text()='" + productName + "']");
						element.isDisplayed();
						element.executeScript("scrollIntoView(true);");
						Reporter.logWithScreenShot("Successfully verified the product structure " + productName
								+ " in the product " + product, MessageTypes.Pass);
					} catch (Exception e) {
						Reporter.logWithScreenShot(
								"Failed to verify the product structure " + productName + " in the product " + product,
								MessageTypes.Fail);
					}
				}
			}
		}
	}

	// Created by Vinay to Add Second ProductsToCart in Working Cart
	public void QuickActionsAddProductsToCart(Map<String, String> data) {
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//div[text()='Price List']//parent::div/button"));
		util.clickUsingJs(By.xpath("//span[text()='SMART Price List']"));
		util.typeDataTo(getProductSearchBox(), data.get("Plan").toString());
		getProductSearchBox().sendKeys(Keys.BACK_SPACE);
		util.typeDataTo(getProductSearchBox(),
				data.get("Plan").toString().charAt(data.get("Plan").toString().length() - 1) + "");
		util.clickUsingJs(By.xpath("//span[text()='" + data.get("Plan").toString().trim()
				+ "']/parent::*/parent::*/following-sibling::div//button"));
		util.waitForCartPageToastMessage();
		util.waitFor(30);
		AppUtils.OrderQuantity(data, data.get("Plan"));
		if(data.get("Plan").contains("BYOD (NON-STANDARD)")) {
			AppUtils.Configure_Parent_Product(data.get("Plan"));
			AppUtils.select_Config_Parameter("MSF BYOD");
			AppUtils.cartPageSaveButton();
		}
		
		if ((!data.get("Plan").contains("BYOD")) && (!data.get("Plan").contains("Bizload"))
				&& (!data.get("Plan").contains("SMART IOT Plan"))&&(!data.get("Plan").contains("Bro"))){
			util.waitFor(15);
			util.clickUsingJs(getDeviceArrow());
			if (data.get("DeviceName").contains("ROUTER")){
				AddBroChildDevice(data.get("DeviceName").toString());
			}else {
			AddChildDevice(data.get("DeviceName").toString(), data.get("paymentType").toString(),
					data.get("DeviceCapcity").toString(), data.get("DeviceColor").toString());
//			AppUtils.cartPageSaveButton();
			util.waitFor(5);
			}
//			AppUtils.bespokeOneTimeChargePriceForR4Device(data.get("Plan"),data.get("DeviceName"), data.get("Price"), "Override");
		}

			if (data.get("SecondDevice").contains("Y")){
				if (data.get("SecondDeviceName").contains("ROUTER")){
					AddBroChildDevice(data.get("SecondDeviceName").toString());
				}
				else {
				AddChildDevice2(data.get("SecondDeviceName").toString(), data.get("SecondpaymentType").toString(),
						data.get("SecondDeviceCapcity").toString(), data.get("SecondDeviceColor").toString());
				}
			}
//			 if(!data.get("Addons").contains("SKIP")) {
//			addAddonsto5GPlans(data.get("Addons"),data);
//			 }
//			 if(!data.get("2 add-on").contains("SKIP")) {
//				 addAddonsto5GPlans(data.get("2 add-on"),data);
//			 }
//			 if  (!data.get("DiscountOnPlanMSF").contains("SKIP")) {
//			DiscountOn5GPlan(data.get("DiscountOnPlanMSF"));}
//
//			 if  (!data.get("DiscountOnDevice").contains("SKIP")) {
//			this.DiscountOnDevice(data.get("DiscountOnDevice"));}
		}
	

	// Created By Vinay to add plan
	public void addPlanToCart(String Product) {
		if (Product.equalsIgnoreCase("e_Government")) {
			Product = "eGovernment";
		}
		util.refreshSwitchToFrame();
		util.waitFor(6);
		util.AttachFrame();
		util.typeDataTo(getProductSearchBox(), Product.toString());
		getProductSearchBox().sendKeys(Keys.BACK_SPACE);
		util.typeDataTo(getProductSearchBox(), Product.toString().charAt(Product.toString().length() - 1) + "");
		util.clickUsingJs(By.xpath("//span[text()='" + Product.toString().trim()
				+ "']/parent::*/parent::*/following-sibling::div//button"));
		util.waitForCartPageToastMessage();
		util.waitFor(30);
		getProductSearchBox().clear();
	}

	/**
	 * WorkingCart_grouping_Product --It Performs the grouping in working cart page.
	 *
	 * @author Vinay .
	 * @return No return value.
	 */
	public void WorkingCart_grouping_Product() {
		int j;
		util.waitFor(3);
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//button[@title='Grouping']"));
		util.waitForVlocityOmniScript();
		util.waitFor(5);
		util.AttachFrame();
		util.waitFor(3);
		String checkboxXpath = "//th/div[.='Product Name']/following::label[@class='slds-checkbox']";
		List<WebElement> elements = driver.findElements(By.xpath(checkboxXpath));
		int count = elements.size();
		System.out.println(count);
		int value = 1;
		if (count > 3) {
			for (int i = 3; i <= count + 1; i += 3) {
				System.out.println(i);
				for (j = value; j <= i; j++) {
					driver.findElement(
							By.xpath("//th/div[.='Product Name']/following::label[@class='slds-checkbox'][" + j + "]"))
							.click();
					if (i > count) {
						value = j + 1;
						break;
					} else {
						value = j + 1;
					}
				}
				if (util.isElementDisplayed(By.xpath("//input[@id='QuoteMembers']"))) {
					util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
					util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"), WaitFor.VISIBLE);
				}
				util.vlocityNextButton();
				util.waitForCartPage();
				util.AttachFrame();
				if (value == count) {
					break;
				} else {
					util.AttachFrame();
					util.clickUsingJs(By.xpath("//button[@title='Grouping']"));
					util.waitForVlocityOmniScript();
					util.AttachFrame();
					continue;
				}
			}
		} else {
			elements.forEach(v -> v.click());
			util.waitFor(5);
			driver.findElement(
					By.xpath("(//th/div[.='Product Name']/following::label[@class='slds-checkbox'])[last()]")).click();
			util.AttachFrame();
			if (util.isElementDisplayed(By.xpath("//input[@id='QuoteMembers']"))) {
				util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"), WaitFor.ATTACH_FRAME);
				util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"), WaitFor.VISIBLE);
			}
			util.vlocityNextButton();
			util.waitForCartPage();
		}
	}

	public void ClickonPromotion(String Product) {
		util.clickUsingJs(By.xpath("//button[.='PROMOTIONS']"));
		util.waitFor(6);
		util.AttachFrame();
		util.typeDataTo(getProductSearchBox(), Product.toString());
		getProductSearchBox().sendKeys(Keys.BACK_SPACE);
		util.typeDataTo(getProductSearchBox(), Product.toString().charAt(Product.toString().length() - 1) + "");
		util.waitFor(5);
		util.clickUsingJs(By.xpath(
				"//p[text()='" + Product.toString().trim() + "']/parent::*/parent::*/following-sibling::div//button"));
		util.clickUsingJs(By.xpath("//button[contains(text(),'Apply')]"));
		util.waitForCartPageToastMessage();
		util.waitFor(30);		
		getProductSearchBox().clear();

	}

	public void ConfigurePromotionBeyondFiberDirectLine(Map<String, String> data) {
		QAFWebElement spinner = new QAFExtendedWebElement(
				"//div[@class='slds-spinner--brand slds-spinner slds-spinner--large']");
		AppUtils.Configure_Parent_Product("PLDT Direct Line");
		AppUtils.select_Config_Parameter("Subscription Type");
		util.waitFor(5);
		AppUtils.select_Config_Parameter("Number Type");
		AppUtils.cartPageSaveButton();
		AppUtils.click_Configure_Product("PLDT Direct Line", "Access");
		AppUtils.select_Config_Parameter("Access Type");
		AppUtils.cartPageSaveButton();
		Reporter.logWithScreenShot("Plan Configuration Done..");

	}

	// Created by Vinay to Add Second ProductsToCart in Working Cart
	public void QuickActionsAddProductsToCart(Map<String, String> data, String Plan) {
		addPlanToCart(Plan);
		util.waitFor(5);
		AppUtils.OrderQuantity(data, Plan);
		if ((!Plan.contains("BYOD")) && (!Plan.contains("Bizload"))) {
			util.clickUsingJs(getDeviceArrow());
//			AddChildDevice(Plan.toString(),data.get("DeviceName").toString(), data.get("paymentType").toString(),
//					data.get("DeviceCapcity").toString(), data.get("DeviceColor").toString());
			/// REPLACED
			util.waitFor(15);
			if (data.get("DeviceName").contains("ROUTER")){
				AddBroChildDevice(data.get("DeviceName").toString());
			}else {
			AddChildDevice(data.get("DeviceName").toString(), data.get("paymentType").toString(),
					data.get("DeviceCapcity").toString(), data.get("DeviceColor").toString());
	//		AppUtils.cartPageSaveButton();
			util.waitFor(5);
//			AppUtils.bespokeOneTimeChargePriceForR4Device(Plan,data.get("DeviceName"), data.get("Price"), "Override");
			}
		}

		if (Plan.contains("5G")) {
			if (data.get("SecondDevice").contains("Y")) {
				if (data.get("SecondDeviceName").contains("ROUTER")){
					AddBroChildDevice(data.get("SecondDeviceName").toString());
				}
				else {
				AddChildDevice2(data.get("SecondDeviceName").toString(), data.get("SecondpaymentType").toString(),
						data.get("SecondDeviceCapcity").toString(), data.get("SecondDeviceColor").toString());
				}
			}
			if (!data.get("Addons").contains("SKIP")) {
				addAddonsto5GPlans(data.get("Addons"), data);
			}
			if (!data.get("2 add-on").contains("SKIP")) {
				addAddonsto5GPlans(data.get("2 add-on"), data);
			}
			if (!data.get("DiscountOnPlanMSF").contains("SKIP")) {
				DiscountOn5GPlan(data.get("DiscountOnPlanMSF"));
			}
			if (!data.get("DiscountOnDevice").contains("SKIP")) {
				this.DiscountOnDevice(data.get("DiscountOnDevice"));
			}
		}
	}

	public void AddChildDevice(String Plan, String deviceName, String paymentType, String capacity, String color) {
		try {
			addDeviceToPlan(deviceName);
			deviceConfiguration(Plan, deviceName);
		} catch (Exception e2) {
		}
		try {
			if (!paymentType.isEmpty())
				selectDevicePaymentType(paymentType);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			if (!capacity.isEmpty())
				selectDeviceCapacity(capacity);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (!color.isEmpty())
				selectColor(color);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			QAFWebElement e = new QAFExtendedWebElement(By.xpath("//div[@class='slds-col slds-align-middle']/h2"));
			e.waitForNotVisible(10000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		util.clickUsingJs(By
				.xpath("//div[@class='cpq-product-container']//*[local-name()='svg'][@alt=\"close\"]/parent::button"));
	}

	// created by Vinay to select Price in cartPage
	public void selectPriceinCartpage() {
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//div[text()='Price List']//parent::div/button"));
		util.clickUsingJs(By.xpath("//span[text()='SMART Price List']"));
	}

	public void deviceConfiguration(String Plan, String Device) {
		System.out.println("Configure device...");
		util.clickUsingJs(By.xpath("((//span[.='" + Plan + "'])[last()]/following::span[.='" + Device
				+ "']/following::button[@title='Show Actions'])[1]"));
		util.waitFor(By.xpath("(//span[contains(.,'Configure')])[2]"), 10, true);
		driver.findElement(By.xpath("(//span[contains(.,'Configure')])[2]")).click();
	}

	// Created by Vinay to Modify and Update Plans
	public void ModifyandUpdatePlans(Map<String, String> data, String product) {
		PageLib pages = new PageLib();
		pages.getQuotepage().ModifyProducts(product);
		pages.getCartpage().clickPlanDownArrow(data, product);
		pages.getCartpage().UpdateAccounts(data, product);
		pages.getAddressassignmentpage().AssignBillingAccount(pageProps.getPropertyValue("BillingAccountName"));
		pages.getAddressassignmentpage().AssignServiceAccount(pageProps.getPropertyValue("ServiceAccountName"));
		pages.getCartpage().SaveWorkingCart();
		pages.getCartpage().WorkingCartConfigure();
		util.waitForQuotePage();
	}

//				Created by Vinay to click on  particular plan down arrow when there is more than one plan
	public void clickPlanDownArrow(Map<String, String> data, String product) {
		util.refreshSwitchToFrame();
		util.waitFor(5);
		util.AttachFrame();
		String planxpath = "//button[contains(@title,'" + product + "')]";
		String actions = "(//button[contains(@title,'" + product + "')]/following::button[@title='Show Actions'])[1]";
		util.waitFor(8);
		util.clickUsingJs(By.xpath(actions));
	}

//				Created by Vinay to click on  particular Update Accounts when there is more than one plan
	public void UpdateAccounts(Map<String, String> data, String product) {
		// getPlanConfig().click();
		// util.refreshSwitchToFrame();
		// util.AttachFrame();
		util.waitFor(5);
		String planxpath = "//button[contains(@title,'" + product + "')]";
		String actions = planxpath + "/following::button[@title='Show Actions']";
		String updateAccount = "(//button[contains(@title,'" + product
				+ "')]/following::button[@title='Show Actions']/following::a[normalize-space()='Update Account'])[1]";
		util.scrollIntoElement(By.xpath(updateAccount));
		util.waitFor(5);
		util.clickUsingJs(By.xpath(updateAccount));
//					getUpdateAccount().click();
		driver.switchTo().defaultContent();
		util.waitForAddressAssignmentPage();
	}

	public void addMainPlan(String mainPlan) {
		util.waitFor(15);
		util.AttachFrame();
		util.typeDataTo(getProductSearchBox(), mainPlan);
		getProductSearchBox().sendKeys(Keys.BACK_SPACE);
		util.typeDataTo(getProductSearchBox(), mainPlan.charAt(mainPlan.length() - 1) + "");
		util.waitFor(10);
		String xpathplan = "//span[text()='" + mainPlan
				+ "']/parent::*/parent::*/following-sibling::div//button[contains(text(),'Add to Cart')]";
		util.waitAndClickUsingJavaScript(xpathplan, "Plan");
		util.waitFor(30);
		Reporter.logWithScreenShot("Clicked on Add to cart button");
	}

	public void selectConfigure(String productName) {
		String productXpath = "(//span[contains(@class,'cpq-error-msg')])[1]//following::span[text()='" + productName
				+ "']/following::button[@title='Show Actions'][1]";
		util.scrollIntoElement(By.xpath(productXpath));
		String configure = productXpath + "/following::a[normalize-space()='Configure'][1]";
		util.waitAndClickUsingJavaScript("xpath=" + productXpath, "Product");
		util.waitFor(5);
		util.waitAndClickUsingJavaScript("xpath=" + configure, "Configure");
	}

	public void select_Config_Parameter(String attribrute, String attributeData) {
		// QAFExtendedWebElement element =
		// driver.findElement(By.xpath("(//form//label[contains(.,'" + attribrute +
		// "')]//following::select[1])[last()]"));
		QAFExtendedWebElement element = new QAFExtendedWebElement(
				By.xpath("(//form//label[contains(.,'" + attribrute + "')]//following::select[1])[last()]"));
		util.scrollIntoElement(element);
		selectValuefromDropDown(element, e -> e.selectByVisibleText(attributeData));
	}

	public void selectValuefromDropDown(QAFExtendedWebElement element, Consumer<Select> consumer) {
		consumer.accept(new Select(element));
	}

	// created by Saisree to Configure promotions in cart page.
	public void ConfigurePromotions(Map<String, String> data) {
		addPromotionToCart(data.get("Plan"));
		util.waitFor(10);
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(6);
		AppUtils.click_Configure_Product(data.get("Plan1"), "Plan");
	//	AppUtils.select_Config_Parameter("Plan Name");
		util.waitFor(3);
		AppUtils.select_Config_Parameter("Speed");
		util.waitFor(3);
		AppUtils.cartPageSave();
		AppUtils.Configure_Primary_Product(data.get("Plan2"));
		util.waitFor(3);
		AppUtils.select_Config_Parameter("Subscription Type");
		AppUtils.select_Config_Parameter("Number Type");
		util.waitFor(3);
	//	AppUtils.select_Config_Parameter("Technology Type");
		AppUtils.cartPageSave();
		AppUtils.Configure_Primary_Product("Access");
		util.waitFor(3);
		AppUtils.select_Config_Parameter("Access Type");
		AppUtils.cartPageSave();
	}

	// Created by Saisree to Add Promotions
	public void addPromotionToCart(String Product) {
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//button[text()='PROMOTIONS']"));
		util.waitFor(3);
		util.typeDataTo(getProductSearchBox(), Product.toString());
		getProductSearchBox().sendKeys(Keys.BACK_SPACE);
		util.typeDataTo(getProductSearchBox(), Product.toString().charAt(Product.toString().length() - 1) + "");
		util.clickUsingJs(By.xpath(
				"//p[text()='" + Product.toString().trim() + "']/parent::*/parent::*/following-sibling::div//button"));
		util.waitFor(5);
		util.waitFor(By.xpath("//button[contains(text(),'Apply')]"), 60, true);
		util.clickUsingJs(By.xpath("//button[contains(text(),'Apply')]"));
		util.waitForCartPageToastMessage();
		util.waitFor(30);
		getProductSearchBox().clear();
	}

	// Created by Saisree to Modify Contract Term
	public void ModifyContractTerm(Map<String, String> data, String ContractTerm) {
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Configure");
		util.waitForCartPage();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(6);
		AppUtils.Configure_Parent_Product(data.get("Plan"));
		AppUtils.select_Config_Parameter("Contract Term");
		util.waitFor(8);
		AppUtils.cartPageSave();
		ViewRecord();
		util.waitForQuotePage();
	}

	/**
	 * ConfigureIgateOffer --It Configures the IgateOffer in the Cart Page.
	 * 
	 * @author Vinay
	 * @return No return value.
	 */
	public void ConfigureIgateOffer(Map<String, String> data) {
		addPlanToCart(data);
//        configurePlanPrimary(data,planVariant,BoD,Speed);    
		util.waitFor(20);
		AppUtils.click_Configure_Product("iGate Offer", "Plan Primary");
		AppUtils.select_Config_Parameter("Plan Variant");
		util.waitFor(8);
		if (data.get("BoD Required").contains("TRUE")) {
			AppUtils.select_Config_Parameter("BoD Required");
			util.waitFor(10);
			AppUtils.select_Config_Parameter("Burst Speed");
			util.waitFor(5);
			util.enterText(
					driver.findElement(
							By.xpath("(//form//label[contains(.,'BOD Excess Rate')]//following::input[1])[last()]")),
					data.get("BODExcess"));
		}
		AppUtils.cartPageSaveButton();
		try {
			String s = driver.findElement(By.xpath("(//span[.='Toggle'])[2]/parent::*//*[local-name()='svg']"))
					.getAttribute("class");
			if (s.contains("cpq-fix-slds-close-switch")) {
				util.clickUsingJs(driver
						.findElement(By.xpath("(//button[contains(@class,'slds-button cpq-item-has-children')])[2]")));
				util.waitFor(8);
				System.out.println("Click on Plan arrow");
			}
		} catch (Exception e) {
		}
		AppUtils.addChildProductsToCart(data.get("Plan"), "Last Mile Specifics");
		util.waitFor(15);
		if ((!data.get("Access Type").contains("FTTX")) && (!data.get("Access Type").contains("IP Radio"))) {
			AppUtils.addChildProductsToCart(data.get("Plan"), "Cross Connect");
			util.waitFor(8);
			AppUtils.click_Configure_Product(data.get("Plan"), "Cross Connect");
			util.waitFor(By.xpath("//h3[.='Cross Connect Details']"), 10, true);
			AppUtils.select_Config_Parameter("3rd Party Provider");
			util.waitFor(8);
			AppUtils.select_Config_Parameter("Data Centre Location");
			util.waitFor(8);
//            util.selectBy(
//                    driver.findElement(By.xpath("(//form//label[contains(.,'Interface')]//following::select[1])[1]")),
//                    data.get("Interface"));
//            util.waitFor(8);
//            AppUtils.select_Config_Parameter("Media");
//            util.waitFor(8);
			AppUtils.cartPageSaveButton();
		}
		util.waitFor(3);
		AppUtils.click_Configure_Product(data.get("Plan"), "Access");
		util.waitFor(3);
		AppUtils.select_Config_Parameter("Access Type");
		if (data.get("Access Type").contains("CEN")) {
			util.waitFor(8);
			util.clickUsingActions(By.xpath(
					"//h3[.='Access Details']/ancestor::div//button[contains(@ng-click,'importedScope.close()')]"));
		}
		if (data.get("Access Type").contains("3pp")) {
			util.waitFor(8);
//            AppUtils.click_Configure_Product(data.get("Plan"), "Access");
			util.waitFor(By.xpath("(//h3[.='Access Details'])[last()]"), 20, true);
			util.waitFor(By.xpath("//form//label[contains(.,'Party Provider')]//following::select[1]"), 20, true);
			AppUtils.select_Config_Parameter("3rd Party Provider");
			util.waitFor(8);
			AppUtils.select_Config_Parameter("3PP Region");
			util.waitFor(8);
			AppUtils.cartPageSaveButton();
		}
		if (data.get("Access Type").contains("IP Radio")) {
			util.waitFor(8);
//            AppUtils.click_Configure_Product(data.get("Plan"), "Access");
			util.waitFor(By.xpath("(//h3[.='Access Details'])[last()]"), 20, true);
			util.waitFor(By.xpath("//form//label[contains(.,'Radio Distance')]//following::select[1]"), 20, true);
			AppUtils.select_Config_Parameter("Radio Distance Between Towers");
			util.waitFor(8);
			AppUtils.select_Config_Parameter("Radio Type");
			util.waitFor(8);
			AppUtils.cartPageSaveButton();
		}
		util.waitFor(8);
		if (data.get("Access Type").contains("IP Radio")) {
			AppUtils.click_Configure_Product("iGate Offer", "Co-Location Site");
			util.waitFor(By.xpath("(//h3[.='Access Details'])[last()]"), 20, true);
//            AppUtils.select_Config_Parameter("Co-Location Site");
			AppUtils.cartPageSaveButton();
		}
		if (data.get("Access Type").contains("FTTX")) {
			util.cartPageSave();
			util.waitFor(By.xpath("//div[@class='slds-spinner_container']"), 30, false);
		}
	}

	public void addPlanToCart(Map<String, String> data) {
		// Copied from ConfigureR4 Created By Vinay
//        util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(10);
		util.typeDataTo(getProductSearchBox(), data.get("Plan").toString());
		getProductSearchBox().sendKeys(Keys.BACK_SPACE);
		util.typeDataTo(getProductSearchBox(),
				data.get("Plan").toString().charAt(data.get("Plan").toString().length() - 1) + "");
//        util.clickUsingJs(By.xpath("//span[text()='" + data.get("Plan").toString().trim()
//                + "']/parent::*/parent::*/following-sibling::div//button"));
		String trimplan = data.get("Plan").toString().trim();
		String xpathplan = pageProps.getString("pldt.cartpage.plan.lnk");
		util.waitAndClickUsingJavaScript(String.format(xpathplan, trimplan), "Plan");
		util.waitForCartPageToastMessage();
		Reporter.logWithScreenShot("Clicked on Add to cart button");
		util.waitFor(30);
	}

}
