package com.pldt.pages;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;

import com.common.utilities.ProjectBeans;
import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.locators.LeadPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;
import com.qmetry.qaf.automation.util.Reporter;

public class LeadPage extends WebDriverBaseTestPage<WebDriverTestPage> implements LeadPageLocators {
	WebUtilities util = new WebUtilities();
	TestDataBean bean = new TestDataBean();
	DateUtil date = new DateUtil();

//	public LeadPage() {
//		bean.fillRandomData();
//	}

	@FindBy(locator = LEAD_NEW_BUTTON)
	private QAFWebElement leadNewButton;
	@FindBy(locator = LEAD_TYPE_ENTERPRISE_EXTENSION)
	private QAFWebElement leadTypeEnterpriseExtension;
	@FindBy(locator = LEAD_TYPE_BUSINESS)
	private QAFWebElement leadTypeBusiness;
	@FindBy(locator = LEAD_TYPE_INFINITY)
	private QAFWebElement leadTypeInfinity;
	@FindBy(locator = LEAD_NEXT_BUTTON)
	private QAFWebElement leadNextButton;
	@FindBy(locator = LEAD_CONVERTED_TITLE)
	private QAFWebElement leadConvertedTitle;
	@FindBy(locator = LEAD_SALUTATION)
	private QAFWebElement leadSalutation;
	@FindBy(locator = LEAD_FIRST_NAME)
	private QAFWebElement leadFirstName;
	@FindBy(locator = LEAD_MID_NAME)
	private QAFWebElement leadMidName;
	@FindBy(locator = LEAD_LAST_NAME)
	private QAFWebElement leadLastName;
	@FindBy(locator = LEAD_SUFFIX)
	private QAFWebElement leadSuffix;
	@FindBy(locator = LEAD_TITLE)
	private QAFWebElement leadTitle;
	@FindBy(locator = LEAD_ROLE)
	private QAFWebElement leadRole;
	@FindBy(locator = LEAD_STATUS)
	private QAFWebElement leadStatus;
	@FindBy(locator = LEAD_NOT_QUALIFIED_REASON)
	private QAFWebElement leadNotQualifiedReason;
	@FindBy(locator = LEAD_SOURCE)
	private QAFWebElement leadSource;
	@FindBy(locator = LEAD_PRODUCT_INTEREST)
	private QAFWebElement leadProductInterest;
	@FindBy(locator = LEAD_OTHER)
	private QAFWebElement leadOther;
	@FindBy(locator = LEAD_DESCRIPTION)
	private QAFWebElement leadDescription;
	@FindBy(locator = LEAD_TYPE)
	private QAFWebElement leadType;
	@FindBy(locator = LEAD_PRODUCT_OF_INTEREST)
	private QAFWebElement leadProductOfInterest;
	@FindBy(locator = LEAD_RTS_REASON)
	private QAFWebElement leadRtsReason;
	@FindBy(locator = LEAD_RFS_DATE)
	private QAFWebElement leadRfsDate;
	@FindBy(locator = LEAD_CALL_BACKDATE)
	private QAFWebElement leadCallBackdate;
	@FindBy(locator = LEAD_ANNUAL_REVENUE)
	private QAFWebElement leadAnnualRevenue;
	@FindBy(locator = LEAD_MIN_FOR_PORT_IN)
	private QAFWebElement leadMinForPortIn;
	@FindBy(locator = LEAD_CURRENT_PROVIDER)
	private QAFWebElement leadCurrentProvider;
	@FindBy(locator = LEAD_OFFER_PACKAGE)
	private QAFWebElement leadOfferPackage;
	@FindBy(locator = LEAD_PHONE)
	private QAFWebElement leadPhone;
	@FindBy(locator = LEAD_MOBILE)
	private QAFWebElement leadMobile;
	@FindBy(locator = LEAD_BIRTHDATE)
	private QAFWebElement leadBirthdate;
	@FindBy(locator = LEAD_EMAIL)
	private QAFWebElement leadEmail;
	@FindBy(locator = LEAD_CREDIT_CHECK)
	private QAFWebElement leadCreditCheck;
	@FindBy(locator = LEAD_SEARCH_ADDRESS)
	private QAFWebElement leadSearchAddress;
	@FindBy(locator = LEAD_COUNTRY)
	private QAFWebElement leadCountry;
	@FindBy(locator = LEAD_STREET)
	private QAFWebElement leadStreet;
	@FindBy(locator = LEAD_CITY)
	private QAFWebElement leadCity;
	@FindBy(locator = LEAD_STATE_PROVINCE)
	private QAFWebElement leadStateProvince;
	@FindBy(locator = LEAD_ZIP_POSTAL_CODE)
	private QAFWebElement leadZipPostalCode;
	@FindBy(locator = LEAD_COMPANY)
	private QAFWebElement leadCompany;
	@FindBy(locator = LEAD_COMPANY_TIN)
	private QAFWebElement leadCompanyTin;
	@FindBy(locator = LEAD_COMPANY_TRADE_NAME)
	private QAFWebElement leadCompanyTradeName;
	@FindBy(locator = LEAD_INDUSTRY)
	private QAFWebElement leadIndustry;
	@FindBy(locator = LEAD_COMPANY_SIZE)
	private QAFWebElement leadCompanySize;
	@FindBy(locator = LEAD_SUB_INDUSTRY)
	private QAFWebElement leadSubIndustry;
	@FindBy(locator = LEAD_BUSINESS_TYPE)
	private QAFWebElement leadBusinessType;
	@FindBy(locator = LEAD_BUSINESS_REGISTRATION_TYPE)
	private QAFWebElement leadBusinessRegistrationType;
	@FindBy(locator = LEAD_BUSINESS_REGISTRATION_NUMBER)
	private QAFWebElement leadBusinessRegistrationNumber;
	@FindBy(locator = LEAD_OTHER_BUSINESS_REGISTRATION_TYPE)
	private QAFWebElement leadOtherBusinessRegistrationType;
	@FindBy(locator = LEAD_WEBSITE)
	private QAFWebElement leadWebsite;
	@FindBy(locator = LEAD_LINE_OF_BUSINESS)
	private QAFWebElement leadLineOfBusiness;
	@FindBy(locator = LEAD_ACCOUNT_CLASS)
	private QAFWebElement leadAccountClass;
	@FindBy(locator = LEAD_EVENT_TRADE_SHOW_REFERRAL_NAME)
	private QAFWebElement leadEventTradeShowReferralName;
	@FindBy(locator = LEAD_CANCEL_BUTTON)
	private QAFWebElement leadCancelButton;
	@FindBy(locator = LEAD_SAVE_NEW_BUTTON)
	private QAFWebElement leadSaveNewButton;
	@FindBy(locator = LEAD_SAVE_BUTTON)
	private QAFWebElement leadSaveButton;
	@FindBy(locator = LEAD_QUALIFIED_STAGE)
	private QAFWebElement leadQualifiedStage;
	@FindBy(locator = LEAD_MARK_AS_CURRENT_STATUS)
	private QAFWebElement leadMarkAsCurrentStatus;
	@FindBy(locator = LEAD_DETAIL_TAB)
	private QAFWebElement leadDetailTab;
	@FindBy(locator = LEAD_CREDIT_SECTION)
	private QAFWebElement leadCreditSection;
	@FindBy(locator = LEAD_CREDIT_LABEL)
	private QAFWebElement leadCreditLabel;
	@FindBy(locator = LEAD_EDIT_CREDIT_ICON)
	private QAFWebElement leadEditCreditIcon;
	@FindBy(locator = LEAD_CREDIT_CHECKBOX)
	private QAFWebElement leadCreditCheckbox;
	@FindBy(locator = LEAD_CONVERTED_BUTTON)
	private QAFWebElement leadConvertedButton;
	@FindBy(locator = LEAD_SELECT_CONVERTED_STATUS)
	private QAFWebElement leadSelectConvertedStatus;
	@FindBy(locator = LEAD_CONVERT_BUTTON)
	private QAFWebElement leadConvertButton;
	@FindBy(locator = "xpath=//div//span[text()='Your lead has been converted']")
	private QAFWebElement leadconvertedmessage;
	@FindBy(locator = LEAD_BANNER_ACCOUNT)
	private QAFWebElement leadbannerAccount;
	@FindBy(locator = LEAD_BANNER_CLOSE)
	private QAFWebElement leadbannerClose;
	@FindBy(locator = AssignUsingActiveAssignmentRule)
	private QAFWebElement AssignmentRuleCheckbox;

	public QAFWebElement getLeadBannerClose() {
		return leadbannerClose;
	}

	public QAFWebElement getLeadBannerAccount() {
		return leadbannerAccount;
	}

	public QAFWebElement getMessage() {
		return leadconvertedmessage;
	}

	public QAFWebElement getLeadNewButton() {
		return leadNewButton;
	}

	public QAFWebElement getLeadTypeEnterpriseExtension() {
		return leadTypeEnterpriseExtension;
	}

	public QAFWebElement getLeadTypeBusiness() {
		return leadTypeBusiness;
	}

	public QAFWebElement getLeadTypeInfinity() {
		return leadTypeInfinity;
	}

	public QAFWebElement getLeadNextButton() {
		return leadNextButton;
	}

	public QAFWebElement getLeadConvertedTitle() {
		return leadConvertedTitle;
	}

	public QAFWebElement getLeadSalutation() {
		return leadSalutation;
	}

	public QAFWebElement getLeadFirstName() {
		return leadFirstName;
	}

	public QAFWebElement getLeadMidName() {
		return leadMidName;
	}

	public QAFWebElement getLeadLastName() {
		return leadLastName;
	}

	public QAFWebElement getLeadSuffix() {
		return leadSuffix;
	}

	public QAFWebElement getLeadTitle() {
		return leadTitle;
	}

	public QAFWebElement getLeadRole() {
		return leadRole;
	}

	public QAFWebElement getLeadStatus() {
		return leadStatus;
	}

	public QAFWebElement getLeadNotQualifiedReason() {
		return leadNotQualifiedReason;
	}

	public QAFWebElement getLeadSource() {
		return leadSource;
	}

	public QAFWebElement getLeadProductInterest() {
		return leadProductInterest;
	}

	public QAFWebElement getLeadOther() {
		return leadOther;
	}

	public QAFWebElement getLeadDescription() {
		return leadDescription;
	}

	public QAFWebElement getLeadType() {
		return leadType;
	}

	public QAFWebElement getLeadProductOfInterest() {
		return leadProductOfInterest;
	}

	public QAFWebElement getLeadRtsReason() {
		return leadRtsReason;
	}

	public QAFWebElement getLeadRfsDate() {
		return leadRfsDate;
	}

	public QAFWebElement getLeadCallBackdate() {
		return leadCallBackdate;
	}

	public QAFWebElement getLeadAnnualRevenue() {
		return leadAnnualRevenue;
	}

	public QAFWebElement getLeadMinForPortIn() {
		return leadMinForPortIn;
	}

	public QAFWebElement getLeadCurrentProvider() {
		return leadCurrentProvider;
	}

	public QAFWebElement getLeadOfferPackage() {
		return leadOfferPackage;
	}

	public QAFWebElement getLeadPhone() {
		return leadPhone;
	}

	public QAFWebElement getLeadMobile() {
		return leadMobile;
	}

	public QAFWebElement getLeadBirthdate() {
		return leadBirthdate;
	}

	public QAFWebElement getLeadEmail() {
		return leadEmail;
	}

	public QAFWebElement getLeadCreditCheck() {
		return leadCreditCheck;
	}

	public QAFWebElement getLeadSearchAddress() {
		return leadSearchAddress;
	}

	public QAFWebElement getLeadCountry() {
		return leadCountry;
	}

	public QAFWebElement getLeadStreet() {
		return leadStreet;
	}

	public QAFWebElement getLeadCity() {
		return leadCity;
	}

	public QAFWebElement getLeadStateProvince() {
		return leadStateProvince;
	}

	public QAFWebElement getLeadZipPostalCode() {
		return leadZipPostalCode;
	}

	public QAFWebElement getLeadCompany() {
		return leadCompany;
	}

	public QAFWebElement getLeadCompanyTin() {
		return leadCompanyTin;
	}

	public QAFWebElement getLeadCompanyTradeName() {
		return leadCompanyTradeName;
	}

	public QAFWebElement getLeadIndustry() {
		return leadIndustry;
	}

	public QAFWebElement getLeadCompanySize() {
		return leadCompanySize;
	}

	public QAFWebElement getLeadSubIndustry() {
		return leadSubIndustry;
	}

	public QAFWebElement getLeadBusinessType() {
		return leadBusinessType;
	}

	public QAFWebElement getLeadBusinessRegistrationType() {
		return leadBusinessRegistrationType;
	}

	public QAFWebElement getLeadBusinessRegistrationNumber() {
		return leadBusinessRegistrationNumber;
	}

	public QAFWebElement getLeadOtherBusinessRegistrationType() {
		return leadOtherBusinessRegistrationType;
	}

	public QAFWebElement getLeadWebsite() {
		return leadWebsite;
	}

	public QAFWebElement getLeadLineOfBusiness() {
		return leadLineOfBusiness;
	}

	public QAFWebElement getLeadAccountClass() {
		return leadAccountClass;
	}

	public QAFWebElement getLeadEventTradeShowReferralName() {
		return leadEventTradeShowReferralName;
	}

	public QAFWebElement getLeadCancelButton() {
		return leadCancelButton;
	}

	public QAFWebElement getLeadSaveNewButton() {
		return leadSaveNewButton;
	}

	public QAFWebElement getLeadSaveButton() {
		return leadSaveButton;
	}

	public QAFWebElement getLeadQualifiedStage() {
		return leadQualifiedStage;
	}

	public QAFWebElement getLeadMarkStatusAsComplete() {
		return leadMarkAsCurrentStatus;
	}

	public QAFWebElement getLeadMarkAsCurrentStatus() {
		return leadMarkAsCurrentStatus;
	}

	public QAFWebElement getLeadDetailTab() {
		return leadDetailTab;
	}

	public QAFWebElement getLeadCreditSection() {
		return leadCreditSection;
	}

	public QAFWebElement getLeadEditCreditIcon() {
		return leadEditCreditIcon;
	}

	public QAFWebElement getLeadCreditCheckbox() {
		return leadCreditCheckbox;
	}

	public QAFWebElement getLeadConvertedButton() {
		return leadConvertedButton;
	}

	public QAFWebElement getLeadConvert() {
		return leadConvertButton;
	}

	public QAFWebElement getLeadSelectConvertedStatus() {
		return leadSelectConvertedStatus;
	}

	public QAFWebElement getLeadCreditLabel() {
		return leadCreditLabel;
	}

	public QAFWebElement getAssignmentRuleCheckbox() {
		return AssignmentRuleCheckbox;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public void selectRecordType(String recordType) {
		switch (recordType.toLowerCase()) {
		case "ee": {
			getLeadTypeEnterpriseExtension().click();
			break;
		}
		case "business": {
			getLeadTypeBusiness().click();
			break;
		}
		case "infinity": {
			getLeadTypeInfinity().click();
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected record value: " + recordType);
		}
	}

	public void selectLeadSaveButton() {
		util.clickUsingJs(getLeadSaveButton());
	}

	public void fillLeadInformation(Map<String, String> data) {
		bean.fillRandomData();
	//	 util.select("Salutation");
		util.waitFor(3);
		util.select("Salutation", bean.RandomSalutation());
		// util.type("First Name");
		String Lead_FirstName = bean.getFirstName();
		util.type("First Name", Lead_FirstName);
		pageProps.setProperty("Lead.firstName", Lead_FirstName);
		// util.type("Middle Name");
		String Lead_middleName = bean.getMiddleName();
		util.type("Middle Name", Lead_middleName);
		// util.type("Last Name");
		String Lead_lastName = bean.getLastName();
		util.type("Last Name", Lead_lastName);
		// util.type("Suffix");
		String Lead_suffix = bean.getSuffix();
		util.type("Suffix", Lead_suffix);
		pageProps.setProperty("Lead.fullName",
				Lead_FirstName + " " + Lead_middleName + " " + Lead_lastName + " " + Lead_suffix);
		Reporter.log("Lead Name: " + Lead_FirstName + Lead_middleName + Lead_lastName + Lead_suffix);
		util.type("Title");
		util.select("Lead Role");
		util.select("Lead Status");
		util.select("Not Qualified Reason");
		util.select("Lead Source");
		util.type("Other", bean.getOther());
		// util.type("Other");
		util.typeIntoTextArea("Description");
		util.select("Lead Type");
		util.type("Annual Revenue");
		util.select("Product Interest");
		util.typeIntoTextArea("Lead Product of Interest", bean.getOther());
		// util.typeIntoTextArea("Lead Product of Interest");
		// util.type("RFS Date");
		// util.enterText(leadRfsDate, "12/12/2022");
		if (data.get("MIN for Port-In").equalsIgnoreCase("SKIP")) {
			util.enterText(leadRfsDate, DateUtil.getDate(365, "MM/dd/yyyy"));
		}
		util.select("RTS Reasons");
		// util.enterText(leadCallBackdate, "12/12/2022");
		util.enterText(leadCallBackdate, DateUtil.getDate(365, "MM/dd/yyyy"));
		// util.type("Call Back Date");
		if (!data.get("MIN for Port-In").equalsIgnoreCase("SKIP")) {
			util.selectAndClickSuggestedValue("Associated Account");
			util.select("Sex");
			util.select("Nationality");
//		util.clickUsingJs(By.xpath("//li//lightning-base-combobox-formatted-text[@title='" + data.get("Associated Account") + "']"));
		}
		util.type("MIN for Port-In");
		util.select("Current Provider");
		util.select("Offer package");
	}

	public void fillPersonalInformation(Map<String, String> data) {
		bean.fillRandomData();
		// util.type("Phone");
		// String Lead_personalPhoneNum= "639"+bean.getPhone_mobile().toString();
		String Lead_personalPhoneNum = String.format("639%s", bean.getPhone_mobile().toString());
		Lead_personalPhoneNum = StringUtils.rightPad(Lead_personalPhoneNum, 12, "0");
		util.type("Phone", Lead_personalPhoneNum);
		pageProps.setProperty("Lead.personalPhoneNum", Lead_personalPhoneNum);
//		util.type("Birthdate");
//		util.enterText(leadBirthdate, "11/16/1998");
		util.enterText(leadBirthdate, DateUtil.getDate(-7120, "MM/dd/yyyy"));
//		util.type("Mobile");
		// String Lead_personalMobileNum="639"+bean.getPhone_mobile().toString();
		String Lead_personalMobileNum = String.format("639%s", bean.getPhone_mobile().toString());
		Lead_personalMobileNum = StringUtils.rightPad(Lead_personalMobileNum, 12, "0");
		util.type("Mobile", Lead_personalMobileNum);
		pageProps.setProperty("Lead.personalMobileNum", Lead_personalMobileNum);
//		util.type("Email");
		String Lead_Email = pageProps.getPropertyValue("Lead.firstName") + "@gmail.com";
		util.type("Email", Lead_Email);
		pageProps.setProperty("Lead.email", Lead_Email);
		util.selectState("Country");
//		util.type("Country");
		util.typeIntoTextArea("Street");
		util.type("City");
		util.selectState("State/Province");
//		util.type("State/Province");
		util.type("Zip/Postal Code");
		// util.click("Credit Check");
		util.select("ID Type");
		util.type("ID Number");
		if (!data.get("MIN for Port-In").equalsIgnoreCase("SKIP")) {
			driver.findElement(By.xpath("(//label[contains(.,'Maiden Name')]/following::input)[1]")).sendKeys(data.get("Mothers' Maiden Name"));
			util.type("Personal TIN");
		}
		
		
	}

	public void fillCompanyInformation() {
		bean.fillRandomData();
		// util.type("Company");
		String Lead_company = pageProps.getPropertyValue("Lead.firstName") + "Company";
		util.type("Company", Lead_company);
		pageProps.setProperty("Lead.company", Lead_company);
		// util.type("Company Trade Name");
		util.type("Company Trade Name", bean.getOther());
		util.select("Company Size");
		util.select("Business Type");
		util.select("Business Registration Type");
		util.type("Company TIN");
		util.select("Industry");
		util.select("Sub-Industry");
		util.type("Business Registration Number");
		util.type("Other Business Registration Type");
		// util.type("Website");
		String Lead_CompanyWebsite = "wwww." + pageProps.getPropertyValue("Lead.firstName") + ".com";
		util.type("Website", Lead_CompanyWebsite);
//		util.type("Deadline of Submission");
	}

	public void fillConsentManagement() {
		util.click("Salesforce Email Opt Out");
		util.click("Pardot Email Opt Out");
		util.click("Do Not Call");
		util.click("Lead Gen Privacy Notice Consent");
		util.click("Sales Engagement Consent");
	}

	public void fillmarketingConsentManagement() {
		util.click("Marketing Consent");
		util.click("Events Consent");
	}

	public void fillAdditionalInformation() {
//		new QAFExtendedWebElement("xpath=//*[text()='LOB(Line of Business)']//following::div[3]/input");
//		util.clickUsingActions(By.xpath("//*[text()='LOB(Line of Business)']//following::div[3]/input"));
		util.select("LOB(Line of Business)");
		util.type("Event/Trade/Show/Referral Name");
		util.select("Account Class");
	}

	public void fillTheLeadForm(Map<String, String> data) {
		fillLeadInformation(data);
		fillPersonalInformation(data);
		fillCompanyInformation();
		fillAdditionalInformation();
		fillConsentManagement();
		fillmarketingConsentManagement();
		if (getAssignmentRuleCheckbox().isSelected()) {
			getAssignmentRuleCheckbox().click();
		}
		util.clickUsingJs(getLeadSaveButton());
	}

	public void markLeadStatusAsQualified() {
		util.ChangeStatus(getLeadQualifiedStage(), getLeadMarkAsCurrentStatus());
		util.waitForMarkStatusAsComplete();
	}

	public void searchAndOpenLead(String filter, String firstName, String middleName, String lastname, String suffix) {
		String name = firstName + " " + middleName + " " + lastname + " " + suffix;
		util.filterRecords(filter);
		util.searchRecord(name);
		util.clickOnRecord(name);
	}

	public void validateCreditCheck() {
		util.clickUsingJs(By.xpath("//a[@id='detailTab__item']"));
		String creditCheckbox = "(//span[text()='Credit Check']/parent::label/span)[1]";
		util.waitFor(By.xpath(creditCheckbox), 05, true);
		util.scrollIntoElement(By.xpath(creditCheckbox));
		util.clickUsingJs(By.xpath("//button[.='Edit Credit Check']"));
		util.scrollIntoElement(By.xpath(creditCheckbox));
		util.clickUsingJs(By.xpath("//input[@name='Credit_Check__c']"));
		util.clickUsingJs(By.xpath("//button[@name='SaveEdit']"));
		util.scrollIntoElement(By.xpath(creditCheckbox));
		util.waitFor(5);
	}

	public void convertLead(Map<String, String> data) {
		{
			util.clickUsingJs(getLeadConvertedButton());
			util.clickUsingJs(getLeadSelectConvertedStatus());
			getLeadConvert().waitForPresent(10000);
//			driver.findElement(By.xpath("(//span[text()='Record Type']/following::div/a[@class='select'])[1]")).click();
//			driver.findElement(By.xpath("//a[@title='Business']")).click();
			util.waitFor(By.xpath("//a[@title='Business']"), 10, true);
			util.waitForClickable(By.xpath("(//button[.='Convert'])[last()]"), 30);
//			util.clickUsingJs(By.xpath("//button[contains(@class,'runtime_sales_leadConvertModalFooter')][2]"));
			util.clickUsingJs(By.xpath("(//button[.='Convert'])[last()]"));
			// util.clickUsingJs(getLeadConvert());
//			getLeadConvert().click();
			util.waitFor(By.xpath("//lightning-formatted-text[text()='Your lead has been converted']"), 240, true);
//			getLeadConvertedTitle().waitForVisible(80000);
			getLeadConvertedTitle().verifyVisible();
			util.waitFor(By.xpath("//img[@title='Account']/following::a[1]"), 40, true);
			String accountURL = null;
			try {
				accountURL = driver.findElement(By.xpath("//img[@title='Account']/following::a[1]"))
						.getAttribute("href");
				ProjectBeans.setAccountURL(accountURL);
			} catch (Exception e) {
				PageLib pages = new PageLib();
				pages.getLoginpage().logoutCurrentUser();
				pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
				pages.getHomepage().switchToAnyAccount(data.get("Company"), "Account");
				util.waitForAccountPage();
				ProjectBeans.setAccountURL(driver.getCurrentUrl());
			}
			getLeadBannerClose().click();
		}
	}
}