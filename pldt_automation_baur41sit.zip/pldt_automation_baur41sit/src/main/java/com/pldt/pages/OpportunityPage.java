package com.pldt.pages;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.common.utilities.ProjectBeans;
import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.pldt.locators.OpportunityPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;

public class OpportunityPage extends WebDriverBaseTestPage<WebDriverTestPage> implements OpportunityPageLocators {
	WebUtilities util = new WebUtilities();
	TestDataBean bean = new TestDataBean();
	DateUtil date = new DateUtil();
	@FindBy(locator = Opportunity_NewButton)
	private QAFWebElement opportunityNewButton;
	@FindBy(locator = NextButton)
	private QAFWebElement nextButton;
	@FindBy(locator = Opportunity_Name)
	private QAFWebElement opportunityName;
	@FindBy(locator = Account_Name)
	private QAFWebElement accountName;
	@FindBy(locator = Contracting_Party)
	private QAFWebElement contractingParty;
	@FindBy(locator = Smart)
	private QAFWebElement smart;
	@FindBy(locator = Close_Date)
	private QAFWebElement closeDate;
	@FindBy(locator = Opportunity_type)
	private QAFWebElement opportunityType;
	@FindBy(locator = Stage)
	private QAFWebElement stage;
	@FindBy(locator = CurrentProvider)
	private QAFWebElement currentProvider;
	@FindBy(locator = MINforPortIn)
	private QAFWebElement minForPortIn;
	@FindBy(locator = opportunityCurrency)
	private QAFWebElement currency;
	@FindBy(locator = NumberofContractMonth)
	private QAFWebElement numberofContractMonth;
	@FindBy(locator = Save)
	private QAFWebElement save;
	@FindBy(locator = Configure)
	private QAFWebElement configure;
	@FindBy(locator = DeviceAvailabilityCheck)
	private QAFWebElement deviceAvailabilityCheck;
	@FindBy(locator = DeviceAvailabilityNextBtn)
	private QAFWebElement deviceAvailabilityNextBtn;
	@FindBy(locator = OppoSearchInput)
	private QAFWebElement SearchInput;
	@FindBy(locator = CreateQuotebtn)
	private QAFWebElement createQuotebtn;
	@FindBy(locator = EstablishNeedStage)
	private QAFWebElement establishneed;
	@FindBy(locator = QualificationStage)
	private QAFWebElement qualificationstage;
	@FindBy(locator = CreateQuote)
	private QAFWebElement createQuote;
	@FindBy(locator = OpportunitySave)
	private QAFWebElement opportunitySave;
	@FindBy(locator = creditCheckButton)
	private QAFWebElement creditCheck;
	@FindBy(locator = ccStatusNextButton)
	private QAFWebElement nextbtn;
	@FindBy(locator = ContractTerm)
	private QAFWebElement contractTerm;
	@FindBy(locator = Speed)
	private QAFWebElement speed;
	@FindBy(locator = PaymentMethod)
	private QAFWebElement paymentMethod;
	@FindBy(locator = PlanName)
	private QAFWebElement planName;
	@FindBy(locator = PaymentFrequency)
	private QAFWebElement paymentFrequency;
	@FindBy(locator = ETSSolutionDesignNeededLabel)
	private QAFWebElement etsSolutionDesignNeededLabel;
	@FindBy(locator = ETSSolutionDesignNeeded)
	private QAFWebElement etsSolutionDesignNeed;
	@FindBy(locator = PriceBook)
	private QAFWebElement priceBook;
	@FindBy(locator = QuickFilter)
	private QAFWebElement quickFilter;
	@FindBy(locator = OpportunityNameSearch)
	private QAFWebElement opportunityNameSearch;
	@FindBy(locator = "xpath=(//i[@class='icon icon-v-menu2'])[1]")
	private QAFWebElement menuXpath;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
	}

	public QAFWebElement getOpportunityNewButton() {
		return opportunityNewButton;
	}

	public QAFWebElement getNextButton() {
		return nextButton;
	}

	public QAFWebElement getOpportunityName() { // new
		return opportunityName;
	}

	public QAFWebElement getAccountName() {
		return accountName;
	}

	public QAFWebElement getContractingParty() {
		return contractingParty;
	}

	public QAFWebElement getSmart() {
		return smart;
	}

	public QAFWebElement getCloseDate() {
		return closeDate;
	}

	public QAFWebElement getOpportunityType() {
		return opportunityType;
	}

	public QAFWebElement getStage() {
		return stage;
	}

	public QAFWebElement getCurrentProvider() {
		return currentProvider;
	}

	public QAFWebElement getMinForPortIn() {
		return minForPortIn;
	}

	public QAFWebElement getCurrency() {
		return currency;
	}

	public QAFWebElement getNumberofContractMonth() {
		return numberofContractMonth;
	}

	public QAFWebElement getSave() {
		return save;
	}

	public QAFWebElement getConfigure() {
		return configure;
	}

	public QAFWebElement getDeviceAvailabilityCheck() {
		return deviceAvailabilityCheck;
	}

	public QAFWebElement getDeviceAvailabilityNextBtn() {
		return deviceAvailabilityNextBtn;
	}

	public QAFWebElement getSearchInput() {
		return SearchInput;
	}

	public QAFWebElement getcreateQuotebtn() {
		return createQuotebtn;
	}

	public QAFWebElement getEstablishneed() {
		return establishneed;
	}

	public QAFWebElement getQualificationstage() {
		return qualificationstage;
	}

	public QAFWebElement getCreateQuote() {
		return createQuote;
	}

	public QAFWebElement getOpportunitySave() {
		return opportunitySave;
	}

	public QAFWebElement getCreditCheck() {
		return creditCheck;
	}

	public QAFWebElement getNextbtn() {
		return nextbtn;
	}

	public QAFWebElement getContractTerm() {
		return contractTerm;
	}

	public QAFWebElement getSpeed() {
		return speed;
	}

	public QAFWebElement getPaymentMethod() {
		return paymentMethod;
	}

	public QAFWebElement getPlanName() {
		return planName;
	}

	public QAFWebElement getPaymentFrequency() {
		return paymentFrequency;
	}

	public QAFWebElement getEtsSolutionDesignNeededLabel() {
		return etsSolutionDesignNeededLabel;
	}

	public QAFWebElement getEtsSolutionDesignNeed() {
		return etsSolutionDesignNeed;
	}

	public QAFWebElement getPriceBook() {
		return priceBook;
	}

	public QAFWebElement getQuickFilter() {
		return quickFilter;
	}

	public QAFWebElement getOpportunityNameSearch() {
		return opportunityNameSearch;
	}

	public void createOpportunity() {
		bean.fillRandomData();
		util.clickUsingJs(By.xpath("(//a[@title='New'])[last()]"));
		util.clickUsingJs(getNextButton());
		String Opportunity_Name = bean.getFirstName() + "CG opp";
		pageProps.setProperty("Opportunity.Name", Opportunity_Name);
		util.type("Opportunity Name", Opportunity_Name);
		// util.type("Account Name");
		util.select("Contracting Party");
		util.select("Opportunity Type");
		util.select("Contract Type");
		util.enterText(getCloseDate(), DateUtil.getDate(365, "MM/dd/yyyy"));
//		util.type("Close Date");
		util.select("Stage");
		String min = Long.toString(bean.getPhone_mobile());
		min = StringUtils.rightPad(min, 9, "0");
		util.type("MIN for Port In", min);
		util.select("Current Provider");
		getSave().click();
		util.waitFor(By.xpath("(//a[@title='New'])[last()]"), 10, true);
	}

	public void SearchOpportunity(String OpportunityName) {
		util.clickUsingJs(quickFilter);
////		getQuickFilter().click();
		getOpportunityNameSearch().sendKeys(OpportunityName);
		getOpportunityNameSearch().sendKeys(Keys.ENTER);
		String opportunity = "//a[text()='" + OpportunityName + "']";
//		QAFWebElement opportunityname = new QAFExtendedWebElement(opportunity);
		util.clickUsingJs(By.xpath(opportunity));
		ProjectBeans.setOpportunityURL(driver.getCurrentUrl());
	}

	//overloading method: created by waseem
	public void SearchOpportunity() {
		util.clickUsingJs(quickFilter);
////		getQuickFilter().click();
		String OpportunityName = pageProps.getPropertyValue("Opportunity.Name");
		getOpportunityNameSearch().sendKeys(OpportunityName);
		getOpportunityNameSearch().sendKeys(Keys.ENTER);
		String opportunity = "//a[text()='" + OpportunityName + "']";
//		QAFWebElement opportunityname = new QAFExtendedWebElement(opportunity);
		util.clickUsingJs(By.xpath(opportunity));
		ProjectBeans.setOpportunityURL(driver.getCurrentUrl());
	}

	public void ClickConfigure() {
		util.clickOnActionToolBarButton("OpportunityActionToolbar", "Configure");
		util.waitForCartPage();
		util.refreshSwitchToFrame();
	}

	public void DeviceAvailability() {
		// Thread.sleep(5000);
		// util.switchToActionFrame();
		// getDeviceAvailabilityCheck().click();
		// Thread.sleep(3000);
		// util.switchToActionFrame();
		util.switchtoFrameAndClick(By.xpath("(//span[text()='Device Availability check'])[1]"));
		util.switchtoFrameAndClick(By.xpath("//button[@id='InventoryDetails_nextBtn']"));
		// util.clickUsingJs(deviceAvailabilityNextBtn);
	}

	public void CreateQuote() {
		util.clickOnActionToolBarButton("OpportunityActionToolbar", "Create Quote");
//		util.switchtoFrameAndClick(By.xpath("(//span[text()='Create Quote'])[1]"));
		util.waitForQuotePage();
		// util.clickOnQuickActionButton("create quote", By.xpath("//div[.='Quote']"),
		// true);
		// getcreateQuotebtn().click();
	}

	public void changestatustoEstablishNeed() {
		QAFWebElement establishNeed = new QAFExtendedWebElement(
				By.xpath("//span[@class='ahead slds-path__stage']/following-sibling::span[text()='Establish Need']"));
		QAFWebElement markStatus = new QAFExtendedWebElement(By.xpath("//span[text()='Mark as Current Stage']"));
		util.ChangeStatus(establishNeed, markStatus);
		System.out.println("Changed Status to Establish Need...");
	}

//	public void Dummy()
//	{
//
//	util.dummy(By.xpath("//span[text()='Edit Record']/parent::div"));
//
//	}
	public void createBulkOpportunity() {
//		//Thread.sleep(2000);
		// getOpportunityNewButton().click();
		util.waitFor(3);
		driver.findElement(By.xpath("//span[text()='New']")).click();
		getNextButton().click();
		util.waitFor(3);
//		getOpportunityName().sendKeys(OpportunityName);
//		//getAccountName().sendKeys(AccountName);
//		util.selectDropdownValue(getContractingParty(),ContractingParty);
//		//driver.findElement(By.xpath("//label[normalize-space(text())='Contracting Party']/following::input[1]")).click();
////		getContractingParty().click();
//		//util.clickDropdownValue(ContractingParty);
//		//getSmart().click();
//		getCloseDate().sendKeys(CloseDate);
////		getOpportunityType().click();
//		//Thread.sleep(2000);
////		util.clickDropdownValue(OpportunityType);
//		util.selectDropdownValue(getOpportunityType(),OpportunityType);
////		getStage().click();
//	//	Thread.sleep(2000);
////		util.clickDropdownValue(Stage);
//		util.selectDropdownValue(getStage(),Stage);
////		getCurrentProvider().click();
//		//Thread.sleep(2000);
////		util.clickDropdownValue(CurrentProvider);
//		util.selectDropdownValue(getCurrentProvider(),CurrentProvider);
//		getMinForPortIn().sendKeys("44545545");
//		getSave().click();
//		Thread.sleep(6000);
		util.type("Opportunity Name");
		// util.type("Account Name");
		util.select("Contracting Party");
		util.select("Opportunity Type");
		util.select("Contract Type");
		util.type("Close Date");
		util.select("Stage");
		// util.type("MIN for Port In");
		util.select("Current Provider");
		getSave().click();
		try {
			Thread.sleep(4000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
