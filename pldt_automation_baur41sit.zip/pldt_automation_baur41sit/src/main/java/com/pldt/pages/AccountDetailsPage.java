package com.pldt.pages;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class AccountDetailsPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	WebUtilities util = new WebUtilities();
	public void clickOnRelated(String LinkName)
	{
	driver.navigate().to(getAccountViewPage(LinkName));
//	util.waituntil.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[@title='"+LinkName+"']")));
	}



	public String getAccountViewPage(String linkName) {
	return driver.getCurrentUrl().replaceFirst("view", "related/"+linkName+"/view");

	}

	public void getAccountRecordType()
	{
	QAFWebElement accountRecordType = new QAFExtendedWebElement("//span[text()='Account Record Type']//following::span[2]");
	String accountRecType=accountRecordType.getText();
	System.out.println(accountRecType);
	ConfigurationManager.getBundle().setProperty("accountRecType", accountRecType);
	}


	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}
	
}
