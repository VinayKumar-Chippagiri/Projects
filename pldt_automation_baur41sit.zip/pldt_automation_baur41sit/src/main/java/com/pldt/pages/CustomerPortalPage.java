package com.pldt.pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class CustomerPortalPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();

	public void clickOnRelated(String LinkName) {
		driver.navigate().to(getAccountViewPage(LinkName));
		util.waituntil
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[@title='" + LinkName + "']")));
	}

	public String getAccountViewPage(String linkName) {
		return driver.getCurrentUrl().replaceFirst("view", "related/" + linkName + "/view");

	}

	public void getAccountRecordType() {
		QAFWebElement accountRecordType = new QAFExtendedWebElement(
				"//span[text()='Account Record Type']//following::span[2]");
		String accountRecType = accountRecordType.getText();
		ConfigurationManager.getBundle().setProperty("accountRecType", accountRecType);
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}

	public void LogintoCustomerPortal() {
//		util.waitForAccountPage();
//		getAccountViewPage("Contacts");
		util.clickUsingJs(By.xpath("(//span[.='Technical Contact - ePLDT']/ancestor::tr//th//a)[1]"));
		util.waitFor(By.xpath("//div[text()='Contact']"), 50, true);
		util.clickUsingJs(By.xpath("(//button[@class='slds-button slds-button_icon-border-filled'])[last()]"));
		util.waitFor(By.xpath("//span[text()='Log in to Experience as User']"), 20, true);
		util.clickUsingJs(By.xpath("//span[text()='Log in to Experience as User']"));
		util.waitFor(By.xpath("//div[@class='logoImage']"), 20, true);
	}

	public void CreateCaseInCustomerPortal(Map<String, String> data) {
		util.clickUsingJs(By.xpath("//a[text()='Help & Support']"));
		util.waitFor(By.xpath("//h3[text()='Log a Request']"), 20, true);
		// util.select("Line of Business");
		QAFExtendedWebElement LOB = new QAFExtendedWebElement(By.xpath("//select[@name='LineOfBusiness_Picklist']"));
		util.selectBy(LOB, data.get("Line of Business"));
		QAFExtendedWebElement RequestType = new QAFExtendedWebElement(
				By.xpath("//select[@name='RequestType_Picklist']"));
		util.selectBy(RequestType, data.get("Request Type"));
		QAFExtendedWebElement Type = new QAFExtendedWebElement(By.xpath("//select[@name='Type_Picklist']"));
		util.selectBy(Type, data.get("Type"));
		QAFExtendedWebElement Subject = new QAFExtendedWebElement(By.xpath("//input[@name='CaseSubject']"));
		util.typeDataTo(Subject, data.get("Subject"));
		util.clickUsingJs(By.xpath("//textarea[@class='slds-textarea']"));
		driver.findElement(By.xpath("//textarea[@class='slds-textarea']")).sendKeys(data.get("Description"));
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(By.xpath("//b[text()='Case Details']"), 20, true);
		QAFExtendedWebElement HighLevelTransaction = new QAFExtendedWebElement(
				By.xpath("//select[@name='HighLevelTransactionClassification_Picklist']"));
		util.selectBy(HighLevelTransaction, data.get("High Level Transaction Classification"));
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(By.xpath("//b[text()='Case Details']"), 20, true);
		QAFExtendedWebElement TransactionType = new QAFExtendedWebElement(
				By.xpath("//select[@name='TransactionType_Picklist']"));
		util.selectBy(TransactionType, data.get("Transaction Type"));
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(By.xpath("//b[text()='Case Details']"), 20, true);
		QAFExtendedWebElement TransactionSubType = new QAFExtendedWebElement(
				By.xpath("//select[@name='TransactionSubType_Picklist']"));
		util.selectBy(TransactionSubType, data.get("Transaction Sub Type"));
		util.clickUsingJs(By.xpath("//button[text()='Next']"));
		util.waitFor(By.xpath("//*[@class='slds-spinner_container']"), 50, false);		
		util.waitFor(By.xpath("//*[text()='Your case has been created. Below are the details:']"), 60, true);
		String CaseNumber = driver.findElement(By.xpath("(//strong[text()='Case Number: ']/following::span)[1]"))
				.getText();
		System.out.println(CaseNumber);
		pageProps.setProperty("CaseNumber", CaseNumber);
		Reporter.logWithScreenShot("Case");
	}
}
