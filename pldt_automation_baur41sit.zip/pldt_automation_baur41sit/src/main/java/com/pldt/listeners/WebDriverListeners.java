package com.pldt.listeners;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriverCommandAdapter;

public  class WebDriverListeners extends QAFWebDriverCommandAdapter{

	@Override
	public void onInitialize(QAFExtendedWebDriver driver) {
		// TODO Auto-generated method stub
		driver.manage().window().maximize();
		
	}
	}