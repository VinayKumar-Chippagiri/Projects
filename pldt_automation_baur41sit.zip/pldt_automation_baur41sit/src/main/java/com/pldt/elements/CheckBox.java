package com.pldt.elements;

import java.util.Map;

import com.common.utilities.JSUtils;
import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;

public class CheckBox extends WebDriverBaseTestPage<WebDriverTestPage>{
	JSUtils js=new JSUtils();
	WebUtilities util = new WebUtilities();

	public void clickCheckbox(String fieldName) {
		try {
			Map<?, ?> map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			String checkBox = map.get(fieldName).toString();
			if (checkBox != null && !checkBox.equalsIgnoreCase("skip")) {
				QAFExtendedWebElement element = new QAFExtendedWebElement(
						"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
								+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
								+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
								+ "']/@id]");
//				clickUsingJs(element);
			js.clickUsingJavaScript(element);
			}
		} catch (Exception e) {
			System.out.println("Clicking On :" + fieldName + " is failed");
		}
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub

	}
}
