package com.pldt.elements;

import java.util.Map;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.Reporter;



public class TextArea extends WebDriverBaseTestPage<WebDriverTestPage>{



@Override
protected void openPage(PageLocator locator, Object... args) {

}
public void typeIntoTextArea(String fieldName)
{
QAFExtendedWebElement element = new QAFExtendedWebElement(
"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
+ "']/@for]|//textarea[@id=//label[normalize-space(text())='" + fieldName + "']/@for]|//textarea[@id=//label[span[normalize-space(text())='" + fieldName + "']]/@for]");
Map<?, ?> map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
if (map.get(fieldName) != null && !map.get(fieldName).toString().equalsIgnoreCase("skip")) {
element.sendKeys(map.get(fieldName).toString());
Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
}
}
}