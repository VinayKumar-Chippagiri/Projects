package com.pldt.elements;

import org.openqa.selenium.By;

import com.common.utilities.JSUtils;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;

public class Button extends WebDriverBaseTestPage<WebDriverTestPage> {
	JSUtils js = new JSUtils();
	private final String BUTTON_LOCATOR = "(//button[@title='%s']|//div[@title='%s']|//div/a[@title='%s'])[last()]";
	private final String MODAL_LOCATOR = "//div[contains(@class,'modal-container')]";
	private final String BUTTON_LOCATOR_IN_MODAL_LOCATOR = "//div[contains(@class,'modal-container')]//span[text()='%s']";

	public void click(String title) {
		if (driver.findElements(By.xpath(MODAL_LOCATOR)).size() > 0) {
			driver.findElement(By.xpath(String.format(BUTTON_LOCATOR_IN_MODAL_LOCATOR, title))).click();
		} else {
			driver.findElement(By.xpath(String.format(BUTTON_LOCATOR, title, title, title))).click();
		}
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
	}

	public void clickUsingJavaScript(String title) {
		js.clickUsingJavaScript(driver.findElement(By.xpath(String.format(BUTTON_LOCATOR, title, title, title))));
	}
}
