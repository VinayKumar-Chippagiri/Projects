package com.pldt.tests.ePLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

/*Prerequisites to execute this scenario  
 * Asset should be active.
 * Parent Account and Billing Account should be active.
 * ServiceID, contract term, pricing information, Asset dates must be populated.
 * 

*/
public class CaseManagement_P001653_51204 extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	String caseURL = null;
	ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdminintoSalesForce(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
		}).when("I Login to salesforce", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(10);
		}).then("I Verify Title of page", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));

		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Creating Case", priority = 2, dependsOnMethods = { "LoginasAdminintoSalesForce" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
		}).when("I open the account page and click on cases link", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			props.setProperty("Account", data.get("Account_Name"));
			util.waitFor(10);

		}).and("I verify that account details page of " + data.get("Account_Name") + " is displayed", () -> {
			String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
					.getText();
			Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getAccountDetailsPage().clickOnRelated("Cases");
		}).and("Creating new case", () -> {
			App().Pages().getAccountDetailsPage().clickOnRelated("Contacts");
			util.waitFor(5);
			App().Pages().getCustomerPortalPage().LogintoCustomerPortal();
			App().Pages().getCustomerPortalPage().CreateCaseInCustomerPortal(data);
		}).then("I Verified that case is created", () -> {
			Reporter.logWithScreenShot("Case is Created");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
		}).when("I Login to salesforce", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(10);
		}).then("I Verify Title of page", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Accept Case", priority = 4, dependsOnMethods = { "ValidateCaseOwner" })
	public void OpenCaseinSalesforce(Map<String, String> data) {
		scenario().given("User is on Home Page", () -> {	
		}).when("User navigated to cases tab", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
		}).and("Search all cases and open created case", () -> {
			App().Pages().getCasepage().SelectCaseGroup("All Cases");
			App().Pages().getCasepage().clickOnCaseByCaseNumber();
			util.waitForCasePage();
		}).then("User verify that navigated to case page", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "ValidateCaseOwner", priority = 3, dependsOnMethods = { "CreatingNewCase" })
	public void ValidateCaseOwner(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User Validate case owner", () -> {
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Case_Owner"));
		}).then("User Validate case owner", () -> {
			Reporter.logWithScreenShot("Validate case owner");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Accept Case", priority = 4, dependsOnMethods = { "ValidateCaseOwner" })
	public void AcceptCase(Map<String, String> data) {
		scenario().given("User is on Home Page", () -> {
		}).when("User Logout as current user", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("User Login with Support Queue", () -> {
			util.waitFor(8);
			App().Pages().getHomepage().SwitchToUser(data.get("Support Queue"), "Support Queue");
		}).and("User navigated to cases tab", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
		}).and("Search cases assign to Case Owner", () -> {
			App().Pages().getCasepage().SelectCaseGroup(data.get("Case_Owner"));
		}).and("User Accept the Case", () -> {
			App().Pages().getCasepage().acceptCase();
			App().Pages().getCasepage().SelectCaseGroup("My Cases");
			App().Pages().getCasepage().clickOnCaseByCaseNumber();
		}).then("User verify that case got accepted and navigated to case", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Create Task in feed", priority = 5, dependsOnMethods = { "AcceptCase" })
	public void CreateTask(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User Create Task from case feed", () -> {
			App().Pages().getCasepage().createTaskinFeed(data);
			Reporter.logWithScreenShot("Task is Created");
		}).then("User change status to resolution in Progress", () -> {
			util.ChangeStatusSMAX("Resolution In Progress", "In progress");
			Reporter.logWithScreenShot("Error Message is Displayed");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "ChangeStatustoResolutioninProgress", priority = 6, dependsOnMethods = { "CreateTask" })
	public void ChangeStatustoResolutioninProgress(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User Check SMAX Termination Request", () -> {
			pages.getCasepage().CheckSMAXTerminationRequest();
			Reporter.logWithScreenShot("Check SMAX Termination Request");
		}).then("User change status to resolution in Progress", () -> {
			util.ChangeStatusSMAX("Resolution In Progress", "In progress");
			Reporter.logWithScreenShot("Status change Successful");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "FillSolutionandchangestatus", priority = 7, dependsOnMethods = {
			"ChangeStatustoResolutioninProgress" })
	public void FillSolutionandchangestatus(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User Fill Solution in case page", () -> {
			pages.getCasepage().FillSolution(data);
		}).then("User change status to Resolved", () -> {
			util.ChangeStatusSMAX("Resolved", "For Client Confirmation");
			Reporter.logWithScreenShot("Status change Successful");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Closecase", priority = 8, dependsOnMethods = { "FillSolutionandchangestatus" })
	public void Closecase(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User is on casepage", () -> {
		}).then("User change status to Closed", () -> {
			util.ChangeStatusSMAX("Closed", "Complete");
			Reporter.logWithScreenShot("Status change Successful");
		}).execute();
	}

	@Test(priority = 9, dependsOnMethods = { "Closecase" })
	public void getReferenceData() {
		Reporter.log("case URL :" + ProjectBeans.getCaseURL(), MessageTypes.Info);

	}
}
