package com.pldt.tests.ePLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
/*Prerequisites to execute this scenario  
 * Asset should be active.
 * Parent Account and Billing Account should be active.
 * ServiceID, contract term, pricing information, Asset dates must be populated.
 * 

*/
public class CreateCase_CustomerPortal extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	String caseURL=null;
	ArrayList<String> orderList = null;



	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdminintoSalesForce(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
		}).when("I Login to salesforce", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(10);
		}).then("I Verify Title of page", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));

		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Creating Case", priority = 2, dependsOnMethods = { "LoginasAdminintoSalesForce" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
		}).when("I open the account page and click on cases link", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			props.setProperty("Account", data.get("Account_Name"));
			util.waitFor(10);

		}).and("I verify that account details page of " + data.get("Account_Name") + " is displayed", () -> {
			String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
					.getText();
			Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).and("Creating new case", () -> {
			App().Pages().getAccountDetailsPage().clickOnRelated("Contacts");
			util.waitFor(5);
			App().Pages().getCustomerPortalPage().LogintoCustomerPortal();
			App().Pages().getCustomerPortalPage().CreateCaseInCustomerPortal(data);
		}).then("I Verified that case is created", () -> {
			Reporter.logWithScreenShot("Case is Created");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login as Admin", priority = 3, dependsOnMethods = { "CreatingNewCase" })
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
		}).when("I Login to salesforce", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(10);
		}).then("I Verify Title of page", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Accept Case", priority = 4, dependsOnMethods = { "LoginasAdmin" })
	public void OpenCaseinSalesforce(Map<String, String> data) {
		scenario().given("User is on Home Page", () -> {	
		}).when("User navigated to cases tab", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
		}).and("Search all cases and open created case", () -> {
			App().Pages().getCaseListPage().SearchCaseUsingCaseNo("All Open Cases",props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
		}).then("User verify that navigated to case page", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R5AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "ValidateCaseOwner", priority = 5, dependsOnMethods = {
			"OpenCaseinSalesforce" })
	public void ValidateCaseOwner(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {	
		}).when("User Validate case owner", () -> {	
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Case_Owner"));	
		}).and("User  Login with Caseowner", () -> {	
			util.waitFor(8);
			App().Pages().getHomepage().SwitchToUser(data.get("Case_Owner"), "Case_Owner");
		}).then("User Validate case owner", () -> {	
			Reporter.logWithScreenShot("Validate case owner");
		}).execute();
	}
	
	
	
	@Test( priority = 6,dependsOnMethods = { "ValidateCaseOwner" })
	public void getReferenceData()
	{
		Reporter.log("case URL :"+ProjectBeans.getCaseURL(), MessageTypes.Info);

	}
}


