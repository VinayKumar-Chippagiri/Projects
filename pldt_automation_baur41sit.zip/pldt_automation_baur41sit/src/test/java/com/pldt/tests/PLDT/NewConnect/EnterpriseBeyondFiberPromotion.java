package com.pldt.tests.PLDT.NewConnect;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;
import java.util.ArrayList;
import java.util.Map;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class EnterpriseBeyondFiberPromotion extends BaseTest {
	 WebUtilities util = new WebUtilities();
	 AppCommons AppUtils = new AppCommons();
	 ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Lead", key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("User log in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(5);
			String title = getDriver().getTitle();
			Validator.verifyThat("User logged in as admin ", title, Matchers.equalTo("Home | Salesforce"));		
		}).and("User Switched to RelationShip Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			ConfigurationManager.getBundle().setProperty("RelationShip_Manager", data.get("Relationship Manager"));
		}).then("verify that User is Switched to RelationShip Manager", () -> {
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading,
					Matchers.containsString("Logged in as " + data.get("Relationship Manager")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Account", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void OpenExistingAccount(Map<String, String> data) {
		scenario().given("User is in home page", () -> {
			util.refreshPage();
		}).when("User open " + data.get("Account_Name") + " account", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			ConfigurationManager.getBundle().setProperty("Account", data.get("Account_Name"));
			ProjectBeans.setAccountURL(getDriver().getCurrentUrl()); // setting account url
			util.waitFor(7);
		}).then("User verified that account details page of " + data.get("Account_Name") + " is displayed", () -> {
			String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
					.getText();
			Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
		}).when("User click on contacts", () -> {
			getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
			util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
		}).and("User captured the contact name", () -> {
			String TechnicalContact = getDriver().findElement(By.xpath("//span[.='Technical']/ancestor::tr//th//a//span"))
					.getText();
			ConfigurationManager.getBundle().setProperty("contact.Technical", TechnicalContact);
			Reporter.log("Technical Contact: " + TechnicalContact);
			String Authorized_Signatory = getDriver()
					.findElement(By.xpath("//span[.='Authorized Signatory']/ancestor::tr//th//a//span")).getText();
			ConfigurationManager.getBundle().setProperty("Lead.fullName", Authorized_Signatory);
			Reporter.log("Authorized Signatory: " + Authorized_Signatory);
			Reporter.logWithScreenShot("Account Contact Details");
		}).and("User clicked on account and navigate back to account details page", () -> {
			QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
			AccountName.click();
		}).then("User verified that account details page is dispayed", () -> {
			util.waitForAccountPage();
			Reporter.logWithScreenShot("Account Details Page");
			util.waitForAccountPage();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "CreatingEnterpriseQuote", priority = 3, dependsOnMethods = { "OpenExistingAccount" })
	public void createEnterpriseQuote(Map<String, String> data) {
		scenario().given("User is on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("User click on create quote button", () -> {
			App().Pages().getAccountpage().ClickOncreateEnterpriseQuote();
		}).and("User create the quote by filling quote form", () -> {
			App().Pages().getQuotepage().createEnterpriseQuoteEndtoEnd(data);
			util.waitForQuotePage();
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("User verify that Quote is created", () -> {
			util.waitFor(5);
			String title = getDriver().findElement(By.xpath("//div[text()='Quote']/following::span[1]")).getText();
			Validator.verifyThat("Quote is created", title,
					Matchers.equalTo(ConfigurationManager.getBundle().getPropertyValue("Quote_name")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "credit check", priority = 4, dependsOnMethods = { "createEnterpriseQuote" })
	public void creditCheck(Map<String, String> data) {
		scenario().given("User is on Quote Page", () -> {
		}).when("User update Credit Information by Credit Analyst", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().CreditCheck();
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			App().Pages().getQuotepage().UpdateCreditInformationAdvance(data);
			App().Pages().getLoginpage().logoutCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		}).then("User verified that Credit Information is Updated", () -> {
			Reporter.logWithScreenShot("Credit Information ", MessageTypes.Pass);
		}).execute();
		util.waitForQuotePage();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "SelectingServiceAddressInBulkSite", priority = 5, dependsOnMethods = { "creditCheck" })
	public void selectServiceAdd(Map<String, String> data) {
		scenario().given("User is on Quote Page", () -> {
		}).when("Selecting Service Address by clicking on Bulk site", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().selectServiceAddress(data);
		}).then("User verify that service address is selected", () -> {
			Reporter.logWithScreenShot("Service adress is selected", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "PLDT_Cart", key = "${key.name}")
	@Test(description = "Configuring cart", priority = 6, dependsOnMethods = { "selectServiceAdd" }) //
	public void configureCart(Map<String, String> data) {
		scenario().given("User is on cart page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().ClickAddProducts();
		}).when("User add the plan "+ data.get("Plan")+"", () -> {
			App().Pages().getCartpage().ClickonPromotion(data.get("Plan"));
		}).when("User configure plans and do grouping and association of plan", () -> {
			App().Pages().getCartpage().ConfigurePromotionBeyondFiberDirectLine(data);
//			 Grouping and Association
		}).and("User do Grouping and Association", () -> {
			AppUtils.WorkingCart_grouping_Product(data.get("ExchangeiD"));
			util.waitForCartPage();
			AppUtils.SaveWorkingCart();
			util.waitForQuotePage();
			AppUtils.WorkingCart_Association("Enterprise Broadband Beyond Fiber Offer");
			AppUtils.Association_Validation();
		}).then("User verify that plan configured, grouping and assocation done", () -> {
			Reporter.logWithScreenShot("Plans configured, grouping and assocation done", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "updating Ets Details", priority = 7, dependsOnMethods = { "configureCart" }) //
	public void updateETSDetails(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().TriggerSD();
		}).when("User logout as current user and login as ETS member", () -> {
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("ETS"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
		}).and("User perform serviceability check", () -> {
//			App().Pages().getQuotepage().ServiceabilityCheck();
		}).and("User update ETS details and perform site survey", () -> {
			App().Pages().getQuotepage().TriggerETS(data);
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().SwitchToUser(
					ConfigurationManager.getBundle().getPropertyValue("Site_Survey_User"), "SiteSurveyUser");
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitFor(5);
			util.waitForQuotePage();
			App().Pages().getQuotepage().SiteSurvey(data);
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("ETS"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			App().Pages().getQuotepage().updateEtsDetails(data.get("EtsStatus"), data.get("EtsRemarks"));
		}).and("User logout as current user and login as RM", () -> {
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).and("User verify that ETS completed", () -> {
			Reporter.logWithScreenShot("Updated ETS details", MessageTypes.Pass);
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "SiteBandZloc", priority = 8, dependsOnMethods = { "updateETSDetails" })
	public void SiteBandZloc(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User selecting siteB and Zloc", () -> {
			App().Pages().getQuotepage().siteBandzloc(data);
		}).then("User Verify notify_toast is displayed", () -> {
			QAFExtendedWebElement notifytoastxpath = new QAFExtendedWebElement(
					"xpath=//div[@class='slds-notify slds-notify_toast slds-theme_info']");
			notifytoastxpath.verifyPresent(
					"You have not indicated any change in Billing Address. System would use below Address for creating Billing Accounts for all services added in this Quote.\r\n"
							+ "Philippines\r\n" + "\r\n"
							+ "Please go to Billing Management button if you want to create new billing accounts manually after clicking Cancel button");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Billing Management", priority = 9, dependsOnMethods = { "SiteBandZloc" })
	public void selectBillingAddress(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User select billing address ", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().billingManagement(data);
		}).then("User verify billing address is selected and navigated to quote page", () -> {
			Reporter.logWithScreenShot("Billing address selected and navigated to quote page", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "updating Contact Details", priority = 10, dependsOnMethods = { "selectBillingAddress" })
	public void updateContactDetails(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User update contact details", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().updatePldtContactDetails(data);
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("User verify contact details are updated", () -> {
			Reporter.logWithScreenShot("Updated contact details", MessageTypes.Pass);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "PLDT_Cart", key = "${key.name}")
	@Test(description = "syncronize QLI Items", priority = 11, dependsOnMethods = { "updateContactDetails" }) //
	public void syncronizeQLIItems(Map<String, String> data) {
		scenario().given("User is on Quote page", () -> {
		}).when("User Change quote status to presented", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			util.ChangeStatus("Internal Approval");
			App().Pages().getQuotepage().ChangeStatusToPresented(data);
			util.waitFor(6);
			Reporter.logWithScreenShot("Quote Status Changed to Presented");
		}).and("User generate quote document", () -> {
			App().Pages().getQuotepage().QuoteGeneration("Pdf");
			AppUtils.pickLatestFileFromDownloads("Quote Document");
			Reporter.logWithScreenShot("Quote to PDF downloaded and status changed to presented");
		}).and("User change quote status to customer accepted", () -> {
			App().Pages().getQuotepage().changeQuoteStatustoCustomerAccepted();
			Validator.verifyThat("Verify Quote status changed to Accepted", AppUtils.getToastMessage(),
					Matchers.containsString("Status changed successfully"));
		}).and("User synchronizing QLI Items", () -> {
			App().Pages().getQuotepage().PLDT_SynchronizingAccount(data.get("Plan"), data.get("Relationship Manager"));
		}).then("User verified that QLI Items got Synced and navigated to quote page", () -> {
			Reporter.logWithScreenShot("QLI Items Synced and navigated to quote page", MessageTypes.Pass);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Detail Design Required", priority = 12, dependsOnMethods = { "syncronizeQLIItems" }) //
	public void DetailDesignRequired(Map<String, String> data) {
		scenario().given("User is on Quote page", () -> {
		}).when("User perform detail design required task", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getLoginpage().logoutCurrentUser();
			App().Pages().getHomepage().SwitchToUser(
					ConfigurationManager.getBundle().getPropertyValue("Site_Survey_User"), "SiteSurveyUser");
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			App().Pages().getQuotepage().DetailDesignReq(data);
		}).then("User verified that detail design required task completed", () -> {
			Reporter.logWithScreenShot("Detail design required task completed", MessageTypes.Pass);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Generate Contract", priority = 13, dependsOnMethods = { "DetailDesignRequired" })
	public void GenerateContract(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User click create contract button", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			App().Pages().getQuotepage().CreateContract();
		}).and("User click on generate Documents ", () -> {
			util.refreshPage();
			util.waitForContractPage();
			App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
			util.waitForContractPage();
			AppUtils.pickLatestFileFromDownloads("Contract Document");
		}).when("User change contract status to signed", () -> {
			App().Pages().getQuotepage().ChangeTheStatusToSigned();
		}).then("User verified that Contract got generated", () -> {
			Reporter.logWithScreenShot(" Contract generated ", MessageTypes.Pass);
			ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
			util.waitFor(3);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnectProducts.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Verify Orders", priority = 14, dependsOnMethods = { "GenerateContract" })
	public void verifyOrders(Map<String, String> data) {
		scenario().given("User is on orders page", () -> {
		}).when("User verify orders", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList = App().Pages().getQuotepage().VerifyingOrders(20, 2);
			ProjectBeans.setOrderURL(getDriver().getCurrentUrl());
		}).then("User verified that Orders got generated", () -> {
			Reporter.logWithScreenShot(" Orders generated ", MessageTypes.Pass);
		}).execute();
	}

	@Test(priority = 15, dependsOnMethods = { "verifyOrders" })
	public void getReferenceData() {
//		Reporter.log("Lead URL :" + ProjectBeans.getLeadURL(), MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :" + ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :" + ProjectBeans.getContractURL(), MessageTypes.Info);
		Reporter.log("OrderPage URL :" + ProjectBeans.getOrderURL(), MessageTypes.Info);
		}
}
