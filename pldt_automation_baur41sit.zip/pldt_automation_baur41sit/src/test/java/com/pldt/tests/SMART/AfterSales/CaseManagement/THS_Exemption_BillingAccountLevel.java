package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

/*******************************************************************************************************************************************
                            Add / Edit THS Exemption (Billing Account Level)
 *********************************************************************************************************************************************/
public class THS_Exemption_BillingAccountLevel extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL=null;
	String orderURL=null;
	ArrayList<String> orderList =null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to Revenue Analyst", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRevenueAnalyst(Map <String,String> data) {
		scenario().given("user Switch to Credit Analyst", () -> {
		}).when("User Login As Revenue Analyst", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Revenue_Analyst"));	
			Reporter.log("Switched to Revenue Analyst:" + data.get("Revenue_Analyst"));
		}).then("verify Admin successfully switched to Revenue Analyst", () -> {
			Reporter.logWithScreenShot("Successfully switched to Revenue Analyst");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRevenueAnalyst" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("user Fill case details form and save", () -> {	
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getCasepage().createNewCaseAfterSalesCaseManagementESoA(data);
			//App().Pages().getCaseListPage().createNewCaseFromAsset(data);
			//App().Pages().getCasepage().retriveCaseNumberFromNotification();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Fill Transaction Details in casepage", priority = 4, dependsOnMethods = { "CreateNewCase" })
	public void UpdateTransactionDetails(Map<String, String> data) {
		scenario().given("Updating TransactionDetails from case page", () -> {
		}).when("User upadtae fields in transaction Details", () -> {
			App().Pages().getCasepage().caseModificationfortreatment(data.get("Asset_Name"),data.get("Asset ID"),data);
		}).and("User Change Status to Resolution in Progress", () -> {		
			util.ChangeStatus("Resolution In Progress");
	}).then("User Verify Changes made in Case page", () -> {
		Reporter.logWithScreenShot("UpdateTransactionDetails and change status to Resolution in Progress", MessageTypes.Info);
	}).execute();
}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Checking Transcation Id", priority = 11, dependsOnMethods = { "UpdateTransactionDetails" })
	public void CheckingTransctionId(Map<String, String> data) {
		scenario().given("Checking Transaction ID creation and status", () -> {
		}).when("User check TransactionID got Created", () -> {
//			App().Pages().getLoginpage().logoutCurrentUser();
//			util.goToURL(caseURL);
			App().Pages().getCasepage().MoveTransactionStatusToSuccessful(caseURL);
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).then("User verify TransactionID status is successful ", () -> {
			Reporter.logWithScreenShot("TransactionID status is successful", MessageTypes.Info);
			}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 12, dependsOnMethods = { "CheckingTransctionId" })
	public void ChangeCaseStatus(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
		}).when("user Changes the status to Resolved", () -> {
			util.ChangeStatus("Resolved");
		}).then("User verify Case Status is Resolved ", () -> {
			Reporter.logWithScreenShot("Case status", MessageTypes.Info);
			}).execute();
	}
	
	
	@Test(priority = 13,dependsOnMethods = { "ChangeCaseStatus" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
	}
}