package com.pldt.tests.PLDT.AfterSales.Modify;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
/*Prerequisites to execute this scenario  
 * Asset should be active.
 * Parent Account and Billing Account should be active.
 * ServiceID, contract term, pricing information, Asset dates must be populated.
 * 

*/
public class DeviceModification_SIM_PLDTLLP extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	ArrayList<String> orderList = null;



	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("User log in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(5);
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("User logged in as admin ", title, Matchers.equalTo("Home | Salesforce"));		
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "Switch to Relationship Manager", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void SwitchingtoRM(Map<String, String> data) {
		scenario().given("user Switch to Relationship Manager", () -> {
		}).when("User Login As Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to Relationship Manager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager", () -> {
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading, Matchers.containsString("Logged in as " + data.get("Relationship Manager")));
		}).execute();
	}

	
	

	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Creating Case", priority = 3, dependsOnMethods = {
			"SwitchingtoRM" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
			pages.getAccountDetailsPage().clickOnRelated("Cases");
		}).and("Creating case for Device Modification", () -> {
			pages.getCaseListPage().clickNewCaseButton();
			pages.getNewCaseModal().SelectRecordType(data.get("Record Type"));
			pages.getCasepage().createAfterSalesNewCase();
		}).then("Selecting The Case Created", () -> {
			util.waitFor(10);
			pages.getCaseListPage().selectCase(data.get("Subject"));		
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());     //set Case URL
	}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "ValidateCaseOwner", priority = 4, dependsOnMethods = {
			"CreatingNewCase" })
	public void ValidateCaseOwner(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Validate case owner", () -> {	
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Case_Owner"));
		}).and("User Logout", () -> {	
			App().Pages().getLoginpage().logoutCurrentUser();	
		}).then("User verify case owner  ", () -> {
			Reporter.logWithScreenShot("User navigate to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Accept Case", priority = 5, dependsOnMethods = { "ValidateCaseOwner" })
	public void AcceptCase(Map<String, String> data) {
		scenario().given("User is on Home Page", () -> {
		}).when("User Logout as current user", () -> {
//			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("User Login with Support Queue", () -> {
			util.waitFor(8);
			getDriver().get(ProjectBeans.getCaseURL());    //get case URL
			util.waitForCartPage();
			App().Pages().getHomepage().SwitchToUser(data.get("Support Team"),"Support Team");		
		}).and("User navigated to cases tab", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
		}).and("Search cases assign to Case Owner", () -> {	
			App().Pages().getCasepage().SelectCaseGroup(data.get("Case_Owner"));
		}).and("User Accept the Case", () -> {	
			App().Pages().getCasepage().acceptCase();
			App().Pages().getCasepage().SelectCaseGroup("My Cases");
			App().Pages().getCasepage().clickOnCaseByCaseNumber();			
		}).then("User verify that case got accepted and navigated to case", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	
		
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Creating Case", priority = 6, dependsOnMethods = {
			"AcceptCase" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("Going in case and adding billing account", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("Checking Negative Scenarios And Add Billing Account", () -> {
			pages.getCasepage().CheckNegativeScenarios();
			pages.getCaseDetailsPage().AddBillingAccountforModify(data);
		}).and("Add Required Documents", () -> {
			pages.getCaseDetailsPage().VerifyBulkServiceRequestFromRelated(ProjectBeans.getCaseURL());
			getDriver().get(ProjectBeans.getCaseURL());               //get case URL
			util.ChangeStatus("Document Pending");
			pages.getCaseDetailsPage().AddDocumentsRequired();
			util.waitFor(5);
		}).then("Change Status to Assigned For Resolution and Clicking on MODIFY And Add Primary Service ", () -> {
			util.ChangeStatus("Assigned For Resolution");
			pages.getCaseDetailsPage().RequestModify(data,"MODIFY");
			ProjectBeans.setOrderURL(getDriver().getCurrentUrl());     //set Order URL
			Reporter.logWithScreenShot("User request Modify");
	}).execute();
	}
	
	
	
	
	@Test( priority = 7,dependsOnMethods = { "AddBillingAccount" })
	public void getReferenceData()
	{
		Reporter.log("Case URL :"+ProjectBeans.getCaseURL(), MessageTypes.Info);
		Reporter.log("Order URL :"+ProjectBeans.getOrderURL(), MessageTypes.Info);
	}
}


