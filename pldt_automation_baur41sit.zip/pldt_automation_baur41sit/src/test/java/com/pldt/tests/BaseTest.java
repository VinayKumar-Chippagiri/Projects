package com.pldt.tests;

import org.testng.annotations.BeforeMethod;

import com.pldt.lib.AppLib;
import com.qmetry.qaf.automation.ui.WebDriverTestCase;

public class BaseTest extends WebDriverTestCase {
	private AppLib applib;

	@BeforeMethod(alwaysRun = true)
	public void setUp() {
		applib = new AppLib();
	}

	public AppLib App() {
		return (applib == null) ? applib = new AppLib() : applib;
		// applib=null;
		// AppLib applib=new AppLib();
		// return applib;
	}
}
