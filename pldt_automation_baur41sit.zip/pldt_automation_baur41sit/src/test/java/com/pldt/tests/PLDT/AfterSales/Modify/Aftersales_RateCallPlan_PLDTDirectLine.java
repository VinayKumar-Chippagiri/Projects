package com.pldt.tests.PLDT.AfterSales.Modify;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
/*Prerequisites to execute this scenario  
 * Asset should be active.
 * Parent Account and Billing Account should be active.
 * ServiceID, contract term, pricing information, Asset dates must be populated.
 * 

*/
public class Aftersales_RateCallPlan_PLDTDirectLine extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	ArrayList<String> orderList = null;



	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(30);
			String title = getDriver().getTitle();		
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).then("verify that User is Switched to Credit Analyst", () -> {
//			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			App().Pages().getHomepage().SwitchToUser(data.get("Credit Analyst"),"Credit Analyst");	
			props.setProperty("Credit Analyst", data.get("Credit Analyst"));
			util.waitFor(20);
			util.waitFor(By.xpath("(//header[@id='oneHeader']//span)[2]"), 30, true);
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading,
					Matchers.containsString("Logged in as " + data.get("Credit Analyst")));
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Account", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void Open_Existing_Account(Map<String, String> data) {
	scenario().given("I am in home page", () -> {
	util.refreshPage();
	util.waitFor(5);
	}).when("I open " + data.get("Account_Name") + " account", () -> {
		App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
	props.setProperty("Account", data.get("Account_Name"));
	util.waitFor(10);
	}).then("I verify that account details page of " + data.get("Account_Name") +" is displayed", () -> {
	String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
	.getText();
	Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
	}).when("I click on contacts", () -> {
	getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
	util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
	}).and("I captured the contact name", () -> {
		String TechnicalContact = getDriver().findElement(By.xpath("(//span[.='Technical']/ancestor::tr//th//a//span)[1]"))
			    .getText();
			    props.setProperty("contact.Technical", TechnicalContact);
			    Reporter.log("Technical Contact: " + TechnicalContact);
			    String Authorized_Signatory = getDriver()
			    .findElement(By.xpath("(//span[.='Authorized Signatory']/ancestor::tr//th//a//span)[1]")).getText();
			    props.setProperty("Lead.fullName", Authorized_Signatory);
			    Reporter.log("Authorized Signatory: " + Authorized_Signatory);
			    Reporter.logWithScreenShot("Account Contact Details");
	}).and("I clicked on account and navigate back to account details page", () -> {
	QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
	AccountName.click();
	}).then("then i verified that account details page is dispayed", () -> {
	util.waitForAccountPage();
	Reporter.logWithScreenShot("Account Details Page");
	}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Creating Case", priority = 3, dependsOnMethods = {
			"Open_Existing_Account" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getAccountDetailsPage().clickOnRelated("Cases");
		}).when("Creating case for Contract Renewal", () -> {
			pages.getCaseListPage().clickNewCaseButton();
			pages.getNewCaseModal().SelectRecordType(data.get("Record Type"));
			pages.getCasepage().createAfterSalesNewCase();
		}).then("Selecting The Case Created", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();	
			util.waitFor(5);
			App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"),"Relationship Manager");	
			util.waitFor(3);
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			util.waitFor(10);
			pages.getAccountDetailsPage().clickOnRelated("Cases");
			util.waitFor(3);
			pages.getCaseListPage().selectCase(data.get("Subject"));		
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());     //set Case URL
	}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "ValidateCaseOwner", priority = 4, dependsOnMethods = {
			"CreatingNewCase" })
	public void ValidateCaseOwnerRM(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Validate case owner", () -> {	
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Relationship Manager"));
		}).and("User Logout", () -> {	
			App().Pages().getLoginpage().logoutCurrentUser();	
		}).and("User Login with Pldt_Support", () -> {	
			util.waitFor(8);
//			App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"),"Relationship Manager");
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			getDriver().get(ProjectBeans.getCaseURL());    
			util.waitForCasePage();
		}).then("User verify case owner  ", () -> {
			Reporter.logWithScreenShot("User navigate to case page");
		}).execute();
	}
	
	
		
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Creating Case", priority = 5, dependsOnMethods = {
			"ValidateCaseOwnerRM" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("Going in case and adding billing account", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("Checking Negative Scenarios And Add Billing Account", () -> {
			pages.getCasepage().CheckNegativeScenarios();
			pages.getCaseDetailsPage().AddBillingAccountforModify(data);
		}).and("Add Required Documents", () -> {
			pages.getCaseDetailsPage().VerifyBulkServiceRequestFromRelated(ProjectBeans.getCaseURL());
			getDriver().get(ProjectBeans.getCaseURL());               //get case URL
			util.ChangeStatus("Document Pending");
			pages.getCaseDetailsPage().AddDocumentsRequired();
		}).then("Change Status to Assigned For Resolution and Clicking on MODIFY And Add Primary Service ", () -> {
			util.ChangeStatus("Assigned For Resolution");
			pages.getCaseDetailsPage().RequestModify(data,"MODIFY");
			Reporter.logWithScreenShot("User request Modify");
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Creating Case", priority = 6, dependsOnMethods = {
			"AddBillingAccount" })
	public void NegotiatedUsageRate(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I Get QuoteName", () -> {
			pages.getQuotepage().copyQuoteName();
		}).then("I Checked Negotiated Usage Rate", () -> {
			QAFWebElement Status = new QAFExtendedWebElement(
					"xpath=//span[.='Negotiated Usage Rates']/parent::div/following-sibling::div//img[@class=' checked']");
			util.scrollIntoElement(Status);
			util.waitFor(3);
			Validator.verifyTrue(Status.isPresent(), "Negotiated Usage Rate not Checked",
				"Negotiated Usage Rate Checked");
			Reporter.logWithScreenShot("User change to Internal Approval");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "updating Contact Details", priority = 7, dependsOnMethods = { "NegotiatedUsageRate" })
	public void updateContactDetails(Map<String, String> data) {
		scenario().given(" Update Contact Details ", () -> {
		}).when("I update contact details", () -> {
		props.setProperty("testdata", data);
		pages.getQuotepage().updatePldtContactDetails(data);
		ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "credit check", priority = 8, dependsOnMethods = { "updateContactDetails" })
	public void creditCheck(Map<String, String> data) {
		scenario().given("I perform credit check and I update credit information", () -> {
		props.setProperty("testdata", data);
		}).when("I Click on Credit Check", () -> {
			pages.getQuotepage().CreditCheck();
		}).and(" I logged out as RM User ", () -> {
		pages.getLoginpage().logoutAsCurrentUser();
		}).then(" I logged in as Credit Analyst ", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		pages.getHomepage().SwitchToUser(data.get("Credit Analyst"), "Credit Analyst");
		getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		util.waitForQuotePage();
		}).and("I Update Credit Approval Status and Credit Remark", () -> {
		pages.getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
				data.get("CreditApprovalCondition"), data.get("CreditRemark"));
		}).and(" I logged out as Credit Analyst ", () -> {
		pages.getLoginpage().logoutCurrentUser(); 
		}).and(" I logged in as Relationship Manager ", () -> { 
		pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		util.waitForQuotePage();
		}).then("Change Status to Internal Approval", () -> {
			util.ChangeStatus("Internal Approval");
			util.waitFor(5);
			Reporter.logWithScreenShot("User change to Internal Approval");
		}).execute();		
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Check SBR approve", priority = 9, dependsOnMethods = { "creditCheck" })
	public void CheckSBRapprove(Map<String, String> data) {
		props.setProperty("testdata", data);
		if(data.get("SBR Approve").contains("YES")) {	
		scenario().given(" I am on Quote Page", () -> {
			}).when("I Wait for Quote page", () -> {
				util.refreshPage();
				util.waitForQuotePage();
			}).and(" I Check SBR Approval required ", () -> {
				pages.getQuotepage().SBRapprovalRequired();
			}).then(" I Check Sbr Approval required ", () -> {
				
			}).execute();
		}
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Login CBOM and check chatter", priority = 10, dependsOnMethods = { "CheckSBRapprove" })
	public void LoginCBOMcheckchatter(Map<String, String> data) {
		props.setProperty("testdata", data);
		if(data.get("SBR Approve").contains("YES")) {
		scenario().given(" I am on Quote Page", () -> {
		}).when("I Login with CBOM member", () -> {
		pages.getLoginpage().logoutAsCurrentUser();
		util.waitFor(5);
		getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL   
		util.waitFor(5);
		App().Pages().getHomepage().SwitchToUser(data.get("CBOM Member"),"CBOM Member");	
		}).and("I navigate to Quote Page", () -> {	
	     pages.getQuotepage().ChatterNotifications(data);	     
		}).then("I Logout User ", () -> {
		pages.getLoginpage().logoutAsCurrentUser();
		util.waitFor(5);
		
		}).execute();
		}
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Login RM and submit approve", priority = 11, dependsOnMethods = { "LoginCBOMcheckchatter" })
	public void LoginRMsubmitapprove(Map<String, String> data) {
		props.setProperty("testdata", data);
		if(data.get("SBR Approve").contains("YES")) {	
		scenario().given(" I am on Quote Page", () -> {
		}).when("I Login with Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).and("I navigate to Quote Page", () -> {	
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL    
			util.waitForQuotePage();
		}).and("I Change status to Presented ", () -> {
			util.ChangeStatus("Presented");
			Reporter.logWithScreenShot("Error message when status change to presented");
		util.waitFor(5);
		}).then("I Submit For Approval", () -> {
			pages.getQuotepage().SubmitForApprovalformQuote();
		}).execute();
		}
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Check Approver and Login", priority = 12, dependsOnMethods = { "LoginRMsubmitapprove" })
	public void CheckApprover_Login(Map<String, String> data) {
		props.setProperty("testdata", data);
		if(data.get("SBR Approve").contains("YES")) {	
		scenario().given(" I am on Quote Page", () -> {
		}).when("I Check the approver", () -> {
			pages.getQuotepage().VerifyApprover();
		}).and("I Logout as RM", () -> {	
			pages.getLoginpage().logoutAsCurrentUser();
			util.waitFor(5);   
		}).and("I Login as Approver ", () -> {
			String Approver = App().Pages().getQuotepage().getAPPROVER();
			getDriver().get(ProjectBeans.getQuoteURL());
			App().Pages().getHomepage().SwitchToUser(Approver,"CRM Head");
		util.waitFor(5);
		}).then("I check logged in CRM Approver", () -> {
			Reporter.logWithScreenShot("Logged in as CRM Approver");
		}).execute();
		}
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Approver Quote Login RM", priority = 13, dependsOnMethods = { "CheckApprover_Login" })
	public void ApproveQuoteLoginRM(Map<String, String> data) {
		props.setProperty("testdata", data);
		if(data.get("SBR Approve").contains("YES")) {	
		scenario().given(" I Logged in as CRM head", () -> {
		}).when("I Approve as a CRM Head", () -> {
			pages.getQuotepage().ApproveQuoteFromItemstoApprove();
		}).and("I Logout as CRM Head", () -> {	
			pages.getLoginpage().logoutAsCurrentUser();
			util.waitFor(5);   
		}).and("I Login as RM ", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		util.waitFor(5);
		}).and("I navigate to quote page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL    
			util.waitForQuotePage();
		}).then("I verify status of Non-SMART SBR Approval Status", () -> {	
			util.waitFor(5);
			util.scrollIntoElement(By.xpath("//div[.='Non-SMART SBR Approval Status']/following-sibling::div/span/span"));
			util.waitFor(5);
			String status = getDriver().findElement(By.xpath("//div[.='Non-SMART SBR Approval Status']/following-sibling::div/span/span"))
					.getText();
					Validator.verifyThat("", status, Matchers.containsString("Pending Approval"));
			Reporter.logWithScreenShot("Non-SMART SBR Approval Status");
		}).execute();
		}
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Approver with Bid Exec", priority = 14, dependsOnMethods = { "ApproveQuoteLoginRM" })
	public void ApprovewithBidExec(Map<String, String> data) {
		props.setProperty("testdata", data);
		if(data.get("SBR Approve").contains("YES")) {	
		scenario().given(" I am on Quote Page", () -> {
		}).when("I Check the approver", () -> {
			pages.getQuotepage().VerifyApprover();
		}).and("I Logout as RM", () -> {	
			pages.getLoginpage().logoutAsCurrentUser();
			util.waitFor(5);   
		}).and("I Login as Approver ", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL   
			util.waitFor(5);
			String Approver = App().Pages().getQuotepage().getAPPROVER();
			App().Pages().getHomepage().SwitchToUser(Approver,"Bid Exec");
		util.waitFor(5);
		}).and("Approve the Quote", () -> {
			pages.getQuotepage().ApproveQuoteFromItemstoApprove();
		}).and("I Logout as BidExec", () -> {	
			pages.getLoginpage().logoutAsCurrentUser();
			util.waitFor(5);   
		}).and("I Login as RM ", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitFor(5);
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		util.waitFor(5);
		}).and("I navigate to quote page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL    
			util.waitForQuotePage();
			Reporter.logWithScreenShot("navigate to quote page");
		}).then("I verify status of Non-SMART SBR Approval Status", () -> {	
			util.waitFor(5);
			util.scrollIntoElement(By.xpath("//div[.='Non-SMART SBR Approval Status']/following-sibling::div/span/span"));
			util.waitFor(5);
			String status = getDriver().findElement(By.xpath("//div[.='Non-SMART SBR Approval Status']/following-sibling::div/span/span"))
					.getText();
					Validator.verifyThat("", status, Matchers.containsString("Pending Approval"));
			Reporter.logWithScreenShot("Non-SMART SBR Approval Status");
		}).execute();
		}
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Approver with CBOM Head", priority = 15, dependsOnMethods = { "ApprovewithBidExec" })
	public void ApprovewithCBOMHead(Map<String, String> data) {
		props.setProperty("testdata", data);
		if(data.get("SBR Approve").contains("YES")) {	
		scenario().given(" I am on Quote Page", () -> {
		}).when("I Check the approver", () -> {
			pages.getQuotepage().VerifyApprover();
		}).and("I Logout as RM", () -> {	
			pages.getLoginpage().logoutAsCurrentUser();
			util.waitFor(5);  
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL 
			util.waitFor(5);
		}).and("I Login as Approver ", () -> {
			String Approver = App().Pages().getQuotepage().getAPPROVER();
			App().Pages().getHomepage().SwitchToUser(Approver,"CBOM Head");
		util.waitFor(5);
		}).and("Approve the Quote", () -> {
			pages.getQuotepage().ApproveQuoteFromItemstoApprove();
		}).and("I Logout as CBOM Head", () -> {	
			pages.getLoginpage().logoutAsCurrentUser();
			util.waitFor(5);  
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL   
			util.waitFor(5);
		}).and("I Login as RM ", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		util.waitFor(5);
		}).and("I navigate to quote page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL    
			util.waitForQuotePage();
			Reporter.logWithScreenShot("navigate to quote page");
		}).then("I verify status of Non-SMART SBR Approval Status", () -> {	
			util.waitFor(5);
			util.scrollIntoElement(By.xpath("//div[.='Non-SMART SBR Approval Status']/following-sibling::div/span/span"));
			util.waitFor(5);
			String status = getDriver().findElement(By.xpath("//div[.='Non-SMART SBR Approval Status']/following-sibling::div/span/span"))
					.getText();
					Validator.verifyThat("", status, Matchers.containsString("Approved"));
			Reporter.logWithScreenShot("Non-SMART SBR Approval Status");
		}).execute();
		}
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "create Contract", priority = 16, dependsOnMethods = { "ApprovewithCBOMHead" })
	public void createContract(Map<String, String> data) {
		props.setProperty("testdata", data);
		util.ChangeStatus("Presented");
		util.waitFor(5);
		util.ChangeStatus("Customer Accepted");
		util.waitFor(5);
		pages.getQuoteDetailsPage().CreateContractinAfterSales(data);
		ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "generate Documents", priority = 17, dependsOnMethods = { "createContract" })
	public void generateDocuments(Map<String, String> data) {
	props.setProperty("testdata", data);	
	scenario().given("I am on Contract Page", () -> {
	}).when("I click on generate Documents ", () -> {
	util.refreshPage();
	util.waitForContractPage();
	App().Pages().getContractpage().GenerateContractDocwithcontact(data.get("Template"));
	util.waitForContractPage();
	}).and("I change status to signed", () -> {
	util.waitFor(5);
	pages.getQuotepage().ChangeTheStatusToSigned();
	}).then("i verified that File is Uploaded", () -> {
	Reporter.logWithScreenShot(" Generate Documents ", MessageTypes.Info);
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Verify EBM notification", priority = 18, dependsOnMethods = { "generateDocuments" })
	public void VerifyEBMnotify(Map<String, String> data) {
	props.setProperty("testdata", data);
	scenario().given("I am on Contract Page", () -> {
	}).when("I click on EBM Notification", () -> {
		util.waitFor(10);
	util.refreshPage();
	util.waitForContractPage();
	App().Pages().getContractpage().verifyEBMnotify(data);
	ProjectBeans.setEBMNotificationURL(getDriver().getCurrentUrl()); // setting EBMNotificationURL Url
	}).and("I Login As EBM Aftersales Member", () -> {
		pages.getLoginpage().logoutAsCurrentUser();
		util.waitFor(5);  
		getDriver().get(ProjectBeans.getEBMNotificationURL());  // Get EBMNotificationURL URL  
		util.waitFor(10);
//		util.waitForQuotePage();
		App().Pages().getHomepage().SwitchToUser(data.get("EBMASmember"),"EBM Aftersales Member");
		util.waitFor(5);
		getDriver().get(ProjectBeans.getEBMNotificationURL()); // Get EBMNotificationURL URL    
	}).and("I Change assigned to and complete task", () -> {
		App().Pages().getContractpage().Changeassignandtaskcomplete(data);
	}).then("i verified task Completed", () -> {
	Reporter.logWithScreenShot(" Task Completed ", MessageTypes.Info);
	}).execute();
	}
	
	
	@Test( priority = 19,dependsOnMethods = { "VerifyEBMnotify" })
	public void getReferenceData()
	{
		Reporter.log("Case URL :"+ProjectBeans.getCaseURL(), MessageTypes.Info);
		Reporter.log("Quote URL :"+ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :"+ProjectBeans.getContractURL(), MessageTypes.Info);
		Reporter.log("EBM Notification URL :"+ProjectBeans.getEBMNotificationURL(), MessageTypes.Info);
	}
}


