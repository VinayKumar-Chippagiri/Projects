package com.pldt.tests.PLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;
import java.util.ArrayList;
import java.util.Map;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class NewInstallBEYONDFIBERDAREPromo extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	ArrayList<String> orderList = null;
	String caseURL = null;
	String quoteURL = null;
	String caseNo = null;
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("User log in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(5);
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("User logged in as admin ", title, Matchers.equalTo("Home | Salesforce"));		
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Switch to Credit Analyst", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void SwitchingtoCreditAnalyst(Map<String, String> data) {
		scenario().given("user Switch to Credit Analyst", () -> {
		}).when("User Login As Credit Analyst", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			Reporter.log("Switched to Credit Analyst:" + data.get("Credit Analyst"));
		}).then("verify Admin successfully switched to Credit Analyst", () -> {
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading, Matchers.containsString("Logged in as " + data.get("Credit Analyst")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Account", priority = 3, dependsOnMethods = { "SwitchingtoCreditAnalyst" })
	public void OpenExistingAccount(Map<String, String> data) {
		scenario().given("User is in home page", () -> {
			util.refreshPage();
		}).when("User open " + data.get("Account_Name") + " account", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			ConfigurationManager.getBundle().setProperty("Account", data.get("Account_Name"));
			ProjectBeans.setAccountURL(getDriver().getCurrentUrl()); // setting account url
			util.waitFor(7);
		}).then("User verified that account details page of " + data.get("Account_Name") + " is displayed", () -> {
			String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
					.getText();
			Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
		}).when("User click on contacts", () -> {
			getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
			util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
		}).and("User captured the contact name", () -> {
			String TechnicalContact = getDriver().findElement(By.xpath("//span[.='Technical']/ancestor::tr//th//a//span"))
					.getText();
			ConfigurationManager.getBundle().setProperty("contact.Technical", TechnicalContact);
			Reporter.log("Technical Contact: " + TechnicalContact);
			String Authorized_Signatory = getDriver()
					.findElement(By.xpath("//span[.='Authorized Signatory']/ancestor::tr//th//a//span")).getText();
			ConfigurationManager.getBundle().setProperty("Lead.fullName", Authorized_Signatory);
			Reporter.log("Authorized Signatory: " + Authorized_Signatory);
			Reporter.logWithScreenShot("Account Contact Details");
		}).and("User clicked on account and navigate back to account details page", () -> {
			QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
			AccountName.click();
		}).then("User verified that account details page is dispayed", () -> {
			util.waitForAccountPage();
			Reporter.logWithScreenShot("Account Details Page");
			util.waitForAccountPage();
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Creating new case ", priority = 4, dependsOnMethods = { "OpenExistingAccount" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().given("Going in account", () -> {
		}).when("User open account page", () -> {
		}).and("user click on cases to create a new case", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("user Fill case details form and save", () -> {
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			App().Pages().getCasepage().createNewCaseCaseManagementBulk(data);
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
		}).then("User verify the case got Created and case page is opened ", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("User is on case page ", title, Matchers.containsString("Salesforce"));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Validate Case Owner and Case Status", priority = 5, dependsOnMethods = { "CreateNewCase" })
	public void ValidateCaseOwnerAndStatus(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User open case page and check for the case owner", () -> {
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Relationship Manager"));
			caseURL = getDriver().getCurrentUrl();
			caseNo = getDriver().findElement(By.xpath(
					"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
					.getText();
		}).then("Verified Case Status", () -> {
			App().Pages().getCaseDetailsPage().verfifyCaseStatus("Open");
			Reporter.logWithScreenShot("Case status is open");
		}).execute();
	}
	

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Switch to Relationship Manager", priority = 6, dependsOnMethods = { "ValidateCaseOwnerAndStatus" })
	public void SwitchingtoRelationshipManager(Map<String, String> data) {
		scenario().given("user Switch to Credit Analyst", () -> {			
		}).when("User Logout as CA and Login As Relationship Manager", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to Relationship Manager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager", () -> {
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading, Matchers.containsString("Logged in as " + data.get("Relationship Manager")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Add Billing Account and Verify Bulk Service Request", priority = 7, dependsOnMethods = {
			"SwitchingtoRelationshipManager" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User click on Add Billing Account", () -> {
			util.goToURL(caseURL);
			App().Pages().getCasepage().AddBillingAccountforCreate(data);
			util.waitForCasePage();
		}).then("Verified Bulk Service Request", () -> {
			App().Pages().getCasepage().VerifyBulkServiceReq();
			Reporter.logWithScreenShot("Bulk Service Request is generated");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Update case status and Select required document", priority = 8, dependsOnMethods = {
			"AddBillingAccount" })
	public void UpdateCaseStatus(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User change case status to Document Pending", () -> {
			App().Pages().getCaseDetailsPage().ChangeCaseStatus("Document Pending");
		}).and("User select required document", () -> {
			App().Pages().getCaseDetailsPage().selectRequiredDocument();
		}).and("User change case status to Assigned for Resolution", () -> {
			App().Pages().getCaseDetailsPage().ChangeCaseStatus("Assigned For Resolution");
			util.waitFor(5);
		}).then("Verified Case Status", () -> {
			App().Pages().getCaseDetailsPage().verfifyCaseStatus("Assigned For Resolution");
			Reporter.logWithScreenShot("Case status is Assigned For Resolution");
		}).execute();
	}


	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "On the Case page clicking on Create Button", priority = 9, dependsOnMethods = {
			"UpdateCaseStatus" })
	public void CreateAction(Map<String, String> data) {
		scenario().given("User is on case page", () -> {
			util.waitForCasePage();
		}).when("User click on Modify link in Quote actions toolbar", () -> {
			util.clickOnActionToolBarButton("Quick Actions", "CREATE");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "CreatingEnterpriseQuote", priority = 10, dependsOnMethods = { "CreateAction" })
	public void createEnterpriseQuote(Map<String, String> data) {
		scenario().given("User is on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("User create the quote by filling quote form", () -> {
			App().Pages().getQuotepage().createEnterpriseQuoteEndtoEnd(data);
			util.waitForQuotePage();
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("User verify that Quote is created", () -> {
			util.waitFor(5);
			String title = getDriver().findElement(By.xpath("//div[text()='Quote']/following::span[1]")).getText();
			Validator.verifyThat("Quote is created", title,
					Matchers.equalTo(ConfigurationManager.getBundle().getPropertyValue("Quote_name")));
		}).execute();
	}
	
		
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Open Case page from Quote", priority = 11, dependsOnMethods = { "createEnterpriseQuote" })
	public void OpenCaseFromQuote(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User validate cart viewer", () -> {
			util.scrollIntoElement(By.xpath("//span[.='Cart Viewer']"));
			util.waitFor(5);
			Reporter.logWithScreenShot("CartViewer");
		}).and("User click on Case Number", () -> {
			util.clickUsingJs(By.xpath("//a[.='" + caseNo + "']"));
			util.waitForCasePage();
//		}).then("Verified Case status", () -> {
//			App().Pages().getCaseDetailsPage().verfifyCaseStatus("Closed");
//			Reporter.logWithScreenShot("Case status is close");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "credit check", priority = 12, dependsOnMethods = { "OpenCaseFromQuote" })
	public void creditCheck(Map<String, String> data) {
		scenario().given("User is on Quote Page", () -> {
		}).when("User update Credit Information by Credit Analyst", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			App().Pages().getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
					data.get("CreditApprovalCondition"), data.get("CreditRemark"));
			App().Pages().getLoginpage().logoutCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		}).then("User verified that Credit Information is Updated", () -> {
			Reporter.logWithScreenShot("Credit Information ", MessageTypes.Pass);
		}).execute();
		util.waitForQuotePage();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "SelectingServiceAddressInBulkSite", priority = 13, dependsOnMethods = { "creditCheck" })
	public void selectServiceAdd(Map<String, String> data) {
//		scenario().given("User is on Quote Page", () -> {
//		}).when("Selecting Service Address by clicking on Bulk site", () -> {
//			ConfigurationManager.getBundle().setProperty("testdata", data);
//			String path = System.getProperty("user.dir") + "\\resources\\testdata\\MultisiteServiceAdd5.csv";
//			App().Pages().getQuotepage().selectBulkSerivceAddressForMultisite(path);
//		}).then("User verify that service address is selected", () -> {
//			Reporter.logWithScreenShot("Service adress is selected", MessageTypes.Info);
//		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "PLDT_Cart", key = "${key.name}")
	@Test(description = "Configuring cart", priority = 14, dependsOnMethods = { "selectServiceAdd" }) //
	public void configureCart(Map<String, String> data) {
		scenario().given("User is on cart page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().ClickAddProducts();
		}).when("User add the plan "+ data.get("Plan")+"", () -> {
			App().Pages().getCartpage().ClickonPromotion(data.get("Plan"));
		}).when("User configure plans and do grouping and association of plan", () -> {
			App().Pages().getCartpage().ConfigurePromotionBeyondFiberDirectLine(data);
//			 Grouping and Association
		}).and("User do Grouping and Association", () -> {
			AppUtils.WorkingCart_grouping_Product_MultiSites("group5",data.get("ExchangeiD"));
			util.waitForCartPage();
			AppUtils.SaveWorkingCart();
			util.waitForQuotePage();
			AppUtils.WorkingCart_Association("Enterprise Broadband Beyond Fiber Offer");
			AppUtils.Association_Validation();
		}).then("User verify that plan configured, grouping and assocation done", () -> {
			Reporter.logWithScreenShot("Plans configured, grouping and assocation done", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "updating Ets Details", priority = 15, dependsOnMethods = { "configureCart" }) //
	public void updateETSDetails(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().TriggerSD();
		}).when("User logout as current user and login as ETS member", () -> {
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("ETS"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
		}).and("User perform serviceability check", () -> {
//			App().Pages().getQuotepage().ServiceabilityCheck();
		}).and("User update ETS details and perform site survey", () -> {
			App().Pages().getQuotepage().TriggerETS(data);
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().SwitchToUser(
					ConfigurationManager.getBundle().getPropertyValue("Site_Survey_User"), "SiteSurveyUser");
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitFor(5);
			util.waitForQuotePage();
			App().Pages().getQuotepage().SiteSurvey(data);
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("ETS"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			App().Pages().getQuotepage().updateEtsDetails(data.get("EtsStatus"), data.get("EtsRemarks"));
		}).and("User logout as current user and login as RM", () -> {
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).and("User verify that ETS completed", () -> {
			Reporter.logWithScreenShot("Updated ETS details", MessageTypes.Pass);
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "SiteBandZloc", priority = 16, dependsOnMethods = { "updateETSDetails" })
	public void SiteBandZloc(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User selecting siteB and Zloc", () -> {
			App().Pages().getQuotepage().siteBandzlocForMultisite(data);
		}).then("User Verify notify_toast is displayed", () -> {
			QAFExtendedWebElement notifytoastxpath = new QAFExtendedWebElement(
					"xpath=//div[@class='slds-notify slds-notify_toast slds-theme_info']");
			notifytoastxpath.verifyPresent(
					"You have not indicated any change in Billing Address. System would use below Address for creating Billing Accounts for all services added in this Quote.\r\n"
							+ "Philippines\r\n" + "\r\n"
							+ "Please go to Billing Management button if you want to create new billing accounts manually after clicking Cancel button");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Billing Management", priority = 17, dependsOnMethods = { "SiteBandZloc" })//
	public void selectBillingAddress(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User select billing address ", () -> {	
			ConfigurationManager.getBundle().setProperty("testdata", data);
			String path = System.getProperty("user.dir") + "\\resources\\testdata\\BillingAccount.csv";
			App().Pages().getQuotepage().manualBillingManagement(data,path,5);
		}).then("User verify billing address is selected and navigated to quote page", () -> {
			Reporter.logWithScreenShot("Billing address selected and navigated to quote page", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "updating Contact Details", priority = 18, dependsOnMethods = { "selectBillingAddress" })
	public void updateContactDetails(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User update contact details", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().updatePldtContactDetails(data);
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("User verify contact details are updated", () -> {
			Reporter.logWithScreenShot("Updated contact details", MessageTypes.Pass);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "PLDT_Cart", key = "${key.name}")
	@Test(description = "Change Quote Status and Quote Document Generation", priority = 19, dependsOnMethods = { "updateContactDetails" }) //
	public void changeQuoteStatus(Map<String, String> data) {
		scenario().given("User is on Quote page", () -> {
		}).when("User Change quote status to presented", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			util.ChangeStatus("Internal Approval");
			App().Pages().getQuotepage().ChangeStatusToPresented(data);
			util.waitFor(6);
			Reporter.logWithScreenShot("Quote Status Changed to Presented");
		}).and("User generate quote document", () -> {
			App().Pages().getQuotepage().QuoteGeneration("Pdf");
			AppUtils.pickLatestFileFromDownloads("Quote Document");
			Reporter.logWithScreenShot("Quote to PDF downloaded and status changed to presented");
		}).and("User change quote status to customer accepted", () -> {
			App().Pages().getQuotepage().changeQuoteStatustoCustomerAccepted();
			Validator.verifyThat("Verify Quote status changed to Accepted", AppUtils.getToastMessage(),
					Matchers.containsString("Status changed successfully"));
//		}).and("User synchronizing QLI Items", () -> {
//			App().Pages().getQuotepage().PLDT_SynchronizingAccount(data.get("Plan"), data.get("Relationship Manager"));
		}).then("User verified that Quote status changed", () -> {
			Reporter.logWithScreenShot("Quote status changed", MessageTypes.Pass);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Detail Design Required", priority = 20, dependsOnMethods = { "changeQuoteStatus" }) //
	public void DetailDesignRequired(Map<String, String> data) {
		scenario().given("User is on Quote page", () -> {
		}).when("User perform detail design required task", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getLoginpage().logoutCurrentUser();
			App().Pages().getHomepage().SwitchToUser(
					ConfigurationManager.getBundle().getPropertyValue("Site_Survey_User"), "SiteSurveyUser");
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			App().Pages().getQuotepage().DetailDesignReq(data);
		}).then("User verified that detail design required task completed", () -> {
			Reporter.logWithScreenShot("Detail design required task completed", MessageTypes.Pass);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Generate Contract", priority = 21, dependsOnMethods = { "DetailDesignRequired" })
	public void GenerateContract(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User click create contract button", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			App().Pages().getQuotepage().CreateContract();
		}).and("User click on generate Documents ", () -> {
			util.refreshPage();
			util.waitForContractPage();
			App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
			util.waitForContractPage();
			AppUtils.pickLatestFileFromDownloads("Contract Document");
		}).when("User change contract status to signed", () -> {
			App().Pages().getQuotepage().ChangeTheStatusToSigned();
		}).then("User verified that Contract got generated", () -> {
			Reporter.logWithScreenShot(" Contract generated ", MessageTypes.Pass);
			ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
			util.waitFor(3);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Verify Orders", priority = 22, dependsOnMethods = { "GenerateContract" })
	public void verifyOrders(Map<String, String> data) {
		scenario().given("User is on orders page", () -> {
		}).when("User verify orders", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList = App().Pages().getQuotepage().VerifyingOrders(50, 5);
			ProjectBeans.setOrderURL(getDriver().getCurrentUrl());
		}).then("User verified that Orders got generated", () -> {
			Reporter.logWithScreenShot(" Orders generated ", MessageTypes.Pass);
		}).execute();
	}

	@Test(priority = 23, dependsOnMethods = { "verifyOrders" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :" + ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :" + ProjectBeans.getContractURL(), MessageTypes.Info);
		Reporter.log("OrderPage URL :" + ProjectBeans.getOrderURL(), MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order _" + (i + 1) + " URL : " + orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
