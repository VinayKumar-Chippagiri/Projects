package com.pldt.tests.SMART.AfterSales.ConnectionDisconnection;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ExcelReader;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class PermanentDisconnection_Bulk extends BaseTest{
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String quoteURL = null;
	String orderURL = null;
	String caseID = null;
	ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "PermanentDisconnection",key="Permanent_Disconnection_Bulk_01")
	@Test(priority = 1)
	private void caseCreationTest(Map<String, String> data) {
		scenario().given("I'm on case search page", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).when("I fill case form details and submit", () -> {
			pages.getHomepage().switchToAnyAccount(data.get("accountName"), data.get("AccountNumber"));
			pages.getAccountDetailsPage().clickOnRelated("Assets");
			pages.getAssetsListPage().openAsset(data.get("assetName"),data.get("MINNumber"), true);
			pages.getAssetDetailsPage().getBillAccountNumber();
			pages.getAssetDetailsPage().clickOnRelated("Cases");
			pages.getCaseListPage().createNewCaseFromAsset(data);
			pages.getCaseListPage().selectCase(data.get("Subject"));
			caseURL= getDriver().getCurrentUrl();
		}).then("I verify that the case is created", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "PermanentDisconnection",key="Permanent_Disconnection_Bulk_01")
	@Test(priority = 2)
	private void changeCaseOwnerTest(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the change owner action", () -> {
			pages.getCaseDetailsPage().changeOwner(data.get("ownerName"));
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();
			caseID =util.getTextFromPage(By.xpath("//p[@title='Case Number']/following::lightning-formatted-text[1]"));
		}).then("I see the owner is changed", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "PermanentDisconnection",key="Permanent_Disconnection_Bulk_01")
	@Test(priority = 3)
	private void verifyTransactionDetails(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to case page and check transaction details section", () -> {
			pages.getCaseDetailsPage().verifyTransactionDetailsForConnectionScenarios(data.get("assetName"), data.get("transactionReasonOrRequest"), data.get("Transaction Type"),data.get("Case Origin"));
		}).then("I verify transaction details section", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "PermanentDisconnection",key="Permanent_Disconnection_Bulk_01")
	@Test(priority = 4)
	private void markCaseStatusToResolutionInProgress(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {
			pages.getCaseDetailsPage().markCaseStatusToResolutionInprogress();
			if(data.get("Case Origin").equalsIgnoreCase("Bulk"))
			{
				try {
					ExcelReader.updateCSV(data, caseID);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(!pages.getCaseDetailsPage().bulkUpload(data)) {
					Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
				}

				getDriver().get(caseURL);
			}

		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "PermanentDisconnection",key="Permanent_Disconnection_Bulk_01")
	@Test(priority = 5,enabled=false)
	private void verifyTransactionAsset(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I scroll to transaction asset section", () -> {
			util.waitForCasePage();
			pages.getCaseDetailsPage().verifyTransactionAsset();
		}).then("I see transaction asset is generated", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx",sheetName = "PermanentDisconnection",key="Permanent_Disconnection_Bulk_01")
	@Test(priority = 6)
	private void performTransactionAction(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform " + data.get("Transaction Type"), () -> {
			pages.getCaseDetailsPage().transactionActionForConnectionScenarios(data.get("Transaction Type"));
		}).then("I verify the " + data.get("Transaction Type"), () -> {
			Reporter.logWithScreenShot("Performed Transaction Action", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx",sheetName = "PermanentDisconnection",key="Permanent_Disconnection_Bulk_01")
	@Test(priority = 7)
	private void verifyOrderDetails(Map<String ,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to order search page", () -> {
			orderList=pages.getOrdersPage().verifyOrdersFromCasePage(caseURL,data.get("Transaction Type"));
		}).then("I verify the order generation", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@Test(priority = 8)
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
		if(orderList.size()>0)
		{
			for(int i=0;i<orderList.size();i++)
			{
				Reporter.log("Order _"+(i+1)+" URL : "+orderList.get(i), MessageTypes.Info);

			}
		}


	}
}
