package com.pldt.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.qmetry.qaf.automation.ui.WebDriverTestCase;

public class NewTest extends WebDriverTestCase{
	@Test()
	  public void method1() throws InterruptedException {
	      getDriver().get("https://test.salesforce.com/");
	      getDriver().findElement(By.xpath("//input[@id='username']")).sendKeys("parallel");
	      getDriver().findElement(By.xpath("//input[@id='password']")).sendKeys("parallel");
	      Thread.sleep(15000);
	      getDriver().findElement(By.xpath("//input[@id='Login']")).click();
	  }

	  @Test()
	  public void method2() throws InterruptedException {
	      getDriver().get("https://test.salesforce.com/");
	      //another improved way
	      getDriver().findElement(By.xpath("//input[@id='username']")).sendKeys("methods");
	      getDriver().findElement(By.xpath("//input[@id='password']")).sendKeys("parallel");
	      Thread.sleep(15000);
	      getDriver().findElement(By.xpath("//input[@id='Login']")).click();

	  }
}
