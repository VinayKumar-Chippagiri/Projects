package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.Map;

import org.testng.annotations.Test;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;

public class PaymentHistoryInquiry extends CaseManage {

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login as Admin into Salesforce application and Switched to CRA", priority = 1)
	@Override
	public void LoginAsAdmin(Map<String, String> data) {
		super.LoginAsAdmin(data);
		super.SwitchToOtherUser(data.get("CRA_User"));
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Open Business Account", priority = 2, dependsOnMethods = { "LoginAsAdmin" })
	@Override
	public void OpenExistingAccount(Map<String, String> data) {
		super.OpenExistingAccount(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "payment History Inquiry", priority = 3, dependsOnMethods = { "OpenExistingAccount" })
	public void paymentHistoryInquiry(Map<String, String> data) {
		super.ClickOnKenanInquiry();
		super.ClickOnPaymentInquiry();
		super.enterKenanStartEnd(data.get("Start_date"), data.get("End_date"));
	}

}
