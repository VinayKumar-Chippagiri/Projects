package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.pages.CasePage;
import com.pldt.pages.HomePage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;


public class Change_Assignee_Bulk extends CaseManage {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL=null;
	String BulkSRURL = null;
	CasePage casepage =new CasePage();
	private static int Qty ;
      int j = 1 ;
       int i =0 ;
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to Credit Analyst", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoCreditAnalyst(Map <String,String> data) {
		scenario().given("user Switch to Credit Analyst", () -> {
		}).when("User Login As Credit Analyst", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			Reporter.log("Switched to Credit Analyst:" + data.get("Credit Analyst"));
		}).then("verify Admin successfully switched to Credit Analyst", () -> {
			Reporter.logWithScreenShot("Successfully switched to Credit Analyst");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Bulk Service Request", priority = 3, dependsOnMethods = { "SwitchingtoCreditAnalyst" })
	public void BulkServiceRequest(Map<String, String> data) {
		String path;
		path = System.getProperty("user.dir") + ".\\resources\\testdata\\Bulk_Change Assignee -1.csv";
		super.getDefaultWindow();
		super.ClickBulkServiceRequest();
		super.ImportBulkFile(data.get("lookupfield"),path);
		super.SwitchToDefaultWindow();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Filter Bulk Service Request", priority = 3, dependsOnMethods = { "BulkServiceRequest" })
	public void FilterBSR(Map<String, String> data) {
		scenario().given("Going in BSR", () -> {
		}).when("User open Bulk Service Request after filer", () -> {	
		util.refreshPage();
		util.waitFor(10);
		BulkSRURL =getDriver().getCurrentUrl();
		App().Pages().getCasepage().SelectBSRGroup("All");
		Qty =App().Pages().getCasepage().clickOnBSRBySubject(data.get("Subject"),data);	
		}).then("User verify the Bulk Service Request is Displayed ", () -> {
			Reporter.logWithScreenShot("Navigated to BSR page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Open Import Case", priority = 3, dependsOnMethods = { "FilterBSR" })
	public void OpenImportCase(Map<String, String> data) {
		scenario().given("Going in Case", () -> {
		}).when("User open BSR And navigate to case", () -> {	
			App().Pages().getCasepage().OpenImportCase(data,j);
			caseURL= getDriver().getCurrentUrl();			
	    }).then("User verify the case got Created and case page is opened ", () -> {
		   Reporter.logWithScreenShot("Navigated to case page");
	    }).execute();	
		}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Change Status to Resolution In Progress", priority = 4, dependsOnMethods = { "OpenImportCase" })
	public void ChangeStatustoResolutionInProgress(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
			}).when("user Change status to Resolution in Progress", () -> {	
				util.clickUsingJs(By
						.xpath("(//a[@data-tab-name='Assigned For Resolution'])[last()]"));
				util.waitFor(3);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
			}).then("User Verify Status Got Changes", () -> {
			Reporter.logWithScreenShot("Changed status to Resolution In Progress", MessageTypes.Info);
		}).execute();
	}	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Checking Transcation Id", priority = 5, dependsOnMethods = { "ChangeStatustoResolutionInProgress" })
	public void CheckingTransctionId(Map<String, String> data) {
		scenario().given("Checking Transaction ID creation and status", () -> {
		}).when("User check TransactionID got Created", () -> {
			App().Pages().getCasepage().CheckingTransactionID(caseURL,data,data.get("Credit Analyst"));	
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).then("User verify TransactionID status is successful ", () -> {
			Reporter.logWithScreenShot("TransactionID status is successful", MessageTypes.Info);
			}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 6, dependsOnMethods = { "CheckingTransctionId" })
	public void CloseTheCase(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
		}).when("user Check status Changed to Closed", () -> {	
			QAFWebElement Status = new QAFExtendedWebElement(
					"xpath=//p/span[contains(.,'Closed')]");
			Validator.verifyTrue(Status.isPresent(), "Status not Changed to Closed",
					"Status Changed to Closed");				
			util.refreshPage();
			}).then("User Verify Status Got Changed", () -> {
			Reporter.logWithScreenShot("Status Got Changed to Closed: " + caseURL, MessageTypes.Info);
		}).execute();
	}
	
	
	@Test(priority = 7, dependsOnMethods = { "CloseTheCase" })
	public void getReferenceData() {
		if(Qty>0)
		{
			for(int i=0;i<Qty;i++)
			{
				Reporter.log("Case _"+(j)+" URL : "+caseURL, MessageTypes.Info);

			}
		}
        i = Qty - j;
        j++ ;
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Open Next Case", priority = 8, dependsOnMethods = { "getReferenceData" })
	public void OpenNextCase(Map<String, String> data) {
		if(i!=0) {
			scenario().given("User Open "+i+" case", () -> {
			}).when("user Go to Bulk Service Request Page For Next Case", () -> {
			util.goToURL(BulkSRURL);
			this.FilterBSR(data);
			this.OpenImportCase(data);
			this.ChangeStatustoResolutionInProgress(data);
			this.CheckingTransctionId(data);
			this.CloseTheCase(data);
			this.getReferenceData();
			this.OpenNextCase(data);
			}).then("user verify Case is closed", () -> {
				Reporter.logWithScreenShot("Status Got Changed to Closed", MessageTypes.Info);
			}).execute();
		}
	}
}