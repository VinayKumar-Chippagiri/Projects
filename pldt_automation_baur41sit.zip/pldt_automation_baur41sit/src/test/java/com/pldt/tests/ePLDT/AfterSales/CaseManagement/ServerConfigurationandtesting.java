package com.pldt.tests.ePLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class ServerConfigurationandtesting extends BaseTest{
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String caseURL2 = null;
	String quoteURL = null;
	String orderURL = null;
	String caseID = null;
	 String BillingAccountUrL = null;
	ArrayList<String> orderList = null;
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to RelationshipManager", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRelationShipManager(Map <String,String> data) {
		scenario().given("user logged in as Asmin", () -> {
		}).when("User Login As Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to RelationShipManager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Successfully switched to Relationship Manager");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRelationShipManager" })
	public void CreateNewCase(Map<String, String> data)  {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {	
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("recordtype"));
			App().Pages().getNewCaseModal().createNewCaseForICT(data);
			App().Pages().getCasepage().getCaseNumberFromToastMessage();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			util.waitFor(8);
			caseID = getDriver().findElement(By.xpath(
					"(//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text)[1]"))
					.getText();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());// set case url in ProjectBeans
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Accepting the case", priority = 4, dependsOnMethods = {"CreateNewCase" })
	public void Acceptcase(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I accept the case", () -> {
			pages.getLoginpage().logoutCurrentUser(); 
			pages.getHomepage().switchToAnyUser(data.get("Level-1User"));
			App().Pages().getHomepage().goToAPP("Cases");
			App().Pages().getCaseListPage().acceptCase("Level 1 - Support Queue",caseID);
			util.waitForCasePage();
			Reporter.logWithScreenShot("Case is Accepted", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Verifying the Case Owner", priority = 5, dependsOnMethods = {"Acceptcase" })
	public void VerifyCaseOwner(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).given("Case is Accepted", () -> {
			pages.getCaseDetailsPage().verfifyCaseOwner(data.get("Level-1User"));
			Reporter.logWithScreenShot("Case Owner is Verified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Verifying the Case Owner", priority = 6, dependsOnMethods = {"VerifyCaseOwner" })
	public void UpdateSMAX(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).given("Case is Accepted", () -> {
			pages.getCaseDetailsPage().updateSupportGroupTier2inSMAXInformation();
			Reporter.logWithScreenShot("Case Owner is Verified", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 7,dependsOnMethods = {"UpdateSMAX"})
	public void markCaseStatusToResolutionInprogress(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {	
			util.ChangeStatusSMAX("Resolution In Progress");
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolution in Progress", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 8,dependsOnMethods = {"markCaseStatusToResolutionInprogress"})
	public void CaseCancellationReason(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("Case status Changed to Resolution in progress", () -> {	
			pages.getCaseDetailsPage().casecancellationreason();
		}).then("I provided the Comments in Case Cancellation Reason", () -> {
			Reporter.logWithScreenShot("Case Cancellation Reason is Provided", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 9,dependsOnMethods = {"CaseCancellationReason"})
	public void markCaseStatusToCancelled(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I provided the Comments in Case Cancellation Reason", () -> {	
			util.ChangeStatusSMAX("Cancelled","Cancelled");
		}).then("I see case status got changed to Cancelled ", () -> {
			Reporter.logWithScreenShot("Case status changed to Cancelled", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 10,dependsOnMethods = {"markCaseStatusToCancelled"})
	public void markCaseStatusToResolved(Map <String,String> data) {
		scenario().given("Case status changed to Cancelled", () -> {
		}).given("Case status changing to Resolved", () -> {	
			util.ChangeStatusSMAX("Resolved","For Client Confirmation");
			util.waitFor(5);
			Reporter.logWithScreenShot("Error message is displayed", MessageTypes.Info);
		}).then("I see the Error message is displayed ", () -> {
		}).execute();
	}

	@Test(priority = 11,dependsOnMethods = {"markCaseStatusToResolved"})
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
	}

}
