package com.pldt.tests.PLDT.AfterSales.Modify;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
/*Prerequisites to execute this scenario  
 * Asset should be active.
 * Parent Account and Billing Account should be active.
 * ServiceID, contract term, pricing information, Asset dates must be populated.
 * 

*/
public class Contract_Renewal_OR_Retention extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	ArrayList<String> orderList = null;



	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void Login_as_Admin_into_SalesForce_Application(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			String title = getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).then("verify that User is Switched to RelationShip Manager", () -> {
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			props.setProperty("RelationShip_Manager", data.get("Relationship Manager"));
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[1]")).getText();
			Validator.verifyThat("", heading,
					Matchers.containsString("Logged in as " + data.get("Relationship Manager")));
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Account", priority = 2, dependsOnMethods = { "Login_as_Admin_into_SalesForce_Application" })
	public void Open_Existing_Account(Map<String, String> data) {
	scenario().given("I am in home page", () -> {
	util.refreshPage();
	util.waitFor(5);
	}).when("I open " + data.get("Account_Name") + " account", () -> {
		App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
	props.setProperty("Account", data.get("Account_Name"));
	util.waitFor(10);
	}).then("I verify that account details page of " + data.get("Account_Name") +" is displayed", () -> {
	String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
	.getText();
	Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
	}).when("I click on contacts", () -> {
	getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
	util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
	}).and("I captured the contact name", () -> {
	String TechnicalContact = getDriver().findElement(By.xpath("//span[.='Technical']/ancestor::tr//th//a"))
	.getText();
	props.setProperty("contact.Technical", TechnicalContact);
	Reporter.log("Technical Contact: " + TechnicalContact);
	String Authorized_Signatory = getDriver()
	.findElement(By.xpath("//span[.='Authorized Signatory']/ancestor::tr//th//a")).getText();
	props.setProperty("Lead.fullName", Authorized_Signatory);
	Reporter.log("Authorized Signatory: " + Authorized_Signatory);
	Reporter.logWithScreenShot("Account Contact Details");
	}).and("I clicked on account and navigate back to account details page", () -> {
	QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
	AccountName.click();
	}).then("then i verified that account details page is dispayed", () -> {
	util.waitForAccountPage();
	Reporter.logWithScreenShot("Account Details Page");
	}).execute();
	}



	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Creating Case", priority = 3, dependsOnMethods = {
			"Open_Existing_Account" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getAccountDetailsPage().clickOnRelated("Cases");
		}).when("Creating case for Contract Renewal", () -> {
			pages.getCaseListPage().clickNewCaseButton();
			pages.getNewCaseModal().SelectRecordType(data.get("Record Type"));
			pages.getCasepage().createAfterSalesNewCase();
		}).then("Selecting The Case Created", () -> {
			pages.getCaseListPage().selectCase(data.get("Subject"));		
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());     //set Case URL
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Creating Case", priority = 4, dependsOnMethods = {
			"CreatingNewCase" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("Going in case and adding billing account", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("Checking Negative Scenarios And Add Billing Account", () -> {
			pages.getCasepage().CheckNegativeScenarios();
			pages.getCaseDetailsPage().AddBillingAccountforModify(data);
		}).and("Add Required Documents", () -> {
			pages.getCaseDetailsPage().VerifyBulkServiceRequestFromRelated(ProjectBeans.getCaseURL());
			getDriver().get(ProjectBeans.getCaseURL());               //get case URL
			pages.getCaseDetailsPage().AddDocumentsRequired();
		}).then("Change Status to Assigned For Resolution and Clicking on MODIFY And Add Primary Service ", () -> {
			util.ChangeStatus("Assigned For Resolution");
			pages.getCaseDetailsPage().RequestModify(data,"MODIFY");
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Creating Case", priority = 5, dependsOnMethods = {
			"AddBillingAccount" })
	public void ConfigureProduct(Map<String, String> data) {
		scenario().given("Updating Contract Term In Cart Page", () -> {
			props.setProperty("testdata", data);
			pages.getCartpage().ModifyContractTerm(data,data.get("Contract Term"));			
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "updating Ets Details", priority = 6, dependsOnMethods = { "ConfigureProduct" })
	public void updateETSDetails(Map<String, String> data) {
		scenario().given(" Update ETS Details ", () -> {
		props.setProperty("testdata", data);
		}).when("I click on TriggerSD And Logout As Current User", () -> {
		pages.getQuotepage().TriggerSD();
		pages.getLoginpage().logoutAsCurrentUser();
		}).and("Login As ETS Member", () -> {	
		pages.getHomepage().switchToAnyUser(data.get("ETS"));
		getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		}).then("I update ETS Details In quote Page ", () -> {
		util.waitForQuotePage();	
		pages.getQuotepage().updateEtsDetails(data.get("EtsStatus"), data.get("EtsRemarks"));
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "updating Contact Details", priority = 7, dependsOnMethods = { "updateETSDetails" })
	public void updateContactDetails(Map<String, String> data) {
		scenario().given(" Update Contact Details ", () -> {
		props.setProperty("testdata", data);
		pages.getQuotepage().updatePldtContactDetails(data);
		ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "credit check", priority = 8, dependsOnMethods = { "updateContactDetails" })
	public void creditCheck(Map<String, String> data) {
		scenario().given(" Perform Credit Check ", () -> {
			props.setProperty("testdata", data);
		}).when("I Perform Credit Check", () -> {
			pages.getQuotepage().CreditCheck();
			}).and("Logout As Current User And Login As Credit Analyst", () -> {
			pages.getLoginpage().logoutAsCurrentUser();
			}).and("Update Credit Information In Quote Page", () -> {	
			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			pages.getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
					data.get("CreditApprovalCondition"), data.get("CreditRemark"));
			}).then("Logout As Current User And Login As Relationship Manager ", () -> {
			pages.getLoginpage().logoutCurrentUser(); 		
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "create Contract", priority = 9, dependsOnMethods = { "creditCheck" })
	public void createContract(Map<String, String> data) {
		props.setProperty("testdata", data);
		util.ChangeStatus("Internal Approval");
		util.ChangeStatus("Presented");
		pages.getQuotepage().changeQuoteStatustoCustomerAccepted();
		pages.getQuoteDetailsPage().CreateContractinAfterSales(data);
		pages.getQuotepage().ChangeTheStatusToSigned();
		ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Upload file", priority = 10, dependsOnMethods = { "createContract" })
	public void generateDocuments(Map<String, String> data) {
	props.setProperty("testdata", data);
	scenario().given("I am on Contract Page", () -> {
	}).when("I click on generate Documents ", () -> {
	util.refreshPage();
	util.waitForContractPage();
	App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
	util.waitForContractPage();
	}).then("i verified that File is Uploaded", () -> {
	Reporter.logWithScreenShot(" Generate Documents ", MessageTypes.Info);
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify",key = "${key.name}")
	@Test(description = "Verify Orders", priority = 11, dependsOnMethods = { "generateDocuments" })
	public void verifyOrders(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Contract Page", () -> {
		}).when("I move to orders page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList=pages.getQuotepage().VerifyOrders();
		}).then("I verified the status of Orders", () -> {
			Reporter.logWithScreenShot(" Orders", MessageTypes.Info);
		}).execute();
	}
	
	@Test( priority = 12,dependsOnMethods = { "verifyOrders" })
	public void getReferenceData()
	{
		Reporter.log("Quote URL :"+ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :"+ProjectBeans.getContractURL(), MessageTypes.Info);
		

		if(orderList.size()>0)
		{
			for(int i=0;i<orderList.size();i++)
			{
				Reporter.log("Order _"+(i+1)+" URL : "+orderList.get(i), MessageTypes.Info);
			}
		}
	}
}


