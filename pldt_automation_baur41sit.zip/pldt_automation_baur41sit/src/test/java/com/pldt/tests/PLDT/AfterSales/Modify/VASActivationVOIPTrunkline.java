package com.pldt.tests.PLDT.AfterSales.Modify;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;
import java.util.Map;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.common.utilities.ProjectBeans;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class VASActivationVOIPTrunkline extends VASActivationIgatePreNLA {
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		super.LoginasAdmin(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Switch to Relationship Manager", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void SwitchingtoRelationshipManager(Map<String, String> data) {
		super.SwitchingtoRelationshipManager(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Account", priority = 3, dependsOnMethods = { "SwitchingtoRelationshipManager" })
	public void OpenExistingAccount(Map<String, String> data) {
		super.OpenExistingAccount(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Creating new case ", priority = 4, dependsOnMethods = { "OpenExistingAccount" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		super.CreateNewCase(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Validate Case Owner and Case Status", priority = 5, dependsOnMethods = { "CreateNewCase" })
	public void ValidateCaseOwnerAndStatus(Map<String, String> data) {
		super.ValidateCaseOwnerAndStatus(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Add Billing Account and Verify Bulk Service Request", priority = 6, dependsOnMethods = {
			"ValidateCaseOwnerAndStatus" })
	public void AddBillingAccount(Map<String, String> data) {
		super.AddBillingAccount(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Update case status and Select required document", priority = 7, dependsOnMethods = {
			"AddBillingAccount" })
	public void UpdateCaseStatus(Map<String, String> data) {
		super.UpdateCaseStatus(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "On the Case page clicking on Modify link", priority = 8, dependsOnMethods = {
			"UpdateCaseStatus" })
	public void ModifyAction(Map<String, String> data) {
		super.ModifyAction(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "PLDT_Cart", key = "${key.name}")
	@Test(description = "Configuring cart", priority = 9, dependsOnMethods = { "ModifyAction" }) //
	public void configureCart(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("User click on configure button", () -> {
			util.clickOnActionToolBarButton("QuoteActionToolbar", "Configure");		
			util.waitForCartPage();
		}).and("User configure plans", () -> {
			App().Pages().getCartpage().addPlanToCart(data.get("Plan"));
			AppUtils.Configure_Parent_Product("Call Forwarding");
			AppUtils.select_Config_Parameter("Call Forwarding");
			AppUtils.cartPageSaveButton();
			AppUtils.Configure_Parent_Product("Speed Calling");
			AppUtils.select_Config_Parameter("Speed Calling Variant");
			AppUtils.cartPageSaveButton();
		}).and("User Click View Record", () -> {
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.waitFor(5);
			util.clickUsingJs(By.xpath("//button[@title='View Record']"));
			util.waitForQuotePage();
		}).then("User verify that cart configuration done", () -> {
			Reporter.logWithScreenShot("cart configuration done", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "updating Contact Details", priority = 10, dependsOnMethods = { "configureCart" })
	public void updateContactDetails(Map<String, String> data) {
		super.updateContactDetails(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "credit check", priority = 11, dependsOnMethods = { "updateContactDetails" })
	public void creditCheck(Map<String, String> data) {
		super.creditCheck(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "PLDT_Cart", key = "${key.name}")
	@Test(description = "Change Quote Status and Quote Document Generation", priority = 12, dependsOnMethods = { "creditCheck" }) //
	public void changeQuoteStatus(Map<String, String> data) {
		super.changeQuoteStatus(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Generate Contract", priority = 13, dependsOnMethods = { "changeQuoteStatus" })
	public void GenerateContract(Map<String, String> data) {
		super.GenerateContract(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Verify Orders", priority = 14, dependsOnMethods = { "GenerateContract" })
	public void verifyOrders(Map<String, String> data) {
		super.verifyOrders(data);
	}

	@Test(priority = 15, dependsOnMethods = { "verifyOrders" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :" + ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :" + ProjectBeans.getContractURL(), MessageTypes.Info);
		Reporter.log("OrderPage URL :" + ProjectBeans.getOrderURL(), MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order _" + (i + 1) + " URL : " + orderList.get(i), MessageTypes.Info);
			}
		}
	}

}
