package com.pldt.tests.PLDT.NewConnect;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.Map;

import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class BeyondFiberPromotion_OmniRio extends EnterpriseBeyondFiberPromotion {
	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Lead", key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		super.LoginasAdmin(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Account", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void OpenExistingAccount(Map<String, String> data) {
		super.OpenExistingAccount(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "CreatingEnterpriseQuote", priority = 3, dependsOnMethods = { "OpenExistingAccount" })
	public void createEnterpriseQuote(Map<String, String> data) {
		super.createEnterpriseQuote(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "credit check", priority = 4, dependsOnMethods = { "createEnterpriseQuote" })
	public void creditCheck(Map<String, String> data) {
		super.creditCheck(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "SelectingServiceAddressInBulkSite", priority = 5, dependsOnMethods = { "creditCheck" })
	public void selectServiceAdd(Map<String, String> data) {
		super.selectServiceAdd(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "PLDT_Cart", key = "${key.name}")
	@Test(description = "Configuring cart", priority = 6, dependsOnMethods = { "selectServiceAdd" }) //
	public void configureCart(Map<String, String> data) {
		scenario().given("User is on cart page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().ClickAddProducts();
		}).when("User add the 1st plan "+ data.get("Plan")+"", () -> {
			App().Pages().getCartpage().ClickonPromotion(data.get("Plan"));
		}).and("User configure plans and do grouping and association of plan", () -> {
			App().Pages().getCartpage().ConfigurePromotionBeyondFiberDirectLine(data);
		}).and("User add the 2nd plan "+ data.get("Plan2")+"", () -> {
			App().Pages().getCartpage().addPlanToCart(data.get("Plan2"));
//			 Grouping and Association
		}).and("User do Grouping and Association", () -> {
			AppUtils.WorkingCart_grouping_Product_MultiSites(null,data.get("ExchangeiD"));
			util.waitForCartPage();
			AppUtils.SaveWorkingCart();
			util.waitForQuotePage();
			AppUtils.WorkingCart_Association("Enterprise Broadband Beyond Fiber Offer");
			AppUtils.Association_Validation();
		}).then("User verify that plan configured, grouping and assocation done", () -> {
			Reporter.logWithScreenShot("Plans configured, grouping and assocation done", MessageTypes.Info);
		}).execute();
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "updating Ets Details", priority = 7, dependsOnMethods = { "configureCart" }) //
	public void updateETSDetails(Map<String, String> data) {
		super.updateETSDetails(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "SiteBandZloc", priority = 8, dependsOnMethods = { "updateETSDetails" })
	public void SiteBandZloc(Map<String, String> data) {
		super.SiteBandZloc(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Billing Management", priority = 9, dependsOnMethods = { "SiteBandZloc" })
	public void selectBillingAddress(Map<String, String> data) {
		super.selectBillingAddress(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "updating Contact Details", priority = 10, dependsOnMethods = { "selectBillingAddress" })
	public void updateContactDetails(Map<String, String> data) {
		super.updateContactDetails(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "PLDT_Cart", key = "${key.name}")
	@Test(description = "syncronize QLI Items", priority = 11, dependsOnMethods = { "updateContactDetails" }) //
	public void syncronizeQLIItems(Map<String, String> data) {
		super.syncronizeQLIItems(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Detail Design Required", priority = 12, dependsOnMethods = { "syncronizeQLIItems" }) //
	public void DetailDesignRequired(Map<String, String> data) {
		super.DetailDesignRequired(data);
	}

	@Override
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Generate Contract", priority = 13, dependsOnMethods = { "DetailDesignRequired" })
	public void GenerateContract(Map<String, String> data) {
		super.GenerateContract(data);
	}

	@Override
	@Test(priority = 14, dependsOnMethods = { "GenerateContract" })
	public void getReferenceData() {
		Reporter.log("Lead URL :" + ProjectBeans.getLeadURL(), MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :" + ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :" + ProjectBeans.getContractURL(), MessageTypes.Info);
	}


}
