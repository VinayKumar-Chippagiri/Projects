package com.pldt.tests.PLDT.AfterSales.Modify;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.Map;
import org.testng.annotations.Test;
import com.common.utilities.ProjectBeans;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class VASDeactivationCloudlineConnectVPN extends VASDeactivationIgatePreNLA {
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		super.LoginasAdmin(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Switch to Relationship Manager", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void SwitchingtoRelationshipManager(Map<String, String> data) {
		super.SwitchingtoRelationshipManager(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Account", priority = 3, dependsOnMethods = { "SwitchingtoRelationshipManager" })
	public void OpenExistingAccount(Map<String, String> data) {
		super.OpenExistingAccount(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Creating new case ", priority = 4, dependsOnMethods = { "OpenExistingAccount" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		super.CreateNewCase(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Validate Case Owner and Case Status", priority = 5, dependsOnMethods = { "CreateNewCase" })
	public void ValidateCaseOwnerAndStatus(Map<String, String> data) {
		super.ValidateCaseOwnerAndStatus(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Assign Case to PLDT Support Team", priority = 6, dependsOnMethods = {
			"ValidateCaseOwnerAndStatus" })
	public void AssignCasetoPLDTSupport(Map<String, String> data) {
		super.AssignCasetoPLDTSupport(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Add Billing Account and Verify Bulk Service Request", priority = 7, dependsOnMethods = {
			"AssignCasetoPLDTSupport" })
	public void AddBillingAccount(Map<String, String> data) {
		super.AddBillingAccount(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Update case status and Select required document", priority = 8, dependsOnMethods = {
			"AddBillingAccount" })
	public void UpdateCaseStatus(Map<String, String> data) {
		super.UpdateCaseStatus(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "On the Case page clicking on Modify link", priority = 9, dependsOnMethods = {
			"UpdateCaseStatus" })
	public void ModifyAction(Map<String, String> data) {
		scenario().given("User navigate to case page", () -> {
			util.waitForCasePage();
		}).when("User click on Modify and select product from primary service list", () -> {
			App().Pages().getCaseDetailsPage().RequestModifyMultiplecheck(data, "MODIFY");
		}).then("Verified modify action done", () -> {
			Reporter.logWithScreenShot("Modify Action Done");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Verify Orders", priority = 10, dependsOnMethods = { "ModifyAction" })
	public void verifyOrders(Map<String, String> data) {
		super.verifyOrders(data);
	}

	@Test(priority = 11, dependsOnMethods = { "verifyOrders" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("OrderPage URL :" + ProjectBeans.getOrderURL(), MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order _" + (i + 1) + " URL : " + orderList.get(i), MessageTypes.Info);
			}
		}
	}

}
