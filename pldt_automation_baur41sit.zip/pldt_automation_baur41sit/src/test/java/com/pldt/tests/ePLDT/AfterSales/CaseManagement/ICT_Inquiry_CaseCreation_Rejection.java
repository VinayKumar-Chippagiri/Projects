package com.pldt.tests.ePLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class ICT_Inquiry_CaseCreation_Rejection extends BaseTest{
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String caseURL2 = null;
	String quoteURL = null;
	String orderURL = null;
	String caseID = null;
	 String BillingAccountUrL = null;
	ArrayList<String> orderList = null;
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Accepting the case", priority = 2, dependsOnMethods = {"Login" })
	public void Acceptcase(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I accept the case", () -> {
//			App().Pages().getLoginpage().logoutCurrentUser(); 
			App().Pages().getHomepage().switchToAnyUser(data.get("Level-1User"));
			App().Pages().getHomepage().goToAPP("Cases");
			App().Pages().getCaseListPage().acceptCase("Level 1 - Support Queue",caseID);
			util.waitForCasePage();
			Reporter.logWithScreenShot("Case is Accepted", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Verifying the Case Owner", priority = 5, dependsOnMethods = {"Acceptcase" })
	public void VerifyCaseOwner(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).given("Case is Accepted", () -> {
			App().Pages().getCaseDetailsPage().verfifyCaseOwner(data.get("Level-1User"));
			Reporter.logWithScreenShot("Case Owner is Verified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Verifying the Case Owner", priority = 6, dependsOnMethods = {"VerifyCaseOwner" })
	public void UpdateSMAX(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).given("Case is Accepted", () -> {
			App().Pages().getCaseDetailsPage().updateSupportGroupTier2inSMAXInformation();
			Reporter.logWithScreenShot("Case Owner is Verified", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 7,dependsOnMethods = {"UpdateSMAX"})
	public void markCaseStatusToResolutionInprogress(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {	
			util.ChangeStatusSMAX("Resolution In Progress");
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolution in Progress", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(description = "Case Creation", priority = 8,dependsOnMethods = {"markCaseStatusToResolutionInprogress"})
	public void ModifyFCRDetails(Map <String,String> data) {		
		scenario().given("Modifying the Transaction Details", () -> {	
			App().Pages().getCaseDetailsPage().modifyFCRDetails(data);
		}).then("I verify that the case is created", () -> {
			Reporter.logWithScreenShot("FCR Details are Modified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(description = "Case Creation", priority = 9,dependsOnMethods = {"ModifyFCRDetails"})
	public void changeCurrentAssignment(Map <String,String> data) {		
		scenario().given("Modified the Transaction Details", () -> {	
			App().Pages().getCaseDetailsPage().changeCurrentAssignment(data);
		}).then("I verify that the case is created", () -> {
			Reporter.logWithScreenShot("FCR Details are Modified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(description = "CaseCancellationReason",priority = 8,dependsOnMethods = {"markCaseStatusToResolutionInprogress"})
	public void CaseCancellationReason(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("Case status Changed to Resolution in progress", () -> {	
			App().Pages().getCaseDetailsPage().casecancellationreason();
		}).then("I provided the Comments in Case Cancellation Reason", () -> {
			Reporter.logWithScreenShot("Case Cancellation Reason is Provided", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 9,dependsOnMethods = {"CaseCancellationReason"})
	public void markCaseStatusToCancelled(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I provided the Comments in Case Cancellation Reason", () -> {	
			util.ChangeStatusSMAX("Cancelled","Cancelled");
		}).then("I see case status got changed to Cancelled ", () -> {
			Reporter.logWithScreenShot("Case status changed to Cancelled", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 10,dependsOnMethods = {"markCaseStatusToCancelled"})
	public void markCaseStatusToResolved(Map <String,String> data) {
		scenario().given("Case status changed to Cancelled", () -> {
		}).given("Case status changing to Resolved", () -> {	
			util.ChangeStatusSMAX("Resolved","For Client Confirmation");
			util.waitFor(5);
			Reporter.logWithScreenShot("Error message is displayed", MessageTypes.Info);
		}).then("I see the Error message is displayed ", () -> {
		}).execute();
	}

	@Test(priority = 11,dependsOnMethods = {"markCaseStatusToResolved"})
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
	}

}
