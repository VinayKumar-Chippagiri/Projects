package com.pldt.tests.SMART.AfterSales.ChangeMIN;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.testng.annotations.Test;

import com.common.utilities.MyScreenRecorder;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class ChangeMINTest extends BaseTest {
	WebUtilities util = new WebUtilities();
	PageLib pages = new PageLib();
	String caseURL=null;
	String quoteURL=null;
	String orderURL=null;
	ArrayList<String> orderList =null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void Login_as_Admin(Map <String,String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			MyScreenRecorder.startRecording("CHANGE MIN");
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
		}).then("I verify User is Logged in as Admin", () -> {
			Reporter.logWithScreenShot("User is Logged in as Admin", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(description = "Switch to RelationShip Manager", priority = 2,dependsOnMethods = { "Login_as_Admin" })
	public void Switching_to_RelationShipManager(Map <String,String> data) {
		scenario().then("I Switch to RelationShip Manager", () -> {
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).then("I verify that User is Switched to Relation Ship Manager", () -> {
				Reporter.logWithScreenShot("User is Switched to RelationShip Manager", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(description = "Selecting Account", priority = 3,dependsOnMethods = {"Switching_to_RelationShipManager"})
	public void Selecting_Account(Map <String,String> data) {
		scenario().and("Selecting Account", () -> {
			util.waitFor(5);
			pages.getHomepage().switchToAnyAccount(data.get("accountName"), "Account");
			App().Pages().getAccountDetailsPage().getAccountRecordType();
		}).then("I verify that Account is Selected", () -> {
			Reporter.logWithScreenShot("Account is Selected", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(description = "Selecting Asset", priority = 4,dependsOnMethods = {"Selecting_Account"})
	public void Selecting_Asset(Map <String,String> data) {
		scenario().then("Selecting Asset ", () -> {
			pages.getAccountDetailsPage().clickOnRelated("Assets");
			pages.getAssetsListPage().openAssetforEEAccount(data.get("assetName"),data.get("MINNumber"),data.get("SFServiceID"), true);
		}).then("I verify that I Select the Asset", () -> {
			Reporter.logWithScreenShot("Asset is Selected", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(description = "Extracting BillAccount Number", priority = 5,dependsOnMethods = {"Selecting_Asset"})
	public void Extracting_BillAccountNumber(Map <String,String> data) {
		scenario().and("Extracting BillAccount Number in Account Details Section", () -> {
			pages.getAssetDetailsPage().getBillAccountNumber();
		}).then("I verify that the Billing Account Number is Extracted", () -> {
			Reporter.logWithScreenShot("Billing Account Number is Extracted", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(description = "Case Creation", priority = 6,dependsOnMethods = {"Extracting_BillAccountNumber"})
	public void create_New_Case(Map <String,String> data) {
		scenario().given("I fill case form details and submit", () -> {
			pages.getAssetDetailsPage().clickOnRelated("Cases");
			pages.getCaseListPage().createNewCaseFromAsset(data);
		}).then("I verify that the case is created", () -> {
			Reporter.logWithScreenShot("case is created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(priority = 7,dependsOnMethods = {"create_New_Case"})
	private void changeCaseOwnerTest(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the change owner action", () -> {
			pages.getCaseListPage().selectCase(data.get("Subject"));
			caseURL= getDriver().getCurrentUrl();
			pages.getCaseDetailsPage().changeOwner(data.get("ownerName"));
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();
		}).then("I see the owner is changed", () -> {
			Reporter.logWithScreenShot("owner is changed", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(priority = 8,dependsOnMethods = {"changeCaseOwnerTest"})
	public void verifyTransactionDetails(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to case page and check transaction details section", () -> {
			pages.getCaseDetailsPage().verifyTransactionDetailsForChangeMIN(data.get("assetName"));
		}).then("I verify transaction details section", () -> {
			Reporter.logWithScreenShot("Transaction Details Section are Verified", MessageTypes.Info);
		}).execute();
	}


	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(priority = 9,dependsOnMethods = {"verifyTransactionDetails"})
	public void markCaseStatusToResolutionInprogress(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {
			pages.getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("case status got changed to resolution in progress", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(priority = 10,dependsOnMethods = {"markCaseStatusToResolutionInprogress"})
	public void numberReservation(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform number reservation", () -> {
			pages.getCasepage().numberReservationCheck();
		}).then("I verify the number reservation", () -> {
			Reporter.logWithScreenShot("Performed Number Reservation", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")
	@Test(priority = 11,dependsOnMethods = {"numberReservation"})
	public void updateQuoteValidationPeriod(Map <String,String> data) {
		scenario().given("I'm on Quote page", () -> {
		}).when("I update quote validation period", () -> {
			pages.getQuotepage().updateQuoteValidatyPeriod(data);
			quoteURL= getDriver().getCurrentUrl();
		}).then("I verify the quote validation period is updated", () -> {
			Reporter.logWithScreenShot("Quotation Validation Period is Updated", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")

	@Test(priority = 12,dependsOnMethods = {"updateQuoteValidationPeriod"})
	public void validateCart(Map <String,String> data) {
		scenario().given("I'm on Quote page", () -> {
		}).when("I perform validate cart action", () -> {
			pages.getQuotepage().ValidateCart();
		}).then("I verify the cart validation", () -> {
			Reporter.logWithScreenShot("Cart is Validated", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")

	@Test(priority = 13,dependsOnMethods = {"validateCart"})
	public void changeQuoteStatustoAccepted(Map <String,String> data) {
		scenario().given("I'm on Quote page", () -> {
		}).when("I change the Quote status to accepted", () -> {
			pages.getQuotepage().changeQuoteStatustoAccepted();
		}).then("I verify the quote status as accepted", () -> {
			Reporter.logWithScreenShot("Quote status changed to Accepted", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key = "${key.name}")

	@Test(priority = 14,dependsOnMethods = {"changeQuoteStatustoAccepted"})
	public void verifyOrderDetails(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to order search page", () -> {
			orderList=pages.getOrdersPage().VerifyOrders(40,1);
			ProjectBeans.setOrderURL(getDriver().getCurrentUrl());
		}).then("I verify the order generation", () -> {
			Reporter.logWithScreenShot("Verified the order generation", MessageTypes.Info);
		}).execute();
		MyScreenRecorder.stopRecording();
	}

	@Test(priority = 15,dependsOnMethods = {"verifyOrderDetails"})
	public void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
		Reporter.log("Quote URL :"+quoteURL, MessageTypes.Info);
		Reporter.log("OrderPage URL :"+ProjectBeans.getOrderURL(), MessageTypes.Info);
		if(orderList.size()>0)
		{
			for(int i=0;i<orderList.size();i++)
			{
				Reporter.log("Order_"+(i+1)+": "+orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
