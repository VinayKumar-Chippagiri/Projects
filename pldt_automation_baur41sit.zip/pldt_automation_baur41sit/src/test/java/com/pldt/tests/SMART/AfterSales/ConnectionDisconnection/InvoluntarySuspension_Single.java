package com.pldt.tests.SMART.AfterSales.ConnectionDisconnection;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ExcelReader;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class InvoluntarySuspension_Single extends BaseTest{
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String orderURL = null;
	String caseID = null;
	 String BillingAccountUrL = null;
	ArrayList<String> orderList = null;
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "TemporaryDisconnection",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "TemporaryDisconnection",key = "${key.name}")
	@Test(description = "Switch to RelationshipManager", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRelationShipManager(Map <String,String> data) {
		scenario().given("user logged in as Asmin", () -> {
		}).when("User Login As Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to RelationShipManager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Successfully switched to Relationship Manager");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "TemporaryDisconnection",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRelationShipManager" })
	public void CreateNewCase(Map<String, String> data)  {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			pages.getHomepage().switchToAnyAccount(data.get("accountName"), data.get("AccountNumber"));
			pages.getAccountDetailsPage().getAccountRecordType();
			pages.getAccountDetailsPage().clickOnRelated("Assets");
			pages.getAssetsListPage().openAssetforEEAccount(data.get("assetName"),data.get("MINNumber"),data.get("SFServiceID"),true);
			pages.getAssetDetailsPage().getBillAccountNumber();
		}).and("user click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().createNewCaseFromAsset(data);
			App().Pages().getCasepage().getCaseNumberFromToastMessage();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());// set case url in ProjectBeans
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "TemporaryDisconnection",key = "${key.name}")
	@Test(priority = 4,dependsOnMethods = { "CreateNewCase" })
	private void changeCaseOwnerTest(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the change owner action", () -> {
			pages.getCaseDetailsPage().changeOwner(data.get("ownerName"));
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();
			caseID =util.getTextFromPage(By.xpath("//p[@title='Case Number']/following::lightning-formatted-text[1]"));
		}).then("I see the owner is changed", () -> {
			Reporter.logWithScreenShot("owner is changed", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "TemporaryDisconnection",key = "${key.name}")
	@Test(description = "Modifying Transaction Details", priority = 5,dependsOnMethods = {"changeCaseOwnerTest"})
	public void ModifyTransactionDetails(Map <String,String> data) {		
		scenario().given("Modifying the Transaction Details", () -> {	
			App().Pages().getCaseDetailsPage().verifyTransactionDetailsForInvoluntary(data);
		}).then("I verify that the case is created", () -> {
			Reporter.logWithScreenShot("Transaction Details are Modified", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx",sheetName = "TemporaryDisconnection",key = "${key.name}")
	@Test(priority = 6,dependsOnMethods = {"ModifyTransactionDetails"})
	public void AddDocuments(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I'm Adding the Documents", () -> {
			pages.getCaseDetailsPage().AddDocumentsRequired();
		}).then("I verify the Documents added", () -> {
			Reporter.logWithScreenShot("I verify the Documents added", MessageTypes.Info);
		}).execute();
	}
	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "TemporaryDisconnection",key="${key.name}")
	@Test(priority = 7,dependsOnMethods = {"AddDocuments"})
	public void markCaseStatusToResolutionInprogress(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {	
			getDriver().navigate().to(caseURL);
			util.waitForCasePage();
			pages.getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolution in Progress", MessageTypes.Info);
		}).execute();
	}

	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "TemporaryDisconnection",key="${key.name}")
	@Test(priority = 8,dependsOnMethods = {"markCaseStatusToResolutionInprogress"})
	private void verifyTransaction(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I open Transaction", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Transaction__r");
			pages.getCaseDetailsPage().verifyTransaction();
			getDriver().get(caseURL);
			util.waitForCasePage();
		}).then("I verify the Transaction", () -> {
			Reporter.logWithScreenShot("Transaction is Verified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "TemporaryDisconnection",key="${key.name}")
	@Test(priority = 9,dependsOnMethods = {"verifyTransaction"})
	private void verifyCaseStatus(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform " + data.get("Transaction Type"), () -> {
			pages.getCaseDetailsPage().verfifyCaseStatus("Closed");
		}).then("I verify the Case Status", () -> {
			Reporter.logWithScreenShot("Case Status is Verified", MessageTypes.Info);
		}).execute();
	}
	
	
	@Test(priority = 10,dependsOnMethods = {"verifyCaseStatus"})
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
	}

}
