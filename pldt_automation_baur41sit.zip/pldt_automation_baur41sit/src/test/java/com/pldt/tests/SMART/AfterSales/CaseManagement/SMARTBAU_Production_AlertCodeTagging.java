package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;


public class SMARTBAU_Production_AlertCodeTagging extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL=null;
	String orderURL=null;
	String BillingAccountURL=null;
	ArrayList<String> orderList =null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to RM", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRM(Map <String,String> data) {
		scenario().given("user Switch to RM", () -> {
		}).when("User Login As RM", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("RM"));
			Reporter.log("Switched to RM:" + data.get("RM"));
		}).then("verify Admin successfully switched to RM", () -> {
			Reporter.logWithScreenShot("Successfully switched to RM");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRM" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("user Fill case details form and save", () -> {	
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getCasepage().createNewCaseAfterSalesCaseManagement(data);
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Change Case Owner", priority = 4, dependsOnMethods = { "CreateNewCase" })
	public void ChangeCaseOwner(Map<String, String> data) throws InterruptedException {
		scenario().
		given("User is on Case page", () -> {
		}).when("User search for new case owner", () -> {	
			App().Pages().getCasepage().changeOwner(data.get("Change Owner"));
			App().Pages().getCasepage().copyCaseOwnerNameAndNumber();
		}).and("Logout with RM", () -> {	
			App().Pages().getLoginpage().logoutCurrentUser();			
		}).and("Log in as case owner", () -> {
				App().Pages().getHomepage().SwitchToUser(data.get("Change Owner"), "Change Owner");
		}).then("User verify the case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Fill Transaction Details in casepage", priority = 5, dependsOnMethods = { "ChangeCaseOwner" })
	public void UpdateTransactionDetails(Map<String, String> data) {
		scenario().given("Updating TransactionDetails from case page", () -> {
		}).when("User go to case page ", () -> {
			util.goToURL(caseURL);
			util.waitForCasePage();
		}).and("User update fields in transaction Details", () -> {
			App().Pages().getCasepage().caseModificationforAlertcode(data);						
	}).then("User Verify Changes made in Case page", () -> {
		Reporter.logWithScreenShot("UpdateTransactionDetails and change status to document pending", MessageTypes.Info);
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Create Alert Code Tagging Request", priority = 6, dependsOnMethods = { "UpdateTransactionDetails" })
	public void CreateAlertCodeTagReq(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User Navigate to Alert Code Tagging Request ", () -> {	
		}).and("User create new alert Request", () -> {	
			App().Pages().getCasepage().CreateAlertcoderequest(caseURL,data);			
		}).then("User navigate to case page ", () -> {
			util.goToURL(caseURL);
			util.waitForCasePage();
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Change Status to resolution progress", priority = 7, dependsOnMethods = { "CreateAlertCodeTagReq" })
	public void ChangeToResolutionProgress(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Change Status to resolution progress", () -> {
			util.clickUsingJs(By
					.xpath("(//a[@data-tab-name='Assigned For Resolution'])[last()]"));
			util.waitFor(3);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();		
		}).then("User verify the case is submitted for Approval ", () -> {
			Reporter.logWithScreenShot("submitted for Approval");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Open Billing Account Page", priority = 8, dependsOnMethods = { "ChangeToResolutionProgress" })
	public void OpenBillingAccountPage(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User open Billing Account Page", () -> {			
			util.refreshPage();
			util.waitForCasePage();
			util.clickUsingJs(By.xpath("//span[.='"+ data.get("BillingAccountName") +"']/ancestor::a"));
            util.waitFor(10);
            BillingAccountURL= getDriver().getCurrentUrl();
		}).then("User verify the case is Approved ", () -> {
			QAFWebElement alert = new QAFExtendedWebElement(
					"xpath=(//div[@role='alert'])[1]");
			Validator.verifyTrue(alert.isPresent(), "alert is not displayed",
					"alert is displayed");
			Reporter.logWithScreenShot("Alert Visible in Billing Account Page");
		}).execute();
	}
	
	
	@Test(priority = 9,dependsOnMethods = { "OpenBillingAccountPage" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Billing Account URL :" + BillingAccountURL, MessageTypes.Info);
	}
}