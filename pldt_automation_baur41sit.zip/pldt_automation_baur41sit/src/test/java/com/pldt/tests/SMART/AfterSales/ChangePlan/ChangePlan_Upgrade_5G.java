package com.pldt.tests.SMART.AfterSales.ChangePlan;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class ChangePlan_Upgrade_5G extends BaseTest {
	WebUtilities util = new WebUtilities();
	String type = null;
	String caseURL = null;
	String quoteURL = null;
	String orderURL = null;
	ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "MNP PortIn")
	public void loginAsAdmin(Map<String, String> data) throws InterruptedException {

		scenario().given("I Log into PLDT Application as admin", () -> {

//			getDriver().get("https://test.salesforce.com/");
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			// ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I log in as Admin", () -> {
			App().Pages().getLoginpage().LoginAsAdmin();
//			App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"), "EE RM");
		}).then("I verified that I logged in as an Admin", () -> {
			Reporter.logWithScreenShot(" Logged in as Relationship Manager", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Login as Relationship Manager", priority = 2, dependsOnMethods = { "loginAsAdmin" })
	public void switchToRM(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Home Page", () -> {
		}).when("I Switched as Relationship Manager", () -> {
			// App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"),
			// "EE RM");
			App().Pages().getHomepage().switchToAnyUser(data.get("RM"));
		}).then("I verified that I Switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Switched to Relationship Manager", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Creating new Case for Change Plan", priority = 3, dependsOnMethods = { "switchToRM" })
	public void createNewCase(Map<String, String> data) throws InterruptedException {
		// ConfigurationManager.getBundle().setProperty("testdata", data);
		props.setProperty("testdata", data);
		scenario().given("I am on Home Page", () -> {
		}).when("I navigate to Account Page and choose an Account", () -> {
			// App().Pages().getHomepage().goToAPP("Accounts");
			// App().Pages().getAccountListPage().launchPage(null, null);

			// App().Pages().getAccountpage().SelectAccount(data.get("Account
			// Name"),data.get("AccoutType"));
			// App().Pages().getAccountListPage().openAccount(data.get("Account Name"));
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account Name"), "Account");
		}).and("I click on Assets and create a new Case", () -> {
			// App().Pages().getAccountpage().clickAssetLink();
			App().Pages().getAccountDetailsPage().clickOnRelated("Assets");
			// App().Pages().getAssetpage().clickOnAsset(data.get("Asset_Name"),
			// data.get("MIN_Number"));
			App().Pages().getAssetsListPage().openAsset(data.get("Asset_Name"), data.get("MIN_Number"), true);
			// App().Pages().getAssetpage().goToAccountRelatedCaseSearchPage();
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			// App().Pages().getAssetpage().clickNewCase();
			// App().Pages().getCasepage().clickNewCase(); //
			App().Pages().getCaseListPage().clickNewCaseButton();
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			// App().Pages().getCasepage().SelectRecordType();
			// App().Pages().getAssetpage().getBillAccountNumber();
			// App().Pages().getNewCaseModal().createNewCase(data.get("Account
			// Name"),data.get("Contact Name"),data.get("Consignee Name"),data.get("Billing
			// Account"));
			App().Pages().getCasepage().createChangePlanNewCase(data.get("BillingAccount"));
		}).then("i verified that Case is Created", () -> {
			Reporter.logWithScreenShot("Case is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Modifying the case", priority = 4, dependsOnMethods = { "createNewCase" })
	public void caseModification(Map<String, String> data) throws InterruptedException {
		// ConfigurationManager.getBundle().setProperty("testdata", data);
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I search for the case", () -> {
			// App().Pages().getCasepage().clickOnCaseByFiltering(data.get("Subject"));
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
		}).and("i modified the case and changed the status to resolution in progress", () -> {
			// getDriver().navigate().to("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Case/5001s000005q4KUAAY/view");
			util.waitForCasePage();
			caseURL = getDriver().getCurrentUrl();
			// App().Pages().getCasepage().caseModification(); ///
			App().Pages().getCaseDetailsPage().caseModification(data.get("MigrationType"),data);
			// App().Pages().getCasepage().clickOnResolInProgress();
			// App().Pages().getCasepage().markCaseStatusToResolutionInprogress();
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();

		}).then("i verified that case is modified", () -> {
			Reporter.logWithScreenShot(" Case is Modified", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Change Plan", priority = 5, dependsOnMethods = { "caseModification" })
	public void changePlan(Map<String, String> data) throws InterruptedException {
		// ConfigurationManager.getBundle().setProperty("testdata", data);
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I perform Change Plan", () -> {
			// App().Pages().getCasepage().requestChangePlan(data.get("Plan"),data.get("Addons"));
			App().Pages().getCaseDetailsPage().requestChangePlan(data.get("Plan"), data.get("Addons"), data);
			util.waitFor(5);
			util.waitForQuotePage();
//			App().Pages().getCartpage().SaveWorkingCart();
//			App().Pages().getCartpage().WorkingCartConfigure();
		}).then("i verified that change plan is executed", () -> {
			Reporter.logWithScreenShot("change plan executed", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Update Quote", priority = 6, dependsOnMethods = { "changePlan" })
	public void updateQuote(Map<String, String> data) throws InterruptedException {
		// ConfigurationManager.getBundle().setProperty("testdata", data);
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Update Quotation Validity period, Contacts and Delivery Date", () -> {
			// getDriver().navigate().to("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Quote/0Q01s0000006HWlCAM/view");
			// App().Pages().getQuotepage().UpdateQuotationValidityPeriod(data.get("QuotationValidity").toString());
			util.refreshPage();
			util.waitForQuotePage();
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl());
			quoteURL = getDriver().getCurrentUrl();
			// App().Pages().getQuotepage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
			App().Pages().getQuoteDetailsPage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);

		}).then("i verified that All the necessary fields are updated", () -> {
			Reporter.logWithScreenShot(" Updated Quotation Validity Period, Contacts, Delivery Date",
					MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Validate Cart", priority = 7, dependsOnMethods = { "updateQuote" })
	public void validateCart(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I perform Validate Cart", () -> {
//			try {
//				Thread.sleep(5000);
//			} catch (Exception e) {}
			// App().Pages().getQuotepage().ValidateCart(); //
			App().Pages().getQuoteDetailsPage().ValidateCart();
			// getDriver().get(ProjectBeans.getQuoteURL());
			util.waitTillLoaderDissapear();
			util.waitForQuotePage();

			type = data.get("Transaction Type");
		}).then("i verified that Cart is Validated", () -> {
			Reporter.logWithScreenShot(" Validate Cart", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Login as Credit Analyst", priority = 8, dependsOnMethods = { "validateCart" })
	public void loginAsCA(Map<String, String> data) throws InterruptedException {
		// ConfigurationManager.getBundle().setProperty("testdata", data);
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("logout and Login as Credit Analyst", () -> {
			// type = data.get("Transaction Type");
			if (type.equalsIgnoreCase("Upgrade / plan upgrade")) {
				App().Pages().getLoginpage().logoutCurrentUser();

				if (getDriver().findElements(By.xpath("//input[@id='username']")).size() != 0) {
					App().Pages().getLoginpage().LoginAsAdmin();
//					try {
//						Thread.sleep(5000);
//					} catch (Exception e) {
//						// TODO: handle exception
//					}
					// App().Pages().getHomepage().SwitchToUser(data.get("Credit Analyst"), "Credit
					// Analyst");
					App().Pages().getHomepage().switchToAnyUser(data.get("CA"));
					try {
						Thread.sleep(5000);
					} catch (Exception e) {
						// TODO: handle exception

					}
				} else {
					// App().Pages().getHomepage().SwitchToUser(data.get("Credit Analyst"), "Credit
					// Analyst");
					App().Pages().getHomepage().switchToAnyUser(data.get("CA"));
				}
			}
		}).then("i verified that I am Logged in as Credit Analyst", () -> {
			Reporter.logWithScreenShot(" Logged in as Credit Analyst ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Update Credit Information", priority = 9, dependsOnMethods = { "loginAsCA" })
	public void updateCreditInformation(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I update Credit Information using Credit Analyst", () -> {
			type = data.get("Transaction Type");
			if (type.equalsIgnoreCase("Upgrade / plan upgrade")) {
				getDriver().get(ProjectBeans.getQuoteURL());
				App().Pages().getQuoteDetailsPage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
						data.get("CreditApprovalCondition"), data.get("Credit Check Remark"));
				// App().Pages().getLoginpage().logoutCurrentUser();
			}
		}).then("i verified that Credit Information Fields are Updated", () -> {
			Reporter.logWithScreenShot("Credit Information ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "login as Relationship Manager", priority = 10, dependsOnMethods = {
			"updateCreditInformation" })
	public void loginAsRM(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("logout and Login as Relationship Manager", () -> {
			// type = data.get("Transaction Type");
			if (type.equalsIgnoreCase("Upgrade / plan upgrade")) {
				App().Pages().getLoginpage().logoutCurrentUser();
				// App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"),
				// "EE RM");
				App().Pages().getHomepage().switchToAnyUser(data.get("RM"));
				try {
					Thread.sleep(3000);
				} catch (Exception e) {
				}
				// App().Pages().getHomepage().switchToAnyUser(data.get("Relationship
				// Manager"));
				getDriver().get(ProjectBeans.getQuoteURL());
			}
		}).then("i verified that I am Logged in as Relationship Manager", () -> {
			Reporter.logWithScreenShot(" Logged in as Relationship Manager ", MessageTypes.Info);
		}).execute();
	}

//	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key="ChangePlan_TC01")
//	@Test(description = "Create Contract", priority = 10, dependsOnMethods = { "logoutAndLoginAsRelationshipManager" })
//	//@Test(description = "Create Contract")
//	public void ebit() {
//		App().Pages().getLoginpage().logoutCurrentUser();
//		App().Pages().getQuotepage().ebit();
//	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Create Contract", priority = 11, dependsOnMethods = { "loginAsRM" })
	// @Test(description = "Create Contract")
	public void contractCreation(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I Click on Quote to PDF", () -> {
			util.ChangeStatus("Internal Approval");								 // New
			App().Pages().getQuoteDetailsPage().QuotetoPDF();					//New
			 util.ChangeStatus("Customer Approved");
		}).and("I Click on Create Contract", () -> {
			App().Pages().getQuoteDetailsPage().ChangeStatusToAccepted();
			App().Pages().getQuoteDetailsPage().CreateContract();
			util.waitForContractPage();
			ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // Set Contract URL
		}).when("I change the status to Awaiting Signature", () -> {
			App().Pages().getContractpage().ChangeTheStatusToSigned();
			util.waitTillLoaderDissapear();
			util.waitForContractPage();
		}).then("i verified that Contract is created and Status is changed to Awaiting Signature", () -> {
			Reporter.logWithScreenShot("Contract is Created", MessageTypes.Info);
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangePlan", key = "${key.name}")
	@Test(description = "Verify Orders", priority = 11, dependsOnMethods = { "contractCreation" })
	private void verifyOrderDetails() {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to order search page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			// App().Pages().getCasepage().verifyOrdersFromCasePage(caseURL);
			orderList = App().Pages().getOrdersPage().VerifyOrders(40,2);
			util.refreshOrders(20, 2);
		}).then("I verify the order generation", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@Test(priority = 12, dependsOnMethods = { "verifyOrderDetails" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Quote URL :" + quoteURL, MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order _"+(i+1)+" URL : "+orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
