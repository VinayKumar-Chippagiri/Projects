package com.pldt.tests.SMART.MainConnect;

import com.common.utilities.AppCommons;
import com.common.utilities.MyScreenRecorder;
import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.google.common.base.Supplier;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElementListHandler;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.awt.*;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

public class MainConnect extends BaseTest {

/*
//	@QAFDataProvider(dataFile = "resources/testdata/NewConnectProducts.xlsx", sheetName = "Lead", key = "${key.name}")
	@BeforeSuite
	public void startrecord() {
		try {
			// MyScreenRecorder.startRecording(context.getSuite().getName());
			MyScreenRecorder.startRecording(context.getName());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@AfterSuite
	public void stoprecord() {
		try {
			MyScreenRecorder.stopRecording();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
*/

    public void LoginAsAdmin(Map<String, String> data) {
        WebDriverTestBase driver = new WebDriverTestBase();
        WebUtilities util = new WebUtilities();
        scenario().given("I am on Salesforce Login page", () -> {
            ConfigurationManager.getBundle().setProperty("testdata", data);
            driver.getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
            Reporter.logWithScreenShot("Login page");
        }).when("I enter admin username and password", () -> {
            App().Pages().getLoginpage().LoginAsAdmin();
            driver.getDriver().executeScript("return document.readyState").equals("complete");
            util.waitFor(20);
        }).then("I verify user able to login and navigated to home page", () -> {
            String title = driver.getDriver().getTitle();
            Validator.verifyThat("verify user able to login as admin or not", title,
                    Matchers.equalTo("Home | Salesforce"));
            mouseMover();
        }).execute();
    }

    public void SwitchToRM(Map<String, String> data) {
        WebDriverTestBase driver = new WebDriverTestBase();
        WebUtilities util = new WebUtilities();
        scenario().given("I am on Salesforce home page, login as Admin", () -> {
        }).when("I Switched to RelationShip Manager", () -> {
            String strRM = data.get("Relationship_Manager");
            Reporter.log("Relationship Manager: " + strRM);
            App().Pages().getHomepage().switchToAnyUser(strRM);
            ConfigurationManager.getBundle().setProperty("RelationShip_Manager", strRM);
            ConfigurationManager.getBundle().setProperty("Credit_Analyst", data.get("Credit_Analyst"));
            ConfigurationManager.getBundle().setProperty("Owner", strRM);
        }).then("I verify switched to RelationShip Manager", () -> {
            util.waitFor(20);
            String heading = driver.getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[contains(text(),'Logged in as')]")).getText();
            Validator.verifyThat("login as RM", heading,
                    Matchers.containsString("Logged in as " + data.get("Relationship_Manager")));
            QAFExtendedWebElement PLDTTitle = new QAFExtendedWebElement(By.xpath("//span[@title='PLDT Enterprise']"));
            Validator.verifyTrue(PLDTTitle.isPresent(), "PLDT Enterprise App Is Not Present On Home Page",
                    "PLDT Enterprise App Is Present On Home Page");
            mouseMover();
        }).execute();
    }

    public void setOwner(String owner) {
        ConfigurationManager.getBundle().setProperty("Owner", owner);
    }


    public void setQuoteURL() {
        WebDriverTestBase driver = new WebDriverTestBase();
        String url = driver.getDriver().getCurrentUrl();
        ConfigurationManager.getBundle().setProperty("QuoteURL", url);
    }

    public void NavigateQuoteURL() {
        WebDriverTestBase driver = new WebDriverTestBase();
        driver.getDriver().navigate().to(ConfigurationManager.getBundle().getPropertyValue("QuoteURL"));
    }


    public void SwitchToCA(Map<String, String> data) {
        WebDriverTestBase driver = new WebDriverTestBase();
        WebUtilities util = new WebUtilities();
        scenario().given("I am on Salesforce home page, login as Admin", () -> {
        }).when("I Switched to Credit Analyst", () -> {
            String strCA = data.get("Credit_Analyst");
            Reporter.log("Credit Analyst: " + strCA);
            App().Pages().getHomepage().switchToAnyUser(strCA);
            ConfigurationManager.getBundle().setProperty("RelationShip_Manager", data.get("Relationship_Manager"));
            ConfigurationManager.getBundle().setProperty("Credit_Analyst", strCA);
            ConfigurationManager.getBundle().setProperty("Owner", strCA);
        }).then("I verify switched to Credit Analyst", () -> {
            util.waitFor(20);
            String heading = driver.getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[contains(text(),'Logged in as')]")).getText();
            Validator.verifyThat("login as CA", heading,
                    Matchers.containsString("Logged in as " + data.get("Credit_Analyst")));
            QAFExtendedWebElement PLDTTitle = new QAFExtendedWebElement(By.xpath("//span[@title='PLDT Enterprise']"));
            Validator.verifyTrue(PLDTTitle.isPresent(), "PLDT Enterprise App Is Not Present On Home Page",
                    "PLDT Enterprise App Is Present On Home Page");
            mouseMover();
        }).execute();
    }

    public void SwitchToOtherUser(String user) {
        WebDriverTestBase driver = new WebDriverTestBase();
        WebUtilities util = new WebUtilities();
        scenario().given("I am switching the user", () -> {
            Reporter.log("Switch user to: " + user);
        }).when("I Switched to " + user, () -> {
            App().Pages().getHomepage().switchToAnyUser(user);
            ConfigurationManager.getBundle().setProperty("Owner", user);
        }).then("I verify switched to " + user, () -> {
            util.waitFor(20);
            String heading = driver.getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[contains(text(),'Logged in as')]")).getText();
            Validator.verifyThat("login as user" + "", heading, Matchers.containsString("Logged in as " + user));
            QAFExtendedWebElement PLDTTitle = new QAFExtendedWebElement(By.xpath("//span[@title='PLDT Enterprise']"));
            Validator.verifyTrue(PLDTTitle.isPresent(), "PLDT Enterprise App Is Not Present On Home Page",
                    "PLDT Enterprise App Is Present On Home Page");
            mouseMover();
        }).execute();
    }

    public void LogoutUser(Map<String, String> data) {
        WebDriverTestBase driver = new WebDriverTestBase();
        WebUtilities util = new WebUtilities();
        scenario().given("I logout as current user", () -> {
            ConfigurationManager.getBundle().setProperty("testdata", data);
            String heading = driver.getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[1]")).getText();
            Reporter.log("Current user " + heading);
        }).when("I Logout", () -> {
            App().Pages().getLoginpage().logoutAsCurrentUser();
        }).then("I verify ", () -> {
            util.waitFor(20);
            Reporter.logWithScreenShot("SetUp screen");
        }).execute();

    }

    public void navigateAcURL(WebDriverTestBase driver) {
        String URL = ConfigurationManager.getBundle().getPropertyValue("AccountURL");
        driver.getDriver().navigate().to(URL);
    }

    public void OpenExistingAccount(Map<String, String> data) {
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        AppCommons AppUtils = new AppCommons();
        scenario().given("I am on home page", () -> {
            util.implicitlyWait(10);
            ConfigurationManager.getBundle().setProperty("testdata", data);
            Reporter.log("given AC: " + data.get("Account_Name"));
        }).when("I am on " + data.get("Account_Name") + " Account page", () -> {
            App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
            ConfigurationManager.getBundle().setProperty("Account", data.get("Account_Name"));
        }).then("I verify Account", () -> {
            util.implicitlyWait(25);
            String heading = driver.getDriver()
                    .findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']")).getText();
            String AcName = data.get("Account_Name");
            Validator.verifyThat("Account name", heading, Matchers.containsString(AcName));
            ConfigurationManager.getBundle().setProperty("AccountURL", driver.getDriver().getCurrentUrl());
            AppUtils.mouseMover();
        }).execute();
    }

    public void CreatingQuoteTest(Map<String, String> data) {
        AppCommons app = new AppCommons();
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        scenario().given("I am on account page", () -> {
            ConfigurationManager.getBundle().setProperty("testdata", data);
            createQuoteBtn(util);
            util.waitFor(20);
        }).when("I click on create quote button, select record type and fill the new quote form", () -> {
            selectRecordType(util);
            verifyCreateQuoteHeading();
            fillQuoteForm(util);
        }).then("I verified that Quote is Created", () -> {
            util.waitFor(25);
            verifyQuotePage();
            app.mouseMover();
        }).execute();
    }

    public void verifyQuotePage() {
        QAFExtendedWebElement title = new QAFExtendedWebElement(By.xpath("//div[text()='Quote']/following::span[1]"));
        title.waitForPresent();
        Validator.verifyThat("I verify quote page is open", title.getText(),
                Matchers.equalTo(ConfigurationManager.getBundle().getPropertyValue("Quote_name")));
    }


    public void createQuoteBtn(WebUtilities util) {
        util.clickOnActionToolBarButton("AccountActionToolbar", "Create Quote");
        util.waitFor(20);
        util.AttachFrame();
    }

    public void selectRecordType(WebUtilities util) {
        QAFExtendedWebElement recordType = new QAFExtendedWebElement(By.xpath("(//span[text()='PLDT_Quote'])"));
        recordType.click();
        util.waitFor(5);
        Reporter.log("selected Record type: PLDT_Quote");
        QAFExtendedWebElement nextButton = new QAFExtendedWebElement(By.xpath("//div[contains(@id,'RecordTypeSelection_nextBtn')]"));
        util.waitFor(3);
        Reporter.log("Clicked on next button");
        nextButton.click();
    }

    public void fillQuoteForm(WebUtilities util) {
        TestDataBean bean = new TestDataBean();
        bean.fillRandomData();
        QAFExtendedWebElement quoteNameTextBox = new QAFExtendedWebElement(By.xpath("//input[@id='QuoteName']"));
        QAFExtendedWebElement closeDateTextBox = new QAFExtendedWebElement(By.xpath("//input[@id='OpportunityCloseDate']"));
        QAFExtendedWebElement priceListSearchBox = new QAFExtendedWebElement(By.xpath("//input[@id='PriceList']"));
        QAFExtendedWebElement smartPriceList = new QAFExtendedWebElement(By.xpath("//input[@id='PriceList']/following::ul/li[contains(text(),'SMART Price List')]"));
        QAFExtendedWebElement enterprisePHPPriceList = new QAFExtendedWebElement(By.xpath("//input[@id='PriceList']/following::ul/li[contains(text(),'Enterprise PHP Price List')]"));
        QAFExtendedWebElement nextButton = new QAFExtendedWebElement(By.xpath("//div[@id='QuoteCreationForm_nextBtn']"));
        String quoteName = bean.getFirstName();
        quoteNameTextBox.sendKeys(quoteName);
        ConfigurationManager.getBundle().setProperty("Quote_name", quoteName);
        util.waitFor(2);
        closeDateTextBox.sendKeys(getDate(1, "Plus", "MM-DD-YYYY"));
        util.waitFor(2);
        priceListSearchBox.click();
        util.waitFor(6);
        //smartPriceList.click();
        enterprisePHPPriceList.click();
        util.scrollUp();
        Reporter.logWithScreenShot("Quote details");
        nextButton.click();
        util.waitFor(15);
    }

    public void verifyCreateQuoteHeading() {
        QAFExtendedWebElement recordType = new QAFExtendedWebElement(By.xpath("//section[@id='QuoteCreationForm']//h1[contains(text(),'Create Quote')]"));
        String header = recordType.getText();
        Validator.verifyThat("Verify Quote page", header, Matchers.containsString("Create Quote"));
    }

    public String getDate(int years, String sign, String pattern) {
        LocalDateTime date = LocalDateTime.now();
        String dateValue = null;
        if (sign.equalsIgnoreCase("Plus")) {
            dateValue = DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH).format(date.plusYears(years));
        } else if (sign.equalsIgnoreCase("Minus")) {
            dateValue = DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH).format(date.minusYears(years));
        }
        return dateValue;
    }

    public void selectBulkSiteMultiple(Map<String, String> data) {
        WebUtilities util = new WebUtilities();
        QAFExtendedWebElement bulkSiteBtn = new QAFExtendedWebElement(By.xpath("//button[contains(text(),'Bulk Sites')]"));
        QAFExtendedWebElement serviceAddSearch = new QAFExtendedWebElement(By.xpath("//input[@placeholder='Service Address Search']"));
        QAFExtendedWebElement nextButton = new QAFExtendedWebElement(By.xpath("//div//button[text()='Next']"));
        QAFExtendedWebElement createGroupButton = new QAFExtendedWebElement(By.xpath("//button[contains(text(),'Create Group')]"));
        QAFExtendedWebElement createGroupInput = new QAFExtendedWebElement(By.xpath("(//label[text()='Group Name']//following::input)[1]"));
        QAFExtendedWebElement createGroupSave = new QAFExtendedWebElement(By.xpath("//button[text()='Save']"));
        QAFExtendedWebElement selectAGroup = new QAFExtendedWebElement(By.xpath("//button[@aria-label='Groups, Select a Group']"));
        QAFExtendedWebElement selectAll = new QAFExtendedWebElement(By.xpath("//span[text()='Select All']//parent::label//span"));
        QAFExtendedWebElement addToGroupButton = new QAFExtendedWebElement(By.xpath("//button[text()='Add To Group']"));
        util.waitFor(15);
        bulkSiteBtn.click();
        util.waitFor(By.xpath("//h1[text()='Select Existing Service Addresses']"), 10, true);
        util.waitFor(30);
        String[] clarityID = data.get("Clarity_ID").split(",");
        /*String singleID = clarityID[0];
        serviceAddSearch.sendKeys(singleID);
        util.waitFor(15);
        serviceAddSearch.sendKeys(Keys.TAB);
        serviceAddSearch.sendKeys(Keys.BACK_SPACE);
        serviceAddSearch.sendKeys(Keys.BACK_SPACE);
        util.waitFor(10);*/
        serviceAddSearch.sendKeys(data.get("Street"));
        util.waitFor(15);
        serviceAddSearch.sendKeys(Keys.ENTER);
        util.waitFor(10);
        for (String id : clarityID) {
            QAFExtendedWebElement serviceAddCheckBox = new QAFExtendedWebElement(
                    By.xpath("//div/lightning-base-formatted-text[text()='" + id
                            + "']/ancestor::tr//span[@class='slds-checkbox_faux']"));
            serviceAddCheckBox.click();
        }
        Reporter.logWithScreenShot("Service Addres checkbox");
        util.scrollIntoElement(nextButton);
        nextButton.click();
        util.waitFor(10);
        createGroupButton.click();
        util.waitFor(5);
        String grpName = null;
        if (!data.get("Group_Name").equalsIgnoreCase("Random") || Objects.nonNull(data.get("Group_Name"))) {
            TestDataBean bean = new TestDataBean();
            bean.fillRandomData();
            grpName = bean.getFirstName();
        } else {
            grpName = data.get("Group_Name");
        }
        createGroupInput.sendKeys(grpName);
        ConfigurationManager.getBundle().setProperty("GroupName", grpName);
        createGroupSave.click();
        util.waitFor(10);
        selectAGroup.click();
        QAFExtendedWebElement selectName = new QAFExtendedWebElement(By.xpath("//span[@title='" + grpName + "']"));
        selectName.click();
        util.waitFor(2);
        selectAll.click();
        util.waitFor(5);
        Reporter.logWithScreenShot("adding to group");
        addToGroupButton.click();
        util.waitFor(15);
        nextButton.click();
        util.waitFor(6);
        Reporter.logWithScreenShot("review to group");
        nextButton.click();
        util.waitFor(20);
        verifyQuotePage();
    }

    public void AddProductToCart() {
        WebUtilities util = new WebUtilities();
        util.clickOnActionToolBarButton("QuoteActionToolbar", "Add Products");
        util.waitFor(20);
        util.AttachFrame();
    }

    public void configIPVPN(Map<String, String> data) {
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        String primaryPlan = data.get("Plan");
        scenario().given("I am on cart page", () -> {
            ConfigurationManager.getBundle().setProperty("testdata", data);
            util.implicitlyWait(15);
        }).when("I add product to cart", () -> {
            App().Pages().getCartpage().addMainPlan(primaryPlan);
            util.waitFor(20);
            util.AttachFrame();
            util.implicitlyWait(By.xpath("//button[contains(@title,'Product Name: " + primaryPlan + "')]"));
        }).then("I verify product added to the cart", () -> {
            QAFExtendedWebElement element = new QAFExtendedWebElement(By.xpath(
                    "//button[contains(@title,'Product Name: " + primaryPlan + "')]"));
            util.waitFor(20);
            mouseMover();
            boolean product = element.isPresent() && element.isDisplayed();
            if (!product) {
                util.refreshSwitchToFrame();
                util.waitFor(20);
                product = element.isPresent() && element.isDisplayed();
            }
            int numberOfRefresh = 0;
            while (!product && numberOfRefresh++ < 3) {
                Reporter.log("failed to add " + primaryPlan + " at attempt " + numberOfRefresh);
                util.refreshPage();
                util.implicitlyWait(15);
                App().Pages().getCartpage().addMainPlan(primaryPlan);
                util.waitFor(10);
                product = element.isPresent() && element.isDisplayed();
            }
            element.verifyPresent(primaryPlan);
            Reporter.log(driver.getDriver().getCurrentUrl());
        }).and("Configuring the attributes", () -> {
            util.waitFor(10);
            util.AttachFrame();
            util.waitFor(20);
            expandingProduct("End Point Primary");
            util.waitFor(15);
            App().Pages().getCartpage().selectConfigure("Access");
            util.waitFor(10);
            App().Pages().getCartpage().select_Config_Parameter("Access Type", data.get("Access Type"));
            util.waitFor(4);
            VerifySave();
            App().Pages().getCartpage().selectConfigure("End Point Primary");
            util.waitFor(4);
            App().Pages().getCartpage().select_Config_Parameter("Bandwidth/ Speed", data.get("Bandwidth/ Speed"));
            util.waitFor(4);
            Reporter.logWithScreenShot("Bandwidth/ Speed");
            VerifySave();
            mouseMover();
            util.refreshPage();
        }).execute();
    }

    public void configCiscoManagedRouter(Map<String, String> data) {
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        String primaryPlan = data.get("Second Plan");
        scenario().given("I am on cart page", () -> {
            ConfigurationManager.getBundle().setProperty("testdata", data);
            util.implicitlyWait(15);
        }).when("I add product to cart", () -> {
            App().Pages().getCartpage().addMainPlan(primaryPlan);
            util.waitFor(20);
            util.AttachFrame();
            util.implicitlyWait(By.xpath("//button[contains(@title,'Product Name: " + primaryPlan + "')]"));
        }).then("I verify product added to the cart", () -> {
            QAFExtendedWebElement element = new QAFExtendedWebElement(By.xpath(
                    "//button[contains(@title,'Product Name: " + primaryPlan + "')]"));
            util.waitFor(20);
            mouseMover();
           /* boolean product = element.isPresent() && element.isDisplayed();
            if (!product) {
                util.refreshSwitchToFrame();
                util.waitFor(20);
                product = element.isPresent() && element.isDisplayed();
            }
            int numberOfRefresh = 0;
            while (!product && numberOfRefresh++ < 3) {
                Reporter.log("failed to add " + primaryPlan + " at attempt " + numberOfRefresh);
                util.refreshPage();
                util.implicitlyWait(15);
                App().Pages().getCartpage().addMainPlan(primaryPlan);
                util.waitFor(10);
                product = element.isPresent() && element.isDisplayed();
            }*/
            element.verifyPresent(primaryPlan);
            Reporter.log(driver.getDriver().getCurrentUrl());
            mouseMover();
            util.refreshPage();
        }).execute();
    }


    public void VerifySave() {
        QAFExtendedWebElement submit = new QAFExtendedWebElement("xpath=//button[@type='submit']");
        QAFExtendedWebElement closebtn = new QAFExtendedWebElement("xpath=//button[@ng-click='importedScope.close()']");
        if (submit.isEnabled()) {
            submit.click();
            QAFExtendedWebElement spinnercontainer = new QAFExtendedWebElement("xpath=//div[@class='slds-spinner_container']");
            while (spinnercontainer.isPresent()) {
                try {
                    Thread.sleep(3);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        } else {
            closebtn.click();
            Reporter.log("no changes applied");
        }
    }

    /**
     * WorkingCart_grouping_Product --It Performs the Grouping in the Working Cart
     * Page.
     *
     * @author Waseem
     */
    public void WorkingCart_grouping(WebUtilities util, WebDriverTestBase driver) {
        int i = 0;
        click_grouping(util);
        String checkboxXpath = "//tbody//label[@class='slds-checkbox']/span[1]";
        List<WebElement> elements = driver.getDriver().findElements(By.xpath(checkboxXpath));
        int count = elements.size();
        while (i < count) {
            for (int j = 0; j < 3; j++) {
                elements.get(i).click();
                i++;
                if (i == count) {
                    break;
                }
            }
            Reporter.logWithScreenShot("Number of products " + i + " selected for grouping");
            select_serviceAdd(util);
            if (i < count) {
                click_grouping(util);
                elements = driver.getDriver().findElements(By.xpath(checkboxXpath));
            }
        }
    }

    public void select_serviceAdd(WebUtilities util) {
        if (util.isElementDisplayed(By.xpath("//input[@id='QuoteMembers']"))) {
            util.clickUsingJs(By.xpath("//input[@id='QuoteMembers']"));
            util.clickUsingJs(By.xpath("(//li[@role='button'])[last()]"));
        }
        util.vlocityNextButton();
        util.waitForCartPage();
        util.waitFor(15);
    }

    public void click_grouping(WebUtilities util) {
        util.waitFor(20);
        util.AttachFrame();
        QAFExtendedWebElement groupingButton = new QAFExtendedWebElement(By.xpath("//button[@title='Grouping']"));
        util.clickUsingJs(groupingButton);
        util.waitForVlocityOmniScript();
        util.waitFor(15);
        util.AttachFrame();
    }

    public void SaveWorkingCart() {
        WebUtilities util = new WebUtilities();
        util.AttachFrame();
        QAFExtendedWebElement save = new QAFExtendedWebElement(By.xpath("//button[@title='Save Working Cart']"));
        save.click();
        Reporter.log("Clicked on Save Working Cart button on cart page...");
        util.waitFor(20);
    }

    public void ClickOnQuoteBundles() {
        QAFExtendedWebElement Bundles = new QAFExtendedWebElement(By.xpath("//a[@title='Bundles']"));
        Bundles.click();
        Reporter.log("Clicked on Bundles link");
    }

    public void ClickOnQuoteRelated() {
        QAFExtendedWebElement Related = new QAFExtendedWebElement(By.xpath("//a[@title='Related']"));
        Related.click();
        Reporter.log("Clicked on Related link");
    }

    public void product_Association(String product, WebUtilities util, WebDriverTestBase driver) {
        QAFExtendedWebElement enterProductNameInput = new QAFExtendedWebElement(By.xpath("//input[@placeholder='Enter Product Name']"));
        QAFExtendedWebElement productCheckbox = new QAFExtendedWebElement(By.xpath("//lightning-base-formatted-text[text()='" + product + "']/ancestor::tr//span[@class='slds-checkbox_faux']"));
        QAFExtendedWebElement productAssociation = new QAFExtendedWebElement(By.xpath("//button[text()='Product Association']"));
        QAFExtendedWebElement nextButton = new QAFExtendedWebElement(By.xpath("//div[@id='RelatedProducts_nextBtn']"));
        util.waitFor(enterProductNameInput, 30, true);
        productCheckbox.click();
        util.waitFor(3);
        productAssociation.click();
        util.waitFor(15);
        util.AttachFrame();
        String checkboxXpath = "//th/div[.='Product Name']/following::label[@class='slds-checkbox']";
        List<WebElement> elements = driver.getDriver().findElements(By.xpath(checkboxXpath));
        elements.forEach(WebElement::click);
        Reporter.logWithScreenShot("selected product association");
        util.waitFor(3);
        nextButton.click();
        Reporter.log("Clicked on next button");
        util.waitFor(15);
    }

    public void Association_Validation(WebUtilities util) {
        util.waitFor(15);
        QAFExtendedWebElement AssociationValidation = new QAFExtendedWebElement(By.xpath(
                "//button[text()='Association Validation']"));
        AssociationValidation.click();
        Reporter.logWithScreenShot("AssociationValidation is done");
        util.waitFor(10);
    }

    public void groupingAndSavingWorkingCart() {
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        scenario().given("I am on working cart page, Grouping the product", () -> {
            WorkingCart_grouping(util, driver);
        }).when("Saving working cart", () -> {
            SaveWorkingCart();
        }).then("I verify", () -> {
            util.waitFor(25);
            verifyQuotePage();
        }).execute();
    }

    public void performAssociation(String product) {
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        scenario().given("I am on Quote page after adding product", () -> {
        }).when("I perform Product Association", () -> {
            ClickOnQuoteBundles();
            product_Association(product, util, driver);
        }).then("I perform Association Validation", () -> {
            ClickOnQuoteBundles();
            Association_Validation(util);
        }).execute();
    }

    public void serviceability() {
        WebUtilities util = new WebUtilities();
        scenario().given("I am on Quote page clicking Serviceability button from QuoteActionToolbar", () -> util.clickOnActionToolBarButton("QuoteActionToolbar", "Serviceability")).when("performing serviceability", () -> {
            QAFExtendedWebElement checkbox = new QAFExtendedWebElement(By.xpath("//label[contains(@for,'lgt-dt-header-factory')]//span[@class='slds-checkbox_faux']"));
            QAFExtendedWebElement ServiceabilityCheckBtn = new QAFExtendedWebElement(By.xpath("//button[text()='Serviceability Check']"));
            QAFExtendedWebElement nextButton = new QAFExtendedWebElement(By.xpath("//span[text()='Next']//parent::button"));
            QAFExtendedWebElement GoToDetailResBtn = new QAFExtendedWebElement(By.xpath("//button[text()='Go to Detailed Response']|//button[text()='Go to Results']"));
            QAFExtendedWebElement ServiceabilityTitle = new QAFExtendedWebElement(By.xpath("//span[@title='Servicability Results Name']"));
            util.implicitlyWait(30);
            util.waitFor(checkbox, 90, true);
            checkbox.click();
            Validator.verifyTrue(ServiceabilityCheckBtn.isPresent(), "Serviceability Check is not displayed", "Serviceability Check is displayed");
            ServiceabilityCheckBtn.click();
            nextButton.click();
            util.waitFor(GoToDetailResBtn, 90, true);
            Validator.verifyTrue(GoToDetailResBtn.isPresent(), "Go to Detailed Response is not displayed", "Go to Detailed Response is displayed");
            GoToDetailResBtn.click();
            util.waitFor(ServiceabilityTitle, 90, true);
            Reporter.logWithScreenShot("Performed Serviceability Check");
        }).then("I verify Access Identifier", () -> {
            NavigateQuoteURL();
            verifyQuotePage();
            /*ClickOnQuoteRelated();
            openQuoteMembers(util, driver);
            NavigateQuoteURL();
            verifyQuotePage();*/
        }).execute();
    }

    public void openQuoteMembers(WebUtilities util, WebDriverTestBase driver) {
        QAFExtendedWebElement quoteMembersLink = new QAFExtendedWebElement(By.xpath("//span[text()='View All']//ancestor::a[contains(@href,'QuoteMembers__r')]"));
        QAFExtendedWebElement accessIdValue = new QAFExtendedWebElement(By.xpath("(//span[text()='Access Identifier']//following::lightning-formatted-text)[1]"));
        QAFExtendedWebElement editAccess = new QAFExtendedWebElement(By.xpath("//button[@title='Edit Access Identifier']"));
        QAFExtendedWebElement AccessInput = new QAFExtendedWebElement(By.xpath("//input[@name='Access_Identifier__c']"));
        QAFExtendedWebElement saveButton = new QAFExtendedWebElement(By.xpath("//button[@name='SaveEdit']"));
        List<WebElement> headings = driver.getDriver().findElements(By.xpath("//div[@class='container forceRelatedListSingleContainer']"));
        for (int i = 0; i <= 3; i++) {
            util.scrollIntoElement(headings.get(i));
        }
        util.waitFor(15);
        quoteMembersLink.click();
        util.waitFor(20);
        String currentPageURL = driver.getDriver().getCurrentUrl();
        List<WebElement> nameLinks = driver.getDriver().findElements(By.xpath("(//table[@aria-label='Quote Members'])[last()]//tbody//th//a"));
        for (int j = 0; j < nameLinks.size(); j++) {
            util.clickUsingJs(nameLinks.get(j));
            util.waitFor(10);
            if (accessIdValue.getText().equalsIgnoreCase("TNT") && Objects.nonNull(accessIdValue.getText())) {
                Validator.verifyThat("Verify Access Identifier", accessIdValue.getText(), Matchers.equalTo("TNT"));
            } else {
                editAccess.click();
                util.waitFor(5);
                AccessInput.sendKeys("TNT");
                AccessInput.sendKeys(Keys.TAB);
                util.clickUsingJs(saveButton);
                util.waitFor(10);
            }
            driver.getDriver().navigate().to(currentPageURL);
            util.refreshPage();
            util.waitFor(20);
            nameLinks = driver.getDriver().findElements(By.xpath("(//table[@aria-label='Quote Members'])[last()]//tbody//th//a"));
        }
    }

 /*   public void CreatingLead(Map<String, String> data) {
        AppCommons app = new AppCommons();
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        scenario().given("", () -> {
            ConfigurationManager.getBundle().setProperty("testdata", data);
            util.waitFor(20);
        }).when("", () -> {
            App().Pages().getHomepage().goToAPP("Leads");
            App().Pages().getLeadpage().getLeadNewButton().verifyVisible();
            App().Pages().getLeadpage().getLeadNewButton().click();
            App().Pages().getLeadpage().selectRecordType("business");
            App().Pages().getLeadpage().getLeadNextButton().click();
            App().Pages().getLeadpage().fillTheLeadForm(data);
            util.waitFor(25);
            Reporter.logWithScreenShot("Lead info is entered", MessageTypes.Info);
            App().Pages().getLeadpage().markLeadStatusAsQualified();
            ConfigurationManager.getBundle().setProperty(driver.getDriver().getCurrentUrl(),"LeadURL");
            Reporter.log(driver.getDriver().getCurrentUrl());
            app.mouseMover();
        }).then("", () -> {
            App().Pages().getLoginpage().logoutCurrentUser();
            util.waitFor(20);
            App().Pages().getHomepage().switchToAnyUser(ConfigurationManager.getBundle().getPropertyValue("Credit_Analyst"));
            driver.getDriver().get(ConfigurationManager.getBundle().getPropertyValue("LeadURL"));
            util.waitForLeadPage();
            util.waitFor(20);
            App().Pages().getLeadpage().validateCreditCheck();
            App().Pages().getLeadpage().convertLead(data);
            App().Pages().getLoginpage().logoutCurrentUser();
            util.waitFor(20);
            String title = driver.getDriver().getTitle();
            Validator.verifyThat("verify user able to logout as Credit Analyst", title,
                    Matchers.equalTo("Home | Salesforce"));
            app.mouseMover();
            App().Pages().getHomepage().switchToAnyUser(ConfigurationManager.getBundle().getPropertyValue("RelationShip_Manager"));
        }).execute();
    }*/


    public void contactCreation(Map<String, String> data) {
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        TestDataBean bean = new TestDataBean();
        scenario().given("I am on account page", () -> {
            ConfigurationManager.getBundle().setProperty("testdata", data);
            util.waitFor(20);
        }).when("I click on contacts and create new contact", () -> {
            App().Pages().getAccountpage().ClickContacts();
            App().Pages().getContactpage().clickNewAccContact();
            fillContactInfo(bean, util, data.get("Contact Roles"));
            fillContactNumbers(bean, util);
            fillPersonalInfo(bean, util);
            fillEmployeeDetails(util);
            fillAdditionalInfo(bean, util);
            App().Pages().getContactpage().clickSaveButton();
        }).then("I verify contact", () -> {
            QAFExtendedWebElement contact = new QAFExtendedWebElement(By.xpath("//span[text()='" + data.get("Contact Roles") + "']//ancestor::tr//th//a"));
            String name = ConfigurationManager.getBundle().getPropertyValue("contact.Technical");
            Validator.verifyThat("verify contact", contact.getText(), Matchers.equalTo(name));
            mouseMover();
            navigateAcURL(driver);
        }).execute();
    }

    public void fillContactInfo(TestDataBean bean, WebUtilities util, String ContactRole) {
        bean.fillRandomData();
        String Contact_FirstName = bean.getFirstName();
        String Contact_MiddleName = bean.getMiddleName();
        String Contact_LastName = bean.getLastName();
        String Contact_Suffix = bean.getSuffix();
        String contactName = Contact_FirstName + " " + Contact_MiddleName + " " + Contact_LastName + " " + Contact_Suffix;
        util.select("Salutation", bean.RandomSalutation());
        util.type("First Name", Contact_FirstName);
        util.type("Middle Name", Contact_MiddleName);
        util.type("Last Name", Contact_LastName);
        util.type("Suffix", Contact_Suffix);
        util.select("Contact Roles");
        util.type("Title");
        util.select("Status");
        ConfigurationManager.getBundle().setProperty("contact." + ContactRole, contactName);
        ConfigurationManager.getBundle().setProperty("Contact.Name", Contact_FirstName);
    }

    public void fillContactNumbers(TestDataBean bean, WebUtilities util) {
        bean.fillRandomData();
        String contact_personalPhoneNum = String.format("639%s", bean.getPhone_mobile().toString());
        contact_personalPhoneNum = StringUtils.rightPad(contact_personalPhoneNum, 12, "0");
        util.type("Mobile", contact_personalPhoneNum);
        util.type("Other Phone", contact_personalPhoneNum);
        util.type("Home Phone", contact_personalPhoneNum);
        util.type("Fax", contact_personalPhoneNum);
    }

    public void fillPersonalInfo(TestDataBean bean, WebUtilities util) {
        bean.fillRandomData();
        String licence = Long.toString(bean.getNumber());
        String contactEmail = ConfigurationManager.getBundle().getPropertyValue("Contact.Name") + "@gmail.com";
        String taxid = Long.toString(bean.getPhone_mobile());
        taxid = StringUtils.rightPad(taxid, 9, "0");
        QAFExtendedWebElement contactBirthdate = new QAFExtendedWebElement(By.xpath("//input[@name='Birthdate']"));
        QAFExtendedWebElement Drivers = new QAFExtendedWebElement("xpath=//input[@name='vlocity_cmt__DriversLicenseNumber__c']");
        util.enterText(contactBirthdate, getDate(20, "Minus", "MM/DD/YYYY"));
        util.select("Sex");
        util.type("Civil Status");
        Drivers.sendKeys(licence);
        util.type("Email", contactEmail);
        util.type("Tax ID", taxid);
    }

    public void fillEmployeeDetails(WebUtilities util) {
        util.click("Employee");
        util.select("Employment Status");
        util.type("Department");
    }

    public void fillAdditionalInfo(TestDataBean bean, WebUtilities util) {
        bean.fillRandomData();
        String Contact_CompanyWebsite = "wwww." + ConfigurationManager.getBundle().getPropertyValue("Contact.Name") + "@gmail.com";
        String assit_personalPhoneNum = String.format("639%s", bean.getPhone_mobile().toString());
        assit_personalPhoneNum = StringUtils.rightPad(assit_personalPhoneNum, 12, "0");
        util.type("Web Site", Contact_CompanyWebsite);
        util.type("Assistant", bean.getOther());
        util.type("Asst. Phone", assit_personalPhoneNum);
        util.select("Lead Source");
        util.select("Customer Sentiment");
    }

    public void updateTechnical(String TechnicalContact, WebUtilities util, WebDriverTestBase driver) {
        if (TechnicalContact.equalsIgnoreCase("Random")) {
            //TechnicalContact = ConfigurationManager.getBundle().getPropertyValue("Lead.fullName");
        }
        QAFExtendedWebElement TechContactInput = new QAFExtendedWebElement(By.xpath("//span[text()='Technical Contact']/parent::label/following-sibling::div//input"));
        util.enterTextUsingJs(TechContactInput, TechnicalContact);
        int check = TechnicalContact.length();
        while (check > 0) {
            TechContactInput.sendKeys(Keys.BACK_SPACE);
            try {
                QAFExtendedWebElement contact = new QAFExtendedWebElement(By.xpath("//span[.='Technical Contact']/parent::label/following-sibling::div//div[@class='listContent']/ul/li//*[@title='"
                        + TechnicalContact + "']"));
                util.waitFor(contact, 10, true);
                contact.click();
                util.waitFor(10);
                break;
            } catch (Exception e) {
                e.printStackTrace();
            }
            check--;
        }
    }

    public void expandingProduct(String Plan) {
        QAFExtendedWebElement planArrow = new QAFExtendedWebElement(By.xpath("(//span[text()='" + Plan
                + "']/parent::button[contains(@class,'slds-button cpq-item-has-children')])"));
        planArrow.click();
        Reporter.log("Clicked arrow button to display hidden child product");
    }

    public void ContactUpdate(Map<String, String> data) {
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        scenario().given("I am on Quote page after adding updating contact", () -> {
            util.waitFor(10);
            QAFExtendedWebElement contactSection = new QAFExtendedWebElement(By.xpath("//button[.='PLDT Contact Details']"));
            QAFExtendedWebElement editModeContact = new QAFExtendedWebElement(By.xpath("(//span[text()='PLDT Contact Details']//following::button[contains(@title,'Edit')])[1]"));
            contactSection.executeScript("scrollIntoView(true);");
            editModeContact.executeScript("click();");
            util.waitFor(5);
            Reporter.logWithScreenShot("In edit mode");
        }).when("I am updating Technical contact", () -> {
            updateTechnical(data.get("Technical Contact"), util, driver);
        }).then("I save the changes", () -> {
            try {
                quoteSaveButton();
                util.waitFor(25);
                Reporter.logWithScreenShot("saved the changes");
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            mouseMover();
        }).execute();
    }

    public void quoteSaveButton() throws InterruptedException {
        QAFExtendedWebElement save = new QAFExtendedWebElement(By.xpath("//button[@title='Save']"));
        save.click();
    }

    public String getETSStatus() {
        QAFExtendedWebElement etsStatus = new QAFExtendedWebElement(By.xpath("(//span[text()='ETS Status']//following::div/span)[1]"));
        return etsStatus.getText();
    }

    public void triggerSD() {
        WebUtilities util = new WebUtilities();
        scenario().given("I am on Quote page", () -> {
            util.waitFor(10);
            String status = getETSStatus();
            Validator.verifyFalse(Objects.isNull(status), "ETS Status is blank in the Quote Page", "ETS Status is blank in the Quote Page");
        }).when("I click on Trigger SD", () -> {
            util.clickOnActionToolBarButton("QuoteActionToolbar", "Trigger SD");
            util.waitFor(30);
        }).then("I verify ETS Status", () -> {
            String status = getETSStatus();
            Validator.verifyThat("Verify ETS Status", status, Matchers.equalTo("Pending Endorsement"));
            mouseMover();
        }).execute();
    }

    public void SolutionDesign() {
        WebUtilities util = new WebUtilities();
        scenario().given("I am on Quote page", () -> {
            util.waitFor(10);
        }).when("I click on solution design", () -> {
            util.clickOnActionToolBarButton("QuoteActionToolbar", "Solution Design");
        }).then("I verify ETS Screen", () -> {
            util.waitFor(15);
            util.refreshSwitchToFrame();
            util.AttachFrame();
            util.waitFor(15);
            QAFExtendedWebElement etsScreen = new QAFExtendedWebElement(By.xpath("//section[@id='ETSScreen']//following-sibling::h1"));
            Validator.verifyTrue(etsScreen.isPresent(), "ETS screen not display", "ETS screen is display");
            mouseMover();
        }).execute();
    }

    public void mouseMover() {
        Robot robot = null;
        try {
            robot = new Robot();
            Random random = new Random();
            int x = random.nextInt() % 640;
            int y = random.nextInt() % 480;
            robot.mouseMove(x, y);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void populateETS(String ETSStatus, String EtsRemarkValue) {
        WebUtilities util = new WebUtilities();
        scenario().given("I am on ETS screen", () -> {
            util.waitFor(10);
        }).when("I am updating ETS Status and ETS Remarks", () -> {
            QAFExtendedWebElement etsStatusDropdown = new QAFExtendedWebElement(By.xpath("//select[@id='ETSStatus']"));
            QAFExtendedWebElement etsRemarkTextarea = new QAFExtendedWebElement(By.xpath("//select[@id='ETSStatus']"));
            QAFExtendedWebElement nextBtn = new QAFExtendedWebElement(By.xpath("//div[@id='ETSScreen_nextBtn']"));
            util.selectValuefromDropDown(etsStatusDropdown, value -> value.selectByVisibleText(ETSStatus));
            etsRemarkTextarea.sendKeys(EtsRemarkValue);
            Reporter.logWithScreenShot("ETS");
            util.scrollDown();
            nextBtn.click();
        }).then("", () -> {
            util.waitFor(15);
            verifyQuotePage();
        }).execute();
    }

    public void updateAccessIdentifier() {
        WebUtilities util = new WebUtilities();
        WebDriverTestBase driver = new WebDriverTestBase();
        scenario().given("I am Quote page clicking Related tab", () -> {
            util.waitFor(10);
            ClickOnQuoteRelated();
        }).when("I am on Quote page Related tab open Quote members and edit Access ID", () -> {
            util.waitFor(15);
            openQuoteMembers(util, driver);
        }).then("I navigate back to Quote", () -> {
            NavigateQuoteURL();
            util.waitFor(15);
            verifyQuotePage();
        }).execute();
    }


    public void ConfigTechnicalAttribute() {
        WebUtilities util = new WebUtilities();
        scenario().given("", () -> {
            util.waitFor(10);
            util.clickOnActionToolBarButton("QuoteActionToolbar", "Configure Technical Attribute");
        }).when("", () -> {


        }).then("", () -> {

        }).execute();
    }
}
