package com.pldt.tests.SMART.AfterSales.OrderManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;
import java.util.ArrayList;
import java.util.Map;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class CancelOrderByClickonCancel extends BaseTest {
	PageLib pages = new PageLib();
	AppCommons app = new AppCommons();
	WebUtilities util = new WebUtilities();
	ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Lead creation for NewConnect", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("I Log into PLDT Application as admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
		}).then("I verify I Logged in as Admin", () -> {
			Reporter.logWithScreenShot("Logged in as Admin", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Switch to RelationShip Manager", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void Switching_to_RelationShipManager(Map<String, String> data) {
		scenario().then("I Switch to RelationShip Manager", () -> {
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).then("I verify I Switched as RelationShip Manager", () -> {
			Reporter.logWithScreenShot("Switched as RelationShip Manager", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Open account", priority = 3, dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void OpenExistingAccount(Map<String, String> data) {
		scenario().given("I am in home page", () -> {
			util.refreshPage();
			util.waitFor(5);
		}).when("I open " + data.get("Account_Name") + " account", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			props.setProperty("Account", data.get("Account_Name"));
			ProjectBeans.setAccountURL(getDriver().getCurrentUrl()); // setting account url
			util.waitFor(10);
		}).then("I verify that account details page of " + data.get("Account_Name") + " is displayed", () -> {
			String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
					.getText();
			Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
		}).when("I click on contacts", () -> {
			getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
			util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
		}).and("I captured the contact name", () -> {
			String BillRecipient = getDriver().findElement(By.xpath("//span[.='Bill Recipient']/ancestor::tr//th//a//span"))
					.getText();
			props.setProperty("contact.BillRecipient", BillRecipient);
			Reporter.log("Technical Contact: " + BillRecipient);
			String DeliveryRecipient = getDriver()
					.findElement(By.xpath("//span[.='Delivery Recipient - Smart']/ancestor::tr//th//a//span")).getText();
			props.setProperty("contact.DeliveryRecipient", DeliveryRecipient);
			Reporter.log("Technical Contact: " + DeliveryRecipient);
			String Authorized_Signatory = getDriver()
					.findElement(By.xpath("//span[.='Authorized Signatory']/ancestor::tr//th//a//span")).getText();
			props.setProperty("Lead.fullName", Authorized_Signatory);
			Reporter.log("Authorized Signatory: " + Authorized_Signatory);
			Reporter.logWithScreenShot("Account Contact Details");
		}).and("I clicked on account and navigate back to account details page", () -> {
			QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
			AccountName.click();
		}).then("then i verified that account details page is dispayed", () -> {
			util.waitForAccountPage();
			Reporter.logWithScreenShot("Account Details Page");
		}).execute();
	}


	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "QuoteCreationTest", priority = 4, dependsOnMethods = { "OpenExistingAccount" })
	public void QuoteCreationTest(Map<String, String> data) {
		scenario().when("Navigating to Accounts to create Quote", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getQuotepage().createQuoteSMARTR4EndtoEnd(data);
		}).then("I verified that Quote is Created", () -> {
			Reporter.logWithScreenShot("Quote is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Adding Products To Cart", priority = 5, dependsOnMethods = { "QuoteCreationTest" })
	public void AddProductsToCart(Map<String, String> data) throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Add the products into the cart ", () -> {
			pages.getQuotepage().ClickAddProducts();
			pages.getCartpage().QuickActionsAddProductsToCart(data);
			if (data.get("SecondPlan").contains("Y")) {
				pages.getCartpage().QuickActionsAddProductsToCart(data, data.get("SecondPlanName"));
			}
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.clickUsingJs(By.xpath("//button[@title='Save Working Cart']"));
			util.waitFor(By.xpath("//h1//span[.='Working Cart']"), 20, true);
			if (util.isElementDisplayed(By.xpath("//h1//span[.='Working Cart']"))) {
				util.clickUsingJs(By.xpath("//span[.='Parent Quote']/following::div[1]/span//a"));
			} else {
				util.waitForQuotePage();
			}
		}).then("I verified that products are added in to cart", () -> {
			Reporter.logWithScreenShot("Products are Added and Redirected to quote page", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Performing Availability Checks", priority = 6, dependsOnMethods = { "AddProductsToCart" })
	public void availabilityChecks(Map<String, String> data) throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I performed various availability checks ", () -> {
			if (util.getEnvironment().equalsIgnoreCase("R32SIT")) {
				pages.getQuotepage().numberAvailabilityCheck();
			}
			pages.getQuotepage().deviceAvailabilityCheck();
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("I verified that checks are completed", () -> {
			Reporter.logWithScreenShot("Availability Checks", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Updating QuoteValidatyPeriod,DeliveryDate and ContactDetails", priority = 7, dependsOnMethods = {
			"availabilityChecks" })
	public void updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I update contact and Validity period Information ", () -> {
			pages.getQuotepage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
			util.waitFor(10);
		}).then("I verified that Details are populated", () -> {
			Reporter.logWithScreenShot("Details are populated", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "BillingAccounts", key = "${key.name}")
	@Test(description = "Creating BillingAccount", priority = 8, dependsOnMethods = {
			"updateQuoteValidatyPeriod_DeliveryDate_ContactDetails" })
	public void createBillingAccount(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Billing Account ", () -> {
			util.refreshPage();
			util.waitFor(5);
			pages.getBillingAndServiceAccount().createBillingAccount();
		}).then("I verified that Billing Account is Created", () -> {
			Reporter.logWithScreenShot("Billing Account is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "ServiceAccounts", key = "${key.name}")
	@Test(description = "Creating Service Account", priority = 9, dependsOnMethods = { "createBillingAccount" })
	public void createServiceAccount(Map<String, String> data) throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Service Account ", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			util.refreshPage();
			util.waitFor(5);
			pages.getBillingAndServiceAccount().createServiceAccount();
		}).then("I verified that Service Account is Created", () -> {
			Reporter.logWithScreenShot("Service Account is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Updating Billing and Service Accounts", priority = 10, dependsOnMethods = {
			"createServiceAccount" })
	public void updateAccounts(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I Update Billing and Service Account", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			pages.getQuotepage().ModifyProducts(data.get("Plan"));
			pages.getCartpage().clickPlanDownArrow(data);
			pages.getCartpage().UpdateAccounts(data);
			pages.getAddressassignmentpage().AssignBillingAccount(props.getPropertyValue("BillingAccountName"));
			pages.getAddressassignmentpage().AssignServiceAccount(props.getPropertyValue("ServiceAccountName"));
			pages.getCartpage().SaveWorkingCart();
			pages.getCartpage().WorkingCartConfigure();
			util.waitForQuotePage();
			if (data.get("SecondPlan").contains("Y")) {
				pages.getQuotepage().ModifyProducts(data.get("SecondPlanName"));
				pages.getCartpage().clickSecondPlanDownArrow(data);
				pages.getCartpage().SecondUpdateAccounts(data);
				pages.getAddressassignmentpage().AssignBillingAccount(props.getPropertyValue("BillingAccountName"));
				pages.getAddressassignmentpage().AssignServiceAccount(props.getPropertyValue("ServiceAccountName"));
				pages.getCartpage().SaveWorkingCart();
				pages.getCartpage().WorkingCartConfigure();
				util.waitForQuotePage();
			}
		}).then("I verified that Billing Account and Service Account is Updated", () -> {
		}).execute();
	}

	@Test(description = "Validating cart", priority = 11, dependsOnMethods = { "updateAccounts" })
	public void validateCart() {
		scenario().given("I am on Quote Page", () -> {
		}).when("I Validate the Cart", () -> {
			pages.getQuotepage().ValidateCart();
		}).then("I verified that Cart is Validated", () -> {
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Performing Credit Check", priority = 12, dependsOnMethods = { "validateCart" })
	public void creditCheck(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I perform Credit Check", () -> {
			pages.getQuotepage().CreditCheck();
			util.waitForQuotePage();
			pages.getLoginpage().logoutCurrentUser();
			// pages.getHomepage().SwitchToUser(data.get("Credit_Analyst"),"CA");
			pages.getHomepage().switchToAnyUser(data.get("Credit_Analyst"));
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			pages.getQuotepage().UpdateCreditInformationAdvance(data);
			util.waitFor(10);
			pages.getLoginpage().logoutCurrentUser();
			// pages.getHomepage().SwitchToUser(data.get("Relationship Manager"),"RM");
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
		}).then("I verified that Credit information is Updated ", () -> {
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Quote status change and Quote to PDF", priority = 13, dependsOnMethods = { "creditCheck" })
	public void quotetoPDF(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
			props.setProperty("testdata", data);
			pages.getQuotepage().changeStatusToInternalApproval();
		}).when("I Converting Quote to PDF", () -> {
			pages.getQuotepage().QuotetoPDF();
			app.pickLatestFileFromDownloads("Quote Document");
//				util.ChangeStatus("Presented");
			Reporter.logWithScreenShot("Quote Status Changed to Presented", MessageTypes.Info);
			pages.getQuotepage().changeStatusToApproved1();
			Reporter.logWithScreenShot("Quote Status Changed to Approved", MessageTypes.Info);
		}).then("I verified that Quote to PDF is Converted and Status Changed to Approved", () -> {
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Number Reservations", priority = 14, dependsOnMethods = { "quotetoPDF" })
	public void numberReservation(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Number Reservation", () -> {
			pages.getQuotepage().numberReservationCheck(data);
			if (data.get("SecondPlan").contains("Y")) {
				pages.getQuotepage().numberReservationCheck(data);
			}
		}).then("I verified that Number Reservation is completed", () -> {
			Reporter.logWithScreenShot("Number Reservation is Completed", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Device Reservations", priority = 15, dependsOnMethods = { "numberReservation" })
	public void deviceReservations(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Device Reservation", () -> {
			pages.getQuotepage().DeviceReservation(data);
		}).then("I verified that Device reservation is completed", () -> {
			Reporter.logWithScreenShot("Device reservation", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Syncronizing QLI Items", priority = 16, dependsOnMethods = { "deviceReservations" })
	public void syncronizeQLIItems(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I perform the Synchronization", () -> {
			App().Pages().getQuotepage().SynchronizingAccount(data.get("Plan"), data.get("Relationship Manager"));
			if (data.get("SecondPlan").contains("Y")) {
				App().Pages().getQuotepage().SynchronizingAccount(data.get("SecondPlanName"),
						data.get("Relationship Manager"));
			}
			pages.getQuotepage().ChangeStatusToAccepted(data);
		}).then("I verified that Status changed to Accepted", () -> {
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Creating Contract", priority = 17, dependsOnMethods = { "syncronizeQLIItems" })
	public void CreateContract(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Create Contract", () -> {
			pages.getQuotepage().CreateContract();
		}).then("I verified that Contract is Created", () -> {
			Reporter.logWithScreenShot("Contract is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Contract", key = "${key.name}")
	@Test(description = "Upload file", priority = 18, dependsOnMethods = { "CreateContract" })
	public void generateDocuments(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Contract Page", () -> {
		}).when("I click on generate Documents ", () -> {
			util.refreshPage();
			util.waitForContractPage();
			App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
			app.pickLatestFileFromDownloads("Contract Document");
			util.waitForContractPage();
		}).then("i verified that File is Uploaded", () -> {
			Reporter.logWithScreenShot(" Generate Documents ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Creating Contract", priority = 19, dependsOnMethods = { "generateDocuments" })
	public void ChangingContractStatus(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Create Contract", () -> {
			pages.getQuotepage().ChangeTheStatusToSigned();
			ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
		}).then("I verified that Contract Status is Changed", () -> {
			Reporter.logWithScreenShot("Contract Status is Changed to Signed", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Checking Orders", priority = 20, dependsOnMethods = { "ChangingContractStatus" })//
	public void orders(Map<String, String> data) {
		scenario().given("I am on Contract Page", () -> {
		}).when("I move to orders page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList = pages.getQuotepage().VerifyingOrders(60, 2);;
			ProjectBeans.setOrderURL(getDriver().getCurrentUrl());
		}).then("I verified the status of Orders", () -> {
			Reporter.logWithScreenShot(" Orders", MessageTypes.Info);
		}).execute();

	}
	
	@Test(description = "Cancel Order", priority = 21, dependsOnMethods = { "orders" })//
	public void cancelOrder() {
		scenario().given("I am on Contract Page", () -> {			
		}).when("I open master order", () -> {
			pages.getOrdersPage().cancelOrder();
		}).then("I verified the order get cancel", () -> {
			Reporter.logWithScreenShot("Cancel Order", MessageTypes.Info);
		}).execute();

	}

	@Test(priority = 22, dependsOnMethods = { "cancelOrder" })
	public void getReferenceData() {
		Reporter.log("Lead URL :" + ProjectBeans.getLeadURL(), MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :" + ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :" + ProjectBeans.getContractURL(), MessageTypes.Info);
		Reporter.log("OrderPage URL :" + ProjectBeans.getOrderURL(), MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order _" + (i + 1) + " URL : " + orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
