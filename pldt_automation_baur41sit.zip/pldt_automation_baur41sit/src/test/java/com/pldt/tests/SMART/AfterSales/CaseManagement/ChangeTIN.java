package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.Map;

import org.testng.annotations.Test;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;

public class ChangeTIN extends CaseManage{
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login as Admin into Salesforce application and Switched to RM", priority = 1)
	@Override
	public void LoginAsAdmin(Map<String, String> data) {
		super.LoginAsAdmin(data);
		super.SwitchToCA(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Open Business Account", priority = 2, dependsOnMethods = {"LoginAsAdmin"})
	@Override
	public void OpenExistingAccount(Map<String, String> data) {
		super.OpenExistingAccount(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Create New Case", priority = 3, dependsOnMethods = {"OpenExistingAccount"})
	@Override
	public void CaseCreationOnAccount(Map<String, String> data) {
		super.CaseCreationOnAccount(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "modify New Case", priority = 4, dependsOnMethods = {"CaseCreationOnAccount"})
	@Override
	public void CaseModificationTIN(Map<String, String> data) {
		super.CaseModificationTIN(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "verify transaction creation", priority = 5, dependsOnMethods = {"CaseModificationTIN"})
	@Override
	public void VerifyTransaction(Map<String, String> data) throws InterruptedException {
		super.VerifyTransaction(data);
		super.LogoutUser(data);
		super.navigateCaseURL();
		super.ModifyTransaction();
		
	}

//	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
//	@Test(description = "verify transaction creation", priority = 6, dependsOnMethods = {"VerifyTransaction"})
//	public void ChangeStatusClosed(Map<String, String> data) throws InterruptedException {
//		super.SwitchToOtherUser(data.get("Credit_Analyst"));
//		super.navigateCaseURL();
//		super.ChangeStatusClosed();
//	}
}
