package com.pldt.tests.SMART.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class Add_Edit_Delete_AlertCode extends BaseTest{
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String caseID = null;
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to RelationshipManager", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRM(Map <String,String> data) {
		scenario().given("user logged in as Asmin", () -> {
		}).when("User Login As Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to RelationShipManager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Successfully switched to Relationship Manager");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRM" })
	public void CreateNewCase(Map<String, String> data)  {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().createNewCaseFromAsset(data);
			App().Pages().getCasepage().getCaseNumberFromToastMessage();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());// set case url in ProjectBeans
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 4,dependsOnMethods = {"CreateNewCase"})
	private void changeCaseOwnerTest(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the change owner action", () -> {
			pages.getCaseDetailsPage().changeOwner(data.get("ownerName"));
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();
		}).then("I see the owner is changed", () -> {
			Reporter.logWithScreenShot("owner is changed", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 5,dependsOnMethods = {"changeCaseOwnerTest"})
	public void modifyTransactionDetails(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to case page and check transaction details section", () -> {
			pages.getCaseDetailsPage().modifyAlertDetais(data);
		}).then("I verify transaction details section", () -> {
			Reporter.logWithScreenShot("Transaction Details Section are Modified", MessageTypes.Info);
		}).execute();
	}
	
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 6,dependsOnMethods = {"modifyTransactionDetails"})
	private void CreateNewAlertCode(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I open Alert Codes", () -> {
			pages.getLoginpage().logoutCurrentUser();
			util.waitForPageToLoad();
			pages.getHomepage().goToAPP("Alert Codes");
			pages.getAccountListPage().clickNewButton();
			pages.getCaseDetailsPage().createNewAlert(data);
			util.waitFor(5);
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();
		}).then("I verify the Alert Code is Created", () -> {
			Reporter.logWithScreenShot("Alert Code is Created", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 7,dependsOnMethods = {"CreateNewAlertCode"})
	private void AddAlertCode(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I open Alert Code Tagging Request", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Alert_Code_Tagging_Request__r");
			pages.getAccountListPage().clickNewButton();
			util.waitFor(By.xpath("(//h2[text()='New Alert Code Tagging Request'])"), 20, true);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Alertrecordtype"));
			util.waitFor(5);
			util.selectAndClickCaseSuggestedValueShowAll(By.xpath("(//label[text()='Alert Code']/following::input[1])"),props.getPropertyValue("AlertCodeName"));
			util.clickUsingJs(By.xpath("//button[text()='Save']"));
			util.waitFor(5);
			getDriver().get(caseURL);
		}).then("I verify the Alert Code is Added", () -> {
			Reporter.logWithScreenShot("Alert Code is Added", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 8,dependsOnMethods = {"AddAlertCode"})
	public void markCaseStatusToResolutionInprogress(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {	
			getDriver().navigate().to(caseURL);
			util.waitForCasePage();
			pages.getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolution in Progress", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 9,dependsOnMethods = {"markCaseStatusToResolutionInprogress"})
	private void markCaseStatusToResolved() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolved", () -> {
			util.ChangeStatus("Resolved");
		}).then("I see case status got changed to Resolved", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolved", MessageTypes.Info);
		}).execute();
	}

	@Test(priority = 10,dependsOnMethods = {"markCaseStatusToResolved"})
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
	}
}
