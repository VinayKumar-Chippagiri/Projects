package com.pldt.tests;

import java.util.Map;

import org.testng.annotations.Test;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;


public class OpportunityTest extends BaseTest{
	@QAFDataProvider(dataFile = "resources/testdata/PLDT_RegressionSuite.xlsx", sheetName="CartDetails")
	@Test(description="Opportunity",priority = 1)
	public void addProductsToCart(Map<String,String>data) throws InterruptedException {
		getDriver().get("https://test.salesforce.com/");
		ConfigurationManager.getBundle().setProperty("testdata", data);
		App().Pages().getLoginpage().LoginAsAdmin();
		App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"), "RM");

//		App().Pages().getHomepage().goToAPP("Accounts");
//		App().Pages().getAccountpage().SelectAccount(data.get("Account Name").toString());
//		App().Pages().getAccountpage().ClickOpportunities();
//		App().Pages().getOpportunitypage().createOpportunity();
//		App().Pages().getOpportunitypage().SearchOpportunity(data.get("Opportunity Name").toString());
		getDriver().get("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/Opportunity/0061s000006ySKzAAM/view");
		App().Pages().getOpportunitypage().ClickConfigure();
		App().Pages().getCartpage().ConfigureCart(data);
		App().Pages().getOpportunitypage().changestatustoEstablishNeed();

 		//App().Pages().getOpportunitypage().CreateQuote();

}


}
