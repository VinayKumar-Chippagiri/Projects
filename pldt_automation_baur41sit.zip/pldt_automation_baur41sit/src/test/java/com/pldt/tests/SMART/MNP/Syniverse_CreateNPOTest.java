package com.pldt.tests.SMART.MNP;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.Map;

import org.testng.annotations.Test;

import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class Syniverse_CreateNPOTest extends BaseTest {
// Prerequisite need to generate order
// step 1: open master order
// step 2: go to orchestration plan
// step 3: check the status of the order (NPO block should be blue) 10 to 15 min
// time required to turn blue
// Strp 4: login to syniverse and create NPO
	@QAFDataProvider(dataFile = "resources/testdata/Syniverse.xlsx", sheetName = "Login", filter = "TestCase=='SyniverseSingle'")
	@Test(description = "Login", priority = 1)
	public void syniverselogin(Map<String, String> data) {
		scenario().given("User Log into Syniverse Application", () -> {
			App().Pages().getSyniverseLogin().launchPage(null, null);
			props.setProperty("testdata", data);
			App().Pages().getSyniverseLogin().LoginAsAdmin(data);
			Reporter.logWithScreenShot("Syniverse portal page");
		}).and("Click On Dashboard link", () -> {
			App().Pages().getSyniverseLogin().ClickOnDashboardLink();
			App().Pages().getSyniverseHomePage().launchPage(null, null);
			Reporter.logWithScreenShot("Syniverse home page");
		}).then("Switch Network to 102 vSmart", () -> {
			App().Pages().getSyniverseLogin().SwitchNetwork();
			Reporter.logWithScreenShot("Syniverse Switch Network");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/Syniverse.xlsx", sheetName = "CreateNPO", filter = "TestCase=='SyniverseSingle'")
	@Test(description = "Creating NPO", priority = 2, dependsOnMethods = { "syniverselogin" })
	public void CreateNPO(Map<String, String> data) {
		scenario().given("Click on NPO to open NPO form", () -> {
			App().Pages().getSyniverseHomePage().ClickOnNPO();
			Reporter.logWithScreenShot("NPO form");
		}).and("Enter Values in NPO form", () -> {
			props.setProperty("testdata", data);
			App().Pages().getSyniverseNPOPage().CreateNPO(data);
			Reporter.logWithScreenShot("NPO form with values");
			App().Pages().getSyniverseNPOPage().ClickOnNPOSave();
			App().Pages().getSyniverseNPOPage().ClickOnNPOConfirmationPageConfirmButton();
		}).then("", () -> {
		}).execute();
	}
}