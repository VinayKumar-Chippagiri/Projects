package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

//Pre-Requisite:
//Billing Account having Asset which already have redirection due ageing

public class CaseManagement_P001653_24868 extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL=null;
	String orderURL=null;
	String BillingAccountURL=null;
	ArrayList<String> orderList =null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to CRA", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoCRA(Map <String,String> data) {
		scenario().given("user Switch to CRA", () -> {
		}).when("User Login As CRA", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("CRA"));
			Reporter.log("Switched to CRA:" + data.get("CRA"));
		}).then("verify Admin successfully switched to CRA", () -> {
			Reporter.logWithScreenShot("Successfully switched to CRA");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoCRA" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("user Fill case details form and save", () -> {	
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getCasepage().createNewCaseAfterSalesCaseManagement(data);
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Fill Transaction Details in casepage", priority = 5, dependsOnMethods = { "CreateNewCase" })
	public void UpdateTransactionDetails(Map<String, String> data) {
		scenario().given("Updating TransactionDetails from case page", () -> {
		}).when("User upadtae fields in transaction Details", () -> {
			App().Pages().getCasepage().caseModificationfortreatment(data.get("Asset_Name"),data.get("Asset ID"),data);
	}).then("User Verify Changes made in Case page", () -> {
		Reporter.logWithScreenShot("UpdateTransactionDetails", MessageTypes.Info);
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "SubmitForApproval", priority = 6, dependsOnMethods = { "UpdateTransactionDetails" })
	public void SubmitForApproval(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Submit Case for Approval", () -> {	
			App().Pages().getCasepage().SubmitForApproval();			
		}).then("User verify the case is submitted for Approval ", () -> {
			Reporter.logWithScreenShot("submitted for Approval");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Approve the Case", priority = 7, dependsOnMethods = { "SubmitForApproval" })
	public void ApproveTheCase(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User open Approval History", () -> {			
			App().Pages().getCasepage().CheckingApprovalUser(caseURL,data);	
		}).and("User Logout", () -> {		
			App().Pages().getLoginpage().logoutCurrentUser();	
		}).and("Login with the Approver", () -> {	
			String Approver = App().Pages().getCasepage().getAPPROVER();
			App().Pages().getHomepage().SwitchToUser(Approver,"ECRM Head");
		}).and("User approve the Case", () -> {	
			App().Pages().getCasepage().ApproveCaseFromNotifications();
		}).then("User verify the case is Approved ", () -> {
			Reporter.logWithScreenShot("Case Approved");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Validate Case Owner and login with the user", priority = 8, dependsOnMethods = { "SubmitForApproval" })
	public void ValidateCaseOwnerAndLogin(Map<String, String> data) {
		scenario().given("User is on Case Approval page", () -> {
		}).when("User open Case Page", () -> {	
			util.goToURL(caseURL);
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Change Owner"));
		}).and("User Logout", () -> {	
			App().Pages().getLoginpage().logoutCurrentUser();	
		}).and("User Login with Payments-Analyst", () -> {	
			App().Pages().getHomepage().switchToAnyUser(data.get("Payments Analyst"));		
		}).execute();
		}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Accept Case", priority = 9, dependsOnMethods = { "ValidateCaseOwnerAndLogin" })
	public void AcceptCase(Map<String, String> data) {
		scenario().given("User is on Home Page", () -> {
		}).when("User navigated to cases tab", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
		}).and("Search cases assign to Case Owner", () -> {	
			App().Pages().getCasepage().SelectCaseGroup(data.get("Change Owner"));
		}).and("User Accept the Case", () -> {	
			App().Pages().getCasepage().acceptCase();
			App().Pages().getCasepage().SelectCaseGroup("My Cases");
			App().Pages().getCasepage().clickOnCaseByCaseNumber();			
		}).then("User verify that case got accepted and navigated to case", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Fill Billed Adjustment Debit in casepage", priority = 10, dependsOnMethods = { "AcceptCase" } )
	public void BilledAdjustmentCredit(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
		}).when("User update fields in Billed Adjustment Credit", () -> {
			util.waitFor(5);
			util.clickOnActionToolBarButton("Quick Actions", "Billed Adjustments");
			App().Pages().getCasepage().UnbilledAdjustment(data);
			Reporter.logWithScreenShot("update fields in Billed Adjustment Credit", MessageTypes.Info);
		}).and("User change case status to resolution in progress", () -> {	
			util.clickUsingJs(By
					.xpath("(//a[@data-tab-name='Assigned For Resolution'])[last()]"));
//			util.clickUsingJs(By.xpath("//span[text()='Mark as Current Status']"));
			util.waitFor(3);
//			util.waitForGenericToastMessage();					
//			util.refreshPage();
//			util.waitForCasePage();
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
	}).then("User Verify Status got Changed", () -> {
		Reporter.logWithScreenShot("Case status changes to resolution in progress", MessageTypes.Info);
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Change Status to Resolution In Progress", priority = 6, dependsOnMethods = { "UpdateTransactionDetails" })
	public void ChangeStatustoResolutionInProgress(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
			}).when("user Change status to Resolution in Progress", () -> {	
				util.clickUsingJs(By
						.xpath("(//a[@data-tab-name='Assigned For Resolution'])[last()]"));
				util.waitFor(3);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
			}).then("User Verify Status Got Changes", () -> {
			Reporter.logWithScreenShot("Changed status to Resolution In Progress", MessageTypes.Info);
		}).execute();
	}	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Checking Transcation Id", priority = 7, dependsOnMethods = { "ChangeStatustoResolutionInProgress" })
	public void CheckingTransctionId(Map<String, String> data) {
		scenario().given("Checking Transaction ID creation and status", () -> {
		}).when("User check TransactionID got Created", () -> {
			App().Pages().getCasepage().CheckingTransactionID(caseURL,data,data.get("Enterprise Hotline"));	
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).then("User verify TransactionID status is successful ", () -> {
			Reporter.logWithScreenShot("TransactionID status is successful", MessageTypes.Info);
			}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 8, dependsOnMethods = { "CheckingTransctionId" })
	public void CloseTheCase(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
			}).when("user Check status Changed to Resolved", () -> {	
				QAFWebElement Status = new QAFExtendedWebElement(
						"xpath=//p/span[contains(.,'Resolved')]");
				Validator.verifyTrue(Status.isPresent(), "Status not Changed to Resolved",
						"Status Changed to Resolved");
			}).and("user Change Status to Closed", () -> {	
				util.clickUsingJs(By
						.xpath("(//a[@data-tab-name='Closed'])[last()]"));
				util.clickUsingJs(By.xpath("//span[text()='Mark as Current Status']"));
				util.waitFor(3);
				util.waitForGenericToastMessage();					
				util.refreshPage();
			}).then("User Verify Status Got Changed", () -> {
			Reporter.logWithScreenShot("Status Got Changed to Closed", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Open Billing Account Page", priority = 9, dependsOnMethods = { "CloseTheCase" })
	public void OpenBillingAccountPage(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User open Billing Account Page", () -> {			
			util.refreshPage();
			util.waitForCasePage();
			util.clickUsingJs(By.xpath("//span[.='"+ data.get("BillingAccountName") +"']/ancestor::a"));
            util.waitFor(10);
            BillingAccountURL= getDriver().getCurrentUrl();
		}).then("User verify the Assignee name in billing account page ", () -> {
			String Assignee_First_Name = getDriver().findElement(By.xpath("//div[.='Assignee/ CI First Name']/following-sibling::div/span"))
					.getText();
			util.scrollIntoElement(By.xpath("//div[.='Assignee/ CI First Name']/following-sibling::div/span"));
					Validator.verifyThat("", Assignee_First_Name, Matchers.containsString(data.get("Assignee First Name")));
					util.waitFor(5);	
					String Assignee_Last_Name = getDriver().findElement(By.xpath("//div[.='Assignee/ CI Last Name']/following-sibling::div/span"))
							.getText();
							Validator.verifyThat("", Assignee_Last_Name, Matchers.containsString(data.get("Assignee Last Name")));		
			Reporter.logWithScreenShot("Assignee name in Billing Account Page");
		}).execute();
	}
	
	
	
	@Test(priority = 10,dependsOnMethods = { "OpenBillingAccountPage" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Billing Account URL :" + BillingAccountURL, MessageTypes.Info);

	}
}