package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;



public class IncreaseCreditLimit_Business_CRA extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL=null;
	String orderURL=null;
	ArrayList<String> orderList =null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to Collection & Reconciliation Analyst", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoCRA(Map <String,String> data) {
		scenario().given("user Switch to Collection & Reconciliation Analyst", () -> {
		}).when("User Login As Collection & Reconciliation Analyst", () -> {
			App().Pages().getHomepage().SwitchToUser(data.get("CRA"),"CRA");
			Reporter.log("Switched to Credit Analyst:" + data.get("CRA"));
		}).then("verify Admin successfully switched to Collection & Reconciliation Analyst", () -> {
			Reporter.logWithScreenShot("Successfully switched to Collection & Reconciliation Analyst");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoCRA" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("user Fill case details form and save", () -> {	
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getCasepage().createNewCaseAfterSalesCaseManagement(data);
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Fill Transaction Details in casepage", priority = 4, dependsOnMethods = { "CreateNewCase" })
	public void UpdateTransactionDetails(Map<String, String> data) {
		scenario().given("Updating TransactionDetails from case page", () -> {
		}).when("User upadtae fields in transaction Details", () -> {
			App().Pages().getCasepage().caseModificationfortreatment(data.get("Asset_Name"),data.get("Asset ID"),data);
	}).then("User Verify Changes made in Case page", () -> {
		Reporter.logWithScreenShot("UpdateTransactionDetails", MessageTypes.Info);
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Validate Case Owner", priority = 5, dependsOnMethods = { "UpdateTransactionDetails" })
	public void ValidateCaseOwner(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Validate case owner", () -> {	
			App().Pages().getCasepage().ValidateCaseOwner(data.get("CRA"));			
		}).then("User verify the case Owner ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "SubmitForApproval", priority = 6, dependsOnMethods = { "ValidateCaseOwner" })
	public void SubmitForApproval(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Submit Case for Approval", () -> {	
			App().Pages().getCasepage().SubmitForApproval();			
		}).then("User verify the case is submitted for Approval ", () -> {
			Reporter.logWithScreenShot("submitted for Approval");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Approve the Case", priority = 7, dependsOnMethods = { "SubmitForApproval" })
	public void ApproveTheCase(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Logout", () -> {				
			App().Pages().getLoginpage().logoutCurrentUser();	
		}).and("Login with the Approver", () -> {	
			util.waitFor(5);
			App().Pages().getHomepage().SwitchToUser(data.get("ECM Head"),"ECM Head");
		}).and("User approve the Case", () -> {	
			App().Pages().getCasepage().ApproveCaseFromItemstoApprove();
			App().Pages().getLoginpage().logoutCurrentUser();
		}).then("User verify the case is Approved ", () -> {
			Reporter.logWithScreenShot("Case Approved");
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Change Status to Resolution In Progress", priority = 8, dependsOnMethods = { "ApproveTheCase" })
	public void ChangeStatustoResolutionInProgress(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
			}).when("user Switch to Collection & Reconciliation Analyst", () -> {	
				App().Pages().getHomepage().SwitchToUser(data.get("CRA"),"CRA");	
			}).and("user navigate to case page", () -> {	
				util.goToURL(caseURL);
			}).and("user Change status to Resolution in Progress", () -> {	
				util.clickUsingJs(By
						.xpath("(//a[@data-tab-name='Assigned For Resolution'])[last()]"));
				util.waitFor(3);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
			}).then("User Verify Status Got Changes", () -> {
			Reporter.logWithScreenShot("Changed status to Resolution In Progress", MessageTypes.Info);
		}).execute();
	}	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Checking Transcation Id", priority = 9, dependsOnMethods = { "ChangeStatustoResolutionInProgress" })
	public void CheckingTransctionId(Map<String, String> data) {
		scenario().given("Checking Transaction ID creation and status", () -> {
		}).when("User check TransactionID got Created", () -> {
			App().Pages().getCasepage().CheckingTransactionID(caseURL,data,data.get("CRA"));
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).then("User verify TransactionID status is successful ", () -> {
			Reporter.logWithScreenShot("TransactionID status is successful", MessageTypes.Info);
			}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 10, dependsOnMethods = { "CheckingTransctionId" })
	public void CloseTheCase(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
		}).when("user Check status Changed to Closed", () -> {	
			QAFWebElement Status = new QAFExtendedWebElement(
					"xpath=//p/span[contains(.,'Closed')]");
			Validator.verifyTrue(Status.isPresent(), "Status not Changed to Closed",
					"Status Changed to Closed");				
			util.refreshPage();
			}).then("User Verify Status Got Changed", () -> {
			Reporter.logWithScreenShot("Status Got Changed to Closed", MessageTypes.Info);
		}).execute();
	}
	
	
	@Test(priority = 11,dependsOnMethods = { "CloseTheCase" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
	}
}