package com.pldt.tests.ePLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.io.IOException;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ExcelReader;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
/*Prerequisites to execute this scenario  
 * Asset should be active.
 * Parent Account and Billing Account should be active.
 * ServiceID, contract term, pricing information, Asset dates must be populated.
 * 

*/
public class Ingress_Deployment extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	String caseURL=null;
	ArrayList<String> orderList = null;


	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdminintoSalesForce(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(10);
			
		}).then("verify that User is Logged In to Salesforce", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating Case", priority = 2, dependsOnMethods = {
			"LoginasAdminintoSalesForce" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
		}).when("I open the account page and click on cases link", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			props.setProperty("Account", data.get("Account_Name"));
			util.waitFor(10);
			}).and("I verify that account details page of " + data.get("Account_Name") +" is displayed", () -> {
			String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
			.getText();
			Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
		}).and("Creating new case", () -> {
			App().Pages().getAccountDetailsPage().clickOnRelated("Contacts");
			util.waitFor(5);
			App().Pages().getCustomerPortalPage().LogintoCustomerPortal();
			App().Pages().getCustomerPortalPage().CreateCaseInCustomerPortal(data);
		}).then("I Verified that case is created", () -> {
			Reporter.logWithScreenShot("Case is Created");
	}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 3, dependsOnMethods = {
	"CreatingNewCase" })
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(10);
			
		}).then("verify that User is Logged In to Salesforce", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Open Created Case", priority = 4, dependsOnMethods = {
	"LoginasAdmin" })
	public void OpenCase(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getHomepage().goToAPP("Cases");
			util.waitFor(5);
			App().Pages().getCaseListPage().SearchCaseUsingCaseNo("All Open Cases",props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
		}).then("I verified that Case Detail Page is Displayed", () -> {
			Reporter.logWithScreenShot("Case Details Page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Verfiy and Update Case Details", priority = 5, dependsOnMethods = { "OpenCase" })
	public void VerifyandUpdateCaseDetails(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("User Checks Case owner and Case Status", () -> {
			App().Pages().getCaseDetailsPage().verifyCaseStatus("Open");
			App().Pages().getCasepage().ValidateCaseOwner("Level 1 - Support Queue");
		}).and("I Update the case Details", () -> {
			App().Pages().getCaseDetailsPage().updateCaseDetail(data);
			
	}).then("I verified Case Details", () -> {
		Reporter.logWithScreenShot("Verified Case Details", MessageTypes.Info);
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "logoutasRMandLoginAsSmartEnterpriseSupport", priority = 6, dependsOnMethods = { "VerifyandUpdateCaseDetails" })
	public void loginAsSupportQueue(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).and("I login as Level 1 - Support Queue", () -> {
			//App().Pages().getHomepage().SwitchToUser(data.get("Support Queue"), "CA");
			 App().Pages().getHomepage().switchToAnyUser(data.get("Support Queue"));
		}).then("i verified that i Switched to Level 1 - Support Queue", () -> {
			Reporter.logWithScreenShot("Switched to Level 1 - Support Queue member", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Accepting and Modifying the case", priority = 7, dependsOnMethods = {
			"loginAsSupportQueue" })
	public void acceptCase(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I accept the case", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
			App().Pages().getCaseListPage().acceptCase("Level 1 - Support Queue",props.getPropertyValue("CaseNumber"));
		}).then("i verified that case is accepted", () -> {
			Reporter.logWithScreenShot(" Case is Modified/Bulk Upload is completed", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Verifying Case Status", priority = 8, dependsOnMethods = {
			"acceptCase" })
	public void verifyCaseStatus(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Case Page", () -> {
		}).when("User Checks Case owner and Case Status", () -> {
			App().Pages().getCaseDetailsPage().verifyCaseStatus("Open");
	}).then("I verified Case Status", () -> {
		Reporter.logWithScreenShot("Verified Case Status", MessageTypes.Info);
	}).execute();	
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Sending an EMAIL", priority = 9, dependsOnMethods = {
			"verifyCaseStatus" })
	public void sendEMAIL(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Case Page", () -> {
		}).when("I send an EMAIL", () -> {
			App().Pages().getCaseDetailsPage().email();
	}).then("I verified that email is send", () -> {
		Reporter.logWithScreenShot("Send Email", MessageTypes.Info);
	}).execute();	
	}
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Accepting and Modifying the case", priority = 10, dependsOnMethods = {
			"sendEMAIL" })
	public void changeCaseStatus(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Case Page", () -> {
		}).when("Change Case Status to Resolution in Progress", () -> {
			//util.ChangeStatus("Resolution In Progress");
			util.ChangeStatusSMAX("Resolution In Progress", "In progress");
			util.scrollUp();
			util.waitFor(5);
		}).and("I Input Solution and Completiton Code", () -> {
			App().Pages().getCasepage().FillSolution(data);
		}).and("I Change the Case Status", () -> {
			//util.ChangeStatus("Resolved");
			util.ChangeStatusSMAX("Resolved", "For Client Confirmation");
			util.scrollUp();
			util.waitFor(5);
			util.ChangeStatus("Closed");
			util.scrollUp();
			util.waitFor(5);
	}).then("I verified that Case Status is Changed", () -> {
		Reporter.logWithScreenShot("Case Status", MessageTypes.Info);
	}).execute();	
	}
	
	@Test( priority = 11,dependsOnMethods = { "changeCaseStatus" })
	public void getReferenceData()
	{
		Reporter.log("case URL :"+ProjectBeans.getCaseURL(), MessageTypes.Info);

	}
}


