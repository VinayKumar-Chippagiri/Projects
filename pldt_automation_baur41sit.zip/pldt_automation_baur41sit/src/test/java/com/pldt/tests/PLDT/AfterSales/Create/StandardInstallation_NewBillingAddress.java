package com.pldt.tests.PLDT.AfterSales.Create;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class StandardInstallation_NewBillingAddress extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	ArrayList<String> orderList = null;
	
	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Installation",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			props.setProperty("testdata", data);	
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
		
		}).then("I verify User is Logged in as Admin", () -> {
			
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Installation",key = "${key.name}")
	@Test(description = "Switch to RelationShip Manager", priority = 2,dependsOnMethods = { "Login_as_Admin_into_SalesForce_Application" })
	public void SwitchingtoRelationshipManager(Map <String,String> data) {
		scenario().then("I Switch to RelationShip Manager", () -> {
//			props.setProperty("testdata", data);	
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).then("I verify that User is Switched to Relation Ship Manager", () -> {			
			Reporter.logWithScreenShot("", MessageTypes.Info);			
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Installation",key = "${key.name}")
	@Test(description = "Account", priority = 3, dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void OpenExistingAccount(Map<String, String> data) {
	scenario().given("I am in home page", () -> {
	util.refreshPage();
	util.waitFor(5);
	}).when("I open " + data.get("Account_Name") + " account", () -> {
	App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
	props.setProperty("Account", data.get("Account_Name"));
	ProjectBeans.setAccountURL(getDriver().getCurrentUrl()); // setting account url
	util.waitFor(10);
	}).then("I verify that account details page of " + data.get("Account_Name") +" is displayed", () -> {
	String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
	.getText();
	Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
	}).when("I click on contacts", () -> {
	getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
	util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
	}).and("I captured the contact name", () -> {
	String TechnicalContact = getDriver().findElement(By.xpath("//span[.='Technical']/ancestor::tr//th//a"))
	.getText();
	props.setProperty("contact.Technical", TechnicalContact);
	Reporter.log("Technical Contact: " + TechnicalContact);
	String Authorized_Signatory = getDriver()
	.findElement(By.xpath("//span[.='Authorized Signatory']/ancestor::tr//th//a")).getText();
	props.setProperty("Lead.fullName", Authorized_Signatory);
	Reporter.log("Authorized Signatory: " + Authorized_Signatory);
	Reporter.logWithScreenShot("Account Contact Details");
	}).and("I clicked on account and navigate back to account details page", () -> {
	QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
	AccountName.click();
	}).then("then i verified that account details page is dispayed", () -> {
	util.waitForAccountPage();
	Reporter.logWithScreenShot("Account Details Page");
	}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Installation",key = "${key.name}")
	@Test(description = "Creating Case", priority = 4, dependsOnMethods = {
			"Open_Existing_Account" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getAccountDetailsPage().clickOnRelated("Cases");
		}).when("Creating case for Contract Renewal", () -> {
			pages.getCaseListPage().clickNewCaseButton();
			pages.getNewCaseModal().SelectRecordType(data.get("Record Type"));
			pages.getCasepage().createAfterSalesNewCase();
		}).then("Selecting The Case Created", () -> {
			pages.getCaseListPage().selectCase(data.get("Subject"));
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());     //set Case URL
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Installation",key = "${key.name}")
	@Test(description = "Creating Case", priority = 5, dependsOnMethods = {
			"CreatingNewCase" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("Going in case and adding billing account", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("Checking Negative Scenarios And Add Billing Account", () -> {
			pages.getCasepage().CheckNegativeScenarios();
			pages.getCaseDetailsPage().AddBillingAccountforCreate(data);
		}).and("Add Required Documents", () -> {	
			pages.getCaseDetailsPage().VerifyBulkServiceRequestFromRelated(ProjectBeans.getCaseURL());
			getDriver().get(ProjectBeans.getCaseURL());               //get case URL
			pages.getCaseDetailsPage().AddDocumentsRequired();
		}).then("Change Status to Assigned For Resolution and Clicking on MODIFY And Add Primary Service ", () -> {
			util.ChangeStatus("Assigned For Resolution");		
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "CreatingEnterpriseQuote", priority = 6, dependsOnMethods = { "AddBillingAccount" })
	public void createEnterpriseQuote(Map<String, String> data) {
		scenario().given("Create Quote From Case", () -> {
		props.setProperty("testdata", data);		
		util.clickOnActionToolBarButton("Quick Actions", "CREATE");
		if (util.getEnvironment().equalsIgnoreCase("R4SIT")) {
			pages.getQuotepage().createEnterpriseQuote(data);
		}
		if (util.getEnvironment().equalsIgnoreCase("R4E2ESIT")) {
			pages.getQuotepage().createEnterpriseQuoteEndtoEnd(data);
		}
		util.waitForQuotePage();
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "SelectingServiceAddress", priority = 7, dependsOnMethods = { "createEnterpriseQuote" })
	public void BulkSites(Map<String, String> data) {
		scenario().given("Select Service Address ", () -> {
		props.setProperty("testdata", data);
		pages.getQuotepage().selectServiceAddress(data);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Cart",key = "${key.name}")
	@Test(description = "Configuring cart", priority = 8, dependsOnMethods = { "BulkSites" })
	public void cartPage(Map<String, String> data) {
		scenario().given("ConfigureIgateOffer ", () -> {
		props.setProperty("testdata", data);		
		if (util.getEnvironment().equalsIgnoreCase("R4SIT")) {
			pages.getCartpage().ConfigureIgateOffer(data);
			AppUtils.grouping_Product(data.get("Plan"));
			pages.getCartpage().ViewRecord();
			}
			if (util.getEnvironment().equalsIgnoreCase("R4E2ESIT")) {
				pages.getQuotepage().ClickAddProducts();
				pages.getCartpage().ConfigureIgateOffer(data);
				AppUtils.WorkingCart_grouping_Product(data.get("ExchangeiD"));
				AppUtils.SaveWorkingCart();
				AppUtils.Association_Validation();
			}
			util.waitForQuotePage();
		}).then("I verify that cart is configured", () -> {
		}).execute();
		
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "updating Ets Details", priority = 9, dependsOnMethods = { "cartPage" })
	public void updateETSDetails(Map<String, String> data) {
		scenario().given("I am on Quote page", () -> {   
		props.setProperty("testdata", data);
		}).then("I Click on Trigger SD", () -> {
		ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		pages.getQuotepage().TriggerSD();
		}).then("I Logout as Relationship manager", () -> {
		pages.getLoginpage().logoutAsCurrentUser();
		}).and("I Login as ETS user", () -> {
		pages.getHomepage().switchToAnyUser(data.get("ETS"));
		getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		util.waitForQuotePage();
		}).and("I Update ETS Status and ETS Rematks", () -> {
		pages.getQuotepage().updateEtsDetails(data.get("EtsStatus"), data.get("EtsRemarks"));
		pages.getLoginpage().logoutAsCurrentUser();
		pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		util.waitForQuotePage();
		}).execute();
	
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "SiteBandZloc", priority = 10, dependsOnMethods = { "updateETSDetails" })
	public void SiteBandZloc(Map<String, String> data) {
		scenario().given("I update SiteBandZloc", () -> {
			pages.getQuotepage().siteBandzloc(data);	
			}).then("I verify that SiteBandZloc is updated", () -> {
			}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Billing Management", priority = 11, dependsOnMethods = { "SiteBandZloc" })
	public void billingManagement(Map<String, String> data) {
		scenario().given("I update billing management", () -> {
		props.setProperty("testdata", data);
		pages.getQuotepage().billingManagement(data, data.get("Country"),data.get("taxExemption") , data.get("taxProfile"));
		}).then("I verify that billing Management is updated", () -> {
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "updating Contact Details", priority = 12, dependsOnMethods = { "billingManagement" })
	public void updateContactDetails(Map<String, String> data) {
		scenario().given("I update Contact Details in Quote page", () -> {
		props.setProperty("testdata", data);
		pages.getQuotepage().updatePldtContactDetails(data);
		ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "credit check", priority = 13, dependsOnMethods = { "updateContactDetails" })
	public void creditCheck(Map<String, String> data) {
		scenario().given(" Perform Credit Check ", () -> {
			props.setProperty("testdata", data);	
		}).when("I Perform Credit Check", () -> {	
			pages.getQuotepage().CreditCheck();
			}).and("Logout As Current User And Login As Credit Analyst", () -> {
			pages.getLoginpage().logoutAsCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			pages.getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
					data.get("CreditApprovalCondition"), data.get("CreditRemark"));
			}).then("Logout As Current User And Login As Relationship Manager ", () -> {
			pages.getLoginpage().logoutCurrentUser(); 		
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			
		}).execute();
	}		
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Cart",key = "${key.name}")
	@Test(description = "syncronize QLI Items", priority = 14, dependsOnMethods = { "creditCheck" })
	public void QLIItems(Map<String, String> data) {
		scenario().given("I change Quote Status to Customer Accepted ", () -> {
			props.setProperty("testdata", data);
			pages.getQuotepage().changeQuoteStatustoPresented(data);
			util.waitFor(5);
			pages.getQuotepage().QuoteGeneration("Word");
			pages.getQuotepage().changeQuoteStatustoCustomerAccepted();
			Reporter.logWithScreenShot("change Quote Status to Customer Accepted");
			}).when("I am Synchronizing Account", () -> {
			App().Pages().getQuotepage().SynchronizingAccount(data.get("Plan1"),data.get("Relationship Manager"));
			}).execute();		
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "create Contract", priority = 15, dependsOnMethods = { "syncronizeQLIItems" })
	public void createContract(Map<String, String> data) {
		scenario().given(" I Perform Create Contract ", () -> {
		props.setProperty("testdata", data);
		}).when("I click On Create Contarct ", () -> {
		pages.getQuotepage().CreateContract();
		}).then("I Change Contarct Page Status Till Signed", () -> {
		pages.getQuotepage().ChangeTheStatusToSigned();
		ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Upload file", priority = 16, dependsOnMethods = { "createContract" })
	public void generateDocuments(Map<String, String> data) {
	props.setProperty("testdata", data);
	scenario().given("I am on Contract Page", () -> {
	}).when("I click on generate Documents ", () -> {
	util.refreshPage();
	util.waitForContractPage();
	App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
	util.waitForContractPage();
	}).then("i verified that File is Uploaded", () -> {
	Reporter.logWithScreenShot(" Generate Documents ", MessageTypes.Info);
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Verify Orders", priority = 17, dependsOnMethods = { "generateDocuments" })
	public void verifyOrders(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Contract Page", () -> {
		}).when("I move to orders page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList=pages.getQuotepage().VerifyOrders();
		}).then("I verified the status of Orders", () -> {
			Reporter.logWithScreenShot(" Orders", MessageTypes.Info);
		}).execute();
	}
	
	@Test( priority = 18,dependsOnMethods = { "verifyOrders" })
	public void getReferenceData()
	{
		Reporter.log("Lead URL :"+ProjectBeans.getLeadURL(), MessageTypes.Info);
		Reporter.log("Account URL :"+ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :"+ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :"+ProjectBeans.getContractURL(), MessageTypes.Info);
		

		if(orderList.size()>0)
		{
			for(int i=0;i<orderList.size();i++)
			{
				Reporter.log("Order _"+(i+1)+" URL : "+orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
