package com.pldt.tests.SMART.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.MyScreenRecorder;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class Smart_MemoCreation extends BaseTest{
	WebUtilities util = new WebUtilities();
	PageLib pages = new PageLib();
	String quoteURL=null;
	String orderURL=null;
	ArrayList<String> orderList =null;
	String caseID = null;
	String caseURL = null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void Login_as_Admin(Map <String,String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
		}).then("I verify User is Logged in as Admin", () -> {
			Reporter.logWithScreenShot("User is Logged in as Admin", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to RelationShip Manager", priority = 2,dependsOnMethods = { "Login_as_Admin" })
	public void Switching_to_RelationShipManager(Map <String,String> data) {
		scenario().then("I Switch to RelationShip Manager", () -> {
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).then("I verify that User is Switched to Relation Ship Manager", () -> {
				Reporter.logWithScreenShot("User is Switched to RelationShip Manager", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Selecting Account", priority = 3,dependsOnMethods = {"Switching_to_RelationShipManager"})
	public void Selecting_Account(Map <String,String> data) {
		scenario().and("Selecting Account", () -> {
			util.waitFor(5);
			pages.getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
			App().Pages().getAccountDetailsPage().getAccountRecordType();
		}).then("I verify that Account is Selected", () -> {
			Reporter.logWithScreenShot("Account is Selected", MessageTypes.Info);
		}).execute();
	}

	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Creating Case", priority = 4, dependsOnMethods = { "Selecting_Account" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getAccountDetailsPage().clickOnRelated("Cases");
		}).when("Creating case for Contract Renewal", () -> {
			pages.getCaseListPage().clickNewCaseButton();
			pages.getNewCaseModal().SelectRecordType(data.get("Record Type"));
			pages.getCasepage().createAfterSalesNewCase();
		}).then("Selecting The Case Created", () -> {
			App().Pages().getCasepage().getCaseNumberFromToastMessage();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			util.waitFor(10);
			caseID = getDriver().findElement(By.xpath(
					"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
					.getText();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl()); // set Case URL
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(priority = 5,dependsOnMethods = {"CreatingNewCase"})
	public void markCaseStatusToResolutionInprogress(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {
			pages.getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("case status got changed to resolution in progress", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 6,dependsOnMethods = {"markCaseStatusToResolutionInprogress"})
	private void markCaseStatusToResolved() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolved", () -> {
			util.ChangeStatus("Resolved");
		}).then("I see case status got changed to Resolved", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolved", MessageTypes.Info);
		}).execute();
	}
	
	@Test(priority = 7,dependsOnMethods = {"markCaseStatusToResolved"})
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
	}

}
