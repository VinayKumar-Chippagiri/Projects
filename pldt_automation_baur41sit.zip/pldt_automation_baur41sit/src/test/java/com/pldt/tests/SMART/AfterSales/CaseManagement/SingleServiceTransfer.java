package com.pldt.tests.SMART.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;
import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class SingleServiceTransfer extends BaseTest{
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String caseURL2 = null;
	String quoteURL = null;
	String orderURL = null;
	String caseID = null;
	 String BillingAccountUrL = null;
	ArrayList<String> orderList = null;
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to RelationshipManager", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRelationShipManager(Map <String,String> data) {
		scenario().given("user logged in as Asmin", () -> {
		}).when("User Login As Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to RelationShipManager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Successfully switched to Relationship Manager");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRelationShipManager" })
	public void CreateNewCase(Map<String, String> data)  {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().createNewCaseFromAsset(data);
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());// set case url in ProjectBeans
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "BillingAccount",key = "${key.name}")
	@Test(description = "Creating BillingAccount",priority = 4, dependsOnMethods = { "CreateNewCase" })
	public void createBillingAccount(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Billing Account ", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Accounts__r");
			pages.getAccountListPage().clickNewButton();
			util.waitFor(By.xpath("//h1[.='Accounts']"), 20, true);
			pages.getAccountListPage().createBillingAccount();
			App().Pages().getAssetDetailsPage().clickOnRelated("Accounts__r");
			util.clickUsingJs(By.xpath("(//span[.='Account Name']/following::tbody/tr/th/span/a)"));
			util.waitForAccountPage();
			BillingAccountUrL = getDriver().getCurrentUrl();
			String NewbillingAcc_number = getDriver().findElement(By.xpath("(//span[.='CRM Account Number']/following::lightning-formatted-text)[1]")).getText();
			props.setProperty("NewBillingAccountNo", NewbillingAcc_number);
		}).then("I verified that Billing Account is Created", () -> {
			Reporter.logWithScreenShot("Billing Account is Created", MessageTypes.Info);
		}).execute();
	}
	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 5,dependsOnMethods = {"createBillingAccount"})
	public void markCaseStatusToResolutionInprogress(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {	
			getDriver().navigate().to(caseURL);
			util.waitForCasePage();
			pages.getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolution in Progress", MessageTypes.Info);
		}).execute();
	}

	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 6,dependsOnMethods = {"markCaseStatusToResolutionInprogress"})
	private void verifyTransaction(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I open Transaction", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Transaction__r");
			pages.getCaseDetailsPage().verifyTransaction();
			getDriver().get(caseURL);
			util.waitForCasePage();
		}).then("I verify the Transaction", () -> {
			Reporter.logWithScreenShot("Transaction is Verified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 7,dependsOnMethods = {"verifyTransaction"})
	private void verifyCaseStatus(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform " + data.get("Transaction Type"), () -> {
				pages.getCaseDetailsPage().verfifyCaseStatus("Closed");
		}).then("I verify the Case Status", () -> {
			Reporter.logWithScreenShot("Case Status is Verified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(description = "Selecting Account", priority = 8,dependsOnMethods = {"verifyCaseStatus"})
	public void Selecting_Account(Map <String,String> data) {
		scenario().and("Selecting Account", () -> {
			util.waitFor(5);
			pages.getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
		}).then("I verify that Account is Selected", () -> {
			Reporter.logWithScreenShot("Account is Selected", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(description = "Selecting Asset", priority = 9,dependsOnMethods = {"Selecting_Account"})
	public void Selecting_Asset(Map <String,String> data) {
		scenario().then("Selecting Asset ", () -> {
			pages.getAccountDetailsPage().clickOnRelated("Assets");
			pages.getAssetsListPage().openAsset(data.get("assetName"),data.get("MINNumber"), true);
		}).then("I verify that I Select the Asset", () -> {
			Reporter.logWithScreenShot("Asset is Selected", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(description = "Extracting BillAccount Number", priority = 10,dependsOnMethods = {"Selecting_Asset"})
	public void Extracting_BillAccountNumber_in_AssetPage(Map <String,String> data) {
		scenario().and("Extracting BillAccount Number in Asset Details Section", () -> {	
			pages.getAssetDetailsPage().getBillAccountNumber();
		}).then("I verify that the Billing Account Number is Extracted", () -> {
			Reporter.logWithScreenShot("Extracted Billing Account Number in Asset Page", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(description = "Case Creation", priority = 11,dependsOnMethods = {"Extracting_BillAccountNumber_in_AssetPage"})
	public void create_New_Case(Map <String,String> data) {		
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I fill case form details and submit", () -> {	
			pages.getAssetDetailsPage().clickOnRelated("Cases");
			pages.getCaseListPage().createNewCaseFromAsset_selectArguments(data);
			App().Pages().getCaseListPage().selectCase(data.get("Subject2"));
			util.waitForCasePage();
			caseURL2= getDriver().getCurrentUrl();
		}).then("I verify that the case is created", () -> {
			Reporter.logWithScreenShot("Case is Created", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(description = "Case Creation", priority = 12,dependsOnMethods = {"create_New_Case"})
	public void ModifyTransactionDetails(Map <String,String> data) {		
		scenario().given("Modifying the Transaction Details", () -> {	
			App().Pages().getCaseDetailsPage().performSingleServiceTransfer(data, props.getPropertyValue("NewBillingAccountNo"));
		}).then("I verify that the case is created", () -> {
			Reporter.logWithScreenShot("Transaction Details are Modified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 13,dependsOnMethods = {"ModifyTransactionDetails"})
	public void markCaseStatusToResolutionInProgress(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {	
			pages.getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolution in Progress", MessageTypes.Info);
		}).execute();
	}

	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 14,dependsOnMethods = {"markCaseStatusToResolutionInProgress"})
	private void VerifyTransaction(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I open Transaction", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Transaction__r");
			pages.getCaseDetailsPage().verifyTransaction();
			getDriver().get(caseURL2);
			util.waitForCasePage();
		}).then("I verify the Transaction", () -> {
			Reporter.logWithScreenShot("Transaction is Verified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 15,dependsOnMethods = {"VerifyTransaction"})
	private void VerifyCaseStatus(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I Verifying the Case Status", () -> {
				pages.getCaseDetailsPage().verfifyCaseStatus("Closed");
			
		}).then("I verify the Case Status", () -> {
			Reporter.logWithScreenShot("Case Status is Verified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 16,dependsOnMethods = {"VerifyCaseStatus"})
	private void verifyNewBillingAccount(Map<String, String> data) {
		scenario().and("Selecting Account", () -> {
			util.waitFor(5);
			pages.getHomepage().switchToAnyAccount(props.getPropertyValue("BillingAccountName"),props.getPropertyValue("NewBillingAccountNo"));
			App().Pages().getAssetDetailsPage().clickOnRelated("vlocity_cmt__BillingAccountAssets__r");
		}).then("I verify the New Billing account is Created", () -> {
			Reporter.logWithScreenShot("New Billing account is Verified", MessageTypes.Info);
		}).execute();
	}

	@Test(priority = 17,dependsOnMethods = {"verifyNewBillingAccount"})
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
		Reporter.log("Case URL2 :"+caseURL2, MessageTypes.Info);
		Reporter.log("Billing Account Url :"+BillingAccountUrL, MessageTypes.Info);
	}

}
