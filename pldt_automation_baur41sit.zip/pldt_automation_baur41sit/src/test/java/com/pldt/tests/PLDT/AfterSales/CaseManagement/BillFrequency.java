package com.pldt.tests.PLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class BillFrequency extends BaseTest{
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String caseURL2 = null;
	String quoteURL = null;
	String orderURL = null;
	String caseID = null;
	 String BillingAccountUrL = null;
	ArrayList<String> orderList = null;
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to RelationshipManager", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRelationShipManager(Map <String,String> data) {
		scenario().given("user logged in as Asmin", () -> {
		}).when("User Login As Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to RelationShipManager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Successfully switched to Relationship Manager");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRelationShipManager" })
	public void CreateNewCase(Map<String, String> data)  {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {	
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			util.waitFor(2)	;
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("recordtype"));
			App().Pages().getNewCaseModal().createAfterSalesNewCase();
			App().Pages().getCasepage().getCaseNumberFromToastMessage();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			util.waitFor(10);
			caseID = getDriver().findElement(By.xpath(
					"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
					.getText();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());// set case url in ProjectBeans
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Accepting the case", priority = 4, dependsOnMethods = {"CreateNewCase" })
	public void Acceptcase(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I accept the case", () -> {
			pages.getLoginpage().logoutCurrentUser(); 
			pages.getHomepage().switchToAnyUser(data.get("EBMUser"));
			App().Pages().getHomepage().goToAPP("Cases");
			App().Pages().getCaseListPage().acceptCase("EBM Aftersales",caseID);
			util.waitForCasePage();
			Reporter.logWithScreenShot("Case is Accepted", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Validate Transaction Description", priority = 5, dependsOnMethods = {"Acceptcase" })
	public void ValidateTransactionDescription(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I Validate Transaction Description", () -> {
			util.waitForCasePage();
			pages.getCaseDetailsPage().ValidateTransactionDescription(data.get("TransactionDescription"));
			Reporter.logWithScreenShot("Validated Transaction Description", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 6,dependsOnMethods = {"ValidateTransactionDescription"})
	public void AddBillingAccount(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to case page and Addong Billing Account", () -> {	
			pages.getCaseDetailsPage().addBillingAccount(data);	
		}).then("I Added the Billing Account in Case Page", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 7,dependsOnMethods = {"AddBillingAccount"})
	public void markCaseStatusToDocumentPending(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Document Pending", () -> {	
			util.ChangeStatus("Document Pending");
		}).then("I see case status got changed to Document Pending", () -> {
			Reporter.logWithScreenShot("Case status changed to Document Pending", MessageTypes.Info);
		}).execute();
	}
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 8,dependsOnMethods = {"markCaseStatusToDocumentPending"})
	public void AddDocuments(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I'm Adding the Documents", () -> {
			pages.getCasepage().AddDocumentsRequiredForTreatment(data);
		}).then("I verify the Documents added", () -> {
			Reporter.logWithScreenShot("I verify the Documents added", MessageTypes.Info);
		}).execute();
	}
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 9,dependsOnMethods = {"AddDocuments"})
	private void markCaseStatusToResolved() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolved", () -> {
			util.ChangeStatus("Resolved");
		}).then("I see case status got changed to Resolved", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolved", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 10,dependsOnMethods = {"markCaseStatusToResolved"})
	private void markCaseStatusToClosed() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Closed", () -> {
			util.ChangeStatus("Closed");
			util.waitFor(5);
		}).then("I see case status got changed to Closed", () -> {
			Reporter.logWithScreenShot("Case status changed to Closed", MessageTypes.Info);
		}).execute();
	}


	@Test(priority = 11,dependsOnMethods = {"markCaseStatusToClosed"})
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
	}

}
