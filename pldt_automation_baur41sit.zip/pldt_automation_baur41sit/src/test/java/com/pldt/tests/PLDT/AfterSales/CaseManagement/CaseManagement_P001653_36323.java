package com.pldt.tests.PLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
/*Prerequisites to execute this scenario  
 * Asset should be active.
 * Parent Account and Billing Account should be active.
 * ServiceID, contract term, pricing information, Asset dates must be populated.
 * 

*/
public class CaseManagement_P001653_36323 extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	String caseURL=null;
	ArrayList<String> orderList = null;



	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdminintoSalesForce(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(10);
			String title = getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).then("verify that User is Switched to EmailAgent", () -> {
			pages.getHomepage().switchToAnyUser(data.get("EmailAgent"));
			props.setProperty("EmailAgent", data.get("EmailAgent"));
			util.waitFor(5);
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading,
					Matchers.containsString("Logged in as " + data.get("EmailAgent")));
		}).execute();
	}
	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating Case", priority = 2, dependsOnMethods = {
			"LoginasAdminintoSalesForce" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
		}).when("I open the account page and click on cases link", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			props.setProperty("Account", data.get("Account_Name"));
			util.waitFor(10);
			}).and("I verify that account details page of " + data.get("Account_Name") +" is displayed", () -> {
			String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
			.getText();
			Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getAccountDetailsPage().clickOnRelated("Cases");
		}).and("Creating new case", () -> {
			pages.getCaseListPage().clickNewCaseButton();
			pages.getNewCaseModal().SelectRecordType(data.get("Record Type"));
			pages.getCasepage().createNewCasetypeTechnical(data);
		}).then("Selecting The Case Created", () -> {
			pages.getCaseListPage().selectCase(data.get("Subject"));	
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());     //set Case URL
	}).execute();
	}
	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "ValidateCaseOwner", priority = 3, dependsOnMethods = {
			"CreatingNewCase" })
	public void ValidateCaseOwner(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Validate case owner", () -> {	
			App().Pages().getCasepage().ValidateCaseOwner(data.get("EmailAgent"));	
		}).then("User verify case owner", () -> {
			Reporter.logWithScreenShot("User verify case owner");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Validatetransactiondescribe", priority = 4, dependsOnMethods = {
			"ValidateCaseOwner" })
	public void Validatetransactiondescribe(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Validate case Description", () -> {	
			util.scrollIntoElement(By.xpath("//div//lightning-formatted-text[contains(.,'Allow modem')]"));
			String description = getDriver().findElement(By.xpath("//div//lightning-formatted-text[contains(.,'Allow modem')]"))
					.getText();
					Validator.verifyThat("", description, Matchers.containsString(data.get("Description")));
		}).then("User verify the case description ", () -> {
			Reporter.logWithScreenShot("verify the case description");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Add Documents Required", priority = 5, dependsOnMethods = {
			"Validatetransactiondescribe" })
	public void AddDocumentsRequired(Map<String, String> data) {
		scenario().given("I am on casepage", () -> {
		}).when("I change status to Document Pending", () -> {
			getDriver().get(ProjectBeans.getCaseURL());               //get case URL
			util.ChangeStatus("Document Pending");
		}).and("I add documents Required", () -> {	
			pages.getCaseDetailsPage().AddDocumentsRequired();
		}).then("I change status to assigned for resolution", () -> {	
			util.ChangeStatus("Assigned For Resolution");
			util.waitFor(8);
			Reporter.logWithScreenShot("verify the case status got Changed");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "ValidateCaseOwner", priority = 6, dependsOnMethods = {
			"AddDocumentsRequired" })
	public void ValidateCaseOwnerandLogin(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Validate case owner", () -> {	
			util.refreshPage();
			util.waitForCasePage();
			App().Pages().getCasepage().ValidateCaseOwner(data.get("CaseOwner"));
		}).and("User Logout", () -> {	
			App().Pages().getLoginpage().logoutCurrentUser();	
		}).and("User Login with Pldt ESAM", () -> {	
			util.waitFor(8);
			App().Pages().getHomepage().SwitchToUser(data.get("PldtESAM"),"Pldt ESAM");		
		}).then("User Logged in  ", () -> {
			Reporter.logWithScreenShot("User Logged in as Pldt ESAM");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Accept Case", priority = 7, dependsOnMethods = { "ValidateCaseOwnerandLogin" })
	public void AcceptCase(Map<String, String> data) {
		scenario().given("User is on Home Page", () -> {
		}).when("User navigated to cases tab", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
		}).and("Search cases assign to Case Owner", () -> {	
			App().Pages().getCasepage().SelectCaseGroup(data.get("CaseOwner"));
		}).and("User Accept the Case", () -> {	
			App().Pages().getCasepage().acceptCase();
			App().Pages().getCasepage().SelectCaseGroup("My Cases");
			App().Pages().getCasepage().clickOnCaseByCaseNumber();			
		}).then("User verify that case got accepted and navigated to case", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "ValidateCaseOwner", priority = 8, dependsOnMethods = {
			"AcceptCase" })
	public void ValidateCaseOwnerPLDT_ESAM(Map<String, String> data) {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Validate case owner", () -> {	
			App().Pages().getCasepage().ValidateCaseOwner(data.get("PldtESAM"));	
		}).then("User verify case owner  ", () -> {
			Reporter.logWithScreenShot("User navigate to case page");
		}).execute();
	}	
		
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "case Close", priority = 9, dependsOnMethods = { "ValidateCaseOwnerPLDT_ESAM" })
	public void caseclose(Map<String, String> data) {
		scenario().given(" I am on case page ", () -> {
			props.setProperty("testdata", data);
		}).when("I change status to resolved", () -> {
			util.ChangeStatus("Resolution In Progress");
			util.waitFor(8);
			util.ChangeStatus("Resolved");
			util.waitFor(8);
			Reporter.logWithScreenShot("verify the case status got Changed");
			}).and("I change status to closed", () -> {
				util.ChangeStatus("Closed");
				util.waitFor(5);
				Reporter.logWithScreenShot("verify the case status got Changed");
			}).then("I verify case got closed", () -> {
				Reporter.logWithScreenShot( "Case got closed");
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "case Close", priority = 10, dependsOnMethods = { "caseclose" })
	public void negativeTest(Map<String, String> data) {
		scenario().given(" I am on case page ", () -> {
			props.setProperty("testdata", data);
		}).when("I try to edit Case Cancellation Reason", () -> {
			util.refreshPage();
			util.waitForCasePage();
			util.clickUsingJs(By.xpath("//span[.='Case Cancellation Reason']/parent::div/following-sibling::div//button"));
			util.waitFor(3);
			util.clickUsingJs(By.xpath("(//button[.='Save'])[last()]"));
			}).then("I verify error msg", () -> {
				util.waitFor(3);
				util.waitFor(By.xpath("//li[.='You cannot edit a CANCELLED or CLOSED case']"), 60, true);
				QAFWebElement Status = new QAFExtendedWebElement(
						"xpath=//li[.='You cannot edit a CANCELLED or CLOSED case']");
				Validator.verifyTrue(Status.isPresent(), "Error Message Not Displayed",
						"Error Message Displayed");
				Reporter.logWithScreenShot( "Error Message Displayed");
		}).execute();
	}
	
	
	@Test( priority = 11,dependsOnMethods = { "negativeTest" })
	public void getReferenceData()
	{
		Reporter.log("case URL :"+ProjectBeans.getCaseURL(), MessageTypes.Info);

	}
}


