package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

/*******************************************************************************************************************************************
     UAT: Aftersales PLDT: Non-Technical Case creation with 
     Transaction Sub Type of Revenue Re-Rating of MRC with Case 
     Creator as CRA member and Approval amount is less than 100,000
 *********************************************************************************************************************************************/
public class RevenueAdjustment extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL=null;
	String orderURL=null;
	ArrayList<String> orderList =null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("I Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("I Logged in As Admin:" + data.get("Username"));
		}).then("I verified that Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to CRA Member", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoCRA_Member(Map <String,String> data) {
		scenario().given("I am on Home Page", () -> {
		}).when("I Login As CRA User", () -> {
			System.out.println(data.get("CRA_User"));
			App().Pages().getHomepage().switchToAnyUser(data.get("CRA_User"));	
			Reporter.log("Switched to Hotline User:" + data.get("CRA_User"));
		}).then("I verified that I have successfully switched to CRA User", () -> {
			Reporter.logWithScreenShot("Successfully switched to "+data.get("CRA_User"));
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoCRA_Member" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().
		given("I am on Home Page", () -> {
		}).when("I open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("I click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("I Filled case details form and save", () -> {	
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getNewCaseModal().createNew_PLDT_Service_Request_Case();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
			props.setProperty("CaseURL", caseURL);
		}).then("I verified that case got Created and case page is in opened Stage ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Verfiy Case Details", priority = 4, dependsOnMethods = { "CreateNewCase" })
	public void VerifyCaseDetails(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("User Checks Case owner and Case Status", () -> {
			App().Pages().getCaseDetailsPage().verifyCaseStatus("Open");
			App().Pages().getCasepage().ValidateCaseOwner(data.get("CRA_User"));
			App().Pages().getCaseDetailsPage().verifyTransactionDescription(data.get("Transaction Description"));
	}).then("I verified Case Details", () -> {
		Reporter.logWithScreenShot("Verified Case Details", MessageTypes.Info);
	}).execute();
}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Add Billing Accounts", priority = 5, dependsOnMethods = { "VerifyCaseDetails" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("When I click on Add Billing account", () -> {
			App().Pages().getCaseDetailsPage().AddBillingAccounts_RevenueAdjustment(data);
		}).and("I navigate to Bulk Service Request Tab", () -> {	
			App().Pages().getCaseDetailsPage().verifyBulkServiceRequest();
	}).then("I verified Bulk Service Request", () -> {
		Reporter.logWithScreenShot("Bulk Service Request", MessageTypes.Info);
	}).execute();
}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Add Billing Accounts", priority = 6, dependsOnMethods = { "AddBillingAccount" })
	public void UpdateCaseDetails(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
			util.goToURL(caseURL);
		}).when("I change the Status to Document Pending", () -> {
			util.ChangeStatus("Document Pending");
			Reporter.logWithScreenShot("Changed Case Status", MessageTypes.Info);
		}).and("When I Navigate to Documents required tab and filled the details", () -> {	
			App().Pages().getCaseDetailsPage().selectRequiredDocument();
	}).then("I verified all the changes are made successfully", () -> {
		Reporter.logWithScreenShot("Bulk Service Request", MessageTypes.Info);
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Change the Status and Verify the Case Owner", priority = 7, dependsOnMethods = { "UpdateCaseDetails" })
	public void ChangeStatusandSubmitforApproval(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("I change the Status to Assigned for Resolution", () -> {
			util.ChangeStatus("Assigned For Resolution");
			util.scrollUp();
			util.waitFor(5);
			Reporter.logWithScreenShot("Changed Case Status", MessageTypes.Info);
		}).and("I Submit the case for Approval", () -> {		
			App().Pages().getCaseDetailsPage().submitforApproval(data);
		}).and("I verfiy the case status", () -> {
			App().Pages().getCaseDetailsPage().verifyCaseStatus("Pending Approval");
	}).then("I verified the Case Staus", () -> {
		Reporter.logWithScreenShot("Case Status", MessageTypes.Info);
	}).execute();
}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login As Credit Analyst", priority = 8, dependsOnMethods = { "ChangeStatusandSubmitforApproval" })
	public void checkCaseStatusandHistory(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("I navigate to Case History", () -> {
			App().Pages().getCaseDetailsPage().checkCaseHistory();
		}).and("I navigate to Approval History", () -> {	
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
			App().Pages().getCaseDetailsPage().checkApprovalHistory();	
	}).then("I verified the case History and Approval History", () -> {
		//Reporter.logWithScreenShot("Logged In As "+data.get("Credit_Analyst")+"", MessageTypes.Info);
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Updating the Billing Accounts In Bulk Service Request", priority = 9, dependsOnMethods = { "checkCaseStatusandHistory" })
	public void LoginasECRM_Head(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).when("I Logout as CRA Head", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("I Login as ECRM Head", () -> {		
			App().Pages().getHomepage().switchToAnyUser(data.get("ECRM_user"));	
	}).then("I verified that I Logged in as Credit Analyst", () -> {
		Reporter.logWithScreenShot("Logged In As "+data.get("ECRM_user")+"", MessageTypes.Info);
			}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 10, dependsOnMethods = { "LoginasECRM_Head" })
	public void RejectCase(Map<String, String> data) {
		scenario().given("I am on Home Page", () -> {

		}).when("I Reject the case", () -> {
			App().Pages().getCaseDetailsPage().rejectCase(data);
		}).and("I verify the Case Owner", () -> {
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
			App().Pages().getCasepage().ValidateCaseOwner(data.get("CRA_User"));
		}).then("I verfied that Case is Validated", () -> {
			Reporter.logWithScreenShot("Rejected Case", MessageTypes.Info);
			}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 11, dependsOnMethods = { "RejectCase" })
	public void LoginAsCRA(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).when("I Logout as CRA Head", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("I Login as ECRM Head", () -> {		
			App().Pages().getHomepage().switchToAnyUser(data.get("CRA_User"));	
	}).then("I verified that I Logged in as Credit Analyst", () -> {
		Reporter.logWithScreenShot("Logged In As "+data.get("CRA_User")+"", MessageTypes.Info);
			}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 12, dependsOnMethods = { "LoginAsCRA" })
	public void SubmitForApproval(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).and("I Submit the case for Approval", () -> {		
			App().Pages().getCaseDetailsPage().submitforApproval(data);
		}).then("I verified that Case is Again Submitted for Approval", () -> {
			Reporter.logWithScreenShot("Case Status");
				}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login As Credit Analyst", priority = 13, dependsOnMethods = { "SubmitForApproval" })
	public void checkCaseStatusandHistory2(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("I navigate to Case History", () -> {
			App().Pages().getCaseDetailsPage().checkCaseHistory();
		}).and("I navigate to Approval History", () -> {		
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
			App().Pages().getCaseDetailsPage().checkApprovalHistory();	
	}).then("I verified the case History and Approval History", () -> {
		//Reporter.logWithScreenShot("Logged In As "+data.get("Credit_Analyst")+"", MessageTypes.Info);
	}).execute();
}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Updating the Billing Accounts In Bulk Service Request", priority = 14, dependsOnMethods = { "checkCaseStatusandHistory2" })
	public void LoginasECRM_Head2(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).when("I Logout as CRA Head", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("I Login as ECRM Head", () -> {		
			App().Pages().getHomepage().switchToAnyUser(data.get("ECRM_user"));	
	}).then("I verified that I Logged in as ECRM Head", () -> {
		Reporter.logWithScreenShot("Logged In As "+data.get("ECRM_user")+"", MessageTypes.Info);
			}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 15, dependsOnMethods = { "LoginasECRM_Head2" })
	public void ApproveCase(Map<String, String> data) {
		scenario().given("I am on Home Page", () -> {
		}).when("I Approve the case", () -> {
			App().Pages().getCaseDetailsPage().ApproveCase(data);
		}).and("I verify the Case Owner", () -> {
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
			App().Pages().getCasepage().ValidateCaseOwner("PLDT EPM - Revenue Adjustment");
		}).then("I verfied that Case is Approved", () -> {
			Reporter.logWithScreenShot("Rejected Case", MessageTypes.Info);
			}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 16, dependsOnMethods = { "ApproveCase" })
	public void LoginasEPM_Member(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).when("I Logout as EPM Head", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("I Login as EPM Member", () -> {		
			App().Pages().getHomepage().switchToAnyUser(data.get("EPM_User"));	
	}).then("I verified that I Logged in as EPM Member", () -> {
		Reporter.logWithScreenShot("Logged In As "+data.get("EPM_User")+"", MessageTypes.Info);
			}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 17, dependsOnMethods = { "LoginasEPM_Member" })
	public void AccepttheCaseandChangeStatus(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("I accept the case", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
			App().Pages().getCaseListPage().acceptCase(props.getPropertyValue("CaseNumber"),data);
		}).and("I verified that Case Owner is EPM Member", () -> {
			App().Pages().getCasepage().ValidateCaseOwner(data.get("EPM_User"));
		}).and("I Changed the Status to Assigned for Resolution", () -> {
			util.ChangeStatus("Assigned For Resolution");
		}).then("I verified that Case Status is changed", () -> {
			Reporter.logWithScreenShot("Logged In As "+data.get("EPM_User")+"and case status changed", MessageTypes.Info);
				}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 18, dependsOnMethods = { "AccepttheCaseandChangeStatus" })
	public void UpdateBulkServiceRequestandValidateCase(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("I Navigate to BSR and Update it", () -> {
			App().Pages().getCaseDetailsPage().updateBulkServiceRequest_RevenueAdjustment(data);
		}).and("I perform Validation", () -> {
			util.waitFor(3);
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
			App().Pages().getCaseDetailsPage().validateCase_RevenueAdjustment();
		}).then("I verfied that Validation is completed", () -> {
			Reporter.logWithScreenShot("Validation", MessageTypes.Info);
				}).execute();
	}
	
	@Test(priority = 19,dependsOnMethods = { "UpdateBulkServiceRequestandValidateCase" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
	}
}