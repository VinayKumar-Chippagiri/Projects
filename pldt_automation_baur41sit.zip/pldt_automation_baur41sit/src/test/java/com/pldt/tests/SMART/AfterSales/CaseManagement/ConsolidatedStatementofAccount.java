package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

/*******************************************************************************************************************************************
     	UAT: Aftersales PLDT: Non-Technical Case creation with 
     	Transaction Sub Type of CSA Inclusion/Exclusion with 
     	Case Origin as CA member and PLDT Credit Rating as New
 *********************************************************************************************************************************************/
public class ConsolidatedStatementofAccount extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL=null;
	String orderURL=null;
	ArrayList<String> orderList =null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("I Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("I Logged in As Admin:" + data.get("Username"));
		}).then("I verified that Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login As Credit Analyst", priority = 2, dependsOnMethods = { "Login" })
	public void LoginAsCA(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("I Logout as HotLine User", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("I Login as Credit Analyst", () -> {		
			App().Pages().getHomepage().switchToAnyUser(data.get("Credit_Analyst"));	
	}).then("I verified that I Logged in as Credit Analyst", () -> {
		Reporter.logWithScreenShot("Logged In As "+data.get("Credit_Analyst")+"", MessageTypes.Info);
	}).execute();
}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "LoginAsCA" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().
		given("I am on Home Page", () -> {
		}).when("I open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("I click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("I Filled case details form and save", () -> {	
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getNewCaseModal().createNew_PLDT_Service_Request_Case();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
			props.setProperty("CaseURL", caseURL);
		}).then("I verified that case got Created and case page is in opened Stage ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Verfiy Case Details", priority = 4, dependsOnMethods = { "CreateNewCase" })
	public void VerifyCaseDetails(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("User Checks Case owner and Case Status", () -> {
			App().Pages().getCaseDetailsPage().verifyCaseStatus("Open");
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Credit_Analyst"));
			App().Pages().getCaseDetailsPage().verifyTransactionDescription(data.get("Transaction Description"));
	}).then("I verified Case Details", () -> {
		Reporter.logWithScreenShot("Verified Case Details", MessageTypes.Info);
	}).execute();
}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Add Billing Accounts", priority = 5, dependsOnMethods = { "CreateNewCase" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("When I click on Add Billing account", () -> {
			App().Pages().getCaseDetailsPage().AddBillingAccounts_CSA(data);
		}).and("I navigate to Bulk Service Request Tab", () -> {	
			App().Pages().getCaseDetailsPage().verifyBulkServiceRequest();
	}).then("I verified Bulk Service Request", () -> {
		Reporter.logWithScreenShot("Bulk Service Request", MessageTypes.Info);
	}).execute();
}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Add Billing Accounts", priority = 6, dependsOnMethods = { "AddBillingAccount" })
	public void UpdateCaseDetails(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
			util.goToURL(caseURL);
		}).when("I change the Status to Document Pending", () -> {
			util.ChangeStatus("Document Pending");
			Reporter.logWithScreenShot("Changed Case Status", MessageTypes.Info);
		}).and("When I Navigate to Documents required tab and filled the details", () -> {	
			App().Pages().getCaseDetailsPage().selectRequiredDocument();
			util.waitFor(5);
	}).then("I verified all the changes are made successfully", () -> {
		Reporter.logWithScreenShot("Bulk Service Request", MessageTypes.Info);
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Change the Status and Verify the Case Owner", priority = 7, dependsOnMethods = { "UpdateCaseDetails" })
	public void ChangeStatus(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("I change the Status to Assigned for Resolution", () -> {
			util.ChangeStatus("Assigned For Resolution");
			util.scrollUp();
			util.waitFor(5);
			Reporter.logWithScreenShot("Changed Case Status", MessageTypes.Info);
//		}).and("I Check the Case Owner", () -> {		
//			App().Pages().getCasepage().ValidateCaseOwner(data.get("Credit_Analyst"));
	}).then("I verified that case status is changed", () -> {
		Reporter.logWithScreenShot("Changed Case Status", MessageTypes.Info);
	}).execute();
}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Updating the Billing Accounts In Bulk Service Request", priority = 8, dependsOnMethods = { "ChangeStatus" })
	public void UpdateBillRunDate(Map<String, String> data) {
		scenario().given("I am on Home Page", () -> {
//		}).when("I Navigate Back to Case", () -> {
//			util.goToURL(caseURL);
//			util.waitForCasePage();
//			util.waitFor(5);
		}).when("I Update Bill Run Date in Case Details Page", () -> {
			App().Pages().getCaseDetailsPage().UpdateCSAInformation();
		}).then("I Navigate to BSR(Bulk Service Request) Tab", () -> {
			Reporter.log("Updated Bulk Service Request");
			}).execute();
	}
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Close The Case", priority = 10, dependsOnMethods = { "UpdateBillRunDate" })
	public void validateCase(Map<String, String> data) {
		scenario().given("I am on Case Page", () -> {
		}).when("I Perform Validate", () -> {
			App().Pages().getCaseDetailsPage().validateCase();
		}).then("I verfied that Case is Validated", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
			}).execute();
	}
	
	
	@Test(priority = 11,dependsOnMethods = { "validateCase" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
	}
}