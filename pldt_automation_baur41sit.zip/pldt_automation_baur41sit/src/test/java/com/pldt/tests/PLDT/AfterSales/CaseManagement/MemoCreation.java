package com.pldt.tests.PLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.elements.Button;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class MemoCreation extends BaseTest{
	PageLib pages = new PageLib();
	Button button = new Button();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String caseURL2 = null;
	String quoteURL = null;
	String orderURL = null;
	String caseID = null;
	 String BillingAccountUrL = null;
	ArrayList<String> orderList = null;
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to RelationshipManager", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoCollectionRevenueAnalyst(Map <String,String> data) {
		scenario().given("user logged in as Asmin", () -> {
		}).when("User Login As Collection Revenue Analyst", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Revenue Analyst"));
			Reporter.log("Switched to RelationShipManager:" + data.get("Revenue Analyst"));
		}).then("verify Admin successfully switched to Collection Revenue Analyst", () -> {
			Reporter.logWithScreenShot("Successfully switched to Collection Revenue Analyst");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoCollectionRevenueAnalyst" })
	public void CreateNewCase(Map<String, String> data)  {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {	
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("recordtype"));
			App().Pages().getNewCaseModal().createAfterSalesNewCase();
			App().Pages().getCasepage().getCaseNumberFromToastMessage();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			util.waitFor(10);
			caseID = getDriver().findElement(By.xpath(
					"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
					.getText();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());// set case url in ProjectBeans
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Adding Notes in Account", priority = 4, dependsOnMethods = {"CreateNewCase" })
	public void AddingNotesinAccount(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I'm Adding Notes in the Account", () -> {
			util.clickUsingActions(By.xpath("((//span[.='Account Name'])[last()]/following::a[1])"));
			util.waitForAccountPage();
			App().Pages().getAssetDetailsPage().clickOnRelated("AttachedContentNotes");
			App().Pages().getCaseDetailsPage().AddingNotes();
			getDriver().get(caseURL);
			util.waitForCasePage();
			Reporter.logWithScreenShot("Added Notes in the Account", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Adding Notes in Case", priority = 5, dependsOnMethods = {"AddingNotesinAccount" })
	public void AddingNotesinCase(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I'm Adding Notes in the Case", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("AttachedContentNotes");
			App().Pages().getCaseDetailsPage().AddingNotes();
			getDriver().get(caseURL);
			util.waitForCasePage();
			Reporter.logWithScreenShot("Added Notes in the Case", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Adding Billing Account in Case", priority = 6, dependsOnMethods = {"AddingNotesinCase" })
	public void AddingBillingaccountinCase(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I'm Adding Billing Account in Case", () -> {
			App().Pages().getCaseDetailsPage().AddingBillingAccountinCase(data.get("Billing Account"));
			Reporter.logWithScreenShot("Added Billing Account in Case", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Adding Notes in Billing Account", priority = 7, dependsOnMethods = {"AddingBillingaccountinCase" })
	public void AddingNotesinBillingAccount(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I'm Adding Notes in the Billing Account", () -> {
			util.clickUsingJs(By.xpath("(//span[.='Billing Account']/following::a)[1]"));
			util.waitForAccountPage();
			App().Pages().getAssetDetailsPage().clickOnRelated("AttachedContentNotes");
			App().Pages().getCaseDetailsPage().AddingNotes();
			getDriver().get(caseURL);
			util.waitForCasePage();
			Reporter.logWithScreenShot("Added Notes in the Billing Account", MessageTypes.Info);
		}).execute();
	}
	

	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 8,dependsOnMethods = {"AddingNotesinBillingAccount"})
	public void markCaseStatusToDocumentPending(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Document Pending", () -> {	
			util.ChangeStatus("Document Pending");
		}).then("I see case status got changed to Document Pending", () -> {
			Reporter.logWithScreenShot("Case status changed to Document Pending", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 9,dependsOnMethods = {"markCaseStatusToDocumentPending"})
	public void markCaseStatusToAssignedForResolution(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Assigned For Resolution", () -> {	
			util.ChangeStatus("Assigned For Resolution");
		}).then("I see case status got changed to Assigned For Resolution", () -> {
			Reporter.logWithScreenShot("Case status changed to Assigned For Resolution", MessageTypes.Info);
		}).execute();
	}
	
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 10,dependsOnMethods = {"markCaseStatusToAssignedForResolution"})
	private void markCaseStatusToResolved() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolved", () -> {
			util.ChangeStatus("Resolved");
		}).then("I see case status got changed to Resolved", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolved", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 11,dependsOnMethods = {"markCaseStatusToResolved"})
	private void markCaseStatusToClosed() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Closed", () -> {
			util.ChangeStatus("Closed");
		}).then("I see case status got changed to Closed", () -> {
			Reporter.logWithScreenShot("Case status changed to Closed", MessageTypes.Info);
		}).execute();
	}


	@Test(priority = 12,dependsOnMethods = {"markCaseStatusToClosed"})
	private void getReferenceData() {
		Reporter.log("Case URL :" +caseURL, MessageTypes.Info);
	}

}
