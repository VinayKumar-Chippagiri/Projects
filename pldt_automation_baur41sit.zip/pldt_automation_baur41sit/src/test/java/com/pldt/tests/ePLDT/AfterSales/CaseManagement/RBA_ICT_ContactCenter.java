package com.pldt.tests.ePLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.Map;

import org.testng.annotations.Test;

import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class RBA_ICT_ContactCenter extends BaseTest{
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	
	// Jira ID : P0016530-51628 
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to RelationshipManager", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRelationShipManager(Map <String,String> data) {
		scenario().given("user logged in as Asmin", () -> {
		}).when("User Login As Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to RelationShipManager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Successfully switched to Relationship Manager");
		}).execute();
		}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating New Contact", priority = 3,dependsOnMethods = { "SwitchingtoRelationShipManager" })
	public void contactCreationTest(Map<String, String> data) {
		scenario().given("Navigating to Contacts to create Contact", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getHomepage().goToAPP("Contacts");
			pages.getContactpage().clickNewContact();
		}).when("I add Contact Information for the New Contact", () -> {
			pages.getContactpage().fillContactForm();
			pages.getContactpage().clickSaveButton();
		}).then("I verify that information is entered", () -> {
			Reporter.logWithScreenShot("Contact info is entered", MessageTypes.Info);
		}).execute();
	}
	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Editing New Contact", priority = 4, dependsOnMethods = { "contactCreationTest" })
	public void editTitle(Map<String, String> data) {
		scenario().given("Contact Page is opened", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getContactpage().editTitle();
		}).when("I edit the Contact Information", () -> {
			pages.getContactpage().getContactSave().click();
			util.waitFor(5);
		}).then("I Click on Save Button", () -> {
			Reporter.logWithScreenShot("User is able to Edit the Title", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating New Dashboard", priority = 5,dependsOnMethods = { "editTitle" })
	public void DashboardCreation(Map<String, String> data) {
		scenario().given("Navigating to Dashboards to create Dashboard", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getHomepage().goToAPP("Dashboards");
			pages.getDashboardPage().clickNewDashboard();
		}).when("I add Dashboard Information for the New Dashboard", () -> {
			pages.getDashboardPage().createNewDasboard();
		}).then("I verify that information is entered", () -> {
			Reporter.logWithScreenShot("New Dashboard  is Created", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Edit Dashboard", priority = 6, dependsOnMethods = { "DashboardCreation" })
	public void editDashboard(Map<String, String> data) {
		scenario().given("Dashboard Page is opened", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I edit the Dashboard Information", () -> {
			pages.getDashboardPage().editDasboard();
		}).then("I Click on Save Button", () -> {
			Reporter.logWithScreenShot("User is able to Edit the Dashboard Information", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating New Report", priority = 7,dependsOnMethods = { "editDashboard" })
	public void ReportCreation(Map<String, String> data) {
		scenario().given("Navigating to Dashboards to create Report", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getHomepage().goToAPP("Reports");
			pages.getDashboardPage().clickNewReport();
		}).when("I add Dashboard Information for the New Report", () -> {
			pages.getDashboardPage().createNewReport();
		}).then("I verify that information is entered", () -> {
			Reporter.logWithScreenShot("New Report  is Created", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Edit Report", priority = 8,dependsOnMethods = { "ReportCreation" })
	public void editReport(Map<String, String> data) {
		scenario().given("Report Page is opened", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I edit the Report Information", () -> {
			pages.getDashboardPage().editReport();
		}).then("I Click on Save Button", () -> {
			Reporter.logWithScreenShot("User is able to Edit the Report Information", MessageTypes.Info);
		}).execute();
	}

}
