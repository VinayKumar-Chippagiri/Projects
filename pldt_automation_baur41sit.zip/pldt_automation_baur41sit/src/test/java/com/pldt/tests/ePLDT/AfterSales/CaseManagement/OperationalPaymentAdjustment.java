package com.pldt.tests.ePLDT.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class OperationalPaymentAdjustment extends BaseTest{
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String caseID = null;
    String BillingAccountUrL = null;
	ArrayList<String> orderList = null;
	
	// Jira ID : P0016530-45108
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Switch to RelationshipManager", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRM(Map <String,String> data) {
		scenario().given("user logged in as Asmin", () -> {
		}).when("User Login As Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to RelationShipManager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager", () -> {
			Reporter.logWithScreenShot("Successfully switched to Relationship Manager");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRM" })
	public void CreateNewCase(Map<String, String> data)  {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {			
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("recordtype"));
			App().Pages().getNewCaseModal().createNewCaseForICT(data);
			App().Pages().getCasepage().getCaseNumberFromToastMessage();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			util.waitFor(8);
			caseID = getDriver().findElement(By.xpath(
					"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
					.getText();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());// set case url in ProjectBeans
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 4,dependsOnMethods = {"CreateNewCase"})
	private void changeCaseOwner(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the change owner action", () -> {
			pages.getCaseDetailsPage().changeOwner(data.get("ownerName"));
			pages.getLoginpage().logoutCurrentUser(); 
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();	
		}).then("I see the owner is changed", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 5,dependsOnMethods = {"changeCaseOwner"})
	public void ValidateTransactionDescription(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I Validate Transaction Description", () -> {	
			pages.getCaseDetailsPage().ValidateTransactionDescription(data.get("TransactionDescription"));
		}).then("I Validate Transaction Description", () -> {
			Reporter.logWithScreenShot("Validated Transaction Description", MessageTypes.Info);
		}).execute();
	}
	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 6,dependsOnMethods = {"ValidateTransactionDescription"})
	public void markCaseStatusToDocumentPending(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Document Pending", () -> {	
			util.ChangeStatusSMAX("Document Pending");
		}).then("I see case status got changed to Document Pending", () -> {
			Reporter.logWithScreenShot("Case status changed to Document Pending", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 7,dependsOnMethods = {"markCaseStatusToDocumentPending"})
	public void AddDocuments(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I'm Adding the Documents", () -> {
			pages.getCasepage().AddDocumentsRequiredForTreatment(data);
		}).then("I verify the Documents added", () -> {
			Reporter.logWithScreenShot("I verify the Documents added", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 8,dependsOnMethods = {"AddDocuments"})
	public void UploadDocument(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I Click on Attachments and Upload the Documents", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("CombinedAttachments");
			pages.getCasepage().uploadFile("resources\\testdata\\BulkFile.csv");
			util.waitFor(5);
		}).then("I Uploaded the Documents in the Attachments", () -> {
			Reporter.logWithScreenShot("I verify that Documents added in the Attachments", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 9,dependsOnMethods = {"UploadDocument"})
	public void UpdateDebitandCreditAmount(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I'm Adjusting Debit and Credit Amounts", () -> {
			pages.getCasepage().adjustCreditandDebitAmounts(data);
		}).then("I Adjusted the Credit and Debit Amounts", () -> {
			Reporter.logWithScreenShot("I Adjusted the Credit and Debit Amounts", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 10,dependsOnMethods = {"UpdateDebitandCreditAmount"})
	public void SubmitForApproval(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I'm Submitting For Approval", () -> {
			pages.getCasepage().SubmitForApproval();
			pages.getCasepage().CheckingApprovalUser(caseURL, data);
		}).then("I Submit For Approval", () -> {
			Reporter.logWithScreenShot("I Submitted the Approval", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 11,dependsOnMethods = {"SubmitForApproval"})
	public void RejectApproval(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I'm Rejecting For Approval", () -> {
			pages.getLoginpage().logoutAsCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("ApproverName"));
			pages.getCasepage().RejectCaseFromItemstoApprove();
		}).then("I Rejected the Approval", () -> {
			Reporter.logWithScreenShot("I Rejected the Approval", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 12,dependsOnMethods = {"RejectApproval"})
	private void verifyStatusofCase(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform " + data.get("Transaction Type"), () -> {
			getDriver().get(caseURL);
			util.waitForCasePage();
			pages.getCaseDetailsPage().verfifyCaseStatus("Rejected");
		}).then("I verify the Case Status", () -> {
			Reporter.logWithScreenShot("Case Status is Verified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 13,dependsOnMethods = {"verifyStatusofCase"})
	public void SubmitforApproval(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I'm Submitting For Approval", () -> {
			pages.getLoginpage().logoutAsCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();
			pages.getCasepage().SubmitForApproval();
		}).and("I'm Checking the Case Status", () -> {
			pages.getCaseDetailsPage().verfifyCaseStatus("Pending Approval");
		}).then("I'm Checking the Approval History", () -> {
			pages.getCasepage().CheckingApprovalUser(caseURL, data);
			Reporter.logWithScreenShot("I Submitted the Approval", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 14,dependsOnMethods = {"SubmitforApproval"})
	public void ApproveItemsForApproval(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I'm Approving For Approval", () -> {
			pages.getLoginpage().logoutAsCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("ApproverName"));
			pages.getCasepage().ApproveCaseFromItemstoApprove();
		}).then("I Approved the Approval", () -> {
			Reporter.logWithScreenShot("I Approved the Approval", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 15,dependsOnMethods = {"ApproveItemsForApproval"})
	private void verifyCaseStatus(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform " + data.get("Transaction Type"), () -> {
			pages.getLoginpage().logoutAsCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();
			pages.getCaseDetailsPage().verfifyCaseStatus("Approved");
		}).then("I verify the Case Status", () -> {
			Reporter.logWithScreenShot("Case Status is Verified", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 16,dependsOnMethods = {"verifyCaseStatus"})
	private void changeCaseOwnerTest(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the change owner action", () -> {
			pages.getCaseDetailsPage().changeOwner(data.get("ownerName"));
//			pages.getLoginpage().logoutCurrentUser(); 
//			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
//			getDriver().get(caseURL);
			util.waitForCasePage();	
		}).then("I see the owner is changed", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 17,dependsOnMethods = {"changeCaseOwnerTest"})
	public void markCaseStatusToAssignedForResolution(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Assigned For Resolution", () -> {	
			util.ChangeStatusSMAX("Assigned For Resolution");
		}).then("I see case status got changed to Assigned For Resolution", () -> {
			Reporter.logWithScreenShot("Case status changed to Assigned For Resolution", MessageTypes.Info);
		}).execute();
	}
	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 18,dependsOnMethods = {"markCaseStatusToAssignedForResolution"})
	private void markCaseStatusToResolved() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolved", () -> {
			util.ChangeStatusSMAX("Resolved");
		}).then("I see case status got changed to Resolved", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolved", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 19,dependsOnMethods = {"markCaseStatusToResolved"})
	private void markCaseStatusToClosed() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Closed", () -> {
			util.ChangeStatusSMAX("Closed");
		}).then("I see case status got changed to Closed", () -> {
			Reporter.logWithScreenShot("Case status changed to Closed", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement",key="${key.name}")
	@Test(priority = 20,dependsOnMethods = {"markCaseStatusToClosed"})
	public void changeCaseStatusToResolved(Map <String,String> data) {
		scenario().given("Case status changed to Cancelled", () -> {
		}).given("Case status changing to Resolved", () -> {	
			util.ChangeStatusSMAX("Resolved","For Client Confirmation");
			util.waitFor(15);
			Reporter.logWithScreenShot("Error message is displayed", MessageTypes.Info);
		}).then("I see the Error message is displayed ", () -> {
		}).execute();
	}

	@Test(priority = 21,dependsOnMethods = {"changeCaseStatusToResolved"})
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
	}

}
