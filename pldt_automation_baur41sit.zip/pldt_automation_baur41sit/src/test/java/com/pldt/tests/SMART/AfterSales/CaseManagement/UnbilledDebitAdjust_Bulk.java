package com.pldt.tests.SMART.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;
import java.util.ArrayList;
import java.util.Map;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class UnbilledDebitAdjust_Bulk extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL = null;
	String orderURL = null;
	ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(5);
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("User logged in as admin ", title, Matchers.equalTo("Home | Salesforce"));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Switch to Revenue Analyst", priority = 2, dependsOnMethods = { "Login" })
	public void SwitchingtoRevenueAnalyst(Map<String, String> data) {
		scenario().given("user Switch to Revenue Analyst", () -> {
		}).when("User Login As Revenue Analyst", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Revenue Analyst"));
			Reporter.log("Switched to Revenue Analyst:" + data.get("Revenue Analyst"));
		}).then("verify Admin successfully switched to Revenue Analyst", () -> {
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading, Matchers.containsString("Logged in as " + data.get("Revenue Analyst")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRevenueAnalyst" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().given("Going in account", () -> {
		}).when("User open account page", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("user Fill case details form and save", () -> {
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getCasepage().createNewCaseCaseManagementBulk(data);
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			caseURL = getDriver().getCurrentUrl();
		}).then("User verify the case got Created and case page is opened ", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("User is on case page ", title, Matchers.containsString("Salesforce"));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Validate Case Owner", priority = 4, dependsOnMethods = { "CreateNewCase" })
	public void ValidateCaseOwner(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User Validate case owner", () -> {
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Revenue Analyst"));
		}).then("User verify the case Owner ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "SubmitForApproval", priority = 5, dependsOnMethods = { "ValidateCaseOwner" })
	public void SubmitForApproval(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User Submit Case for Approval", () -> {
			App().Pages().getCasepage().SubmitForApproval();
		}).then("User verify the case is submitted for Approval ", () -> {
			Reporter.logWithScreenShot("submitted for Approval");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Approve the Case", priority = 6, dependsOnMethods = { "SubmitForApproval" })
	public void ApproveTheCase(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User open Approval History", () -> {
			App().Pages().getCasepage().CheckingApprovalUser(caseURL, data);
		}).and("User Logout", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("Login with the Approver", () -> {
			String Approver = App().Pages().getCasepage().getAPPROVER();
			App().Pages().getHomepage().SwitchToUser(Approver, "ECRM Head");
		}).and("User approve the Case", () -> {
			App().Pages().getCasepage().ApproveCaseFromItemstoApprove();
		}).then("User verify the case is Approved ", () -> {
			Reporter.logWithScreenShot("Case Approved");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Approve the Case", priority = 7, dependsOnMethods = { "ApproveTheCase" })
	public void ApprovalfromSCCMHead(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User Logout", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("Login with the Approver", () -> {
			App().Pages().getHomepage().SwitchToUser(data.get("SCCMHead"), "SCCMHead");
		}).and("User approve the Case", () -> {
			App().Pages().getCasepage().ApproveCaseFromItemstoApprove();
		}).then("User verify the case is Approved ", () -> {
			Reporter.logWithScreenShot("Case Approved");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Approve the Case", priority = 8, dependsOnMethods = { "ApprovalfromSCCMHead" })
	public void ApprovalfromEBSOMHead(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User Logout", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("Login with the Approver", () -> {
			App().Pages().getHomepage().SwitchToUser(data.get("EBSOMHead"), "EBSOMHead");
		}).and("User approve the Case", () -> {
			App().Pages().getCasepage().ApproveCaseFromItemstoApprove();
		}).and("User Logout ", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).then("User verify the case is Approved ", () -> {
			Reporter.logWithScreenShot("Case Approved");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Verify the case status", priority = 9, dependsOnMethods = {"ApprovalfromEBSOMHead" })
	public void VerifyCaseStatus(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User go to the case page", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
			util.goToURL(caseURL);
		}).then("User verify the case is Approved ", () -> {
			App().Pages().getCaseDetailsPage().verfifyCaseStatus("Approved");
			Reporter.logWithScreenShot("Case Approved");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Validate Case Owner and login with the user", priority = 10, dependsOnMethods = {
			"VerifyCaseStatus" })
	public void ValidateCaseOwnerAndLogin(Map<String, String> data) {
		scenario().given("User is on Case Approval page", () -> {
		}).when("User open Case Page", () -> {
			App().Pages().getCasepage().ValidateCaseOwner(data.get("CaseOwner2"));
		}).and("User Login with Payments-Analyst", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Payments Analyst"));
		}).then("Verify user switched to Payments Analyst", () -> {
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading, Matchers.containsString("Logged in as " + data.get("Payments Analyst")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Accept Case", priority = 11, dependsOnMethods = { "ValidateCaseOwnerAndLogin" })
	public void AcceptCase(Map<String, String> data) {
		scenario().given("User is on Home Page", () -> {
		}).when("User navigated to cases tab", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
		}).and("Search cases assign to Case Owner", () -> {
			App().Pages().getCasepage().SelectCaseGroup(data.get("CaseOwner2"));
		}).and("User Accept the Case", () -> {
			App().Pages().getCasepage().acceptCase();
			App().Pages().getCasepage().SelectCaseGroup("My Cases");
			App().Pages().getCasepage().clickOnCaseByCaseNumber();
		}).then("User verify that case got accepted and navigated to case", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@Test(description = "Update Case ID in BulkFile", priority = 12, dependsOnMethods = { "AcceptCase" }) //
	public void UpdateCaseIDInBulkFile() {
		scenario().given("User is on Case Page", () -> {
		}).when("User retrive case Id from URL and update to bulk file", () -> {
			String Caseid = App().Pages().getCasepage().retriveCaseNumberFromURL();
			app.UpdateIDInCSVFile("resources/testdata/UAT_Bulk_UnbilledDebitCreditAdj.csv", Caseid);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Upload Bulk File", priority = 13, dependsOnMethods = { "UpdateCaseIDInBulkFile" })
	public void BulkFileUpload(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
		}).when("User click on Bulk Upload Button", () -> {
			App().Pages().getCasepage().ClickOnBulkUpload();
		}).and("User upload Bulk file", () -> {
			App().Pages().getCasepage().BulkFileUploadCaseManagement(
					props.getProperty("user.dir") + "\\resources\\testdata\\UAT_Bulk_UnbilledDebitCreditAdj.csv");
			util.goToURL(caseURL);
		}).then("User verify that Bulk file got Uploaded", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Move Case status to RIP and all Transaction status to successful", priority = 14, dependsOnMethods = {
			"BulkFileUpload" }) //
	public void MoveCaseToRIP(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
		}).when("User move case status to RIP", () -> {
			util.clickUsingJs(By.xpath("(//a[@data-tab-name='Assigned For Resolution'])[last()]"));
			util.waitFor(3);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).and("User move all transaction status to successful", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
			App().Pages().getCasepage().MoveTransactionStatusToSuccessful(caseURL);
			util.goToURL(caseURL);
			util.waitForCasePage();
		}).then("User verify that case status move to the Closed", () -> {
			App().Pages().getCaseDetailsPage().verfifyCaseStatus("Closed");
			Reporter.logWithScreenShot("Case status changed to Closed");
		}).execute();
	}

	@Test(priority = 15, dependsOnMethods = { "MoveCaseToRIP" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
	}
}
