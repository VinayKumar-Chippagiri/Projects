package com.pldt.tests.SMART.AfterSales.OrderManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.ExcelReader;
import com.common.utilities.MyScreenRecorder;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class updateServiceContract extends BaseTest{
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String caseURL2 = null;
	String quoteURL = null;
	String orderURL = null;
	String caseID = null;
	 String BillingAccountUrL = null;
	ArrayList<String> orderList = null;
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key = "${key.name}")
	@Test(description = "Switch to Credit Analyst", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoCreditAnalyst(Map <String,String> data) {
		scenario().given("user logged in as Asmin", () -> {
		}).when("User Login As Credit Analyst", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			Reporter.log("Switched to RelationShipManager:" + data.get("Credit Analyst"));
		}).then("verify Admin successfully switched to Credit Analyst", () -> {
			Reporter.logWithScreenShot("Successfully switched to Credit Analyst");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoCreditAnalyst" })
	public void CreateNewCase(Map<String, String> data)  {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {	
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {	
			props.setProperty("billingAccountNumber", data.get("Billing Account"));
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().createNewCaseFromAsset(data);
			App().Pages().getCasepage().getCaseNumberFromToastMessage();
			App().Pages().getCaseListPage().selectCaseUsingCaseNo(props.getPropertyValue("CaseNumber"));
			util.waitForCasePage();
			util.waitFor(10);
			caseID = getDriver().findElement(By.xpath(
					"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
					.getText();
			caseURL= getDriver().getCurrentUrl();
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());// set case url in ProjectBeans
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key = "${key.name}")
	@Test(description = "Accepting the case", priority = 4, dependsOnMethods = {"CreateNewCase" })
	public void caseModification(Map<String, String> data) throws InterruptedException {
		props.setProperty("testdata", data);
		scenario().given("I am on Case Page", () -> {
		}).when("I accept the case", () -> {
			App().Pages().getCasepage().changeOwnerForTreatment(data.get("ownerNameValue"), data);
			pages.getLoginpage().logoutCurrentUser(); 
			pages.getHomepage().switchToAnyUser(data.get("SmartUser"));
			App().Pages().getHomepage().goToAPP("Cases");
			App().Pages().getCaseListPage().acceptCase("SMART Enterprise Support",caseID);
			Reporter.logWithScreenShot("Case is Accepted", MessageTypes.Info);
		}).execute();
	}	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key="${key.name}")
	@Test(priority = 5,dependsOnMethods = {"caseModification"})
	private void changeCaseOwnerTest(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the change owner action", () -> {
			pages.getCaseDetailsPage().changeOwner(data.get("ownerName"));
			pages.getLoginpage().logoutCurrentUser(); 
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();	
		}).then("I see the owner is changed", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key="${key.name}")
	@Test(priority = 6,dependsOnMethods = {"changeCaseOwnerTest"})
	public void verifyTransactionDetails(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to case page and check transaction details section", () -> {	
			pages.getCaseDetailsPage().verifyTransactionDetailsForUpdateServiceContract(data.get("MINNumber"), data.get("serviceEndDate"));	
		}).then("I verify transaction details section", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key="${key.name}")
	@Test(priority = 7,dependsOnMethods = {"verifyTransactionDetails"})
	public void markCaseStatusToResolutionInprogress(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {	
			pages.getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("Case status changed to Resolution in Progress", MessageTypes.Info);
		}).execute();
	}
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key="${key.name}")
	@Test(priority = 8,dependsOnMethods = {"markCaseStatusToResolutionInprogress"})
	public void updateServiceContract(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform update Service Contract", () -> {
			pages.getCasepage().updateServiceContract();
		}).then("I verify the update Service Contract", () -> {
			Reporter.logWithScreenShot("I verify the update Service Contract", MessageTypes.Info);
		}).execute();
	}
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key="${key.name}")
	@Test(priority = 9,dependsOnMethods = {"updateServiceContract"})
	private void verifyTransactionAsset() {
		scenario().given("I'm on case page", () -> {
		}).when("I scroll to transaction asset section", () -> {
			pages.getCaseDetailsPage().verifyTransactionAsset();
		}).then("I see transaction asset is generated", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key="${key.name}")
	@Test(priority = 10,dependsOnMethods = {"verifyTransactionAsset"})
	public void verifyOrderDetails(Map <String,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to order search page", () -> {
			orderList=pages.getOrdersPage().verifyOrdersFromCasePage(caseURL,data.get("Transaction Type"));
		}).then("I verify the order generation", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key="${key.name}")
	@Test(priority = 11,dependsOnMethods = {"verifyOrderDetails"},enabled=false)
	private void verifyCaseStatus(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform " + data.get("Transaction Type"), () -> {
			getDriver().get(caseURL);
			util.waitForCasePage();
			pages.getCaseDetailsPage().verfifyCaseStatus("Resolved");
			util.waitFor(10);
		}).then("I verify the Case Status", () -> {
			Reporter.logWithScreenShot("Case Status is Verified", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "OrderManagement",key="${key.name}")
	@Test(priority = 12,dependsOnMethods = {"verifyCaseStatus"},enabled=false)
	private void verifyServiceEndDate(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform " + data.get("Transaction Type"), () -> {
			pages.getCaseDetailsPage().verfifyServiceEndDate(data.get("serviceEndDate"));
		}).then("I verify the verfifyServiceEndDate", () -> {
			Reporter.logWithScreenShot("Case Status is Verified", MessageTypes.Info);
		}).execute();
	}
	
	

	@Test(priority = 13,dependsOnMethods = {"verifyOrderDetails"})
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
		if(orderList.size()>0)
		{
			for(int i=0;i<orderList.size();i++)
			{
				Reporter.log("Order_"+(i+1)+": "+orderList.get(i), MessageTypes.Info);
			}
		}
	}

}
