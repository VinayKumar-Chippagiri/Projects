package com.pldt.tests.SMART.AfterSales.CaseManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.*;

import javax.tools.Tool;

import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElementListHandler;
import org.apache.commons.lang.StringUtils;
import org.checkerframework.checker.units.qual.A;
import org.hamcrest.Matchers;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.common.utilities.AppCommons;
import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.JsToolkit;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.ClipBoardUtil;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class CaseManage extends BaseTest {

	String caseID = null;
	String caseURL = null;

//	@QAFDataProvider(dataFile = "resources/testdata/NewConnectProducts.xlsx", sheetName = "Lead", key = "${key.name}")
//	@BeforeSuite
//	public void startrecord() {
//		try {
//			// MyScreenRecorder.startRecording(context.getSuite().getName());
//			MyScreenRecorder.startRecording(context.getName());
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//	@AfterSuite
//	public void stoprecord() {
//		try {
//			MyScreenRecorder.stopRecording();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	public void LoginAsAdmin(Map<String, String> data) {
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on Salesforce Login page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			driver.getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
			Reporter.logWithScreenShot("Login page");
		}).when("I enter admin username and password", () -> {
			App().Pages().getLoginpage().LoginAsAdmin();
			driver.getDriver().executeScript("return document.readyState").equals("complete");
			util.waitFor(20);
		}).then("I verify user able to login and navigated to home page", () -> {
			String title = driver.getDriver().getTitle();
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void SwitchToRM(Map<String, String> data) {
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on Salesforce home page, login as Admin", () -> {
		}).when("I Switched to RelationShip Manager", () -> {
			String strRM = data.get("Relationship_Manager");
			Reporter.log("Relationship Manager: " + strRM);
			App().Pages().getHomepage().switchToAnyUser(strRM);
			ConfigurationManager.getBundle().setProperty("RelationShip_Manager", strRM);
			ConfigurationManager.getBundle().setProperty("Credit_Analyst", data.get("Credit_Analyst"));
			ConfigurationManager.getBundle().setProperty("Owner", strRM);
		}).then("I verify switched to RelationShip Manager", () -> {
			util.waitFor(20);
			String heading = driver.getDriver()
					.findElement(By.xpath("(//header[@id='oneHeader']//span)[contains(text(),'Logged in as')]"))
					.getText();
			Validator.verifyThat("login as RM", heading,
					Matchers.containsString("Logged in as " + data.get("Relationship_Manager")));
			QAFExtendedWebElement PLDTTitle = new QAFExtendedWebElement(By.xpath("//span[@title='PLDT Enterprise']"));
			Validator.verifyTrue(PLDTTitle.isPresent(), "PLDT Enterprise App Is Not Present On Home Page",
					"PLDT Enterprise App Is Present On Home Page");
			AppUtils.mouseMover();
		}).execute();
	}

	public void setOwner(String owner) {
		ConfigurationManager.getBundle().setProperty("Owner", owner);
	}

	public void setCaseID(String owner) {
		ConfigurationManager.getBundle().setProperty("CaseID", owner);
	}

	public void SwitchToCA(Map<String, String> data) {
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on Salesforce home page, login as Admin", () -> {
		}).when("I Switched to Credit Analyst", () -> {
			String strCA = data.get("Credit_Analyst");
			Reporter.log("Credit Analyst: " + strCA);
			App().Pages().getHomepage().switchToAnyUser(strCA);
			ConfigurationManager.getBundle().setProperty("RelationShip_Manager", data.get("Relationship_Manager"));
			ConfigurationManager.getBundle().setProperty("Credit_Analyst", strCA);
			ConfigurationManager.getBundle().setProperty("Owner", strCA);
		}).then("I verify switched to Credit Analyst", () -> {
			util.waitFor(20);
			String heading = driver.getDriver()
					.findElement(By.xpath("(//header[@id='oneHeader']//span)[contains(text(),'Logged in as')]"))
					.getText();
			Validator.verifyThat("login as CA", heading,
					Matchers.containsString("Logged in as " + data.get("Credit_Analyst")));
			QAFExtendedWebElement PLDTTitle = new QAFExtendedWebElement(By.xpath("//span[@title='PLDT Enterprise']"));
			Validator.verifyTrue(PLDTTitle.isPresent(), "PLDT Enterprise App Is Not Present On Home Page",
					"PLDT Enterprise App Is Present On Home Page");
			AppUtils.mouseMover();
		}).execute();
	}

	public void SwitchToOtherUser(String user) {
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am switching the user", () -> {
			Reporter.log("Switch user to: " + user);
		}).when("I Switched to " + user, () -> {
			App().Pages().getHomepage().switchToAnyUser(user);
			ConfigurationManager.getBundle().setProperty("Owner", user);
		}).then("I verify switched to " + user, () -> {
			util.waitFor(20);
			String heading = driver.getDriver()
					.findElement(By.xpath("(//header[@id='oneHeader']//span)[contains(text(),'Logged in as')]"))
					.getText();
			Validator.verifyThat("login as user" + "", heading, Matchers.containsString("Logged in as " + user));
			QAFExtendedWebElement PLDTTitle = new QAFExtendedWebElement(By.xpath("//span[@title='PLDT Enterprise']"));
			Validator.verifyTrue(PLDTTitle.isPresent(), "PLDT Enterprise App Is Not Present On Home Page",
					"PLDT Enterprise App Is Present On Home Page");
			AppUtils.mouseMover();
		}).execute();
	}

	public void LogoutUser(Map<String, String> data) {
		WebDriverTestBase driver = new WebDriverTestBase();
		WebUtilities util = new WebUtilities();
		scenario().given("I logout as current user", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			String heading = driver.getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[1]")).getText();
			Reporter.log("Current user " + heading);
		}).when("I Logout as user", () -> {
			App().Pages().getLoginpage().logoutAsCurrentUser();
		}).then("I verify setup screen", () -> {
			util.waitFor(20);
			Reporter.logWithScreenShot("SetUp screen");
		}).execute();

	}

	public void OpenExistingAccount(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on home page", () -> {
			util.implicitlyWait(10);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			Reporter.log("given AC: " + data.get("Account_Name"));
		}).when("I am on " + data.get("Account_Name") + " Account page", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			ConfigurationManager.getBundle().setProperty("Account", data.get("Account_Name"));
			util.implicitlyWait(20);
		}).then("I verify Account", () -> {
			String heading = driver.getDriver()
					.findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']")).getText();
			String AcName = data.get("Account_Name");
			Validator.verifyThat("Account name", heading, Matchers.containsString(AcName));
			ConfigurationManager.getBundle().setProperty("AccountURL", driver.getDriver().getCurrentUrl());
			AppUtils.mouseMover();
		}).execute();
	}

	public void OpenOtherAccount(String ACName, String ACNumber, String ACindex) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on home page", () -> {
			util.implicitlyWait(10);
			Reporter.log("given AC: " + ACName);
		}).when("I am on " + ACName + " Account page", () -> {
			App().Pages().getHomepage().switchToAnyAccount(ACName, ACNumber);
			ConfigurationManager.getBundle().setProperty(ACindex + "_AccountName", ACName);
			util.implicitlyWait(20);
		}).then("I verify Account", () -> {
			String heading = driver.getDriver()
					.findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']")).getText();
			Validator.verifyThat("Account name", heading, Matchers.containsString(ACName));
			ConfigurationManager.getBundle().setProperty(ACindex + "_AccountURL", driver.getDriver().getCurrentUrl());
			AppUtils.mouseMover();
		}).execute();
	}

	public void navigateAcURL() {
		WebDriverTestBase driver = new WebDriverTestBase();
		String URL = ConfigurationManager.getBundle().getPropertyValue("AccountURL");
		driver.getDriver().navigate().to(URL);
	}

	public void CaseCreationOnAsset(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on " + data.get("Account_Name") + " Account page", () -> {
			util.implicitlyWait(10);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I choose asset and creat new case", () -> {
			App().Pages().getAccountDetailsPage().getAccountRecordType();
			App().Pages().getAccountDetailsPage().clickOnRelated("Assets");
			App().Pages().getAssetsListPage().openAssetforEEAccount(data.get("Asset_Name"), data.get("MIN_Number"),
					data.get("SFServiceID"), true);
			App().Pages().getAssetDetailsPage().getBillAccountNumber();
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			Reporter.log("Clicked on Cases link from Related section");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(15);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record_Type"));
			App().Pages().getNewCaseModal().CreatingNewCase(data);
			util.waitFor(20);
		}).then("I verify case created", () -> {
			caseID = App().Pages().getCaseListPage().FilterCaseOnAsset(data.get("Subject"));
			util.waitFor(15);
			Reporter.logWithScreenShot("New Case ID" + caseID);
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseCreationOnAccount(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on " + data.get("Account_Name") + " Account page", () -> {
			util.implicitlyWait(10);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I am creating new case", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			Reporter.log("Clicked on Cases link from Related section");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(10);
			App().Pages().getNewCaseModal().SelectNewCaseType(data.get("Record_Type"));
			App().Pages().getNewCaseModal().CreatingNewCase(data);
			util.waitFor(10);
		}).then("I verify case created", () -> {
			util.refreshPage();
			util.waitFor(6);
			caseID = App().Pages().getCaseListPage().FilterCaseOnAccount(data);
			util.waitFor(15);
			Reporter.logWithScreenShot("New Case ID" + caseID);
			AppUtils.mouseMover();
		}).execute();
	}

	public void ChangeCaseOwner(String Owner) {
		WebUtilities util = new WebUtilities();
		scenario().given("I am on case list page clicking on case link", () -> {
			util.implicitlyWait(20);
			Reporter.log("new Case Owner: " + Owner);
		}).when("I am case page to change ower", () -> {
//			util.implicitlyWait(20);
			App().Pages().getCasepage().changeOwner(Owner);
			util.waitFor(15);
		}).then("I vierfy owner changed or not", () -> {
			QAFExtendedWebElement caseOwner = new QAFExtendedWebElement(By.xpath(
					"//span[@class='test-id__section-header-title' and text()='Case Information']//following::span[@id='window']"));
//			Validator.verifyThat("Case Owner", caseOwner.getText(), Matchers.equalTo(Owner));
			util.waitFor(10);
		}).execute();
	}

	public void AcceptCase(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getHomepage().goToAPP("Cases");
		}).when("I Accept the case", () -> {
			QAFExtendedWebElement downArrowbtn = new QAFExtendedWebElement(
					By.xpath("//button[contains(@title,'Select a List View')]"));
			QAFExtendedWebElement searchBarCaseType = new QAFExtendedWebElement(
					By.xpath("//input[contains(@aria-owns,'virtualAutocompleteListbox')]"));
			QAFExtendedWebElement suggestFirstOption = new QAFExtendedWebElement(
					By.xpath("(//ul[contains(@id,'virtualAutocompleteListbox')]//a)[1]"));
			QAFExtendedWebElement searchBarCase = new QAFExtendedWebElement(
					By.xpath("//input[@name='Case-search-input']"));
			QAFExtendedWebElement caseCheckbox;
			QAFExtendedWebElement Acceptbtn = new QAFExtendedWebElement(By.xpath("//a[@title='Accept']"));
			downArrowbtn.click();
			util.waitFor(3);
			searchBarCaseType.sendKeys(data.get("CaseType_Accept"));
			util.waitFor(3);
			suggestFirstOption.click();
			util.waitFor(5);
			Reporter.log("case list filter with " + data.get("CaseType_Accept"));
			searchBarCase.sendKeys(caseID);
			searchBarCase.sendKeys(Keys.ENTER);
			util.waitFor(5);
			new QAFExtendedWebElement(By.xpath("//tbody//following::input[@type='checkbox']//parent::div")).click();
			util.waitFor(3);
			Reporter.logWithScreenShot(caseID + " is selected to accept");
			Acceptbtn.click();
			util.waitFor(20);
		}).then("I verify case accepted", () -> {
			QAFExtendedWebElement downArrowbtn = new QAFExtendedWebElement(
					By.xpath("//button[contains(@title,'Select a List View')]"));
			QAFExtendedWebElement searchBarCaseType = new QAFExtendedWebElement(
					By.xpath("//input[contains(@aria-owns,'virtualAutocompleteListbox')]"));
			QAFExtendedWebElement suggestFirstOption = new QAFExtendedWebElement(
					By.xpath("(//ul[contains(@id,'virtualAutocompleteListbox')]//a)[1]"));
			QAFExtendedWebElement searchBarCase = new QAFExtendedWebElement(
					By.xpath("//input[@name='Case-search-input']"));
			downArrowbtn.click();
			util.waitFor(3);
			searchBarCaseType.sendKeys(data.get("CaseType_Verify"));
			util.waitFor(3);
			suggestFirstOption.click();
			util.waitFor(5);
			Reporter.log("case list filter with " + data.get("CaseType_Verify"));
			searchBarCase.sendKeys(caseID);
			searchBarCase.sendKeys(Keys.ENTER);
			util.waitFor(5);
			Reporter.logWithScreenShot(caseID + "is displaying on My Cases");
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationTIN(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a//span"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationTIN(data.get("NewCompanyTIN"), data.get("Remarks"));
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationChangeBusiness(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a//span"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationChangeBusiness(data.get("New Company Trade Name"),
					data.get("Remarks"));
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationTHSRating(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(10);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a//span"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationTHSRating(data);
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationVIPCodeChange(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a//span"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationVIPCode(data);
			util.waitFor(15);
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			QAFExtendedWebElement submitApprovalBtn = new QAFExtendedWebElement(
					By.xpath("//ul[@class='slds-button-group-list']//li//button[@name='Submit']"));
			QAFExtendedWebElement submitApprovaltextArea = new QAFExtendedWebElement(
					By.xpath("//textarea[@class='inputTextArea cuf-messageTextArea textarea']"));
			QAFExtendedWebElement submitApprovalSubmit = new QAFExtendedWebElement(
					By.xpath("(//span[text()='Submit']//parent::button)[1]"));
			submitApprovalBtn.click();
			util.waitFor(3);
			submitApprovaltextArea.sendKeys(data.get("Subject"));
			util.waitFor(5);
			submitApprovalSubmit.click();
			util.waitFor(15);
		}).then("I Logout as current user", () -> {
			App().Pages().getLoginpage().logoutAsCurrentUser();
			util.waitFor(15);
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationBillCycle(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a//span"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationBillCycle(data);
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationChangeAssignee(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case list page and open case", () -> {
			util.implicitlyWait(10);
			ConfigurationManager.getBundle().setProperty("testdata", data);
			QAFExtendedWebElement caselink = new QAFExtendedWebElement(By.xpath("//tbody//tr//th//a"));
			caselink.click();
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationChangeAssignee(data);
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void VerifyTransaction(Map<String, String> data) throws InterruptedException {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case page ", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).then("I Verify Transaction generation", () -> {
//			App().Pages().getCaseDetailsPage().markCaseStatusToResolved();
//			util.waitFor(15);
//			QAFWebElement status = new QAFExtendedWebElement(By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
//			Validator.verifyThat("Status of case",status.getText(), Matchers.equalTo("Status: Resolved"));
			QAFWebElement showAlllink = new QAFExtendedWebElement(By.xpath("//a[contains(text(),'Show All')]"));
			QAFWebElement transactionlink = new QAFExtendedWebElement(
					By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'Transaction__r')]"));
			QAFWebElement transactionID = new QAFExtendedWebElement(By.xpath("(//tbody//tr//th//a)[1]"));
			showAlllink.click();
			util.waitFor(5);
			transactionlink.click();
			util.waitFor(10);
			util.refreshPage();
			util.waitFor(10);
			int numberOfRefresh = 0;
			while (!transactionID.isDisplayed() || !transactionID.isPresent() && numberOfRefresh < 5) {
				util.waitFor(30);
				util.refreshPage();
				util.waitFor(10);
				AppUtils.mouseMover();
				numberOfRefresh++;
			}
			String transID = transactionID.getText();
			Reporter.logWithScreenShot("Transaction ID: " + transID);
		}).then("I navigate back to case page", () -> {
			driver.getDriver().navigate().to(caseURL);
			util.waitFor(30);
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			// Validator.verifyThat("Status of case",status.getText(),
			// Matchers.equalTo("Status: Resolved"));
			Reporter.log("current status of the case: " + status.getText());
		}).execute();
	}

	public void VerifyTransactionStatus(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case page ", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I Verify Transaction generation", () -> {
			QAFWebElement showAlllink = new QAFExtendedWebElement(By.xpath("//a[contains(text(),'Show All')]"));
			QAFWebElement transactionlink = new QAFExtendedWebElement(
					By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'Transaction__r')]"));
			QAFWebElement transactionID = new QAFExtendedWebElement(By.xpath("(//tbody//tr//th//a//span)[1]"));
			showAlllink.click();
			util.waitFor(5);
			transactionlink.click();
			util.waitFor(10);
			util.refreshPage();
			util.waitFor(10);
			int numberOfRefresh = 0;
			while (!transactionID.isDisplayed() || !transactionID.isPresent() && numberOfRefresh < 5) {
				util.waitFor(30);
				util.refreshPage();
				util.waitFor(10);
				AppUtils.mouseMover();
				numberOfRefresh++;
			}
			String transID = transactionID.getText();
			Reporter.logWithScreenShot("Transaction ID: " + transID);
			transactionID.click();
			util.waitFor(15);
		}).then("I Verify transaction status is updated to successful", () -> {
			QAFWebElement detailTab = new QAFExtendedWebElement(By.xpath("//li[@title='Details']//a"));
			QAFWebElement TransStatus = new QAFExtendedWebElement(By.xpath(
					"(//span[text()='Transaction Information']//following::span[text()='Transaction Status']//following::lightning-formatted-text)[1]"));
			detailTab.click();
			int refreshpage = 0;
			while (TransStatus.getText().equalsIgnoreCase("In-Progress") && refreshpage < 20) {
				util.refreshPage();
				util.waitFor(30);
				if (TransStatus.getText().equalsIgnoreCase("Successful")) {
					break;
				}
				refreshpage++;
				AppUtils.mouseMover();
			}
			Validator.verifyThat("Transaction Status", TransStatus.getText(), Matchers.equalTo("Successful"));
			driver.getDriver().navigate().to(ConfigurationManager.getBundle().getPropertyValue("caseURL"));
		}).execute();
	}

	public void ApproveCase(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am login as ECM Head", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			String strECM = data.get("ECM_Head");
			Reporter.log("ECM Head: " + strECM);
			App().Pages().getHomepage().switchToAnyUser(strECM);
			util.implicitlyWait(10);
		}).when("I open case page and open approval history", () -> {
			driver.getDriver().navigate().to(caseURL);
			util.waitFor(15);
			QAFWebElement showAlllink = new QAFExtendedWebElement(By.xpath("//a[contains(text(),'Show All')]"));
			QAFWebElement approvalHistlink = new QAFExtendedWebElement(
					By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'ProcessSteps')]"));
			showAlllink.click();
			util.waitFor(5);
			approvalHistlink.click();
			util.waitFor(10);
			util.refreshPage();
			util.waitFor(10);
		}).then("I approve the case", () -> {
			QAFWebElement approveBtnApprovalHistory = new QAFExtendedWebElement(
					By.xpath("(//div[@title='Approve']//parent::a)[1]"));
			QAFWebElement txtAreaApprovalHistory = new QAFExtendedWebElement(
					By.xpath("//textarea[@class='inputTextArea cuf-messageTextArea textarea']"));
			QAFWebElement ApprveBtnApprovalHistory = new QAFExtendedWebElement(
					By.xpath("(//span[text()='Approve']//parent::button)[1]"));
			approveBtnApprovalHistory.click();
			util.waitFor(5);
			txtAreaApprovalHistory.sendKeys(data.get("Subject"));
			util.waitFor(2);
			ApprveBtnApprovalHistory.click();
			util.waitFor(15);
			AppUtils.mouseMover();
		}).execute();
	}

	public void VerifyCaseApproved(String user) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I login as" + user, () -> {
			App().Pages().getHomepage().switchToAnyUser(user);
			util.waitFor(10);
		}).when("I open case page", () -> {
			driver.getDriver().navigate().to(caseURL);
			util.waitFor(10);
		}).then("I verify status", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			if (Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"))) {
				Reporter.log("Status changed to Resolution In Progress");
			} else {
				Reporter.log("Status not changed to Resolution In Progress");
			}
			AppUtils.mouseMover();
		}).execute();
	}

	public void OpenAsset(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		scenario().given("I am on " + data.get("Account_Name") + " Account page", () -> {
			util.implicitlyWait(10);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I choose asset from asset list page", () -> {
			util.implicitlyWait(10);
			// App().Pages().getAccountDetailsPage().getAccountRecordType();
			App().Pages().getAccountDetailsPage().clickOnRelated("Assets");
			App().Pages().getAssetsListPage().openAssetforEEAccount(data.get("Asset_Name"), data.get("MIN_Number"),
					data.get("SFServiceID"), true);
			// App().Pages().getAssetDetailsPage().getBillAccountNumber();
		}).then("I verify Asset Open", () -> {
			util.implicitlyWait(10);
			QAFWebElement assetMINNumber = new QAFExtendedWebElement(
					By.xpath("(//p[@title='MIN']//following::slot)[1]//lightning-formatted-text"));
			Validator.verifyThat("Asset MIN Number", assetMINNumber.getText(),
					Matchers.equalTo(data.get("MIN_Number")));
		}).execute();
	}

	public void OpenBillingAccount(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		scenario().given("I am on " + data.get("Asset_Name") + " Asset page", () -> {
			util.implicitlyWait(10);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I open billing account", () -> {
			util.implicitlyWait(15);
			String billingAc = App().Pages().getAssetDetailsPage().getBillingAccount();
			Reporter.log("Billing Account: " + billingAc);
			util.implicitlyWait(5);
			QAFWebElement billingAclink = new QAFExtendedWebElement(By.xpath(
					"(//span[text()='Account Information']//following::span[text()='Billing Account']//following::a)[1]"));
			util.clickUsingJs(billingAclink);
			util.waitFor(20);
		}).then("I verify Asset Open", () -> {
			util.implicitlyWait(10);
			util.scrollDown();
			QAFWebElement CollectionStatus = new QAFExtendedWebElement(By.xpath(
					"(//span[text()='System SMART Integration Updates']//following::span[text()='SFDC Collection Status']//following::lightning-formatted-text)[1]"));
			Validator.verifyThat("SFDC Collection Status", CollectionStatus.getText(), Matchers.equalTo("ACTIVE"));
			QAFWebElement THSStatus = new QAFExtendedWebElement(By.xpath(
					"(//span[text()='System SMART Integration Updates']//following::span[text()='SFDC THS Status']//following::lightning-formatted-text)[1]"));
			Validator.verifyThat("SFDC THS Status", THSStatus.getText(), Matchers.equalTo("ACTIVE"));
		}).execute();
	}

	public void CaseModificationTransferofService(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case details page", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I am modify case", () -> {
//			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationTransService(data);
			App().Pages().getCaseDetailsPage().selectRequiredDocument();
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void CaseModificationTransferofOwner(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case details page", () -> {
			util.implicitlyWait(15);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I am modify case", () -> {
			util.waitFor(15);
			App().Pages().getCaseDetailsPage().caseModificationTransOwner(data);
			App().Pages().getCaseDetailsPage().selectRequiredDocument();
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			Reporter.log("case URL: " + caseURL);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void CreateBillingAccountOnCase(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case details page", () -> {
			util.implicitlyWait(8);
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I am creating new billing account", () -> {
			util.waitFor(5);
			clickOnNewBillingAC();
			AlertClose();
			FillNewBillingACINFO(data);
			FillNewBillingCustomerProfile(data);
			FillNewBillingSMARTINFO(data);
			FillNewBillingContactPreferences();
			FillNewBillingAddressINFO(data);
			NewBillingACSave();
			util.waitFor(25);
		}).then("I verify newly created billing account", () -> {
			ConfigurationManager.getBundle().setProperty("caseURL", driver.getDriver().getCurrentUrl());
			caseURL = ConfigurationManager.getBundle().getPropertyValue("caseURL");
			QAFWebElement showAllLink = new QAFExtendedWebElement(By.xpath("//a[contains(text(),'Show All')]"));
			QAFWebElement AccountsLink = new QAFExtendedWebElement(
					By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'Accounts__r')]"));
			util.waitFor(10);
			showAllLink.click();
			util.waitFor(2);
			AccountsLink.click();
			util.waitFor(2);
			util.refreshPage();
			util.waitFor(10);
			String BillingAcName = ConfigurationManager.getBundle().getPropertyValue("BillingAccountName");
			QAFWebElement Acname = new QAFExtendedWebElement(
					By.xpath("(//span[text()='" + BillingAcName + "'])[last()]"));
			boolean Acnamelink = Acname.isPresent() && Acname.isDisplayed();
			Validator.verifyTrue(Acnamelink, "Newly Created Account name not displayed",
					"Newly Created Account name is displayed");
			util.waitFor(20);
			driver.getDriver().navigate().to(ConfigurationManager.getBundle().getPropertyValue("caseURL"));
			util.waitFor(20);
			AppUtils.mouseMover();
		}).execute();
	}

	public void clickOnNewBillingAC() {
		WebUtilities util = new WebUtilities();
		QAFWebElement showAllLink = new QAFExtendedWebElement(By.xpath("//a[contains(text(),'Show All')]"));
		QAFWebElement AccountsLink = new QAFExtendedWebElement(
				By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'Accounts__r')]"));
		QAFWebElement newBillingBtn = new QAFExtendedWebElement(By.xpath("//button[text()='New Billing']"));
		QAFWebElement headingNewAccountBilling = new QAFExtendedWebElement(
				By.xpath("//h2[text()='New Account: Billing']"));
		util.waitFor(10);
		showAllLink.click();
		util.waitFor(2);
		AccountsLink.click();
		util.waitFor(2);
		newBillingBtn.click();
		util.waitFor(20);
		boolean headingAccountBilling = headingNewAccountBilling.isPresent() && headingNewAccountBilling.isDisplayed();
		Validator.verifyTrue(headingAccountBilling, "New Billing Account popup box is not displayed",
				"New Billing Account popup box displayed");
	}

	public void FillNewBillingACINFO(Map<String, String> data) {
		TestDataBean bean = new TestDataBean();
		WebUtilities util = new WebUtilities();
		bean.fillRandomData();
//		By parentAcInput= By.xpath("(//span[text()='Parent Account']//following::input[@title='Search Accounts'])[1]");
		String BillingAcName = bean.getFirstName() + "billingaccount";
		ConfigurationManager.getBundle().setProperty("BillingAccountName", BillingAcName);
		util.waitFor(5);
		util.type("Account Name", BillingAcName);
		util.waitFor(3);
//		util.selectAndClickCaseSuggestedValue(parentAcInput, data.get("Parent Account"));
		util.waitFor(3);
		util.select("LoB (Line of Business)");
		Reporter.logWithScreenShot("Account Information");
	}

	public void FillNewBillingCustomerProfile(Map<String, String> data) {
		TestDataBean bean = new TestDataBean();
		WebUtilities util = new WebUtilities();
		bean.fillRandomData();
//		By BillDispatch = By.xpath("//span[text()='Customer Profile']//following::span[text()='Bill Dispatch Method']//following::input[@title='Search Bill Dispatch Method LOV']");
		By BillCycle = By.xpath(
				"//span[text()='Customer Profile']//following::span[text()='Bill Cycle']//following::input[@title='Search Bill Cycle LOV']");
		By TaxProfile = By.xpath(
				"//span[text()='Customer Profile']//following::span[text()='Smart Tax Profile']//following::input[@title='Search Tax Profile LOV']");
		util.select("Industry");
		util.waitFor(3);
		util.type("Company TIN");
		util.waitFor(3);
		util.select("Industry Sub Type");
		util.waitFor(3);
		util.select("Bill Frequency");
		util.waitFor(3);
		util.searchAndSelect(BillCycle, data.get("Bill cycle"));
		util.waitFor(3);
		util.select("Smart Tax Exemption");
		util.waitFor(3);
		util.searchAndSelect(TaxProfile, data.get("Smart Tax Profile"));
		util.waitFor(3);
		util.type("eSOA Notification Email ID", bean.getOther() + "@capgemini.com");
		util.waitFor(10);
		Reporter.logWithScreenShot("Customer Profile");
	}

	public void FillNewBillingSMARTINFO(Map<String, String> data) {
		TestDataBean bean = new TestDataBean();
		WebUtilities util = new WebUtilities();
		bean.fillRandomData();
		By AccTypeCode = By.xpath(
				"//span[text()='SMART Billing Information']//following::span[text()='Account Type Code']//following::input[@title='Search Account Type LOV']");
		By Subscription = By.xpath(
				"//span[text()='SMART Billing Information']//following::span[text()='Subscription']//following::input[@title='Search Subscription LOV']");
		By VIPCode = By.xpath(
				"//span[text()='SMART Billing Information']//following::span[text()='VIP Code']//following::input[@title='Search VIP Code LOV']");
		util.searchAndSelect(AccTypeCode, data.get("Account Type Code"));
		util.waitFor(3);
		util.searchAndSelect(Subscription, data.get("Subscription"));
		util.waitFor(3);
		util.searchAndSelect(VIPCode, data.get("VIP Code"));
		util.waitFor(3);
		util.type("Assignee/ CI First Name", bean.getFirstName());
		util.waitFor(3);
		util.type("Assignee/ CI Middle Name", bean.getMiddleName());
		util.waitFor(3);
		util.type("Assignee/ CI Last Name", bean.getLastName());
		util.waitFor(3);
		Reporter.logWithScreenShot("Billing SMART Information");
	}

	public void FillNewBillingContactPreferences() {
		TestDataBean bean = new TestDataBean();
		WebUtilities util = new WebUtilities();
		bean.fillRandomData();
		util.type("Notify Email ID", bean.getOther() + "@capgemini.com");
		util.waitFor(3);
		String MobileNo = String.format("639%s", bean.getPhone_mobile().toString());
		MobileNo = StringUtils.rightPad(MobileNo, 12, "0");
		util.type("Notify Mobile No", MobileNo);
		util.waitFor(3);
		Reporter.logWithScreenShot("Contact Preferences");
	}

	public void FillNewBillingAddressINFO(Map<String, String> data) {
		WebUtilities util = new WebUtilities();
		By BillingCity = By.xpath(
				"//span[text()='Billing Address Information']//following::span[text()='Billing City']//following::input[@title='Search Cities']");
		By BARANGAY = By.xpath(
				"//span[text()='Billing Address Information']//following::span[text()='BARANGAY']//following::input[@title='Search Barangays']");
		By Postal = By.xpath(
				"//span[text()='Billing Address Information']//following::span[text()='Billing Zip/Postal Code']//following::input[@title='Search ZipCodes']");
		util.type("Billing Address Line 1");
		util.waitFor(3);
		util.select("Billing State/Province");
		util.waitFor(3);
		util.searchAndSelect(BillingCity, data.get("Billing City"));
		util.waitFor(3);
		util.searchAndSelect(BARANGAY, data.get("BARANGAY"));
		util.waitFor(3);
		util.searchAndSelect(Postal, data.get("Billing Zip/Postal Code"));
		util.waitFor(3);
		Reporter.logWithScreenShot("Address Information");
	}

	public void NewBillingACSave() {
		WebUtilities util = new WebUtilities();
		QAFExtendedWebElement SaveBtn = new QAFExtendedWebElement(
				By.xpath("(//span[text()='Save']//parent::button[@title='Save'])[1]"));
		SaveBtn.click();
		util.waitFor(15);
	}

	public void caseOpen() {
		WebUtilities util = new WebUtilities();
		util.implicitlyWait(15);
		QAFExtendedWebElement caselink = new QAFExtendedWebElement(
				By.xpath("//tbody//tr//th//a|//tbody//tr//th//a//span"));
		caselink.click();
		util.waitFor(15);
	}

	public void CaseOwnercheck(String expOwner) {
		String Actualowner = App().Pages().getCaseDetailsPage().getCaseOwner();
		// Validator.verifyThat("Current Owner of case", Actualowner,
		// Matchers.equalTo(expOwner));
	}

	public void AlertClose() {
		WebUtilities util = new WebUtilities();
		QAFExtendedWebElement AlertpopUp = new QAFExtendedWebElement(By.xpath("//div[text()='Alert!']"));
		if (AlertpopUp.isPresent() && AlertpopUp.isDisplayed()) {
			Reporter.logWithScreenShot("Alert displayed");
			QAFExtendedWebElement alertclosebtn = new QAFExtendedWebElement(
					By.xpath("(//div[text()='Alert!']//following::button)[1]"));
			alertclosebtn.click();
			util.waitFor(10);
		} else {
			Reporter.logWithScreenShot("Alert not displayed");
		}
	}

	public void StatusChangeToResolutionInProgress() {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case details page", () -> {
			util.implicitlyWait(5);
		}).when("I change status to Resolution in Progress", () -> {
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I verify case status change to Resolution Inprogress", () -> {
			util.implicitlyWait(10);
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(),
					Matchers.equalTo("Status: Resolution In Progress"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void StatusChangeToResolved() {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am on case details page", () -> {
			util.implicitlyWait(15);
		}).when("I change status to Resolved", () -> {
			App().Pages().getCaseDetailsPage().markCaseStatusToResolved();
		}).then("I verify case status change to Resolved", () -> {
			util.implicitlyWait(15);
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(), Matchers.equalTo("Status: Resolved"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void VerifyCaseStatus(String Status) {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		util.implicitlyWait(15);
		QAFWebElement status = new QAFExtendedWebElement(
				By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
		Validator.verifyThat("Status of case", status.getText(), Matchers.equalTo("Status: " + Status + ""));
		AppUtils.mouseMover();
	}

	public void VerifyPaymentsInquiry() {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I on case details page", () -> {
			util.implicitlyWait(15);
		}).when("I go to Payments Inquiry", () -> {
			QAFWebElement showAllLink = new QAFExtendedWebElement(By.xpath("//a[contains(text(),'Show All')]"));
			QAFWebElement AccountsLink = new QAFExtendedWebElement(
					By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'Accounts__r')]"));
			util.waitFor(10);
			showAllLink.click();
			util.waitFor(3);
			AccountsLink.click();
			util.waitFor(20);
			String BillingAcName = ConfigurationManager.getBundle().getPropertyValue("BillingAccountName");
			QAFWebElement Acname = new QAFExtendedWebElement(
					By.xpath("(//span[text()='" + BillingAcName + "'])[last()]"));
			Acname.click();
			util.waitFor(10);
		}).then("I get Kenan Billing Account Number", () -> {
			QAFWebElement KenanInquirylink = new QAFExtendedWebElement(By.xpath("//a[text()='Kenan Inquiry']"));
			QAFWebElement PaymentInquiryBtn = new QAFExtendedWebElement(By.xpath("//button[text()='Payment Inquiry']"));
			QAFWebElement KenanBillingAcNum = new QAFExtendedWebElement(By
					.xpath("//label[text()='Kenan Billing Account Number']//following::input[@name='txtBillAcctId']"));
			KenanInquirylink.click();
			util.waitFor(4);
			util.clickUsingJs(PaymentInquiryBtn);
			util.waitFor(5);
			String billACNum = KenanBillingAcNum.getText();
			ConfigurationManager.getBundle().setProperty("KenanBillingAcNum", billACNum);
			util.waitFor(10);
			AppUtils.mouseMover();
		}).execute();
	}

	public void VerifyBillingAsset() {
		WebUtilities util = new WebUtilities();
		scenario().given("I am case page click on trasaction details", () -> {
			util.implicitlyWait(15);
			QAFWebElement transactionDetailsC = new QAFExtendedWebElement(
					By.xpath("//a[text()='Transaction Details']"));
			transactionDetailsC.click();
			util.waitFor(10);
		}).when("I open new billing account", () -> {
			String billingAcName = ConfigurationManager.getBundle().getPropertyValue("BillingAccountName");
			QAFWebElement billingAcLine = new QAFExtendedWebElement(By
					.xpath("(//span[text()='New Billing Account']//following::a[text()='" + billingAcName + "'])[1]"));
			util.clickUsingJs(billingAcLine);
			util.waitFor(15);
		}).then("I open billing asset page", () -> {
			QAFWebElement showAlllink = new QAFExtendedWebElement(By.xpath("//a[contains(text(),'Show All')]"));
			QAFWebElement BillingAssets = new QAFExtendedWebElement(
					By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'BillingAccountAssets__r')]"));
			QAFWebElement Asset = new QAFExtendedWebElement(By.xpath("(//tbody//tr//th//a//span)[1]"));
			showAlllink.click();
			util.waitFor(8);
			BillingAssets.click();
			util.waitFor(15);
			util.refreshPage();
			util.waitFor(15);
			boolean assetdisplay = Asset.isPresent() && Asset.isDisplayed();
			Validator.verifyTrue(assetdisplay, "Change owner is not successful", "Change owner is successful");
		}).execute();
	}

	public void ClickBulkServiceRequest() {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I am on home page", () -> {
			util.implicitlyWait(15);
		}).when("Click on Bulk Service Request button", () -> {
			QAFWebElement moreButton = new QAFExtendedWebElement(By.xpath("(//span[text()='More']//parent::a)[1]"));
			QAFWebElement BulkServiceRequestsButton = new QAFExtendedWebElement(
					By.xpath("//a[@title='Bulk Service Requests']"));
			QAFWebElement BulkServiceRequestslink = new QAFExtendedWebElement(
					By.xpath("(//a[contains(@href,'Bulk_Service_Request__c')])[last()]"));
			moreButton.click();
			util.waitFor(4);
			if (BulkServiceRequestslink.isPresent() && BulkServiceRequestslink.isDisplayed()) {
				util.clickUsingJs(BulkServiceRequestslink);
			} else {
				BulkServiceRequestsButton.click();
			}
		}).then("I verify Bulk Service Request page is open", () -> {
			util.implicitlyWait(15);
			QAFWebElement table = new QAFExtendedWebElement(By.xpath("//table[@aria-label='Recently Viewed']"));
			boolean bulkpagetable = table.isDisplayed() && table.isPresent();
			Validator.verifyTrue(bulkpagetable, "Bulk Service Requests page is not open",
					"Bulk Service Requests page is open");
			AppUtils.mouseMover();
		}).and("Click on Import and switch window", () -> {
			QAFWebElement Import = new QAFExtendedWebElement(By.xpath("//a[@title='Import']"));
			Import.click();
			util.waitFor(5);
			ArrayList<String> tabs = new ArrayList<String>(driver.getDriver().getWindowHandles());
			driver.getDriver().switchTo().window(tabs.get(tabs.size() - 1));
			util.waitFor(5);
			QAFWebElement DataImport = new QAFExtendedWebElement(
					By.xpath("//span[text()='Import your Data into Salesforce']"));
			boolean DataImportWizard = DataImport.isDisplayed() && DataImport.isPresent();
			Validator.verifyTrue(DataImportWizard, "Import your Data into Salesforce is not open",
					"Import your Data into Salesforce is open");
		}).execute();
	}

	public void SwitchToDefaultWindow() {
		WebDriverTestBase driver = new WebDriverTestBase();
		driver.getDriver().switchTo().window(ConfigurationManager.getBundle().getPropertyValue("defaultWindow"));
		Reporter.logWithScreenShot("Switched back to main window");
	}

	public void getDefaultWindow() {
		WebDriverTestBase driver = new WebDriverTestBase();
		String defaultWindow = driver.getDriver().getWindowHandle();
		ConfigurationManager.getBundle().setProperty("defaultWindow", defaultWindow);
	}

	public void ImportBulkFile(String lookupfieldvalue, String path) {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		WebDriverTestBase driver = new WebDriverTestBase();
		scenario().given("I am on Data Import Wizard page", () -> {
			util.waitFor(5);
		}).when("Click on Bulk Service Request button", () -> {
			QAFWebElement Customobjectslink = new QAFExtendedWebElement(By.xpath("//a[text()='Custom objects']"));
			QAFWebElement BulkServiceRequestslink = new QAFExtendedWebElement(
					By.xpath("//a[text()='Bulk Service Requests']"));
			QAFWebElement Addnewrecordlink = new QAFExtendedWebElement(By.xpath("//a[text()='Add new records']"));
			QAFWebElement selectlookupfield = new QAFExtendedWebElement(By.xpath(
					"//span[text()='Which Account field in your file do you want to match against to set the Billing Account Number lookup field?']//following::select"));
			QAFWebElement CSV = new QAFExtendedWebElement(By.xpath("(//span[text()='CSV']//ancestor::a)[1]"));
			QAFWebElement fileinput = new QAFExtendedWebElement(By.xpath("//input[@name='file']"));
			QAFWebElement nextButton = new QAFExtendedWebElement(By.xpath("//a[text()='Next']"));
			QAFWebElement Unmapped = new QAFExtendedWebElement(By.xpath("//td[@title='Unmapped']"));
			QAFWebElement StartImportbutton = new QAFExtendedWebElement(By.xpath("//a[text()='Start Import']"));
			QAFWebElement OkButton = new QAFExtendedWebElement(By.xpath("//a[text()='OK']"));
			Customobjectslink.click();
			util.waitFor(4);
			BulkServiceRequestslink.click();
			util.waitFor(4);
			Addnewrecordlink.click();
			util.waitFor(4);
			util.selectOptionByPartialText(selectlookupfield, lookupfieldvalue);
			util.waitFor(4);
			CSV.click();
			util.waitFor(4);
			fileinput.sendKeys(path);
			util.waitFor(10);
			nextButton.click();
			util.waitFor(15);
//			boolean Unmappedfiled = Unmapped.isDisplayed() && Unmapped.isPresent();
//          Validator.verifyTrue(Unmapped.isPresent(), "please check unmmaped filed present", "All fields are mapped");
			nextButton.click();
			util.waitFor(8);
			StartImportbutton.click();
			util.waitFor(4);
			OkButton.click();
		}).then("I verify Bulk Data Load Job", () -> {
			util.waitFor(20);
			util.refreshPage();
			util.waitFor(8);
			QAFWebElement Status = new QAFExtendedWebElement(
					By.xpath("((//div[@class='pbBody'])[last()]//tbody//tr//td)[last()]"));
			Validator.verifyThat("I verify Batch status", Status.getText(), Matchers.equalTo("Completed"));
			AppUtils.mouseMover();
		}).execute();
	}

	public void ClickOnKenanInquiry() {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("User is on Account page", () -> {
			util.implicitlyWait(15);
		}).when("user clicked on Kenan Inquiry link", () -> {
			QAFWebElement KenanInquirylink = new QAFExtendedWebElement(By.xpath("//a[text()='Kenan Inquiry']"));
			KenanInquirylink.click();
			util.waitFor(15);
		}).then("User verify Inquiry buttons display", () -> {
			QAFWebElement table = new QAFExtendedWebElement(
					By.xpath("//flexipage-component2[@data-target-selection-name='InquiryButtonsBillingAccount']"));
			boolean buttonsTable = table.isPresent() && table.isDisplayed();
			Validator.verifyTrue(buttonsTable, "User is not able to click On Kenan Inquiry",
					"User is able to click On Kenan Inquiry");
			AppUtils.mouseMover();
		}).execute();
	}

	public void ClickOnPaymentInquiry() {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("User is on Kenan Inquiry tab", () -> {
			util.implicitlyWait(15);
		}).when("user clicked on Payment Inquiry button", () -> {
			QAFWebElement PaymentInquirybtn = new QAFExtendedWebElement(By.xpath("//button[text()='Payment Inquiry']"));
//			PaymentInquirybtn.click();
			util.clickUsingJs(PaymentInquirybtn);
			util.waitFor(15);
		}).then("User verify  Kenan Form display", () -> {
			QAFWebElement KenanForm = new QAFExtendedWebElement(By.xpath("//form//div[@aria-labelledby='Kenan Form']"));
			boolean form = KenanForm.isPresent() && KenanForm.isDisplayed();
			Validator.verifyTrue(form, "User is not able to click On Payment Inquiry",
					"User is able to click On Payment Inquiry");
			AppUtils.mouseMover();
		}).execute();
	}

	public void enterKenanStartEnd(String startdate, String enddate) {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("User is on Kenan Inquiry tab", () -> {
			util.implicitlyWait(15);
		}).when("user entered start and end dates", () -> {
			QAFWebElement startDateInput = new QAFExtendedWebElement(By.xpath("//input[@name='txtStartDateRange']"));
			QAFWebElement endDateInput = new QAFExtendedWebElement(By.xpath("//input[@name='txtEndDateRange']"));
			startDateInput.clear();
			startDateInput.sendKeys(startdate);
			util.waitFor(6);
			endDateInput.clear();
			endDateInput.sendKeys(enddate);
			util.waitFor(15);
		}).then("User click on Copy URL to Clipboard", () -> {
			QAFWebElement copyurl = new QAFExtendedWebElement(By.xpath("//button[text()='Copy Url to clipboard']"));
			util.clickUsingJs(copyurl);
			// copyurl.click();
			AppUtils.mouseMover();
		}).execute();
	}

	public void refreshPage() {
		WebUtilities util = new WebUtilities();
		util.refreshPage();
	}

	public void ModifyTransaction() {
		WebUtilities util = new WebUtilities();
		WebDriverTestBase driver = new WebDriverTestBase();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I open transaction ", () -> {
			util.implicitlyWait(15);
			QAFWebElement showAlllink = new QAFExtendedWebElement(
					By.xpath("(//a[contains(text(),'Show All')])[last()]"));
			QAFWebElement transactionlink = new QAFExtendedWebElement(
					By.xpath("//li[@class='rlql-relatedListQuickLink']//a[contains(@href,'Transaction__r')]"));
			// (//tbody//tr//th//a//span)[1]
			QAFWebElement transactionID = new QAFExtendedWebElement(
					By.xpath("(//tbody//tr//th[@data-label='Transaction Id']//a//slot/span)"));

			showAlllink.click();
			util.waitFor(5);
			transactionlink.click();
			util.waitFor(10);
			util.refreshPage();
			util.waitFor(10);
			int numberOfRefresh = 0;
			while (!transactionID.isDisplayed() || !transactionID.isPresent() && numberOfRefresh < 5) {
				util.waitFor(30);
				util.refreshPage();
				util.waitFor(10);
				AppUtils.mouseMover();
				numberOfRefresh++;
			}
			String transID = transactionID.getText();
			System.out.println(transID);
			System.out.println(transID);
			transactionID.click();
		}).then("I edit Transaction status", () -> {
			QAFExtendedWebElement editTranStatusButton = new QAFExtendedWebElement(
					By.xpath("//button[@title='Edit Transaction Status']"));
			editTranStatusButton.click();
			util.waitFor(5);
			QAFExtendedWebElement status = new QAFExtendedWebElement(By.xpath(
					"//label[text()='Transaction Status']//following::button[contains(@aria-label,'Transaction Status,')]"));
			util.clickUsingJs(status);
			QAFExtendedWebElement DropDownelement = new QAFExtendedWebElement(
					"xpath=//lightning-base-combobox-item[@data-value='Successful']|//a[@title='Successful']");
			util.clickUsingJs(DropDownelement);
			QAFExtendedWebElement saveButton = new QAFExtendedWebElement(By.xpath("//button[@name='SaveEdit']"));
			saveButton.click();
			util.waitFor(15);
		}).then("I navigate back to case page and verify Status: Closed", () -> {
			driver.getDriver().navigate().to(caseURL);
			util.waitFor(20);
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(), Matchers.equalTo("Status: Closed"));
		}).execute();
	}

	public void navigateCaseURL() throws InterruptedException {
		getDriver().navigate().to(ConfigurationManager.getBundle().getPropertyValue("caseURL"));
		Thread.sleep(20);
	}

	public void putCaseURL() throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("caseURL", getDriver().getCurrentUrl());
		Thread.sleep(5);
	}

	public void ChangeStatusClosed() {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am Case page", () -> {
//        }).when("I change case status to closed", () -> {
//            App().Pages().getCaseDetailsPage().markCaseStatusToClosed();
		}).then("I verify status closed", () -> {
			util.waitFor(30);
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(), Matchers.equalTo("Status: Closed"));
		}).execute();
	}

	public void VerifyBSRCases(String subject) {
		WebUtilities util = new WebUtilities();
		AppCommons AppUtils = new AppCommons();
		scenario().given("I am navigating to Bulk Service Requests", () -> {
			// App().Pages().getHomepage().goToAPP("Bulk Service Requests");
		}).when("I filter records based on subject", () -> {
			SortALlBSR(subject);
			util.waitFor(20);
		}).then("verify cases", () -> {
			copyBSRCaseLinks(util, AppUtils);
		}).execute();
	}

	public void SortALlBSR(String subject) {
		QAFExtendedWebElement downArrowbtn = new QAFExtendedWebElement(
				By.xpath("//button[@title='Select a List View']"));
		QAFExtendedWebElement AllBtn = new QAFExtendedWebElement(
				By.xpath("//span[text()='All' and @class=' virtualAutocompleteOptionText']//parent::a"));
		downArrowbtn.click();
		AllBtn.click();
		QAFExtendedWebElement searchInput = new QAFExtendedWebElement(
				By.xpath("//input[@name='Bulk_Service_Request__c-search-input']"));
		searchInput.sendKeys(subject);
		searchInput.sendKeys(Keys.ENTER);
		searchInput.sendKeys(Keys.TAB);
	}

	public void copyBSRCaseLinks(WebUtilities util, AppCommons AppUtils) {
		String CaseNum = null;
		QAFExtendedWebElement refresh = new QAFExtendedWebElement(By.xpath("//button[@name='refreshButton']"));
		refresh.click();
		List<String> AllLinks = new ArrayList<>();
		List<WebElement> numOfRecords = getDriver().findElements(By.xpath("//tbody//tr"));
		for (int i = 1; i == numOfRecords.size(); i++) {
			QAFExtendedWebElement status = new QAFExtendedWebElement(
					By.xpath("(//tbody//tr[" + i + "]//td//a//following::td//span[@class='slds-truncate'])[1]"));
			for (int j = 0; j <= 20; j++) {
				util.waitFor(20);
				if (status.getText().equalsIgnoreCase("success")) {
					break;
				}
				refresh.click();
				AppUtils.mouseMover();
			}
			QAFExtendedWebElement link = new QAFExtendedWebElement(By.xpath("(//tbody//tr[" + i + "]//td//a)[1]"));
			Validator.verifyTrue(link.getAttribute("href") != null, "Import case number not generated",
					"Import case number generated");
			AllLinks.add(link.getAttribute("href"));
			CaseNum = link.getAttribute("title");
			Reporter.log("Import case number: " + CaseNum);
		}
		for (String url : AllLinks) {
			getDriver().navigate().to(url);
			util.waitFor(20);
			Reporter.log("Navigated to case number: " + CaseNum);
			QAFWebElement status = new QAFExtendedWebElement(
					By.xpath("//p[@class='stepLabel slds-path__stage-name']//span"));
			Validator.verifyThat("Status of case", status.getText(), Matchers.equalTo("Status: Resolved"));
		}
	}
}
