package com.pldt.tests.ePLDT.TaskCreation;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class TaskCreation_BusinessAccount extends BaseTest {
	PageLib pages = new PageLib();
	AppCommons AppUtils = new AppCommons();
	WebUtilities util = new WebUtilities();
	String AccountOwner = null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("User log in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
			App().Pages().getLoginpage().LoginAsAdmin();
		}).then("Verify that user login as Admin", () -> {
			util.waitFor(5);
			String title = getDriver().getTitle();
			Validator.verifyThat("User logged in as admin ", title, Matchers.equalTo("Home | Salesforce"));
			Reporter.logWithScreenShot("Logged in as Admin", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Switch to RelationShip Manager", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void Switching_to_RelationShipManager(Map<String, String> data) {
		scenario().given("User Switched to RelationShip Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			ConfigurationManager.getBundle().setProperty("RelationShip_Manager", data.get("Relationship Manager"));
		}).then("verify that User is Switched to RelationShip Manager", () -> {
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading,
					Matchers.containsString("Logged in as " + data.get("Relationship Manager")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Creating Lead", priority = 3, dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void CreatingLead(Map<String, String> data) {
		scenario().given("User is on lead page", () -> {
		}).when("User create the lead", () -> {
			util.waitFor(5);
			pages.getHomepage().goToAPP("Leads");
			pages.getLeadpage().getLeadNewButton().verifyVisible();
			pages.getLeadpage().getLeadNewButton().click();
			pages.getLeadpage().selectRecordType("business");
			pages.getLeadpage().getLeadNextButton().click();
			pages.getLeadpage().fillTheLeadForm(data);
		}).then(" User verified lead is created", () -> {
			Validator.verifyThat("", AppUtils.getToastMessage().replaceAll("\"", ""), Matchers.containsString(
					ConfigurationManager.getBundle().getPropertyValue("Lead.fullName") + " was created"));
			util.waitForLeadPage();
			util.waitFor(5);
		}).when("User change lead status and verify lead status", () -> {
			pages.getLeadpage().markLeadStatusAsQualified();
			Validator.verifyThat("Verify lead status changed to Qualified", AppUtils.getToastMessage(),
					Matchers.containsString("Status changed successfully"));
			ProjectBeans.setLeadURL(getDriver().getCurrentUrl());
			pages.getLoginpage().logoutCurrentUser();
		}).and("User convert lead", () -> {
			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			getDriver().get(ProjectBeans.getLeadURL());
			util.waitForLeadPage();
			pages.getLeadpage().validateCreditCheck();
			pages.getLeadpage().convertLead(data);
		}).then("Verify lead is created and account also got created", () -> {
			Reporter.logWithScreenShot("Lead is Converted and account got created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Validate Account Owner", priority = 4, dependsOnMethods = { "CreatingLead" })
	public void ValidateAccountOwner(Map<String, String> data) {		
		scenario().given("User is on Account page and fetching account owner name", () -> {
			getDriver().get(ProjectBeans.getAccountURL());
			util.waitForAccountPage();
			util.waitFor(By.xpath("(//div[.='Account Owner']//following::div[1]//span)[1]"), 30, true);
			AccountOwner = getDriver().findElement(By.xpath("//button[@title='Change Owner']/preceding::slot[1]/span"))
					.getText();
			System.out.println(AccountOwner);
			Reporter.log("Captured account owner" + AccountOwner);
		}).then("Verified the account owner ", () -> {
			Validator.verifyThat("verify account Owner", AccountOwner, Matchers.equalTo(data.get("Relationship Manager")));
		}).execute();
	}
	
	@Test(priority = 5, dependsOnMethods = { "ValidateAccountOwner" })
	public void getReferenceData() {
		Reporter.log("Lead URL :" + ProjectBeans.getLeadURL(), MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
	}

}
