package com.pldt.tests.SMART.MNP;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.Map;

import org.testng.annotations.Test;

import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class Syniverse_DisconnectRequestTest extends BaseTest {
	@QAFDataProvider(dataFile = "resources/testdata/Syniverse.xlsx", sheetName = "Login", filter = "TestCase=='Syniverse'")
	@Test(description = "Login", priority = 1)
	public void syniverselogin(Map<String, String> data) {
		scenario().given("User Log into Syniverse Application", () -> {
			App().Pages().getSyniverseLogin().launchPage(null, null);
			props.setProperty("testdata", data);
			App().Pages().getSyniverseLogin().LoginAsAdmin(data);
			Reporter.logWithScreenShot("Syniverse portal page");
		}).and("Click On Dashboard link", () -> {
			App().Pages().getSyniverseLogin().ClickOnDashboardLink();
			App().Pages().getSyniverseHomePage().launchPage(null, null);
			Reporter.logWithScreenShot("Syniverse home page");
		}).then("Switch Network to 102 vSmart", () -> {
			App().Pages().getSyniverseLogin().SwitchNetwork();
			Reporter.logWithScreenShot("Syniverse Switch Network");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/Syniverse.xlsx", sheetName = "DisconnectRequest",filter="TestCase=='Syniverse'")
	@Test(description = "Disconnect Request", priority = 2, dependsOnMethods = { "syniverselogin" })
	public void DisconnectRequest(Map<String, String> data) {
		scenario().given("Click on Disconnect Request to open form", () -> {
		App().Pages().getSyniverseDisconnectPage().ClickDisconnectRequest();
		Reporter.logWithScreenShot("Disconnect Request form");
		}).and("Enter Values in form", () -> {
		props.setProperty("testdata", data);
		App().Pages().getSyniverseDisconnectPage().DisconnectRequest(data);
		Reporter.logWithScreenShot("Disconnect Request form with values");
		}).then("", () -> {
		}).execute();
	}

}
