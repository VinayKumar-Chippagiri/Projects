package com.pldt.tests.SMART.MNP;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ExcelReader;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class MNPPortOut_Bulk_TC02 extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	ExcelReader excelRead = new ExcelReader();
	PageLib pages = new PageLib();
	String caseURL = null;
	String orderURL = null;
	ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Login",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) throws InterruptedException {
		scenario().given("User Log into PLDT Application as admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).when("User Switched as Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to Relationship manager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to Relationship Manager user", () -> {
			Reporter.logWithScreenShot("Successfully switched to RM");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Case",key = "${key.name}")
	@Test(description = "Creating new case for MNP portout", priority = 2, dependsOnMethods = { "Login" })
	public void createNewCaseAndAcceptCase(Map<String, String> data) {
		scenario().given("Going in account and selecting asset", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).when("Creating case and checking case owner", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(8);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getCasepage().createNewCase();
			caseURL= getDriver().getCurrentUrl();
			App().Pages().getLoginpage().logoutCurrentUser();
			util.goToURL(caseURL);
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			caseURL = getDriver().getCurrentUrl();
			App().Pages().getCasepage().copyCaseOwnerNameAndNumber();
		}).and("Log in as case owner", () -> {
			try {
//				App().Pages().getLoginpage().logoutAsCurrentUser();
				App().Pages().getCasepage().openCaseOwnerAndRelatedUser();
				App().Pages().getHomepage().goToAPP("Cases");
				String caseOwner = App().Pages().getCasepage().getCASEOWNER();
				App().Pages().getCasepage().SelectCaseGroup(caseOwner);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}).and("Accepting case by case owner", () -> {
			App().Pages().getCasepage().acceptCase();
			App().Pages().getCasepage().SelectCaseGroup("My Cases");
			App().Pages().getCasepage().clickOnCaseByCaseNumber();
		}).then("User verify that case got accepted and navigated to case", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Case",key = "${key.name}")
	@Test(description = "Perform EligibilityCheck", priority = 3, dependsOnMethods = { "createNewCaseAndAcceptCase" })
	public void performEligibilityCheck(Map<String, String> data) {
		scenario().given("Clicking on EligibilityCheck button from case page", () -> {
			App().Pages().getCasepage().ClickOnEligibilityCheckButton();
		}).then("Performing eligibility check by uploading BulkEligibility file", () -> {
			App().Pages().getVlocitypage().vlocityBulkEligibilityCheck(
					props.getProperty("user.dir") + "\\resources\\MNP_Upload\\BulkEligibilityCheck.csv");
		}).then("User performed EligibilityCheck by uploading file ", () -> {
			Reporter.logWithScreenShot("Performed EligibilityCheck", MessageTypes.Info);
		}).execute();
	}

	@Test(description = "read", priority = 4, dependsOnMethods = { "performEligibilityCheck" })
	public void readCaseIDAndUploadInFile() {
		scenario().given("Getting Case Id from downloaded eligibility file", () -> {
			List<String> valueid = app.ReadListOfIDInCSVFile("C:\\Users\\valla\\Downloads\\Eligibility Result.csv");
			System.out.println(valueid);
			app.UpdateListOfIDInCSVFile("resources/MNP_Upload/ManualEligibiltyCheck.csv", valueid);
		}).then("Updating Case Id into ManualEligibiltyCheck.csv file", () -> {
			Reporter.log("Updated Case Id in file..");
		}).execute();
	}

	@Test(description = "Perform Manual EligibilityCheck And Generate LOU and USC", priority = 5, dependsOnMethods = {
			"readCaseIDAndUploadInFile" })
	public void performManualEligibilityCheckAndGenerateUSCAndLOU() {
		scenario().given("Checking MNPPortability checks and perform manual eligibility", () -> {
			App().Pages().getCasepage().scrolltoRelatedSection("MNPPortabilityChecks");
			util.waitFor(5);
			App().Pages().getCasepage().clickOnCaseNoBulkMNPPotabilityCheck();
			App().Pages().getCasepage().ClickOnBulkUpload();
			App().Pages().getCasepage().manualEligibilityCheckPerform(
					props.getProperty("user.dir") + "\\resources\\MNP_Upload\\ManualEligibiltyCheck.csv");
		}).when("Clicking on generateLOU button and change case status to resolution in progress and clicking on generateUSC",
				() -> {
					App().Pages().getCasepage().clickOnGenerateLOU();
					App().Pages().getCasepage().clickOnResolInProgress();
					String caseNumber = App().Pages().getCasepage().getCASENUMBER();
					util.UpdateCaseIDWithzeroInCSVFile(
							props.getProperty("user.dir") + "\\resources\\MNP_Upload\\Bulk_PortoutTransactionAsset.csv",
							"\t" + caseNumber);
					App().Pages().getCasepage().ClickOnBulkUpload();
					App().Pages().getCasepage().bulkCreateTransAsset(props.getProperty("user.dir")
							+ "\\resources\\MNP_Upload\\Bulk_PortoutTransactionAsset.csv");
					util.waitForCasePage();
					App().Pages().getCaseDetailsPage().verifyTransactionAsset();
					App().Pages().getCasepage().clickOnGenerateUSC();
				}).then("User verify that generate LOU and USC are completed", () -> {
					Reporter.logWithScreenShot("Generated LOU and USC ", MessageTypes.Info);
				}).execute();
	}

	@Test(description = "Verify Orders", priority = 6, dependsOnMethods = {
			"performManualEligibilityCheckAndGenerateUSCAndLOU" })
	public void verifyOrders() {
		scenario().given("Generating orders", () -> {
			orderList = App().Pages().getOrdersPage().verifyOrderFromCasePage(caseURL, 1);
		}).then("User verified that Orders got generated", () -> {
			Reporter.logWithScreenShot(" Orders generated ", MessageTypes.Info);
		}).execute();
	}

	@Test(priority = 7, dependsOnMethods = { "verifyOrders" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order_" + i + 1 + ": " + orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
