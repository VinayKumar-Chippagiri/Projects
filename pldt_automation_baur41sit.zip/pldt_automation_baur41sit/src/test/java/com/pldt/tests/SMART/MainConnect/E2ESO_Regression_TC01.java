package com.pldt.tests.SMART.MainConnect;

import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import org.jetbrains.annotations.NotNull;
import org.testng.annotations.Test;

import java.util.Map;

public class E2ESO_Regression_TC01 extends MainConnect {

    @QAFDataProvider(dataFile = "resources/testdata/MainConnect.xlsx", sheetName = "Login", key = "${key.name}")
    @Test(description = "As a user login in salesforce application", priority = 1)
    public void loginAdmin(Map<String, String> data) {
        super.LoginAsAdmin(data);
    }

    @QAFDataProvider(dataFile = "resources/testdata/MainConnect.xlsx", sheetName = "Quote", key = "${key.name}")
    @Test(description = "Switching to Relation Manager and opening account page", priority = 2, dependsOnMethods = {"loginAdmin"})
    public void openAccount(Map<String, String> data) {
        super.SwitchToRM(data);
        super.OpenExistingAccount(data);
    }

    @QAFDataProvider(dataFile = "resources/testdata/MainConnect.xlsx", sheetName = "Contact", key = "${key.name}")
    @Test(description = "Contact creation", priority = 3, dependsOnMethods = {"openAccount"})
    public void createContact(Map<String, String> data) {
        super.contactCreation(data);
    }

    @QAFDataProvider(dataFile = "resources/testdata/MainConnect.xlsx", sheetName = "Quote", key = "${key.name}")
    @Test(description = "Create new Quote form account page and selecting bulk site address", priority = 3, dependsOnMethods = {"openAccount"})
    public void createQuote(Map<String, String> data) {
        super.CreatingQuoteTest(data);
        super.selectBulkSiteMultiple(data);
        super.setQuoteURL();
        super.updateAccessIdentifier();
    }

    @QAFDataProvider(dataFile = "resources/testdata/MainConnect.xlsx", sheetName = "CartDetails", key = "${key.name}")
    @Test(description = "Working cart page, adding plan and config it, performing grouping", priority = 4, dependsOnMethods = {"createQuote"})
    public void addingPlan(Map<String, String> data) {
        super.AddProductToCart();
        super.configIPVPN(data);
        super.configCiscoManagedRouter(data);
        super.groupingAndSavingWorkingCart();
    }

    @QAFDataProvider(dataFile = "resources/testdata/MainConnect.xlsx", sheetName = "CartDetails", key = "${key.name}")
    @Test(description = "performing product association and association validation", priority = 5, dependsOnMethods = {"addingPlan"})
    public void performAssociations(@NotNull Map<String, String> data) {
        super.performAssociation(data.get("Plan"));
    }


    @Test(description = "performing serviceability with RM", priority = 6, dependsOnMethods = {"performAssociations"})
    public void serviceabilityWithRM() {
        super.serviceability();
    }

    @QAFDataProvider(dataFile = "resources/testdata/MainConnect.xlsx", sheetName = "Quote", key = "${key.name}")
    @Test(description = "update contact", priority = 7, dependsOnMethods = {"serviceabilityWithRM"})
    public void contactsUpdate(Map<String, String> data) {
        super.ContactUpdate(data);
    }

    @Test(description = "Perform Trigger SD and verify ETS status", priority = 8, dependsOnMethods = {"contactsUpdate"})
    public void performTriggerSD() {
        super.triggerSD();
    }

    @QAFDataProvider(dataFile = "resources/testdata/MainConnect.xlsx", sheetName = "Quote", key = "${key.name}")
    @Test(description = "logout current user(RM) and switch to other user", priority = 9, dependsOnMethods = {"performTriggerSD"})
    public void switchUser(Map<String, String> data) {
        super.LogoutUser(data);
        super.SwitchToOtherUser(data.get("ETS_User"));
        super.NavigateQuoteURL();
        super.verifyQuotePage();
    }

    @Test(description = "Perform Solution Design with ETS user", priority = 10, dependsOnMethods = {"switchUser"})
    public void solutionDesignWithETS() {
        super.SolutionDesign();
    }

    @QAFDataProvider(dataFile = "resources/testdata/MainConnect.xlsx", sheetName = "Quote", key = "${key.name}")
    @Test(description = "populate ETS status and ETS Remark", priority = 11, dependsOnMethods = {"solutionDesignWithETS"})
    public void ETSReviewWithETSUser(Map<String, String> data) {
        super.populateETS(data.get("ETS Status"), data.get("ETS Remarks"));
    }

    @Test(description = "performing serviceability with ETS", priority = 12, dependsOnMethods = {"ETSReviewWithETSUser"})
    public void serviceabilityWithETS() {
        super.serviceability();
        super.updateAccessIdentifier();
        System.out.println("*********8");
    }
}
