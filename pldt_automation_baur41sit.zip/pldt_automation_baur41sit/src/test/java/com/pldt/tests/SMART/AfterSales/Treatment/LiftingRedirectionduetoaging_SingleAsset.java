package com.pldt.tests.SMART.AfterSales.Treatment;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

//Pre-Requisite:
//Billing Account having Asset which already have redirection due ageing

public class LiftingRedirectionduetoaging_SingleAsset extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL=null;
	String orderURL=null;
	ArrayList<String> orderList =null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
		}).when("User Login As Admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			Reporter.logWithScreenShot("Successfully landed on home page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Switch to RelationShip Manager", priority = 2,dependsOnMethods = { "Login" })
	public void SwitchingtoRelationShipManager(Map <String,String> data) {
		scenario().given("user Switch to RelationShip Manager", () -> {
		}).when("User Login As RelationShip Manager", () -> {
			App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"), "Relationship Manager");
			Reporter.log("Switched to Relationship manager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to RM user", () -> {
			Reporter.logWithScreenShot("Successfully switched to Relationship Manager");
		}).execute();
		}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Creating new case ", priority = 3, dependsOnMethods = { "SwitchingtoRelationShipManager" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().
		given("Going in account", () -> {
		}).when("User open account page", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).and("user click on cases to create a new case", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("user Fill case details form and save", () -> {
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getCasepage().createNewCaseAfterSalesTreatment(data.get("BillingAccount"));
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			caseURL= getDriver().getCurrentUrl();
		}).then("User verify the case got Created and case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Update Required Documents", priority = 4, dependsOnMethods = { "CreateNewCase" })
	public void RequiredDocuments(Map<String, String> data) throws InterruptedException {
		scenario().
		given("User is on Case page", () -> {
		}).when("User go to required Document tab update details of documents", () -> {
			App().Pages().getCasepage().AddDocumentsRequiredForTreatment(data);
			caseURL= getDriver().getCurrentUrl();
		}).then("User verify the required documents got updated", () -> {
			Reporter.logWithScreenShot("Required documents");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Validate CaseOwner", priority = 5, dependsOnMethods = { "RequiredDocuments" })
	public void ValidateCaseOwner(Map<String, String> data) throws InterruptedException {
		scenario().
		given("User is on Case page", () -> {
		}).when("User Validate case owner", () -> {
			util.scrollDown();
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Change Owner"));
			App().Pages().getCasepage().copyCaseOwnerNameAndNumber();
		}).and("Logout with RM", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
		}).and("Log in as case owner", () -> {
			try {
				App().Pages().getCasepage().openCaseOwnerAndRelatedUserforTreatment(data);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}).then("User verify the case page is opened ", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Accept Case", priority = 6, dependsOnMethods = { "ValidateCaseOwner" })
	public void AcceptCase(Map<String, String> data) {
		scenario().given("User is on Home Page", () -> {
		}).when("User navigated to cases tab", () -> {
			App().Pages().getHomepage().goToAPP("Cases");
		}).and("Search cases assign to Case Owner", () -> {
			App().Pages().getCasepage().SelectCaseGroup(data.get("Change Owner"));
		}).and("User Accept the Case", () -> {
			App().Pages().getCasepage().acceptCase();
			App().Pages().getCasepage().SelectCaseGroup("My Cases");
			App().Pages().getCasepage().clickOnCaseByCaseNumber();
		}).then("User verify that case got accepted and navigated to case", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Fill Transaction Details in casepage", priority = 7, dependsOnMethods = { "AcceptCase" })
	public void UpdateTransactionDetails(Map<String, String> data) {
		scenario().given("Updating TransactionDetails from case page", () -> {
		}).when("User upadtae fields in transaction Details", () -> {
			App().Pages().getCasepage().caseModificationfortreatment(data.get("Asset_Name"),data.get("Asset ID"),data);
	}).then("User Verify Changes made in Case page", () -> {
		Reporter.logWithScreenShot("UpdateTransactionDetails", MessageTypes.Info);
	}).execute();
}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Change Status to Assigned for Resolution ", priority = 8, dependsOnMethods = { "UpdateTransactionDetails" })
	public void ChangeStatustoAssigned(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
			}).when("user Change status to Assigned for Resolution", () -> {
				util.clickUsingJs(By
						.xpath("(//a[@data-tab-name='Assigned For Resolution'])[last()]"));
				util.clickUsingJs(By.xpath("//span[text()='Mark as Current Status']"));
				util.waitFor(3);
				util.waitForGenericToastMessage();
				util.refreshPage();
			}).then("User Verify Status Got Changes", () -> {
			Reporter.logWithScreenShot("Change Status to Assigned for Resolution ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Add Credit Arrangement", priority = 9, dependsOnMethods = { "ChangeStatustoAssigned" })
	public void AddCreditArrangement(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
		}).when("User Click on Add Credit Arrangment from Quick Actions", () -> {
			util.clickOnActionToolBarButton("Quick Actions", "Add Credit Arrangement");
		}).and("User Perform Credit Arrangment", () -> {
			App().Pages().getCasepage().AddCreditArrangement(data);
		}).then("User verify  ", () -> {
			Reporter.logWithScreenShot("TransactionID status is successful", MessageTypes.Info);
			}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Change Status to Resolution In Progress", priority = 10, dependsOnMethods = { "AddCreditArrangement" })
	public void ChangeStatustoResolutionInProgress(Map<String, String> data) {
		scenario().given("User is on Case Page", () -> {
			}).when("user Change status to Resolution in Progress", () -> {	
				util.clickUsingJs(By
						.xpath("(//a[@data-tab-name='Assigned For Resolution'])[last()]"));
				util.waitFor(3);
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
			
			}).then("User Verify Status Got Changes", () -> {
			Reporter.logWithScreenShot("Changed status to Resolution In Progress", MessageTypes.Info);
		}).execute();
	}	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "Treatment",key = "${key.name}")
	@Test(description = "Change Status to Resolution In Progress", priority = 11, dependsOnMethods = { "ChangeStatustoResolutionInProgress" })
	public void CheckingTransctionId(Map<String, String> data) {
		scenario().given("Checking Transaction ID creation and status", () -> {
		}).when("User check TransactionID got Created", () -> {
			App().Pages().getCasepage().CheckingTransactionID(caseURL,data,data.get("Smart Enterprise Support"));	
			util.goToURL(caseURL);
			util.waitForCasePage();
			util.waitFor(5);
		}).then("User verify TransactionID status is successful ", () -> {
			Reporter.logWithScreenShot("TransactionID status is successful", MessageTypes.Info);
			}).execute();
	}

	@Test(priority = 12,dependsOnMethods = { "CheckingTransctionId" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
	}
}