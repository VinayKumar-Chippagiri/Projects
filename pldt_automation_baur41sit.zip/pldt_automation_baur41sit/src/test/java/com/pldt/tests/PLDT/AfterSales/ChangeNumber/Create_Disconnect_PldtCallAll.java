package com.pldt.tests.PLDT.AfterSales.ChangeNumber;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
/*Prerequisites to execute this scenario  
 * Asset should be active.
 * Parent Account and Billing Account should be active.
 * ServiceID, contract term, pricing information, Asset dates must be populated.
 * 

*/
public class Create_Disconnect_PldtCallAll extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	ArrayList<String> orderList = null;



	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(10);
			String title = getDriver().getTitle();		
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).then("verify that User is Switched to Relationship Manager", () -> {
//			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"),"Relationship Manager");	
			props.setProperty("Relationship Manager", data.get("Relationship Manager"));
			util.waitFor(5);
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading,
					Matchers.containsString("Logged in as " + data.get("Relationship Manager")));
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "Account", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void Open_Existing_Account(Map<String, String> data) {
	scenario().given("I am in home page", () -> {
	util.refreshPage();
	util.waitFor(5);
	}).when("I open " + data.get("Account_Name") + " account", () -> {
		App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
	props.setProperty("Account", data.get("Account_Name"));
	util.waitFor(10);
	}).then("I verify that account details page of " + data.get("Account_Name") +" is displayed", () -> {
	String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
	.getText();
	Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
	}).when("I click on contacts", () -> {
	getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
	util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
	}).and("I captured the contact name", () -> {
		String TechnicalContact = getDriver().findElement(By.xpath("(//span[.='Technical']/ancestor::tr//th//a//span)[1]"))
			    .getText();
			    props.setProperty("contact.Technical", TechnicalContact);
			    Reporter.log("Technical Contact: " + TechnicalContact);
			    String Authorized_Signatory = getDriver()
			    .findElement(By.xpath("(//span[.='Authorized Signatory']/ancestor::tr//th//a//span)[1]")).getText();
			    props.setProperty("Lead.fullName", Authorized_Signatory);
			    Reporter.log("Authorized Signatory: " + Authorized_Signatory);
			    Reporter.logWithScreenShot("Account Contact Details");
	}).and("I clicked on account and navigate back to account details page", () -> {
	QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
	AccountName.click();
	}).then("then i verified that account details page is dispayed", () -> {
	util.waitForAccountPage();
	Reporter.logWithScreenShot("Account Details Page");
	}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "Creating Case", priority = 3, dependsOnMethods = {
			"Open_Existing_Account" })
	public void CreatingNewCase(Map<String, String> data) {
		scenario().given("Going in account and creating new case", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getAccountDetailsPage().clickOnRelated("Cases");
		}).when("i am Creating case ", () -> {
			pages.getCaseListPage().clickNewCaseButton();
			pages.getNewCaseModal().SelectRecordType(data.get("Record Type"));
			pages.getCasepage().createAfterSalesNewCase();
		}).then("Selecting The Case Created", () -> {
			pages.getCaseListPage().selectCase(data.get("Subject"));		
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());     //set Case URL
	}).execute();
	}
	
	
		
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "Creating Case", priority = 4, dependsOnMethods = {
			"CreatingNewCase" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("Going in case and adding billing account", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("Add Billing Account", () -> {		
			pages.getCaseDetailsPage().AddBillingAccountforModify(data);
		}).and("Add Required Documents", () -> {
			pages.getCaseDetailsPage().VerifyBulkServiceRequestFromRelated(ProjectBeans.getCaseURL());
			getDriver().get(ProjectBeans.getCaseURL());               //get case URL
			util.ChangeStatus("Document Pending");
			pages.getCaseDetailsPage().AddDocumentsRequired();
		}).then("Change Status to Assigned For Resolution and Clicking on MODIFY NUMBER And Add Primary Service ", () -> {
			util.ChangeStatus("Assigned For Resolution");
			pages.getCaseDetailsPage().RequestModify(data,"CREATE+DISCONNECT");
			Reporter.logWithScreenShot("User request CREATE+DISCONNECT");
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "Configuring cart", priority = 5, dependsOnMethods = { "AddBillingAccount" })
	public void cartPage(Map<String, String> data) {
		scenario().given("ConfigureIgateOffer ", () -> {
		props.setProperty("testdata", data);		
		}).when("Click on Configure", () -> {	
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Configure");
		util.waitFor(10);
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(10);
		util.waitForCartPage();
		Reporter.logWithScreenShot("Clicked on Configure");	
		}).and("Configure PLDT Landline Plus", () -> {
			AppUtils.Configure_Primary_Product(data.get("Plan"));
			util.waitFor(3);
			if (data.get("Number Type").contains("Vanity")) {
			AppUtils.Input_Config_Parameter(data.get("Plan"), "Reserved Number", "Reserved Number");
			}
			util.waitFor(2);
			AppUtils.select_Config_Parameter("Number Type");
			AppUtils.cartPageSave();
			util.waitFor(10);
		}).and("Click on View Record", () -> {
		util.clickUsingJs(By.xpath("//button[@title='View Record']"));
		Reporter.logWithScreenShot("Cofigured Cart Page");
			util.waitForQuotePage();
		}).then("I verify that cart is configured", () -> {
		}).execute();
		
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "updating Contact Details", priority = 6, dependsOnMethods = { "cartPage" })
	public void updateContactDetails(Map<String, String> data) {
		scenario().given(" Update Contact Details ", () -> {
		}).when("I update contact details", () -> {
		props.setProperty("testdata", data);
		pages.getQuotepage().updatePldtContactDetails(data);
		ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("Change Status to Internal Approval", () -> {
			util.ChangeStatus("Internal Approval");
			util.waitFor(5);
			Reporter.logWithScreenShot("User change to Internal Approval");
		}).execute();
	}
	
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "create Contract", priority = 7, dependsOnMethods = { "updateContactDetails" })
	public void createContract(Map<String, String> data) {
		props.setProperty("testdata", data);
		util.ChangeStatus("Presented");
		util.waitFor(5);
		util.ChangeStatus("Customer Accepted");
		util.waitFor(5);
		pages.getQuoteDetailsPage().CreateContractinAfterSales(data);
		ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "generate Documents", priority = 8, dependsOnMethods = { "createContract" })
	public void generateDocuments(Map<String, String> data) {
	props.setProperty("testdata", data);	
	scenario().given("I am on Contract Page", () -> {
	}).when("I click on generate Documents ", () -> {
	util.refreshPage();
	util.waitForContractPage();
	App().Pages().getContractpage().GenerateContractDocwithcontact(data.get("Template"));
	util.waitForContractPage();
	}).and("I change status to signed", () -> {
	util.waitFor(5);
	pages.getQuotepage().ChangeTheStatusToSigned();
	}).then("i verified that File is Uploaded", () -> {
	Reporter.logWithScreenShot(" Generate Documents ", MessageTypes.Info);
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote",key = "${key.name}")
	@Test(description = "Verify Orders", priority = 9, dependsOnMethods = { "generateDocuments" })
	public void verifyOrders(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Contract Page", () -> {
		}).when("I move to orders page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList=pages.getQuotepage().VerifyingOrders(90,2);
			ProjectBeans.setOrderURL(getDriver().getCurrentUrl());
		}).then("I verified the status of Orders", () -> {
			Reporter.logWithScreenShot(" Orders", MessageTypes.Info);
		}).execute();
	}
	
	
	@Test( priority = 10,dependsOnMethods = { "verifyOrders" })
	public void getReferenceData()
	{
		Reporter.log("Case URL :"+ProjectBeans.getCaseURL(), MessageTypes.Info);
		Reporter.log("Quote URL :"+ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :"+ProjectBeans.getContractURL(), MessageTypes.Info);
		if(orderList.size()>0)
		{
			for(int i=0;i<orderList.size();i++)
			{
				Reporter.log("Order _"+(i+1)+" URL : "+orderList.get(i), MessageTypes.Info);
			}
		}
	}
}


