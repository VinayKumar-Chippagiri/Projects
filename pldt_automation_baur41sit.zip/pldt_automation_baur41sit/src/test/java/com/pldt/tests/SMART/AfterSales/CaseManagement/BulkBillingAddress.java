package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.Map;

import org.testng.annotations.Test;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;

public class BulkBillingAddress extends CaseManage{
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login as Admin into Salesforce application and Switched to RM", priority = 1)
	public void LoginAdmin(Map<String, String> data) {
		super.LoginAsAdmin(data);
		super.SwitchToOtherUser(data.get("Smart_Enterprise_Support"));
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "I clicked on Bulk Service Request", priority = 2, dependsOnMethods = {"LoginAdmin"})
	public void BulkService(Map<String, String> data) {
		super.getDefaultWindow();
		super.ClickBulkServiceRequest();
		super.ImportBulkFile(data.get("lookupfield"),data.get("BulkFilePath"));
		super.SwitchToDefaultWindow();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "I verify cases", priority = 3, dependsOnMethods = {"BulkService"})
	public void verifyCase(Map<String, String> data){
		VerifyBSRCases(data.get("FilterSubject"));
	}
}
