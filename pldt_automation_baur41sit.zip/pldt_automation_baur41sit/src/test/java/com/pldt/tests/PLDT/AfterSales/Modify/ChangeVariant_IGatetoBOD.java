package com.pldt.tests.PLDT.AfterSales.Modify;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;
import java.util.ArrayList;
import java.util.Map;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class ChangeVariant_IGatetoBOD extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	ArrayList<String> orderList = null;
	String caseURL = null;
	String quoteURL = null;
	String caseNo = null;
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("User log in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(5);
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).then("User verify Admin successfully landed on home page", () -> {
			String title = getDriver().getTitle();
			Validator.verifyThat("User logged in as admin ", title, Matchers.equalTo("Home | Salesforce"));		
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "Switch to EBM Member", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void SwitchingtoEBMMember(Map<String, String> data) {
		scenario().given("user Switch to EBM Member", () -> {
		}).when("User Login As EBM Member", () -> {
			App().Pages().getHomepage().SwitchToUser(data.get("EBM Member"), "EBM member");
			Reporter.log("Switched to EBM Member:" + data.get("EBM Member"));
		}).then("verify Admin successfully switched to EBM Member", () -> {
			util.waitFor(30);
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading, Matchers.containsString("Logged in as " + data.get("EBM Member")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Account", priority = 3, dependsOnMethods = { "SwitchingtoEBMMember" })
	public void OpenExistingAccount(Map<String, String> data) {
		scenario().given("User is in home page", () -> {
			util.refreshPage();
		}).when("User open " + data.get("Account_Name") + " account", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			ConfigurationManager.getBundle().setProperty("Account", data.get("Account_Name"));
			ProjectBeans.setAccountURL(getDriver().getCurrentUrl()); // setting account url
			util.waitFor(7);
		}).then("User verified that account details page of " + data.get("Account_Name") + " is displayed", () -> {
			String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
					.getText();
			Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
		}).when("User click on contacts", () -> {
			getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
			util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
		}).and("User captured the contact name", () -> {
			String TechnicalContact = getDriver().findElement(By.xpath("//span[.='Technical']/ancestor::tr//th//a"))
					.getText();
			ConfigurationManager.getBundle().setProperty("contact.Technical", TechnicalContact);
			Reporter.log("Technical Contact: " + TechnicalContact);
			String Authorized_Signatory = getDriver()
					.findElement(By.xpath("//span[.='Authorized Signatory']/ancestor::tr//th//a")).getText();
			ConfigurationManager.getBundle().setProperty("Lead.fullName", Authorized_Signatory);
			Reporter.log("Authorized Signatory: " + Authorized_Signatory);
			Reporter.logWithScreenShot("Account Contact Details");
		}).and("User clicked on account and navigate back to account details page", () -> {
			QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
			AccountName.click();
		}).then("User verified that account details page is dispayed", () -> {
			util.waitForAccountPage();
			Reporter.logWithScreenShot("Account Details Page");
			util.waitForAccountPage();
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "Creating new case ", priority = 4, dependsOnMethods = { "OpenExistingAccount" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().given("Going in account", () -> {
		}).when("User open account page", () -> {
		}).and("user click on cases to create a new case", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
		}).and("user Fill case details form and save", () -> {
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			App().Pages().getCasepage().createAfterSalesNewCase();
		}).then("Selecting The Case Created", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();	
			util.waitFor(5);
			App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"),"Relationship Manager");	
			util.waitFor(3);
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
			util.waitFor(10);
			App().Pages().getAccountDetailsPage().clickOnRelated("Cases");
			util.waitFor(3);
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));		
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());     //set Case URL
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "Validate Case Owner and Case Status", priority = 5, dependsOnMethods = { "CreateNewCase" })
	public void ValidateCaseOwnerAndStatus(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User open case page and check for the case owner", () -> {
			App().Pages().getCasepage().ValidateCaseOwner(data.get("Relationship Manager"));
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());     //set Case URL
			caseURL = getDriver().getCurrentUrl();
			caseNo = getDriver().findElement(By.xpath(
					"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]"))
					.getText();
		}).then("Verified Case Status", () -> {
			App().Pages().getCaseDetailsPage().verfifyCaseStatus("Open");
			Reporter.logWithScreenShot("Case status is open");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "Add Billing Account and Verify Bulk Service Request", priority = 6, dependsOnMethods = {
			"ValidateCaseOwnerAndStatus" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User click on Add Billing Account", () -> {
			caseURL = getDriver().getCurrentUrl();
			App().Pages().getCaseDetailsPage().AddBillingAccountforModify(data);
			util.waitForCasePage();
			util.waitFor(5);
		}).then("Verified Bulk Service Request", () -> {
			App().Pages().getCasepage().VerifyBulkServiceReq();
			Reporter.logWithScreenShot("Bulk Service Request is generated");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "Update case status and Select required document", priority = 7, dependsOnMethods = {
			"AddBillingAccount" })
	public void UpdateCaseStatus(Map<String, String> data) {
		scenario().given("User is on Case page", () -> {
		}).when("User change case status to Document Pending", () -> {
			App().Pages().getCaseDetailsPage().ChangeCaseStatus("Document Pending");
		}).and("User select required document", () -> {
			App().Pages().getCaseDetailsPage().AddDocumentsRequired();
		}).and("User change case status to Assigned for Resolution", () -> {
			App().Pages().getCaseDetailsPage().ChangeCaseStatus("Assigned For Resolution");
			util.waitFor(5);
		}).then("Verified Case Status", () -> {
			App().Pages().getCaseDetailsPage().verfifyCaseStatus("Assigned For Resolution");
			Reporter.logWithScreenShot("Case status is Assigned For Resolution");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "On the Case page clicking on Modify link", priority = 8, dependsOnMethods = {
			"UpdateCaseStatus" })
	public void ModifyAction(Map<String, String> data) {
		scenario().given("User navigate to case page", () -> {
			util.waitForCasePage();
		}).when("User click on Modify link in Quote actions toolbar", () -> {
		}).and("User select product from primary service list", () -> {
			App().Pages().getCaseDetailsPage().RequestModify(data,"CREATE+DISCONNECT");
		}).then("Verified user is on Quote page", () -> {
			QAFWebElement quoteText = new QAFExtendedWebElement("//div[.='Quote']");
			quoteText.isPresent();
			Reporter.logWithScreenShot("Quote page opened");
			quoteURL = getDriver().getCurrentUrl();
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Modify", key = "${key.name}")
	@Test(description = "Configuring cart", priority = 9, dependsOnMethods = { "ModifyAction" }) //
	public void configureCart(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("User click on configure button", () -> {
			util.clickOnActionToolBarButton("QuoteActionToolbar", "Configure");		
			util.waitForCartPage();
		}).and("User configure plans", () -> {
			util.waitFor(10);
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.waitFor(6);
			Reporter.logWithScreenShot("Clicked on Configure");
		}).and("User Validated Changes refelected", () -> {
			AppUtils.Configure_Primary_Product(data.get("ChildPlan"));
			AppUtils.Input_Config_Parameter("BOD Excess Rate");
			util.waitFor(3);
			AppUtils.select_Config_Parameter("Burst Speed");
			String Change = getDriver().findElement(By.xpath("(//label[contains(.,'BoD Required')]/following::select/option[@selected='selected'])[1]")).getText();
			Validator.verifyThat("", Change, Matchers.containsString("TRUE"));
			Reporter.logWithScreenShot("Changes in IGate Offer");
			AppUtils.cartPageSave();
			util.waitFor(3);
		}).and("User click on View Record", () -> {
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.waitFor(5);
			util.clickUsingJs(By.xpath("//button[@title='View Record']"));
			util.waitForQuotePage();
		}).then("User verify that plan configured", () -> {
			Reporter.logWithScreenShot("Plans configured", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "updating Contact Details", priority = 10, dependsOnMethods = { "configureCart" })
	public void updateContactDetails(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User update contact details", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getQuotepage().updatePldtContactDetails(data);
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("User verify contact details are updated", () -> {
			Reporter.logWithScreenShot("Updated contact details", MessageTypes.Pass);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "credit check", priority = 11, dependsOnMethods = { "updateContactDetails" })
	public void creditCheck(Map<String, String> data) {
		scenario().given("User is on Quote Page", () -> {
		}).when("User update Credit Information by Credit Analyst", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getLoginpage().logoutAsCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			App().Pages().getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
					data.get("CreditApprovalCondition"), data.get("CreditRemark"));
			App().Pages().getLoginpage().logoutCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
		}).then("User verified that Credit Information is Updated", () -> {
			Reporter.logWithScreenShot("Credit Information ", MessageTypes.Pass);
		}).execute();
		util.waitForQuotePage();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Change Quote Status and Quote Document Generation", priority = 12, dependsOnMethods = { "creditCheck" }) //
	public void changeQuoteStatus(Map<String, String> data) {
		scenario().given("User is on Quote page", () -> {
		}).when("User Change quote status to presented", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			util.ChangeStatus("Internal Approval");
			App().Pages().getQuotepage().ChangeStatusToPresented(data);
			util.waitFor(6);
			Reporter.logWithScreenShot("Quote Status Changed to Presented");
		}).and("User change quote status to customer accepted", () -> {
			App().Pages().getQuotepage().changeQuoteStatustoCustomerAccepted();
			Validator.verifyThat("Verify Quote status changed to Accepted", AppUtils.getToastMessage(),
					Matchers.containsString("Status changed successfully"));
		}).then("User verified that Quote status changed", () -> {
			Reporter.logWithScreenShot("Quote status changed", MessageTypes.Pass);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Generate Contract", priority = 13, dependsOnMethods = { "changeQuoteStatus" })
	public void GenerateContract(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User click create contract button", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			util.waitFor(10);
			App().Pages().getQuotepage().CreateContractVASActivation();
		}).and("User click on generate Documents ", () -> {
			util.refreshPage();
			util.waitForContractPage();
			App().Pages().getContractpage().GenerateContractDocwithcontact(data.get("Template"));
			util.waitForContractPage();
			AppUtils.pickLatestFileFromDownloads("Contract Document");
		}).when("User change contract status to signed", () -> {
			App().Pages().getQuotepage().ChangeTheStatusToSigned();
		}).then("User verified that Contract got generated", () -> {
			Reporter.logWithScreenShot(" Contract generated ", MessageTypes.Pass);
			ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
			util.waitFor(3);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Verify Orders", priority = 14, dependsOnMethods = { "GenerateContract" })
	public void verifyOrders(Map<String, String> data) {
		scenario().given("User is on orders page", () -> {
		}).when("User verify orders", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList = App().Pages().getQuotepage().VerifyingOrders(50, 2);
			ProjectBeans.setOrderURL(getDriver().getCurrentUrl());
		}).then("User verified that Orders got generated", () -> {
			Reporter.logWithScreenShot(" Orders generated ", MessageTypes.Pass);
		}).execute();
	}

	@Test(priority = 15, dependsOnMethods = { "verifyOrders" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :" + ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :" + ProjectBeans.getContractURL(), MessageTypes.Info);
		Reporter.log("OrderPage URL :" + ProjectBeans.getOrderURL(), MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order _" + (i + 1) + " URL : " + orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
