package com.pldt.tests.PLDT.AfterSales.ChangeNumber;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.sql.Driver;
import java.util.ArrayList;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.pages.CaseDetailsPage;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;
/*Prerequisites to execute this scenario  
 * Asset should be active.
 * Parent Account and Billing Account should be active.
 * ServiceID, contract term, pricing information, Asset dates must be populated.
 * 

*/
public class Create_Disconnect_PldtDL extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons AppUtils = new AppCommons();
	PageLib pages = new PageLib();
	ArrayList<String> orderList = null;



	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "Login as Admin", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			getDriver().get(props.getString("env.baseurl"));
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			util.waitFor(10);
			String title = getDriver().getTitle();		
			Validator.verifyThat("verify user able to login as admin or not", title,
					Matchers.equalTo("Home | Salesforce"));
		}).then("verify that User is Switched to Relationship Manager", () -> {
//			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager"),"Relationship Manager");	
			props.setProperty("Relationship Manager", data.get("Relationship Manager"));
			util.waitFor(20);
			String heading = getDriver().findElement(By.xpath("(//header[@id='oneHeader']//span)[2]")).getText();
			Validator.verifyThat("", heading,
					Matchers.containsString("Logged in as " + data.get("Relationship Manager")));
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "Creating Case", priority = 2, dependsOnMethods = {
			"LoginasAdmin" })
	public void CreatingNewCase(Map<String, String> data) {
			scenario().given("Going in account and creating new case", () -> {
			}).when("I open the account page ", () -> {
				App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
				props.setProperty("Account", data.get("Account_Name"));
				util.waitFor(10);
				}).and("I verify that account details page of " + data.get("Account_Name") +" is displayed", () -> {
				String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
				.getText();
				Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
				ConfigurationManager.getBundle().setProperty("testdata", data);
				}).and("I Create New Case ", () -> {
			pages.getAccountDetailsPage().clickOnRelated("Cases");
			pages.getCaseListPage().clickNewCaseButton();
			pages.getNewCaseModal().SelectRecordType(data.get("Record Type"));
			pages.getCasepage().createAfterSalesNewCase();
		}).then("Selecting The Case Created", () -> {
			pages.getCaseListPage().selectCase(data.get("Subject"));		
			ProjectBeans.setCaseURL(getDriver().getCurrentUrl());     //set Case URL
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "AddBillingAccount", priority = 3, dependsOnMethods = {
			"CreatingNewCase" })
	public void AddBillingAccount(Map<String, String> data) {
		scenario().given("Going in case and adding billing account", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I Add Billing Account", () -> {
			pages.getCaseDetailsPage().AddBillingAccountforModify(data);
		}).and("Verify Bulk Service Request", () -> {
			pages.getCaseDetailsPage().VerifyBulkServiceRequestFromRelated(ProjectBeans.getCaseURL());
		}).then("I verify bulk service Request got Created", () -> {
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "Add Documents Required", priority = 4, dependsOnMethods = {
			"AddBillingAccount" })
	public void AddDocumentsRequired(Map<String, String> data) {
		scenario().given("I am on casepage", () -> {
		}).when("I change status to Document Pending", () -> {
			getDriver().get(ProjectBeans.getCaseURL());               //get case URL
			util.ChangeStatus("Document Pending");
		}).and("I add documents Required", () -> {	
			pages.getCaseDetailsPage().AddDocumentsRequired();
		}).then("I change status to assigned for resolution", () -> {	
			util.ChangeStatus("Assigned For Resolution");
			Reporter.logWithScreenShot("verify the case status got Changed");
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/R4AfterSales.xlsx", sheetName = "ChangeNumber",key = "${key.name}")
	@Test(description = "Add Documents Required", priority = 5, dependsOnMethods = {
			"AddDocumentsRequired" })
	public void RequestCreate_Disconnect(Map<String, String> data) {
		scenario().given("I am on casepage", () -> {
		}).when("I Request Create + Disconnect", () -> {
		util.clickOnActionToolBarButton("Quick Actions", "CREATE+DISCONNECT");
		}).then("I Verify error Message Appeared", () -> {	
			util.waitFor(10);
			Reporter.logWithScreenShot("Error Message After requesting for CREATE+DISCONNECT ");
		}).execute();
	}
	
	
	@Test( priority = 6,dependsOnMethods = { "RequestCreate_Disconnect" })
	public void getReferenceData()
	{
		Reporter.log("Case URL :"+ProjectBeans.getCaseURL(), MessageTypes.Info);
		
	}
}


