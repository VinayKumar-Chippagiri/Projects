package com.pldt.tests.SMART.AfterSales.CaseManagement;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;

public class TransService extends CaseManage {

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Login as Admin into Salesforce application and Switched to RM", priority = 1)
	public void LoginAdmin(Map<String, String> data) {
		super.LoginAsAdmin(data);
		super.SwitchToRM(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Open Business Account which is already existing", priority = 2, dependsOnMethods = {
			"LoginAdmin" })
	public void OpenAccount(Map<String, String> data) {
		super.OpenExistingAccount(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Create New Case from Account page", priority = 3, dependsOnMethods = { "OpenAccount" })
	public void CaseCreation(Map<String, String> data) {
		Map<String, String> Casedata = new HashMap<String, String>();
		String[] CaseKeys = { "Record_Type", "BillingAccountNumber", "BillingAccountName", "Contact Name", "Subject",
				"Line of Business", "Type of Customer Request", "Type", "High Level Transaction Classification",
				"Transaction Type", "Transaction Sub Type", "Case Origin" };
		for (String strData : CaseKeys) {
			Casedata.put(strData, data.get(strData));
		}
		super.setOwner("SMART Enterprise Support");
		super.CaseCreationOnAccount(Casedata);
		Casedata.clear();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Creating new billing account on case page", priority = 4, dependsOnMethods = {
			"CaseCreation" })
	public void CreateBillingAc(Map<String, String> data) {
		super.caseOpen();
		super.CreateBillingAccountOnCase(data);
		super.StatusChangeToResolutionInProgress();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "verify transaction creation, verify Kenan Inquiries tab under Payments Inquiry Screen", priority = 5, dependsOnMethods = {
			"CreateBillingAc" })
	public void VerifyTransStatus(Map<String, String> data) throws InterruptedException {
		/*super.VerifyTransactionStatus(data);
		super.VerifyCaseStatus("Resolved");
		super.VerifyPaymentsInquiry();*/
//		super.VerifyTransaction(data);
		super.LogoutUser(data);
		super.navigateCaseURL();
		super.ModifyTransaction();
		super.VerifyCaseStatus("Closed");
		super.VerifyPaymentsInquiry();
		super.SwitchToRM(data);
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Open other account", priority = 6, dependsOnMethods = { "VerifyTransStatus" })
	public void SwitchAccount(Map<String, String> data) {
		super.navigateAcURL();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "create new additional case", priority = 7, dependsOnMethods = { "SwitchAccount" })
	public void additionalNewCase(Map<String, String> data) {
		Map<String, String> Casedata = new HashMap<String, String>();
		String[] CaseKeys = { "2ndRecord_Type", "2ndBillingAccountNumber", "2ndBillingAccountName", "2ndContact Name", "2ndSubject",
				"2ndLine of Business", "2ndType of Customer Request", "2ndType", "2ndHigh Level Transaction Classification",
				"2ndTransaction Type", "2ndTransaction Sub Type", "2ndCase Origin" };
		for (String strData : CaseKeys) {
			String strNewData = strData.replace("2nd", "");
			Casedata.put(strNewData, data.get(strData));
		}
		super.setOwner("SMART Enterprise Support");
		super.CaseCreationOnAccount(Casedata);
		//super.caseOpen();
		//super.AlertClose();
		//super.CaseOwnercheck("SMART Enterprise Support");
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "Accept Case", priority = 8, dependsOnMethods = {"additionalNewCase"})
	@Override
	public void AcceptCase(Map<String, String> data) {
		super.LogoutUser(data);
		super.SwitchToOtherUser(data.get("Smart_Enterprise_Support"));
		super.AcceptCase(data);
		super.caseOpen();
		super.AlertClose();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "modify Transaction details on Case page", priority = 9, dependsOnMethods = { "AcceptCase" })
	public void CaseModify(Map<String, String> data) {
		super.CaseModificationTransferofService(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "CaseManagement", key = "${key.name}")
	@Test(description = "verify transaction creation, verify Kenan Inquiries tab under Payments Inquiry Screen", priority = 9, dependsOnMethods = {
			"CaseModify" })
	public void VerifyTranslatest(Map<String, String> data) throws InterruptedException {
		/*super.VerifyTransactionStatus(data);
		super.VerifyCaseStatus("Resolved");*/
		super.VerifyTransaction(data);
		super.LogoutUser(data);
		super.navigateCaseURL();
		super.ModifyTransaction();
		super.VerifyCaseStatus("Closed");
	}
}
