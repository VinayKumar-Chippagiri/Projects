package com.pldt.tests.SMART.AfterSales.OrderManagement;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;
import java.util.ArrayList;
import java.util.Map;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.common.utilities.AppCommons;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class CancelOderDuetoNonPayment extends CancelOrderByClickonCancel {

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Lead creation for NewConnect", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		super.LoginasAdmin(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Switch to RelationShip Manager", priority = 2, dependsOnMethods = { "LoginasAdmin" })
	public void Switching_to_RelationShipManager(Map<String, String> data) {
		super.Switching_to_RelationShipManager(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Open account", priority = 3, dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void OpenExistingAccount(Map<String, String> data) {
		super.OpenExistingAccount(data);
	}


	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "QuoteCreationTest", priority = 4, dependsOnMethods = { "OpenExistingAccount" })
	public void QuoteCreationTest(Map<String, String> data) {
		super.QuoteCreationTest(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Adding Products To Cart", priority = 5, dependsOnMethods = { "QuoteCreationTest" })
	public void AddProductsToCart(Map<String, String> data) throws InterruptedException {
		super.AddProductsToCart(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Performing Availability Checks", priority = 6, dependsOnMethods = { "AddProductsToCart" })
	public void availabilityChecks(Map<String, String> data) throws InterruptedException {
		super.availabilityChecks(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Updating QuoteValidatyPeriod,DeliveryDate and ContactDetails", priority = 7, dependsOnMethods = {
			"availabilityChecks" })
	public void updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(Map<String, String> data) {
		super.updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "BillingAccounts", key = "${key.name}")
	@Test(description = "Creating BillingAccount", priority = 8, dependsOnMethods = {
			"updateQuoteValidatyPeriod_DeliveryDate_ContactDetails" })
	public void createBillingAccount(Map<String, String> data) {
		super.createBillingAccount(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "ServiceAccounts", key = "${key.name}")
	@Test(description = "Creating Service Account", priority = 9, dependsOnMethods = { "createBillingAccount" })
	public void createServiceAccount(Map<String, String> data) throws InterruptedException {
		super.createServiceAccount(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Updating Billing and Service Accounts", priority = 10, dependsOnMethods = {
			"createServiceAccount" })
	public void updateAccounts(Map<String, String> data) throws InterruptedException {
		super.updateAccounts(data);
	}

	@Test(description = "Validating cart", priority = 11, dependsOnMethods = { "updateAccounts" })
	public void validateCart() {
		super.validateCart();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Performing Credit Check", priority = 12, dependsOnMethods = { "validateCart" })
	public void creditCheck(Map<String, String> data) {
		super.creditCheck(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Quote status change and Quote to PDF", priority = 13, dependsOnMethods = { "creditCheck" })
	public void quotetoPDF(Map<String, String> data) {
		super.quotetoPDF(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Number Reservations", priority = 14, dependsOnMethods = { "quotetoPDF" })
	public void numberReservation(Map<String, String> data) {
	super.numberReservation(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote", key = "${key.name}")
	@Test(description = "Device Reservations", priority = 15, dependsOnMethods = { "numberReservation" })
	public void deviceReservations(Map<String, String> data) {
		super.deviceReservations(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Syncronizing QLI Items", priority = 16, dependsOnMethods = { "deviceReservations" })
	public void syncronizeQLIItems(Map<String, String> data) {
		super.syncronizeQLIItems(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Creating Contract", priority = 17, dependsOnMethods = { "syncronizeQLIItems" })
	public void CreateContract(Map<String, String> data) {
		super.CreateContract(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Contract", key = "${key.name}")
	@Test(description = "Upload file", priority = 18, dependsOnMethods = { "CreateContract" })
	public void generateDocuments(Map<String, String> data) {
		super.generateDocuments(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Creating Contract", priority = 19, dependsOnMethods = { "generateDocuments" })
	public void ChangingContractStatus(Map<String, String> data) {
		super.ChangingContractStatus(data);
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Smart_Cart", key = "${key.name}")
	@Test(description = "Checking Orders", priority = 20, dependsOnMethods = { "ChangingContractStatus" })
	public void orders(Map<String, String> data) {
		super.orders(data);
	}
	
	@Test(priority = 21, dependsOnMethods = { "orders" },description = "Cancel Order")//, priority = 21, dependsOnMethods = { "orders" }
	public void cancelOrder() {
		scenario().given("I am on Contract Page", () -> {			
		}).when("I open master order", () -> {
//			pages.getOrdersPage().cancelOrder();
			pages.getOrdersPage().cancelOrderNonPayment();
		}).then("I verified the order get cancel", () -> {
			Reporter.logWithScreenShot("Cancel Order", MessageTypes.Info);
		}).execute();

	}

	@Test(priority = 22, dependsOnMethods = { "cancelOrder" })
	public void getReferenceData() {
		Reporter.log("Lead URL :" + ProjectBeans.getLeadURL(), MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Quote URL :" + ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :" + ProjectBeans.getContractURL(), MessageTypes.Info);
		Reporter.log("OrderPage URL :" + ProjectBeans.getOrderURL(), MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order _" + (i + 1) + " URL : " + orderList.get(i), MessageTypes.Info);
			}
		}
	}

}
