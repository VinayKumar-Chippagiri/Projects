package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pages.DemoLoginPage;

public class DataDrivenTest {
	WebDriver driver;

	@BeforeMethod
	public void setUp() {
		driver = utilities.DriverFactory.open("Edge");
		driver.navigate().to("https://www.saucedemo.com/");
//		driver.manage().window().maximize();

	}
	
	@Test(dataProvider="testdata")
	public void loginTest(String Username,String Password) {
		DemoLoginPage DP = new DemoLoginPage(driver);
		DP.login(Username,Password);
	}
	
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
	
	@DataProvider(name="testdata")
	public Object[][] getdata(){
		return new Object[][]
		{
			{"standard_user","secret_sauce"},
			{"problem_user","secret_sauce"},
			{"performance_glitch_user","secret_sauce"}
		};
		
	}
}
