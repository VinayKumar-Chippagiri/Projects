package Tests;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class testNGAnnotation {
	WebDriver driver;
	
	public void methodImplicitWait() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
	}
	
	@BeforeTest
	public void Method1() {
		System.out.println("Before Test");
	}

	@Test
	public void Method3() {
		System.out.println("test1");
	}

	@Test
	public void Method4() {
		System.out.println("test2");
	}

	@Test
	public void Method5() {
		System.out.println("test3");
	}

	@AfterTest
	public void Method2() {
		System.out.println("After Test");
	}

}
