package Tests;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class sample {
	public static void main(String[] args) {
//		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
//		ChromeOptions options= new ChromeOptions();
//		options.addArguments("--remote-allow-origins=*");
//		ChromeDriver driver= new ChromeDriver(options);
//		driver.get("https://www.google.com/");
		
//		WebDriverManager.chromedriver().setup();
//		ChromeOptions options= new ChromeOptions();
//		options.addArguments("--remote-allow-origins=*");
//		ChromeDriver driver = new ChromeDriver(options);
//		driver.get("https://www.google.com/");
//		driver.manage().window().maximize();
	
		WebDriverManager.edgedriver().setup();
		WebDriver driver= new EdgeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys("Selenium Tutorials");
	}

}
