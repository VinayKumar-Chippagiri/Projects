package Tests;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ChromeDriverTest_SysProperty {
	public static void main(String[] args) {
//		System.setProperty("webdriver.chrome.driver","chromedriver.exe");		
		ChromeOptions options = new ChromeOptions();
//		options.setBrowserVersion("117");
		options.addArguments("--remote-allow-origins=*","--incognito");
		ChromeDriver driver = new ChromeDriver(options);	
		driver.get("https://demo.guru99.com/test/delete_customer.php");
		driver.close();
		
	}

}
