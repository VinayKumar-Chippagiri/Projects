package Tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ddd {
	static WebDriver driver;

	public static void main(String[] args) throws Exception {
		ddd d=new ddd();
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		d.takescreenshot("c://AutoSS//abcc1.png");
		driver.navigate().to("https://www.saucedemo.com/");
		d.Explicitywait(By.id("login-button"), Duration.ofSeconds(60));
		d.waitFor(By.id("login-button"), 20, true);
		d.takescreenshot("c://AutoSS//abcc2.png");
		driver.navigate().back();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.close();
	}
	
	public void takescreenshot(String filepath) throws Exception {
		TakesScreenshot srcshot=((TakesScreenshot)driver);
		File srcfile=srcshot.getScreenshotAs(OutputType.FILE);
		File targetfile=new File(filepath);
		FileUtils.copyFile(srcfile, targetfile);
		
	}
	
	public void Implicitwait(int seconds) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(seconds));
		driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
	}

	public void Explicitywait(By locator, Duration i) {
		WebDriverWait wait=new WebDriverWait(driver, i);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}
	
	public void Fluentwait(By locator) {
		Wait<WebDriver> wait=new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(10))
				.pollingEvery(Duration.ofSeconds(1))
				.ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		
	}
		
	public boolean waitFor(By locator,int seconds,boolean visibility) {
		Wait<WebDriver> wait=new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(seconds))
				.pollingEvery(Duration.ofSeconds(1))
				.ignoring(NoSuchElementException.class);
		if(visibility) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		}
		else {
			wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
		}
		return true;			
	}

	public void alert() {
		driver.switchTo().alert();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().dismiss();
	}
	
}