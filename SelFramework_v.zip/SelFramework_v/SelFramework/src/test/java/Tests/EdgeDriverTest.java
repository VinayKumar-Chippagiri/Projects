package Tests;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class EdgeDriverTest {
	public static void main(String[] args) {						
		WebDriverManager.edgedriver().setup();	
		EdgeOptions option= new EdgeOptions();
		option.addArguments("--remote-allow-origins=*");
		EdgeDriver driver= new EdgeDriver(option);
		//WebDriver driver = new EdgeDriver();		
		driver.get("https://demo.guru99.com/test/delete_customer.php");
		driver.manage().window().maximize();
		
	}

}
