package Tests;
import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestNGTest {
	ChromeDriver driver;
	
	@BeforeTest
	public void launchBrowser() {		
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);	
	}
	
	@Test
	public void getSite() {
		driver.get("https://www.google.com/");
		driver.navigate().to("https://www.expedia.com/");
//		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//		System.out.println(scrFile);
		driver.navigate().back();
	}

	@AfterTest
	public void terminateTest() {
		driver.close();
	}
}
