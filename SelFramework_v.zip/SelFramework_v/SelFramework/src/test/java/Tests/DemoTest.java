package Tests;



import java.util.Hashtable;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import Pages.DemoLoginPage;
import utilities.ExcelReader;

public class DemoTest {
	WebDriver driver;	
//	String Username="standard_user";
//	String Password="secret_sauce";
	
	@BeforeMethod
	public void setUp() {
		driver=utilities.DriverFactory.open("Chrome");
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
	}
	
	@Test(dataProviderClass = ExcelReader.class,dataProvider = "getData")
	public void loginuser(String Username,String Password) {	
		DemoLoginPage DP = new DemoLoginPage(driver);
		DP.login(Username,Password);
	}
		
	@Test(priority=1) 
	public void confirmlogin() {
		String title=driver.findElement(By.xpath("//div[@class='header_secondary_container']//span[@class='title']")).getText();
		System.out.println(title);
		 Assert.assertSame("Products", title);
		 Assert.assertEquals("Products", title);
	
	}
	
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
