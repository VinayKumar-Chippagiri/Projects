package Tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FetchExcelData {

	public static void main(String[] args) throws Exception {
		FetchExcelData FD = new FetchExcelData();
		FD.fetchData();
	}

	public void fetchData() throws Exception {
		File f = new File(System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\credentials.xlsx");
		FileInputStream fis=new FileInputStream(f);
		Workbook wb=new XSSFWorkbook(fis);
		Sheet sheetname=wb.getSheetAt(0);
		
		int rowcount=sheetname.getLastRowNum();
		System.out.println("Total no of rows:"+rowcount);
		Row cells=sheetname.getRow(0);
		int colcount=cells.getLastCellNum();
		System.out.println("Total no of columns:"+colcount);
		
		String testdata[][]=new String[rowcount][colcount];
		for(int i=1;i<=rowcount;i++) {
			Row rows=sheetname.getRow(i);
			for(int j=0;j<colcount;j++) {
				Cell cell=rows.getCell(j);
				String value=cell.getStringCellValue();
				testdata[i-1][j]=value;
				System.out.println(value);
			}
	}
		
		
	}
}
