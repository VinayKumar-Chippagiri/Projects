package Tests;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.HotelReservationPage;

public class expedia {
	static WebDriver driver;
	String browserType = "Chrome";
	String destination = "Pune Maharashtra, India";
	String checkin = "2023-06-10";
	String checkout ="2023-06-15";

	@BeforeTest
	public void setUp() {
		driver=utilities.DriverFactory.open(browserType);
		driver.get("https://www.expedia.com/");
		driver.manage().window().maximize();

	}
	
	@Test
	public void Reservation() {
		HotelReservationPage Res=new HotelReservationPage(driver);
		Res.reservation(destination, checkin, checkout);
	}
	
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}
