package JavaPrograms;

public class pattern2 {

	public static void main(String[] args) {
		int k=1;
		for(int i=1;i<5;i++) {
			for(int j=1;j<=5-i;j++) {
				System.out.print(j);
//				k++;
			}
			System.out.println("");
		}
	}

}


//1 2 3 4
//1 2 3
//1 2
//1