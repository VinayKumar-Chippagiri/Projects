package JavaPrograms;

public class SwapTempVariable {

	public static void main(String[] args) {
		int n1=20;
		int n2=57;
		int temp;
		System.out.println("Before Swapping Number 1:"+n1);
		System.out.println("Before Swapping Number 2:"+n2);
		
		temp=n1;
		n1=n2;
		n2=temp;
		System.out.println("After Swapping Number 1:"+n1);
		System.out.println("After Swapping Number 2:"+n2);
		
		n1=n1+n2;
		n2=n1-n2;
		n1=n1-n2;
		System.out.println("After Swapping without temp Number 1:"+n1);
		System.out.println("After Swapping without temp Number 2:"+n2);
		
	}

}
