package JavaPrograms;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetDemo {

	public static void main(String[] args) {
		HashSet<String> hs=new HashSet<String>();
		hs.add("UK");
		hs.add("USA");
		hs.add("INDIA");
		hs.add("He");
		hs.add("She");
		hs.add("It");
		
		System.out.println(hs);
		hs.add("INDIA");
		System.out.println(hs);
//		hs.remove("UK");
//		System.out.println(hs);
		System.out.println(hs.isEmpty());
		System.out.println(hs.size());
		
		Iterator<String> i=hs.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}

}
