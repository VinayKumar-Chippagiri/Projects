package JavaPrograms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.testng.annotations.Test;

public class StreamExample {

	@Test
	public void filter() {

		ArrayList<String> list = new ArrayList<String>();
		list.add("Abc");
		list.add("Xyz");
		list.add("Acg");
		list.add("Trd");
		list.add("Edtf");
		list.add("Aws");
		list.add("Aqew");
		list.add("Ldr");

		long c = list.stream().filter(L -> L.startsWith("A")).count();
		System.out.println(c);
		System.out.println("--------------------");
	}

	@Test
	public void streamMap() {

		// print the names which have last letter as "a" with uppercase
		Stream.of("Abhishekh","Raja","Adam","Alekhya","Don","Rob","Siri","Rama").filter(s->s.endsWith("a"))
		.map(s->s.toUpperCase()).forEach(s-> System.out.println(s));
		
		System.out.println("--------------------");
		//print the names which have first letter as "a" with uppercase n sorted
		List<String>names=Arrays.asList("Alekhya","Raja","Adam","Abhishekh","Don","Rob","Siri","Rama");
		names.stream().filter(s->s.startsWith("A")).sorted().map(s->s.toUpperCase()).forEach(s->System.out.println(s));

	}

}
