package JavaPrograms;

public class Palindrome {

	public static void main(String[] args) {
		String str1="English";
		String Reverse_str="";
		System.out.println("Original String: "+str1);
		for(int i=0;i<str1.length();i++) {
			char ch=str1.charAt(i);
			Reverse_str=ch + Reverse_str;
			System.out.println(ch);
			
		}
		System.out.println("Reverse String: "+Reverse_str);
		
		if(str1.equalsIgnoreCase(Reverse_str)) {
			System.out.println("String is Palindrome");
		}
		else {
			System.out.println("String is not Palindrome");
		}
}
}
