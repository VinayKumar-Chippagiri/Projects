package JavaPrograms;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		ArrayList<String> a=new ArrayList<String>();
		a.add("Vidya");
		a.add("Java");
		a.add("Java");
		System.out.println(a);
		a.add(0,"Program");
		System.out.println(a);
		System.out.println(a.contains("Java"));
		System.out.println(a.indexOf("Vidya"));
		System.out.println(a.isEmpty());
		System.out.println(a.size());
	}

}
