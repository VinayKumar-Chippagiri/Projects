package JavaPrograms;

public class EvenOdd {

	public static void main(String[] args) {
		int num=64;
		if(num%2==0) {
			System.out.println("number is even "+num);
		}
		else {
			System.out.println("number is odd "+num);
		}

	}

}
