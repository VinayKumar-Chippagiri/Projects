package utilities;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

//How to read excel files using Apache POI
public class ExcelReader {
	static String filePath=System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\Test.xlsx";
//	public static void main(String args[]) throws Exception {
//		ExcelReader ER = new ExcelReader();
//		ER.getExcelData("Sheet1",filePath);
//	}

	
	public String[][] getExcelData(String excelSheetName,String filePath) throws Exception {
		File file = new File(filePath);
		FileInputStream fis = new FileInputStream(file);
		Workbook wb = new XSSFWorkbook(fis);
		Sheet sheetname = wb.getSheet(excelSheetName);

		int TotalRows = sheetname.getLastRowNum();
		System.out.println(TotalRows);
		Row rowCells = sheetname.getRow(0);
		int TotalCols = rowCells.getLastCellNum();
		System.out.println(TotalCols);

		DataFormatter format = new DataFormatter();

		String testData[][] = new String[TotalRows][TotalCols];

		for (int i = 1; i <= TotalRows; i++) {
			for (int j = 0; j < TotalCols; j++) {
				testData[i - 1][j] = format.formatCellValue(sheetname.getRow(i).getCell(j));
				System.out.println(testData[i - 1][j]);
			}
		}
		return testData;

	}

	@DataProvider(name = "getData")
	public Object[][] getLoginData() throws Exception {
		Object[][] retObjArr = getExcelData("Sheet1",filePath);
		System.out.println("getData function executed!!");
		return retObjArr;
	}

}
