package utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverFactory {
	public static WebDriver open(String browserType) {
		switch (browserType) {
		case "Firefox":
			WebDriverManager.firefoxdriver().setup();
			return new FirefoxDriver();
		case "Edge":
			WebDriverManager.edgedriver().setup();
			EdgeOptions option = new EdgeOptions();
			option.addArguments("--remote-allow-origins=*","--start-maximized");
			return new EdgeDriver(option);
		case "Chrome":
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			return new ChromeDriver(options);
		}
		return null;

//		if(browserType.equalsIgnoreCase("Firefox")) {
//			WebDriverManager.firefoxdriver().setup();
//			return new FirefoxDriver();
//		}		
//	else if(browserType.equalsIgnoreCase("Edge")) {
//		WebDriverManager.edgedriver().setup();
//		EdgeOptions option=new EdgeOptions();
//		option.addArguments("--remote-allow-origins=*");
//		 return new EdgeDriver(option);	
//	}
//	else {
//		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
//		ChromeOptions option=new ChromeOptions();
//		option.addArguments("--remote-allow-origins=*","--incognito");
//		return new ChromeDriver(option);
//	}	

	}

}
