package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HotelReservationPage {
	WebDriver driver;

	@FindBy(xpath = "//button[.='Going to']")
	WebElement Goingto;

	@FindBy(id = "location-field-destination")
	WebElement Destination;
	
	@FindBy(xpath = "//ul[@class='uitk-action-list no-bullet']//li[1]//button")
	WebElement Selectdesti;

	@FindBy(name = "d1")
	WebElement Checkin;

	@FindBy(name = "d2")
	WebElement Checkout;

	@FindBy(xpath = "//button[.='Search']")
	WebElement searchBtn;

	public void reservation(String destination, String checkin, String checkout) {
		Goingto.click();
		Destination.sendKeys(destination);
		Selectdesti.click();
//		Checkin.clear();
		Checkin.sendKeys(checkin);
//		Checkout.clear();
		Checkout.sendKeys(checkout);
		searchBtn.click();
		
	}

	public HotelReservationPage(WebDriver driver) {
		PageFactory.initElements(driver,this);

	}
}
