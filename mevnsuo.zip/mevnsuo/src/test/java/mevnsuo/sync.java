package mevnsuo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class sync {
	 WebDriver driver;
	 WebElement uname,password;
	 @Test
	public  void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stubc
		
		  
		  uname=driver.findElement(By.xpath("//input[@id='username']"));
		  uname.sendKeys("chippagiri-vinay.kumar@capgemini.com.r32sit");
		  
		  password=driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/div[2]/div[3]/form/input[1]"));
		  password.sendKeys("Vinay@2022");
		  password.submit();
		  Thread.sleep(20000);
		  driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		  
		  driver.navigate().to("https://pldtoneenterprise--r32sit.lightning.force.com/lightning/r/QLI_Account_Details__c/a6E1s0000004hWdEAI/view");
		  driver.findElement(By.xpath("//button[@title='Edit CSP Account Sync Status']")).click();
			System.out.println();
			driver.findElement(By.xpath("(//label[.='CSP Account Sync Status']/following::div[1]//button)[last()]")).click();

	}
	 
	 @BeforeTest
	  public void beforeTest() throws InterruptedException {
		  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		  driver=new ChromeDriver();
		  driver.get("https://test.salesforce.com/");
		  Thread.sleep(2000);

	  }

}
