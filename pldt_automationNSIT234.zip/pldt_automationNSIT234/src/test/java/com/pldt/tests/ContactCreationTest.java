package com.pldt.tests;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class ContactCreationTest extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();

	@QAFDataProvider(dataFile = "resources/testdata/PLDT_RegressionSuite.xlsx", sheetName = "Contact")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) throws InterruptedException {
		scenario().given("I Log into PLDT Application as admin", () -> {
			getDriver().get("https://pldtoneenterprise--r32sit.my.salesforce.com/");
			getDriver().manage().window().maximize();
			ConfigurationManager.getBundle().setProperty("testdata", data);
			App().Pages().getLoginpage().LoginAsAdmin();
			try {
				App().Pages().getHomepage().SwitchToUser(data.get("Relationship Manager "), "EE RM");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			App().Pages().getHomepage().goToAPP("Accounts");
			try {
	//			App().Pages().getAccountpage().SelectAccount(data.get("Account Name").toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			App().Pages().getAccountpage().ClickContacts();
			App().Pages().getContactpage().clickNewAccContact();
		}).
		when("I add Lead Information for the New Lead: Enterprise Extension ", () -> {
			App().Pages().getContactpage().fillContactForm();
			App().Pages().getContactpage().clickSaveButton();
			App().Pages().getLoginpage().logoutCurrentUser();
		}).
//		and("I add Additional Information for the New Lead: Enterprise Extension ",()->{
//		App().Pages().getLeadpage().InputAdditionalInfo();
//		Reporter.logWithScreenShot("Lead Information for the New Lead: Enterprise Extension ",MessageTypes.Pass);
//		}).
				then("i verify that information is entered", () -> {
					Reporter.logWithScreenShot("Laed info is entered", MessageTypes.Info);
				}).execute();
	}
}
