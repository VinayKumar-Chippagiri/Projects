package com.pldt.tests.SMART.AfterSales.Activation;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.testng.annotations.Test;

import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class SIMActivation_Single extends BaseTest {
	PageLib pages = new PageLib();
	WebUtilities util = new WebUtilities();
	String caseURL = null;
	String orderURL = null;
	ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "SIMActivation",key="SIMActivation_Single")
	@Test(priority = 1)
	private void caseCreationTest(Map<String, String> data) {
		scenario().given("I'm on case search page", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager"));
		}).when("I fill case form details and submit", () -> {
			pages.getHomepage().switchToAnyAccount(data.get("accountName"), data.get("AccountNumber"));
			App().Pages().getAccountDetailsPage().getAccountRecordType();
		pages.getAccountDetailsPage().clickOnRelated("Assets");
		pages.getAssetsListPage().openAssetforEEAccount(data.get("assetName"),data.get("MINNumber"),data.get("SFServiceID"), true);
			pages.getAssetDetailsPage().getBillAccountNumber();
			pages.getAssetDetailsPage().clickOnRelated("Cases");
			pages.getCaseListPage().createNewCaseFromAsset(data);
			pages.getCaseListPage().selectCase(data.get("Subject"));
			caseURL= getDriver().getCurrentUrl();
		}).then("I verify that the case is created", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "SIMActivation",key="SIMActivation_Single")
	@Test(priority = 2,dependsOnMethods = {"caseCreationTest"})
	private void changeCaseOwnerTest(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the change owner action", () -> {
			pages.getCaseDetailsPage().changeOwner(data.get("ownerName"));
			pages.getLoginpage().logoutCurrentUser(); 
			pages.getHomepage().switchToAnyUser(data.get("ownerName"));
			getDriver().get(caseURL);
			util.waitForCasePage();			
		}).then("I see the owner is changed", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}
	

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "SIMActivation",key="SIMActivation_Single")
	@Test(priority = 3,dependsOnMethods = {"changeCaseOwnerTest"})
	private void verifyTransactionDetails(Map<String, String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to case page and check transaction details section", () -> {
			pages.getCaseDetailsPage().verifyTransactionDetailsForSIMActivation(data,data.get("assetName"));
		}).then("I verify transaction details section", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "SIMActivation",key="SIMActivation_Single")
	@Test(priority = 4,dependsOnMethods = {"verifyTransactionDetails"})
	private void markCaseStatusToResolutionInProgress() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform the case status to Resolution in progress", () -> {
			pages.getCaseDetailsPage().markCaseStatusToResolutionInprogress();
		}).then("I see case status got changed to resolution in progress", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "SIMActivation",key="SIMActivation_Single")
	@Test(priority = 5,dependsOnMethods = {"markCaseStatusToResolutionInProgress"})
	private void verifyTransactionAsset() {
		scenario().given("I'm on case page", () -> {
		}).when("I scroll to transaction asset section", () -> {
			pages.getCaseDetailsPage().verifyTransactionAsset();
		}).then("I see transaction asset is generated", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "SIMActivation",key="SIMActivation_Single")
	@Test(priority = 6,dependsOnMethods = {"verifyTransactionAsset"})
	private void requestSIMActivation() {
		scenario().given("I'm on case page", () -> {
		}).when("I perform sim replacement action ", () -> {
			pages.getCaseDetailsPage().requestSIMActivation();
		}).then("I verify the sim replacement", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "SIMActivation",key="SIMActivation_Single")
	@Test(priority = 7,dependsOnMethods = {"requestSIMActivation"})
	private void verifyOrderDetails(Map<String ,String> data) {
		scenario().given("I'm on case page", () -> {
		}).when("I navigate to order search page", () -> {
			
			orderList=pages.getOrdersPage().verifyOrdersFromCasePage(caseURL,data.get("Transaction Type"));
		}).then("I verify the order generation", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@Test(priority = 8)
	private void getReferenceData() {
		Reporter.log("Case URL :"+caseURL, MessageTypes.Info);
		if(orderList.size()>0)
		{
			for(int i=0;i<orderList.size();i++)
			{
				Reporter.log("Order _"+(i+1)+" URL : "+orderList.get(i), MessageTypes.Info);

			}
		}
	
	}

}
