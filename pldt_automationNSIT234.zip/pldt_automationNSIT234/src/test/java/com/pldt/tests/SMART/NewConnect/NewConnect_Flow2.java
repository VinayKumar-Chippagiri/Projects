package com.pldt.tests.SMART.NewConnect;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.MyScreenRecorder;
import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;
import com.qmetry.qaf.automation.util.Validator;

public class NewConnect_Flow2 extends BaseTest {
	PageLib pages = new PageLib();
	AppCommons app = new AppCommons();
	WebUtilities util = new WebUtilities();
	ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Lead")
	@Test(description = "Lead creation for NewConnect", priority = 1)
	public void LoginasAdmin(Map<String, String> data) {
		scenario().given("I Log into PLDT Application as admin", () -> {
			MyScreenRecorder.startRecording("NewConnect Bulk");
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
		}).then("I verify User is Logged in as Admin", () -> {
		Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
		}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Lead")
	@Test(description = "Switch to RelationShip Manager", priority = 2,dependsOnMethods = { "LoginasAdmin" })
	public void Switching_to_RelationShipManager(Map <String,String> data) {
		scenario().then("I Switch to RelationShip Manager", () -> {
			props.setProperty("testdata", data);	
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
		}).then("I verify that User is Switched to Relation Ship Manager", () -> {			
			Reporter.logWithScreenShot("", MessageTypes.Info);			
	}).execute();
	}
	
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote")
	@Test(description = "Account", priority = 3, dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void OpenExistingAccount(Map<String, String> data) {
	scenario().given("I am in home page", () -> {
	util.refreshPage();
	util.waitFor(5);
	}).when("I open " + data.get("Account_Name") + " account", () -> {
	App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
	props.setProperty("Account", data.get("Account_Name"));
	ProjectBeans.setAccountURL(getDriver().getCurrentUrl()); // setting account url
	util.waitFor(10);
	}).then("I verify that account details page of " + data.get("Account_Name") +" is displayed", () -> {
	String heading = getDriver().findElement(By.xpath("//lightning-formatted-text[@class='custom-truncate']"))
	.getText();
	Validator.verifyThat("", heading, Matchers.containsString(data.get("Account_Name")));
	}).when("I click on contacts", () -> {
	getDriver().get(App().Pages().getAccountDetailsPage().getAccountViewPage("Contacts"));
	util.waitFor(By.xpath("//title[text()='Contacts | Salesforce']"), 10, true);
	}).and("I captured the contact name", () -> {
	String BillRecipient = getDriver().findElement(By.xpath("//span[.='Bill Recipient']/ancestor::tr//th//a"))
	.getText();
	props.setProperty("contact.BillRecipient", BillRecipient);
	Reporter.log("Technical Contact: " + BillRecipient);
	String DeliveryRecipient = getDriver().findElement(By.xpath("//span[.='Delivery Recipient - Smart']/ancestor::tr//th//a"))
			.getText();
			props.setProperty("contact.DeliveryRecipient", DeliveryRecipient);
			Reporter.log("Technical Contact: " + DeliveryRecipient);
	String Authorized_Signatory = getDriver()
	.findElement(By.xpath("//span[.='Authorized Signatory']/ancestor::tr//th//a")).getText();
	props.setProperty("Lead.fullName", Authorized_Signatory);
	Reporter.log("Authorized Signatory: " + Authorized_Signatory);
	Reporter.logWithScreenShot("Account Contact Details");
	}).and("I clicked on account and navigate back to account details page", () -> {
	QAFWebElement AccountName = new QAFExtendedWebElement("//a[@title='" + data.get("Account_Name") + "']");
	AccountName.click();
	}).then("then i verified that account details page is dispayed", () -> {
	util.waitForAccountPage();
	util.waitFor(3);
	pages.getLoginpage().logoutCurrentUser();
	Reporter.logWithScreenShot("Account Details Page");
	}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Lead")
	@Test(description = "Creating Lead", priority = 3,dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void CreatingLead(Map <String,String> data) {
		scenario().given("I am on list of lead page", () -> {
			util.waitFor(5);
			pages.getHomepage().goToAPP("Leads");
			pages.getLeadpage().getLeadNewButton().verifyVisible();
			pages.getLeadpage().getLeadNewButton().click();
			pages.getLeadpage().selectRecordType("business");
			pages.getLeadpage().getLeadNextButton().click();
		}).when("I add Lead Information for the New Lead: Business ", () -> {
			pages.getLeadpage().fillTheLeadForm();
			util.waitForLeadPage();
			Reporter.logWithScreenShot("Lead info is entered", MessageTypes.Info);
			pages.getLeadpage().markLeadStatusAsQualified();
			ProjectBeans.setLeadURL(getDriver().getCurrentUrl());
		}).then("I verify that user is changed as Credit Analyst and perform credit", () -> {
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("Credit Analyst"));
			getDriver().get(ProjectBeans.getLeadURL());
			util.waitForLeadPage();
			pages.getLeadpage().validateCreditCheck();
			pages.getLeadpage().convertLead(data);
			pages.getLoginpage().logoutCurrentUser();
			Reporter.logWithScreenShot("user is changed and perform credit", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Contact")
	@Test(description = "CreatingNewContactforNewConnect", priority = 4, dependsOnMethods = {"CreatingLead" })
	public void contactCreationTest(Map<String, String> data) {
		scenario().given("Navigating to Accounts to create Contact", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
			getDriver().get(ProjectBeans.getAccountURL());
			util.waitForAccountPage();
			pages.getAccountpage().ClickContacts();
			pages.getContactpage().clickNewAccContact();
		}).when("I add Contact Information for the New Contact", () -> {
			pages.getContactpage().fillContactForm();
			pages.getContactpage().clickSaveButton();
			pages.getLoginpage().logoutCurrentUser();
		}).then("I verify that information is entered", () -> {
			Reporter.logWithScreenShot("Laed info is entered", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Opportunity")
	@Test(description = "QuoteCreationTest",priority = 5, dependsOnMethods = { "Switching_to_RelationShipManager" })
	public void QuoteCreationTest(Map<String, String> data) {
		scenario().when("Navigating to Accounts to create Opportunity", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
			getDriver().get(ProjectBeans.getAccountURL());
			util.waitForAccountPage();
			if (util.getEnvironment().equalsIgnoreCase("NSIT234")) {
				pages.getAccountpage().CreateQuoteinAccountpage(data, data.get("OpportunityRecordType"),
						data.get("OpportunityType"), data.get("ContractingParty"), data.get("CurrentProvider"));
			} 
		}).when("I add Opportunity Information for the New Opportunity ", () -> {
		}).then("I verified that Opportunity is Created", () -> {
			Reporter.logWithScreenShot("Opportunity is Created", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test(description = "Adding Products To Cart",priority = 6, dependsOnMethods = { "QuoteCreationTest" })
	public void AddProductsToCart(Map<String, String> data) throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Add the products into the cart ", () -> {
			if (!util.getEnvironment().equalsIgnoreCase("R32SIT")) {
				pages.getQuotepage().ClickAddProducts();
				pages.getCartpage().selectPriceinCartpage();
				pages.getCartpage().QuickActionsAddProductsToCart(data,data.get("Plan"));
				if(data.get("SecondPlan").contains("Y")) {
					pages.getCartpage().QuickActionsAddProductsToCart(data,data.get("SecondPlanName"));	
				}
				if(data.get("Plan3").contains("Y")) {
					pages.getCartpage().QuickActionsAddProductsToCart(data,data.get("Plan3Name"));	
				}
				if(data.get("Plan4").contains("Y")) {
					pages.getCartpage().QuickActionsAddProductsToCart(data,data.get("Plan4Name"));	
				}
				if(data.get("Plan5").contains("Y")) {
					pages.getCartpage().QuickActionsAddProductsToCart(data,data.get("Plan5Name"));	
				}
				util.refreshSwitchToFrame();
				util.AttachFrame();
				util.clickUsingJs(By.xpath("//button[@title='Save Working Cart']"));
				 util.waitFor(By.xpath("//h1//span[.='Working Cart']"), 20, true);
				if (util.isElementDisplayed(By.xpath("//h1//span[.='Working Cart']"))) {
					util.clickUsingJs(By.xpath("//span[.='Parent Quote']/following::div[1]/span//a"));
				} else {
					util.waitForQuotePage();
				}
			}
		}).then("I verified that products are added in to cart", () -> {
			Reporter.logWithScreenShot("Products are Added and Redirected to quote page", MessageTypes.Info);
		}).execute();
	}


	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test(description = "Performing Availability Checks",priority = 7, dependsOnMethods = { "AddProductsToCart" })
	public void availabilityChecks(Map<String, String> data) throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I performed various availability checks ", () -> {
			if (util.getEnvironment().equalsIgnoreCase("R32SIT")) {
				pages.getQuotepage().numberAvailabilityCheck();
			}
			pages.getQuotepage().deviceAvailabilityCheck();
			ProjectBeans.setQuoteURL(getDriver().getCurrentUrl()); // SetQuoteURL
		}).then("I verified that checks are completed", () -> {
			Reporter.logWithScreenShot("Availability Checks", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote")
	@Test(description = "Updating QuoteValidatyPeriod,DeliveryDate and ContactDetails",priority = 8, dependsOnMethods = { "availabilityChecks" })
	public void updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I update contact and Validity period Information ", () -> {
			pages.getQuotepage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
		}).then("I verified that Details are populated", () -> {
			Reporter.logWithScreenShot("Details are populated", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "BillingAccounts")
	@Test(description = "Creating BillingAccount",priority = 9, dependsOnMethods = { "updateQuoteValidatyPeriod_DeliveryDate_ContactDetails" })
	public void createBillingAccount(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Billing Account ", () -> {
			pages.getBillingAndServiceAccount().createBillingAccount();
		}).then("I verified that Billing Account is Created", () -> {
			Reporter.logWithScreenShot("Billing Account is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "ServiceAccounts")
	@Test(description = "Creating Service Account",priority = 10, dependsOnMethods = { "createBillingAccount" })
	public void createServiceAccount(Map<String, String> data) throws InterruptedException {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I Create a Service Account ", () -> {
			getDriver().get(ProjectBeans.getQuoteURL()); // Get Quote URL
			util.waitForQuotePage();
			pages.getBillingAndServiceAccount().createServiceAccount();
		}).then("I verified that Service Account is Created", () -> {
			Reporter.logWithScreenShot("Service Account is Created", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test(description = "Updating Billing and Service Accounts",priority = 11, dependsOnMethods = { "createServiceAccount" })
	public void updateAccounts(Map<String, String> data) throws InterruptedException {
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I Update Billing and Service Account", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			pages.getCartpage().ModifyandUpdatePlans(data, data.get("Plan"));
			if (data.get("SecondPlan").contains("Y")) {
			pages.getCartpage().ModifyandUpdatePlans(data, data.get("SecondPlanName"));
			}
			if (data.get("Plan3").contains("Y")) {
				pages.getCartpage().ModifyandUpdatePlans(data, data.get("Plan3Name"));
				}
			if (data.get("Plan4").contains("Y")) {
				pages.getCartpage().ModifyandUpdatePlans(data, data.get("Plan4Name"));
				}
			if (data.get("Plan5").contains("Y")) {
				pages.getCartpage().ModifyandUpdatePlans(data, data.get("Plan5Name"));
				}
		}).then("I verified that Billing Account and Service Account is Updated", () -> {			
		}).execute();
	}

	@Test(description = "Validating cart", priority = 12, dependsOnMethods = { "updateAccounts" })
	public void validateCart() {
		scenario().given("I am on Quote Page", () -> {
		}).when("I Validate the Cart", () -> {
			pages.getQuotepage().ValidateCart();
		}).then("I verified that Cart is Validated", () -> {
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote")
	@Test(description = "Performing Credit Check",priority = 13, dependsOnMethods = { "validateCart" })
	public void creditCheck(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I perform Credit Check", () -> {
			pages.getQuotepage().CreditCheck();
			util.waitForQuotePage();
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("Credit_Analyst"));
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			pages.getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
					data.get("CreditApprovalCondition"), data.get("CreditRemark"));
			util.waitFor(10);
			pages.getLoginpage().logoutCurrentUser();
			pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
		}).then("I verified that Credit information is Updated ", () -> {
		}).execute();
	}
	

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Opportunity")
	@Test(description = "EBIT", priority = 14, dependsOnMethods = { "creditCheck" })
	public void performEbitApprovalTest(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
			ConfigurationManager.getBundle().setProperty("testdata", data);
		}).when("I Checking the EBIT Value and Submitting for Approval", () -> {
			util.scrollIntoElement(By.xpath("(//h3[.='Internal Approvals'])[1]"));
			if (!util.isElementDisplayed(By.xpath("//span[.='EBIT']/following::span[contains(text(),'40.00%')]"))) {
				pages.getQuotepage().submitEBITForApproval(data);
				pages.getLoginpage().logoutCurrentUser();
				pages.getHomepage().switchToAnyUser(data.get("Business Head"));
				pages.getQuotepage().approveEBIT(data);
				pages.getHomepage().switchToAnyUser(data.get("Relationship Manager "));
				getDriver().get(ProjectBeans.getQuoteURL());
			}else {
			pages.getQuotepage().changeStatusToInternalApproval();
			}
		}).then("I verified that Quote Status is moved to Internal Approval", () -> {
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote")
	@Test(description = "Quote to PDF", priority = 15, dependsOnMethods = { "performEbitApprovalTest" })
	public void quotetoPDF(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
			props.setProperty("testdata", data);
		}).when("I Converting Quote to PDF", () -> {			
			pages.getQuotepage().QuotetoPDF();
			app.pickLatestFileFromDownloads("Quote Document");
			Reporter.logWithScreenShot("Quote Status Changed to Presented", MessageTypes.Info);
			pages.getQuotepage().changeStatusToApproved1();
			Reporter.logWithScreenShot("Quote Status Changed to Approved", MessageTypes.Info);
		}).then("I verified that Quote to PDF is Converted and Status Changed to Approved", () -> {
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Quote")
	@Test(description = "Device Reservations",priority = 16, dependsOnMethods = { "quotetoPDF" })
	public void deviceReservations(Map<String, String> data) {
		ConfigurationManager.getBundle().setProperty("testdata", data);
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Device Reservation", () -> {
			pages.getQuotepage().DeviceReservation(data);
		}).then("I verified that Device reservation is completed", () -> {
			Reporter.logWithScreenShot("Device reservation", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test(description = "Number Reservations",priority = 17, dependsOnMethods = { "deviceReservations" })
	public void numberReservation(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Number Reservation", () -> {
			pages.getQuotepage().numberReservationCheck(data);
			if (data.get("SecondPlan").contains("Y")) {
				pages.getQuotepage().numberReservationCheck(data);
			}
			if (data.get("Plan3").contains("Y")) {
				pages.getQuotepage().numberReservationCheck(data);
			}
			if (data.get("Plan4").contains("Y")) {
				pages.getQuotepage().numberReservationCheck(data);
			}
			if (data.get("Plan5").contains("Y")) {
				pages.getQuotepage().numberReservationCheck(data);
			}
		}).then("I verified that Number Reservation is completed", () -> {
			Reporter.logWithScreenShot("Number Reservation is Completed", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test(description = "Syncronizing QLI Items",priority = 18, dependsOnMethods = { "numberReservation" })
	public void syncronizeQLIItems(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I perform the Synchronization", () -> {
			App().Pages().getQuotepage().SynchronizingAccount(data.get("Plan"), data.get("Relationship Manager"));
			if (data.get("SecondPlan").contains("Y")) {
				App().Pages().getQuotepage().SynchronizingAccount(data.get("SecondPlanName"), data.get("Relationship Manager"));	
			}
			if (data.get("Plan3").contains("Y")) {
				App().Pages().getQuotepage().SynchronizingAccount(data.get("Plan3Name"), data.get("Relationship Manager"));	
			}
			if (data.get("Plan4").contains("Y")) {
				App().Pages().getQuotepage().SynchronizingAccount(data.get("Plan4Name"), data.get("Relationship Manager"));	
			}
			if (data.get("Plan5").contains("Y")) {
				App().Pages().getQuotepage().SynchronizingAccount(data.get("Plan5Name"), data.get("Relationship Manager"));	
			}
			pages.getQuotepage().ChangeStatusToAccepted(data);
		}).then("I verified that Status changed to Accepted", () -> {
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test(description = "Creating Contract",priority = 19, dependsOnMethods = { "syncronizeQLIItems" })
	public void CreateContract(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Create Contract", () -> {
			pages.getQuotepage().CreateContract();
		}).then("I verified that Contract is Created", () -> {
			Reporter.logWithScreenShot("Contract is Created", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "Contract")
	@Test(description = "Upload file", priority = 20, dependsOnMethods = { "CreateContract" })
	public void generateDocuments(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("I am on Contract Page", () -> {
		}).when("I click on generate Documents ", () -> {
			util.refreshPage();
			util.waitForContractPage();
			App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
			app.pickLatestFileFromDownloads("Contract Document");
			util.waitForContractPage();
		}).then("i verified that File is Uploaded", () -> {
			Reporter.logWithScreenShot(" Generate Documents ", MessageTypes.Info);
		}).execute();
	}
	
	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test(description = "Creating Contract",priority = 21, dependsOnMethods = { "generateDocuments" })
	public void ChangingContractStatus(Map<String, String> data) {
		scenario().given("I am on Quote Page", () -> {
		}).when("I click on Create Contract", () -> {
			pages.getQuotepage().ChangeTheStatusToSigned();
			ProjectBeans.setContractURL(getDriver().getCurrentUrl()); // setting Contract Url
		}).then("I verified that Contract Status is Changed", () -> {
			Reporter.logWithScreenShot("Contract Status is Changed to Signed", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/NewConnect.xlsx", sheetName = "CartDetails")
	@Test(description = "Checking Orders",priority = 22, dependsOnMethods = { "ChangingContractStatus" })
	public void orders(Map<String, String> data) {
		scenario().given("I am on Contract Page", () -> {
		}).when("I move to orders page", () -> {
			getDriver().get(ProjectBeans.getQuoteURL());
			util.waitForQuotePage();
			orderList = pages.getQuotepage().VerifyOrders(90,11);
			ProjectBeans.setOrderURL(getDriver().getCurrentUrl());
		}).then("I verified the status of Orders", () -> {
			Reporter.logWithScreenShot(" Orders", MessageTypes.Info);
		}).execute();
		MyScreenRecorder.stopRecording();
	}

	@Test(priority = 23, dependsOnMethods = { "orders" })
	public void getReferenceData() {
		Reporter.log("Lead URL :" + ProjectBeans.getLeadURL(), MessageTypes.Info);
		Reporter.log("Account URL :" + ProjectBeans.getAccountURL(), MessageTypes.Info);
		Reporter.log("Opportunity URL :" + ProjectBeans.getOpportunityURL(), MessageTypes.Info);
		Reporter.log("Quote URL :" + ProjectBeans.getQuoteURL(), MessageTypes.Info);
		Reporter.log("Contract URL :" + ProjectBeans.getContractURL(), MessageTypes.Info);
		Reporter.log("OrderPage URL :"+ProjectBeans.getOrderURL(), MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order _" + (i + 1) + " URL : " + orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
