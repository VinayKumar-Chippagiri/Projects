package com.pldt.tests;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class CleanUp extends BaseTest {
	WebUtilities util = new WebUtilities();
	PageLib pages = new PageLib();
	private static By userName = By.xpath("//input[@id='username']");
	private static By passWord = By.xpath("//input[@id='password']");
	private static By login = By.xpath("//input[@id='Login']");
	private static By showActions = By.xpath("(//td/span/div/a)[last()]");
	private static By actionsDelete = By.xpath("//a[@title='Delete']");

//	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "ChangeMIN",key="ChangeMIN_Tc_01")
	@Test(description = "Login as Admin", priority = 1)
	public void Login_as_Admin_into_SalesForce_Application() {
		scenario().given("I logged in to PLDT Application as Admin", () -> {
			getDriver().get(props.getString("env.baseurl"));
			getDriver().findElement(userName).sendKeys(props.getString("admin.userName"));
			getDriver().findElement(passWord).sendKeys(props.getString("admin.password"));
			getDriver().findElement(login).click();
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}).then("I verify User is Logged in as Admin", () -> {
			Reporter.logWithScreenShot("", MessageTypes.Info);
		}).execute();
	}

	@Test(description = "Selecting case to delete", priority = 2)
	public void CaseCleanUp() {
		scenario().and("Selecting Case to delete", () -> {
			App().Pages().getHomepage().switchToAnyAccount(props.getString("delete.caseNumber"), "Case");
			try {
				util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])"));
			} catch (Exception e) {
				util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[last()]"));
			}
			util.clickUsingJs(By.xpath("//span[normalize-space()='Delete']"));
			util.waitFor(By.xpath("//button[@title='Delete']"), 10, true);
			util.clickUsingJs(By.xpath("//button[@title='Delete']"));
			util.waitForGenericToastMessage();
		}).then("I verify that Case is deleted", () -> {
			if (util.isElementDisplayed(By.xpath("//*[@data-aura-class='forceToastMessage']"))) {
				Reporter.logWithScreenShot("Case is deleted", MessageTypes.Pass);
			} else {
				Reporter.logWithScreenShot("Case is Not deleted", MessageTypes.Fail);
			}
		}).execute();
	}

	@Test(description = "Selecting Order to delete", priority = 3)
	public void OrderCleanUp() {
		scenario().given("Selecting Order to delete", () -> {
			util.refreshPage();
			App().Pages().getHomepage().switchToAnyAccount(props.getString("delete.orderNumber"), "Order");
			try {
				util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])"));
			} catch (Exception e) {
				util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[last()]"));
			}
			util.waitFor(actionsDelete, 10, true);
			util.clickUsingJs(actionsDelete);
			util.waitFor(By.xpath("//button[@title='Delete']"), 10, true);
			util.clickUsingJs(By.xpath("//button[@title='Delete']"));
			util.waitForGenericToastMessage();
		}).then("I verify that Order is deleted", () -> {
			if (util.isElementDisplayed(By.xpath("//*[@data-aura-class='forceToastMessage']"))) {
				Reporter.logWithScreenShot("Order is deleted", MessageTypes.Pass);
			} else {
				Reporter.logWithScreenShot("Order is Not deleted", MessageTypes.Fail);
			}
		}).execute();
	}

	@Test(description = "deleting quote", priority = 4)
	public void QuoteCleanUp() {
		scenario().given("Selecting Quote to delete", () -> {
			util.refreshPage();
//			pages.getHomepage().goToAPP("Quotes");
//			util.waitFor(By.xpath("//input[@placeholder='Search this list...']"), 20, true);
//			
//			pages.getQuoteListPage().getQuoteLink(props.getString("delete.QuoteNumber"));
			App().Pages().getQuoteListPage().SwitchToAccount(props.getString("delete.QuoteNumber"));
			util.clickUsingJs(showActions);
			util.waitFor(actionsDelete, 10, true);
			util.clickUsingJs(actionsDelete);
			util.waitFor(By.xpath("//button[@title='Delete']"), 10, true);
			util.clickUsingJs(By.xpath("//button[@title='Delete']"));
			util.waitForGenericToastMessage();
		}).then("I verify that Quote is deleted", () -> {
			if (util.isElementDisplayed(By.xpath("//*[@data-aura-class='forceToastMessage']"))) {
				Reporter.logWithScreenShot("Quote is deleted", MessageTypes.Pass);
			} else {
				Reporter.logWithScreenShot("Quote is Not deleted", MessageTypes.Fail);
			}
		}).execute();
	}
}
