package com.pldt.tests.SMART.MNP;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.util.ArrayList;
import java.util.Map;

import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.data.MetaData;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class MNPPortOut_Sun_TC03 extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL = null;
	String orderURL = null;
	ArrayList<String> orderList = null;

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Login", key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).when("User Switched as Relationship Manager", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("Relationship Manager"));
			Reporter.log("Switched to Relationship manager:" + data.get("Relationship Manager"));
		}).then("verify Admin successfully switched to RM user", () -> {
			Reporter.logWithScreenShot("Successfully switched to RM");
			
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/MNP_TestData.xlsx", sheetName = "Case", key = "${key.name}")
	@Test(description = "Creating new case for MNP portout", priority = 2, dependsOnMethods = { "Login" })
	public void CreateNewCase(Map<String, String> data) throws InterruptedException {
		scenario().given("Going in account and selecting asset", () -> {
//			App().Pages().getAccountListPage().launchPage(null, null);
//			util.waitFor(5);
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"),data.get("Account_No"));
		}).when("Creating case and checking case owner", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getCasepage().createNewCase();
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			caseURL = getDriver().getCurrentUrl();
		}).and("Copying case owner and case number", () -> {
			App().Pages().getCasepage().copyCaseOwnerNameAndNumber();
		}).then("User verify that case got created and navigated to case", () -> {
			Reporter.logWithScreenShot("Navigated to case page");
		}).execute();
	}

	@Test(description = "Create TransactionAsset And Perform EligibilityCheck", priority = 3, dependsOnMethods = { "CreateNewCase" })
	public void CreateTransactionAssetAndPerformEligibilityCheck() {
		scenario().given("Getting Case Number and updating in AssetCreationSUNInfinty.csv file ", () -> {
			String casenum = App().Pages().getCasepage().getCASENUMBER();
			app.UpdateIDInCSVFile("resources/MNP_Upload/AssetCreationSUNInfinty.csv", "\t" + casenum);
		}).when("uploading AssetCreationSUN.csv file to create transaction asset ", () -> {
			App().Pages().getCasepage().ClickOnBulkUpload();
			App().Pages().getCasepage().bulkCreateTransAsset(props.getProperty("user.dir")+ "\\resources\\MNP_Upload\\AssetCreationSUNInfinty.csv");
			util.waitForCasePage();
			App().Pages().getCaseDetailsPage().verifyTransactionAsset();
		}).and("Clicking on resolution in progress and performing eligibility check", () -> {
			App().Pages().getCasepage().clickOnResolInProgress();
			App().Pages().getCasepage().ClickOnBulkUpload();
			String Caseid = App().Pages().getCasepage().retriveCaseNumberFromURL();
			util.waitForCasePage();
			app.UpdateIDInCSVFile("resources/MNP_Upload/EligibilityCheckSUNInfinity.csv", Caseid);
			App().Pages().getCasepage().SUNInfinityEligibilityCheckPerform(
					props.getProperty("user.dir")+ "\\resources\\MNP_Upload\\EligibilityCheckSUNInfinity.csv");
		 }).then("User performed EligibilityCheck by uploading file ", () -> {
				Reporter.logWithScreenShot("Performed EligibilityCheck", MessageTypes.Info);
		}).execute();
	}

	@Test(description = "Create SUNInfinityAsset and GenerateUSC", priority = 4, dependsOnMethods = { "CreateTransactionAssetAndPerformEligibilityCheck" })
	public void CreateSUNInfinityAssetAndGenerateUSC() {
		scenario().given("Creating SUN Infinity asset and clicking on GenerateUSC ", () -> {
			try {
				App().Pages().getCasepage().createSUNInfinityAsset();
				App().Pages().getOrdersPage().verifyOrderFromCasePage(caseURL,1);
				App().Pages().getOrdersPage().verifyOrderIsActivated(25);
				App().Pages().getCasepage().redirectCaseByClickOnCaseNo();
				App().Pages().getCasepage().clickOnGenerateUSC();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}).then("User verify that SUNInfinityAseet created and USC are completed", () -> {
			Reporter.logWithScreenShot("SUNInfinityAseet created and USC ", MessageTypes.Info);
		}).execute();
	}

	
	@Test(description = "Verify Orders", priority = 5,dependsOnMethods = { "CreateSUNInfinityAssetAndGenerateUSC" })
	public void verifyOrders() {
		scenario().given("Generating orders", () -> {
			orderList=App().Pages().getOrdersPage().verifyOrderFromCasePage(caseURL,2);
		}).then("User verified that Orders got generated", () -> {
			Reporter.logWithScreenShot(" Orders generated ", MessageTypes.Info);
		}).execute();
	}

	@Test(priority = 6,dependsOnMethods = { "verifyOrders" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order_" +i+1 + ": " + orderList.get(i), MessageTypes.Info);
			}
		}
	}
}