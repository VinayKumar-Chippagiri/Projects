package com.pldt.tests.SMART.AfterSales.Retention;

import static com.qmetry.qaf.automation.step.client.RuntimeScenarioFactory.scenario;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.testng.annotations.Test;

import com.common.utilities.AppCommons;
import com.common.utilities.ExcelReader;
import com.common.utilities.MyScreenRecorder;
import com.common.utilities.WebUtilities;
import com.pldt.tests.BaseTest;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.util.Reporter;

public class RetentionBulk extends BaseTest {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	String caseURL = null;
	String quoteURL = null;
	String orderURL = null;
	ArrayList<String> orderList = null;
	String caseID = null;

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "RetentionBrandMigration", key = "${key.name}")
	@Test(description = "Login", priority = 1)
	public void Login(Map<String, String> data) {
		scenario().given("User Log into PLDT Application as admin", () -> {
			props.setProperty("testdata", data);
			App().Pages().getLoginpage().launchPage(null, null);
			App().Pages().getLoginpage().LoginAsAdmin();
			Reporter.log("User Login As Admin:" + data.get("Username"));
		}).when("User Switched as RM", () -> {
			App().Pages().getHomepage().switchToAnyUser(data.get("RM"));
			Reporter.log("Switched to Relationship manager:" + data.get("RM"));
		}).then("verify Admin successfully switched to RM user", () -> {
			Reporter.logWithScreenShot("Successfully switched to RM");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "RetentionBrandMigration", key = "${key.name}")
	@Test(description = "Creating new case for Retention", priority = 2, dependsOnMethods = { "Login" }) //
	public void CreateNewCase(Map<String, String> data) {
		scenario().given("User going in account", () -> {
			App().Pages().getHomepage().switchToAnyAccount(data.get("Account_Name"), data.get("Account_No"));
		}).when("User creating case and checking case owner", () -> {
			App().Pages().getAssetDetailsPage().clickOnRelated("Cases");
			App().Pages().getCaseListPage().clickNewCaseButton();
			util.waitFor(5);
			App().Pages().getNewCaseModal().SelectRecordType(data.get("Record Type"));
			props.setProperty("testdata", data);
			App().Pages().getNewCaseModal().createRetentionNewCase(data.get("BillingAccountNumber"), data);
			App().Pages().getCaseListPage().selectCase(data.get("Subject"));
			util.waitForCasePage();
			util.waitFor(5);
			caseID = getDriver().findElementByXPath(
					"//span[text()='Case Information']//following::span[text()='Case Number']//following::lightning-formatted-text[1]")
					.getText();
		}).and("User modifying case and change status to resolution in progress", () -> {
			props.setProperty("testdata", data);
			App().Pages().getCaseDetailsPage().caseModification(data, data.get("OfferMigrationType"));
			caseURL = getDriver().getCurrentUrl();
			if (data.get("EFSAM") != null && !data.get("EFSAM").equalsIgnoreCase("SKIP")) {
				App().Pages().getCaseDetailsPage().changeOwner(data.get("EFSAM"));
				App().Pages().getLoginpage().logoutCurrentUser();
				App().Pages().getHomepage().switchToAnyUser(data.get("EFSAM"));
				getDriver().get(caseURL);
				util.waitForCasePage();
			}
			App().Pages().getCaseDetailsPage().markCaseStatusToResolutionInprogress();
			if (data.get("Case Origin").equalsIgnoreCase("Bulk")) {
				try {
					ExcelReader.updateCSV(data, "\t" + caseID);
				} catch (IOException e) {
					e.printStackTrace();
				}
				if (!App().Pages().getCaseDetailsPage().bulkUpload(data)) {
					Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
				}

				getDriver().get(caseURL);
			}
		}).and("User uploading bulk file", () -> {
			App().Pages().getCaseDetailsPage().requestRetention(data.get("Plan"), data);
		}).and("User navigate to quote", () -> {
			App().Pages().getCaseDetailsPage().navigateToQuoteFromCart();
		}).then("Successfully Created case and navigated to quote page", () -> {
			Reporter.logWithScreenShot("Successfully Created case,Modified case and navigated to quote page");
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "RetentionBrandMigration", key = "${key.name}")
	@Test(description = "Adding Device and Configuring Device ", priority = 3, dependsOnMethods = { "CreateNewCase" })
	public void ConfigureCart(Map<String, String> data) {
		scenario().given("User is on quote page", () -> {
		}).when("User click on Modify product and navigate to cart page", () -> {
		}).and("User add device and configure it", () -> {
			props.setProperty("testdata", data);
			App().Pages().getQuotepage().workingCartForBulk(data);
		}).then("User verify that cart configuration done", () -> {
			Reporter.logWithScreenShot("Cart Configuration done ", MessageTypes.Pass);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "RetentionBrandMigration", key = "${key.name}")
	@Test(description = "Updating mandatory fields in quote page", priority = 4, dependsOnMethods = { "ConfigureCart" })
	public void QuoteUpdation(Map<String, String> data) {
		scenario().given("User is on Quote page", () -> {
		}).when("User updating quote page", () -> {
			util.waitForQuotePage();
			App().Pages().getQuotepage().ValidateCart();
			App().Pages().getQuoteDetailsPage().updateQuoteValidatyPeriod_DeliveryDate_ContactDetails(data);
			quoteURL = getDriver().getCurrentUrl();
			util.waitFor(5);
		}).then("Verify quote page updated or not", () -> {
			props.setProperty("QuoteURL", getDriver().getCurrentUrl());
			System.out.println(props.getProperty("QuoteURL"));
			Reporter.logWithScreenShot("Quote updation is done ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "RetentionBrandMigration", key = "${key.name}")
	@Test(description = "Logout as RM and Login as CA", priority = 5, dependsOnMethods = { "QuoteUpdation" })
	public void logoutAndLoginAsCA(Map<String, String> data) {
		scenario().given("User is on Quote Page", () -> {
		}).when("logout as RM and Login as Credit Analyst", () -> {
			App().Pages().getQuotepage().CreditCheck();
			App().Pages().getLoginpage().logoutCurrentUser();
			App().Pages().getHomepage().switchToAnyUser(data.get("CA").toString());
		}).then("User verified that User is Logged in as Credit Analyst", () -> {
			Reporter.logWithScreenShot(" Logged in as Credit Analyst ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "RetentionBrandMigration", key = "${key.name}")
	@Test(description = "Credit check using Credit Analyst", priority = 6, dependsOnMethods = { "logoutAndLoginAsCA" })
	public void UpdateCreditInfo(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("User is on Quote Page", () -> {
		}).when("User update Credit Information using Credit Analyst", () -> {
			String url = props.getPropertyValue("QuoteURL");
			getDriver().navigate().to(url);
			App().Pages().getQuotepage().UpdateCreditInformation(data.get("CreditApprovalStatus"),
					data.get("CreditApprovalCondition"), data.get("CreditRemark"));
		}).then("User verified that Credit Information Fields are Updated", () -> {
			Reporter.logWithScreenShot("Credit Information ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "RetentionBrandMigration", key = "${key.name}")
	@Test(description = "Logout as CA and Login as RM", priority = 7, dependsOnMethods = { "UpdateCreditInfo" })
	public void logoutAndloginAsRM(Map<String, String> data) {
		props.setProperty("testdata", data);
		scenario().given("User is on Quote Page", () -> {
		}).when("logout as CA and Login as Relationship Manager", () -> {
			App().Pages().getLoginpage().logoutCurrentUser();
			if (data.get("EFSAM") != null && !data.get("EFSAM").equalsIgnoreCase("SKIP")) {
				App().Pages().getHomepage().switchToAnyUser(data.get("EFSAM").toString());
			} else {
				App().Pages().getHomepage().switchToAnyUser(data.get("RM").toString());
			}
			getDriver().navigate().to(props.getPropertyValue("QuoteURL"));
		}).then("User verified that User is Logged in as Relationship Manager", () -> {
			Reporter.logWithScreenShot(" Logged in as Relationship Manager ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "RetentionBrandMigration", key = "${key.name}")
	@Test(description = "Device Availability Check And Device Reservation", priority = 8, dependsOnMethods = {
			"QuoteUpdation" })
	public void DeviceReservation(Map<String, String> data) {
		scenario().given("User is on Quote page", () -> {
		}).when("User performing device availability", () -> {
			if (data.get("AddDeviceOrNot").equalsIgnoreCase("Yes")) {
				App().Pages().getQuotepage().deviceAvailability();
			}
		}).and("User performing quote to pdf", () -> {
			util.ChangeStatus("Internal Approval");
			App().Pages().getQuotepage().QuotetoPDF();
			app.pickLatestFileFromDownloads("Quote Document");
			util.ChangeStatus("Customer Approved");
		}).and("User performing device reservation", () -> {
			App().Pages().getQuotepage().DeviceReservation(data);
			App().Pages().getQuotepage().ChangeStatusToAccepted(data);
		}).then("User verified that Device is available and Reserved", () -> {
			Reporter.logWithScreenShot(" Device Reservation done ", MessageTypes.Info);
		}).execute();
	}

	@QAFDataProvider(dataFile = "resources/testdata/AfterSales.xlsx", sheetName = "RetentionBrandMigration", key = "${key.name}")
	@Test(description = "Create contract", priority = 9, dependsOnMethods = { "DeviceReservation" })
	public void CreateContract(Map<String, String> data) {
		scenario().given("User is on Quote page", () -> {
		}).when("User create contract", () -> {
			App().Pages().getQuoteDetailsPage().CreateContract();
		}).and("User click on generate Documents ", () -> {
			util.refreshPage();
			util.waitForContractPage();
			App().Pages().getContractpage().GenerateContractDocument(data.get("Template"));
			app.pickLatestFileFromDownloads("Contract Document");
			util.waitForContractPage();
		}).and("User changed contract status to signed", () -> {
			App().Pages().getContractpage().ChangeTheStatusToSigned();
			util.waitFor(3);
		}).then("User verified that Contract got generated", () -> {
			Reporter.logWithScreenShot(" Contract generated ", MessageTypes.Info);
		}).execute();

	}

	@Test(description = "Verify Orders", priority = 10, dependsOnMethods = { "CreateContract" })
	public void VerifyOrders() {
		scenario().given("Generating orders", () -> {
			getDriver().navigate().to(props.getPropertyValue("QuoteURL"));
			orderList = App().Pages().getOrdersPage().VerifyOrders(40,2);
		}).then("User verified that Orders got generated", () -> {
			Reporter.logWithScreenShot(" Orders generated ", MessageTypes.Info);
		}).execute();
		MyScreenRecorder.stopRecording();
	}

	@Test(priority = 11, dependsOnMethods = { "VerifyOrders" })
	public void getReferenceData() {
		Reporter.log("Case URL :" + caseURL, MessageTypes.Info);
		Reporter.log("Quote URL :" + quoteURL, MessageTypes.Info);
		if (orderList.size() > 0) {
			for (int i = 0; i < orderList.size(); i++) {
				Reporter.log("Order_" + i + 1 + ": " + orderList.get(i), MessageTypes.Info);
			}
		}
	}
}
