package com.pldt.pages;

import org.openqa.selenium.interactions.Actions;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SyniverseHomePage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	@FindBy(locator = "xpath=//tr[@class='menubar']//tbody//a[text()='RP']")
	private QAFWebElement RPLink;
	@FindBy(locator = "xpath=//div[@id='dropmenudiv']/a[text()='Create NPO']")
	private QAFWebElement CreateNPOLink;
	@FindBy(locator = "xpath=//tr[@class='menubar']//tbody//a[text()='DP']")		//Nimesh
	private QAFWebElement DPLink;
	@FindBy(locator = "xpath=//div[@id='dropmenudiv']/a[text()='Service Disconnect']")		//Nimesh
	private QAFWebElement ServiceDisconnectLink;
	@FindBy(locator = "xpath=//div[@id='dropmenudiv']/a[text()='Answer NPO']")		//Nimesh
	private QAFWebElement AnswerNPOLink;
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getRPLink() {
		return RPLink;
	}

	public QAFWebElement getCreateNPOLink() {
		return CreateNPOLink;
	}

	public QAFWebElement getDPLink() {
		return DPLink;
	}

	public QAFWebElement getServiceDisconnectLink() {
		return ServiceDisconnectLink;
	}

	public QAFWebElement getAnswerNPOLink() {
		return AnswerNPOLink;
	}

	public void ClickOnNPO() {
		Actions action = new Actions(driver);
		action.moveToElement(getRPLink()).perform();
		getCreateNPOLink().click();
	}
	public void ClickOnAnswerNPO() {
		Actions action = new Actions(driver);
		action.moveToElement(getDPLink()).perform();
		getAnswerNPOLink().click();
	}
	public void ClickOnServiceDisconnect()
	{
		Actions action = new Actions(driver);
		action.moveToElement(getDPLink()).perform();
		getServiceDisconnectLink().click();
		
	}
}