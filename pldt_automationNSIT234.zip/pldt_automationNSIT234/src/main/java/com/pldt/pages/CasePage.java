package com.pldt.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Set;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.apache.http.util.Asserts;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.common.utilities.AppCommons;
import com.common.utilities.WebUtilities;
import com.pldt.locators.CasePageLocators;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class CasePage extends WebDriverBaseTestPage<WebDriverTestPage> implements CasePageLocators {
	WebUtilities util = new WebUtilities();
	AppCommons app = new AppCommons();
	private static String CASEOWNER;
	private static String CASENUMBER;
	private static String CASEURL;
	public static By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	public static By assetID = By.xpath("//span[.='Asset ID']/following::div[1]");
	public static By MINNumber = By.xpath("//span[.='MIN Number']/following::div[1]");
	public static By transactionStatus = By.xpath("//span[.='Transaction Status']/following::div[1]");
	public static By markCurrentStatus = By.xpath("//span[text()='Mark as Current Status']");
	private static By changeOwnerEdit = By.xpath("//button[@title='Change Owner']");
	private static By searchUser = By.xpath("//input[@placeholder='Search Users...']");
	private static By changeOwnerButton = By.xpath("//button[@name='change owner']");
	private static By simReplacementFee = By.xpath("//span[.='SIM Replacement Fee']/following::div[1]");
	private static By transactionAsset = By.xpath("(//span[text()='Transaction Asset'])[1]/following-sibling::span");
	private static By relatedSection = By.xpath("(//flexipage-record-home-scrollable-column)[3]");
	private static By doneButton = By.xpath("//p[.='Done']");
	private static By editButton = By.xpath("//button[text()='Edit'][@class='slds-button slds-button_brand']");
	private static By servicereq = By
			.xpath("(//label[text()='Services Requested']/following::button[@name='Services_Requested__c'])");
	private static By highLevelDisconnection = By.xpath(
			"(//label[text()='High Level Disconnection Reason']/following::button[@name='High_Level_Disconnection_Reason__c'])");
	private static By saveRecord = By.xpath("//button[@class='slds-button slds-button_brand'][@type='submit']");
	@FindBy(locator = "xpath=//div[@class='iframe-parent slds-template_iframe slds-card']//iframe")
	private QAFWebElement frame2;
	@FindBy(locator = Subject)
	private QAFWebElement CaseSubject;
	@FindBy(locator = Line_of_business)
	private QAFWebElement CaseLOB;
	@FindBy(locator = Type_of_cust_req)
	private QAFWebElement CaseTypeCustomerRequest;
	@FindBy(locator = Type)
	private QAFWebElement CaseType;
	@FindBy(locator = Case_origin)
	private QAFWebElement CaseOrigin;
	@FindBy(locator = Status)
	private QAFWebElement CaseStatus;
	@FindBy(locator = High_level_Trans_class)
	private QAFWebElement CaseHighLevelTransactionClassification;
	@FindBy(locator = Trans_type)
	private QAFWebElement CaseTransactionType;
	@FindBy(locator = Trans_sub_type)
	private QAFWebElement CaseTransactionSubType;
	@FindBy(locator = Trans_reason)
	private QAFWebElement CaseTransactionReason;
	@FindBy(locator = MIN_portin)
	private QAFWebElement CaseMINPortIn;
	@FindBy(locator = Current_provider)
	private QAFWebElement CaseCurrentProvider;
	@FindBy(locator = Rec_provider)
	private QAFWebElement CaseRecipientProvider;
	@FindBy(locator = Save)
	private QAFWebElement save;
	@FindBy(locator = SMARTSERREQ)
	private QAFWebElement smartserreq;
	@FindBy(locator = NEWCASE_NEXT)
	private QAFWebElement newcasenext;
	@FindBy(locator = Case_filter)
	private QAFWebElement casefilter;
	@FindBy(locator = Subject_inputBox)
	private QAFWebElement SubjectInputBox;
	@FindBy(locator = Apply_Btn)
	private QAFWebElement ApplyBtn;
	@FindBy(locator = Apply_Btn2)
	private QAFWebElement ApplyBtn2;
	@FindBy(locator = CLOSE_FILTER)
	private QAFWebElement close_filter;
	@FindBy(locator = caseInfo)
	private QAFWebElement CaseInfo;
	@FindBy(locator = caseOwner)
	private QAFWebElement CaseOwner;
	@FindBy(locator = casenumber)
	private QAFWebElement CaseNumber;
	@FindBy(locator = setupSearchBox)
	private QAFWebElement SetupSearchBox;
	@FindBy(locator = groupQueues)
	private QAFWebElement GroupQueueBtn;
	@FindBy(locator = groupName)
	private QAFWebElement GroupName;
	@FindBy(locator = queueUserName)
	private QAFWebElement QueueUserName;
	@FindBy(locator = userLoginBtn)
	private QAFWebElement UserLoginBtn;
	@FindBy(locator = frame)
	private QAFWebElement switchframe;
	@FindBy(locator = toastmsg)
	private QAFWebElement Message;
	@FindBy(locator = filterCase)
	private QAFWebElement FilterCaseIcon;
	@FindBy(locator = filterCaseSearch)
	private QAFWebElement FilterCaseSearchBox;
	@FindBy(locator = searchList)
	private QAFWebElement SearchList;
	@FindBy(locator = casecheckbox)
	private QAFWebElement CaseCheckBox;
	@FindBy(locator = caseAcceptbtn)
	private QAFWebElement CaseAcceptBtn;
	@FindBy(locator = ThreeDotQuickActionTool)
	private QAFWebElement threedotQuickActionTool;
	@FindBy(locator = eligibilityCheckBtn)
	private QAFWebElement EligibilityCheckBtn;
	@FindBy(locator = caseTitle)
	private QAFWebElement CaseTitle;
	@FindBy(locator = showMoreActions)
	private QAFWebElement ShowMoreActionIcon;
	@FindBy(locator = uploadBulk)
	private QAFWebElement UploadBulkOption;
	@FindBy(locator = customObjects)
	private QAFWebElement CustomObjects;
	@FindBy(locator = mnpPortabilityCheckBtn)
	private QAFWebElement MNPPortabilityCheckBtn;
	@FindBy(locator = updateExistingRec)
	private QAFWebElement UpdateExistingRecord;
	@FindBy(locator = matchBy)
	private QAFWebElement MatchBy;
	@FindBy(locator = csv)
	private QAFWebElement CSVOption;
	@FindBy(locator = chooseFile)
	private QAFWebElement ChooseFile;
	@FindBy(locator = importFileNextButton)
	private QAFWebElement ImportFileNextBtn;
	@FindBy(locator = editMappingFieldNextButton)
	private QAFWebElement EditMappingFieldNextBtn;
	@FindBy(locator = startImport)
	private QAFWebElement StartImport;
	@FindBy(locator = okButton)
	private QAFWebElement OkButton;
	@FindBy(locator = generateLOU)
	private QAFWebElement GenerateLOU;
	@FindBy(locator = successTitle)
	private QAFWebElement SuccessTitle;
	@FindBy(locator = backToCaseBtn)
	private QAFWebElement BackToCaseBtn;
	@FindBy(locator = nextArrow)
	private QAFWebElement NextArrow;
	@FindBy(locator = resolutionInProgress)
	private QAFWebElement ResolutionInProgress;
	@FindBy(locator = markStatusComplete)
	private QAFWebElement MarkStatusComplete;
	@FindBy(locator = transactionDetailsC)
	private QAFWebElement TransactionDetails;
	@FindBy(locator = generateUSC)
	private QAFWebElement GenerateUSC;
	@FindBy(locator = doneBtn)
	private QAFWebElement DoneBtn;
	@FindBy(locator = caseSectionNewcase)
	private QAFWebElement CaseSectionNewcase;
	@FindBy(locator = transAssetBtn)
	private QAFWebElement TransAssetBtn;
	@FindBy(locator = addNewRec)
	private QAFWebElement AddNewRec;
	@FindBy(locator = "//div[@class='vlc-control-wrapper ng-binding']//input[@name='loopname']")
	private QAFWebElement planame;
	@FindBy(locator = triggerCheckbox)
	private QAFWebElement TriggerCheckbox;
	@FindBy(locator = caseLookupField)
	private QAFWebElement CaseLookupField;
	@FindBy(locator = "//span[text()='Create SUN Infinity Assets']")
	private QAFWebElement CreateSunInfinityAsset;
	@FindBy(locator = "//div[contains(text(),'Back to Case')]")
	private QAFWebElement SUNBackToCaseBtn;
	@FindBy(locator = "xpath=//button[text()='OK']")
	private QAFWebElement SUNOkBtn;
	@FindBy(locator = "//span[text()='Move selection to Chosen']")
	private QAFWebElement moveDocumentArrow;
	@FindBy(locator = "//div[@class='vlc-control-wrapper ng-binding']//input[@name='loopname']")
	private QAFWebElement PlanName;
//	@FindBy(locator = availableDocuments)
//	private QAFWebElement AvailableDocuments;
	@FindBy(locator = editButton1)
	private QAFWebElement EditButton;
	@FindBy(locator = "//button[text()='Save Record']")
	private QAFWebElement SaveRecord;
	@FindBy(locator = "//label[text()='Offer Migration Type']/following::div/div/button[@name='Offer_Migration_Type__c']")
	private QAFWebElement OfferMigrationType;
//	@FindBy(locator = PlanName)
//	private QAFWebElement planName;
	@FindBy(locator = SelectPlanNextButton)
	private QAFWebElement selectPlanNextButton;
	@FindBy(locator = Listview)
	private QAFWebElement listview;
	@FindBy(locator = SearchInput)
	private QAFWebElement searchInput;
	@FindBy(locator = ViewRecord)
	private QAFWebElement viewRecord;
//	@FindBy(locator = ChangeOwnerEdit)
//	private QAFWebElement changeOwnerEdit;
//	
//	@FindBy(locator = SearchUser)
//	private QAFWebElement searchUser;
//	
//	@FindBy(locator = ChangeOwnerButton)
//	private QAFWebElement changeOwnerButton;
//	

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getCaseSubject() {
		return CaseSubject;
	}

	public QAFWebElement getCaseLOB() {
		return CaseLOB;
	}

	public QAFWebElement getCaseTypeCustomerRequest() {
		return CaseTypeCustomerRequest;
	}

	public QAFWebElement getCaseType() {
		return CaseType;
	}

	public QAFWebElement getCaseOrigin() {
		return CaseOrigin;
	}

	public QAFWebElement getCaseStatus() {
		return CaseStatus;
	}

	public QAFWebElement getCaseHighLevelTransactionClassification() {
		return CaseHighLevelTransactionClassification;
	}

	public QAFWebElement getCaseTransactionType() {
		return CaseTransactionType;
	}

	public QAFWebElement getCaseTransactionSubType() {
		return CaseTransactionSubType;
	}

	public QAFWebElement getCaseTransactionReason() {
		return CaseTransactionReason;
	}

	public QAFWebElement getCaseMINPortIn() {
		return CaseMINPortIn;
	}

	public QAFWebElement getCaseCurrentProvider() {
		return CaseCurrentProvider;
	}

	public QAFWebElement getCaseRecipientProvider() {
		return CaseRecipientProvider;
	}

	public QAFWebElement getSave() {
		return save;
	}

	public QAFWebElement getSmartserreq() {
		return smartserreq;
	}

	public QAFWebElement getNewcasenext() {
		return newcasenext;
	}

	public QAFWebElement getCasefilter() {
		return casefilter;
	}

	public QAFWebElement getSubjectInputBox() {
		return SubjectInputBox;
	}

	public QAFWebElement getApplyBtn() {
		return ApplyBtn;
	}

	public QAFWebElement getCaseInfo() {
		return CaseInfo;
	}

	public QAFWebElement getCaseOwner() {
		return CaseOwner;
	}

	public QAFWebElement getCaseNumber() {
		return CaseNumber;
	}

	public QAFWebElement getSetupSearchBox() {
		return SetupSearchBox;
	}

	public QAFWebElement getGroupQueueBtn() {
		return GroupQueueBtn;
	}

	public QAFWebElement getGroupName() {
		return GroupName;
	}

	public QAFWebElement getQueueUserName() {
		return QueueUserName;
	}

	public QAFWebElement getUserLoginBtn() {
		return UserLoginBtn;
	}

	public QAFWebElement getSwitchframe() {
		return switchframe;
	}

	public QAFWebElement getMessage() {
		return Message;
	}

	public QAFWebElement getClose_filter() {
		return close_filter;
	}

	public QAFWebElement getFilterCaseIcon() {
		return FilterCaseIcon;
	}

	public QAFWebElement getFilterCaseSearchBox() {
		return FilterCaseSearchBox;
	}

	public QAFWebElement getSearchList() {
		return SearchList;
	}

	public QAFWebElement getCaseCheckBox() {
		return CaseCheckBox;
	}

	public QAFWebElement getCaseAcceptBtn() {
		return CaseAcceptBtn;
	}

	public QAFWebElement getThreedotQuickActionTool() {
		return threedotQuickActionTool;
	}

	public QAFWebElement getEligibilityCheckBtn() {
		return EligibilityCheckBtn;
	}

	public QAFWebElement getCaseTitle() {
		return CaseTitle;
	}

	public String getCASEOWNER() {
		return CASEOWNER;
	}

	public void setCASEOWNER(String cASEOWNER) {
		CASEOWNER = cASEOWNER;
	}

	public String getCASENUMBER() {
		return CASENUMBER;
	}

	public void setCASENUMBER(String cASENUMBER) {
		CASENUMBER = cASENUMBER;
	}

	public QAFWebElement getShowMoreActionIcon() {
		return ShowMoreActionIcon;
	}

	public QAFWebElement getUploadBulkOption() {
		return UploadBulkOption;
	}

	public QAFWebElement getCustomObjects() {
		return CustomObjects;
	}

	public QAFWebElement getMNPPortabilityCheckBtn() {
		return MNPPortabilityCheckBtn;
	}

	public QAFWebElement getUpdateExistingRecord() {
		return UpdateExistingRecord;
	}

	public QAFWebElement getMatchBy() {
		return MatchBy;
	}

	public QAFWebElement getCSVOption() {
		return CSVOption;
	}

	public QAFWebElement getChooseFile() {
		return ChooseFile;
	}

	public QAFWebElement getImportFileNextBtn() {
		return ImportFileNextBtn;
	}

	public QAFWebElement getEditMappingFieldNextBtn() {
		return EditMappingFieldNextBtn;
	}

	public QAFWebElement getStartImport() {
		return StartImport;
	}

	public QAFWebElement getOkButton() {
		return OkButton;
	}

	public QAFWebElement getGenerateLOU() {
		return GenerateLOU;
	}

	public QAFWebElement getSuccessTitle() {
		return SuccessTitle;
	}

	public QAFWebElement getBackToCaseBtn() {
		return BackToCaseBtn;
	}

	public QAFWebElement getGenerateUSC() {
		return GenerateUSC;
	}

	public QAFWebElement getDoneBtn() {
		return DoneBtn;
	}

	public QAFWebElement getCaseSectionNewcase() {
		return CaseSectionNewcase;
	}

	public QAFWebElement getViewRecord() {
		return viewRecord;
	}

	public void clickNewCase() {
		getCaseSectionNewcase().click();
		Reporter.log("Clicked on New button..");
	}
//	public QAFWebElement getAvailableDocuments() {
//		return AvailableDocuments;
//	}

	public QAFWebElement getMoveDocumentArrow() {
		return moveDocumentArrow;
	}

	public QAFWebElement getPlanName() {
		return PlanName;
	}

	public QAFWebElement getSelectPlanNextButton() {
		return selectPlanNextButton;
	}

	public QAFWebElement getListview() {
		return listview;
	}

	public QAFWebElement getSearchInput() {
		return searchInput;
	}
//	public QAFWebElement getChangeOwnerEdit() {
//		return changeOwnerEdit;
//	}
//
//	public QAFWebElement getSearchUser() {
//		return searchUser;
//	}
//
//	public QAFWebElement getChangeOwnerButton() {
//		return changeOwnerButton;
//	}

	public void createNewCase() {
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Transaction Type");
		util.select("Case Origin");
		util.select("Recipient Provider");
		getSave().click();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		getMessage().waitForNotVisible(200000);
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void SelectRecordType() {
		getSmartserreq().click();
		getNewcasenext().click();
		Reporter.log("Selected case record type as Smart Service Request..");
	}

	public void clickOnCaseByFiltering(String sub) {
		util.waitFor(casefilter, 10, true);
		getCasefilter().click();
		getSubjectInputBox().sendKeys(sub);
		if (getApplyBtn().isPresent()) {
			getApplyBtn().click();
		} else {
			ApplyBtn2.click();
		}
		getClose_filter().click();
		Reporter.logWithScreenShot("Created Case");
		QAFWebElement CaseInRowOne = new QAFExtendedWebElement("//a[text()=" + "'" + sub + "'" + "]/parent::span/a");
		util.waitFor(CaseInRowOne, 10, true);
		CaseInRowOne.click();
		Reporter.log("Opened created case by filtering case name..");
	}

	public void copyCaseOwnerNameAndNumber() {
		util.waitFor(By.xpath("//div[.='Case']"), 20, true);
		util.waitFor(By.xpath("//button[@title='Change Owner']/preceding::slot[1]/span"), 10, true);
		if (driver.findElementsByXPath("//button[@title='Change Owner']/preceding::slot[1]/span").size() > 0) {
			String CASEOWNER = driver.findElementByXPath("//button[@title='Change Owner']/preceding::slot[1]/span")
					.getText();
			setCASEOWNER(CASEOWNER);
		} else {
			String CASEOWNER = driver.findElementByXPath("//button[@title='Change Owner']/preceding::slot[1]")
					.getText();
			setCASEOWNER(CASEOWNER);
		}
		CASENUMBER = getCaseNumber().getText();
		setCASENUMBER(CASENUMBER);
		System.out.println(CASEOWNER);
		System.out.println(CASENUMBER);
		Reporter.log("Captured case owner and case number..");
	}

	public void openCaseOwnerAndRelatedUser() throws InterruptedException {
		util.clickUsingJs(By.xpath("(//div[@class='headerTrigger tooltip-trigger uiTooltip'])[last()]"));
		util.clickUsingJs(By.xpath("//a[@title='Setup']"));
		String winHandleBefore = driver.getWindowHandle();
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		System.out.println(tabs.size());
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.enterText(getSetupSearchBox(), CASEOWNER);
		getSetupSearchBox().sendKeys(Keys.ENTER);
		getGroupQueueBtn().waitForPresent(10000);
		getGroupQueueBtn().click();
		getGroupName().click();
		util.switchtoFrameAndClick(By.xpath("//th[text()='Name']/following::tr[2]/th/a"));
		util.switchToLoginFrame();
		getUserLoginBtn().waitForVisible(30000);
		util.clickUsingJs(getUserLoginBtn());
		util.waitFor(By.xpath("//span[contains(text(),'Logged in as')]"), 25, true);
		Reporter.log("logged in with case owner..");
	}

	public void SelectCaseGroup(String grpName) {
		getFilterCaseIcon().click();
		getFilterCaseSearchBox().waitForVisible(10000);
		getFilterCaseSearchBox().sendKeys(grpName);
		QAFWebElement SelectDropdownEBG = new QAFExtendedWebElement("//mark[text()=" + "'" + grpName + "'" + "]");
		SelectDropdownEBG.waitForPresent(10000);
		SelectDropdownEBG.click();
		Reporter.log("Filtered case with case owner group..");
	}

	// made chnage by vidya
	public void acceptCase() {
		getSearchList().sendKeys(CASENUMBER);
		getSearchList().sendKeys(Keys.ENTER);
		// added by vidya
		util.waitFor(5);
		QAFWebElement Checkbox = new QAFExtendedWebElement("//a[@title='" + CASENUMBER
				+ "']//ancestor::th//ancestor::tr//td//following-sibling::td//label[@class='slds-checkbox']//span[1]");
		util.waitFor(Checkbox, 20, true);
		Checkbox.click();
		// getCaseCheckBox().click();
		getCaseAcceptBtn().click();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
	}

	public void clickOnCaseByCaseNumber() {
		getSearchList().sendKeys(CASENUMBER);
		getSearchList().sendKeys(Keys.ENTER);
		QAFWebElement SelectCase = new QAFExtendedWebElement("//a[text()=" + "'" + CASENUMBER + "'" + "]");
		util.waitFor(SelectCase, 10, true);
		SelectCase.click();
		Reporter.logWithScreenShot("Opened created case by case number..");
		util.waitForCasePage();
	}

	public void ClickOnEligibilityCheckButton() {
		util.waitForCasePage();
		util.waitForCasePage();
		util.clickOnActionToolBarButton("Quick Actions", "Eligibility Check");
		util.waitFor(By.xpath("//title[contains(text(),'Lightning Experience | Salesforce')]"), 5, true);
		Reporter.log("On case page clicked on eligibility check button..");
	}

	public void ClickOnMNPPortabilityChecks() {
		util.waitForCasePage();
		CASEURL = driver.getCurrentUrl();
		util.waitFor(7);
		QAFWebElement RelatedSection = new QAFExtendedWebElement("//span[@title='MNPPortabilityChecks']/parent::a");
		List<WebElement> listOfSection = driver.findElements(By.xpath("//div[@class='container']/div"));
		System.out.println(listOfSection.size());
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (int i = 0; i < listOfSection.size(); i++) {
			js.executeScript("arguments[0].scrollIntoView(true)", listOfSection.get(i));
			util.waitFor(1);
			if (RelatedSection.isPresent()) {
				util.waitFor(1);
				RelatedSection.click();
				QAFWebElement PortabilityChecks = new QAFExtendedWebElement("//table//tbody//tr//th//a");
				PortabilityChecks.waitForEnabled(15000);
				PortabilityChecks.click();
				Reporter.logWithScreenShot("Clicked on MNPPortablity check.. ");
				break;
			}
		}
		Reporter.log("In related section scrolled till MNPPortability Checks and clicked on that..");
	}

	public void VerifyEligibilityCheckbox() {
		String listOFAutoCheck = "InfinityGoldAutoCheck,PostpaidAutoCheck,WithinContractAutoCheck,NotBundleAutoCheck";
		String[] split = Arrays.stream(listOFAutoCheck.split(",")).map(String::trim).toArray(String[]::new);
		for (String AutoCheck : split) {
			System.out.println(AutoCheck);
			QAFWebElement Checks = new QAFExtendedWebElement(
					"//input[@name='" + AutoCheck + "__c' and @type='checkbox']");
			Checks.isSelected();
			Reporter.logWithScreenShot("Checked all checkboxes..");
		}
		new QAFExtendedWebElement("//span[text()='" + CASENUMBER + "']").click();
		// new QAFExtendedWebElement("//span[text()='00830499']").click();
	}

	// made change vidya
	public void ClickOnBulkUpload() {
		util.waitForCasePage();
		CASEURL = driver.getCurrentUrl();
		getCaseTitle().waitForPresent(10000);
		QAFWebElement showMoreAction = new QAFExtendedWebElement(
				By.xpath("(//div[@class='slds-grid primaryFieldRow']//div//ul//li[4]//button)[last()]"));
		if (showMoreAction.isPresent()) {
			util.clickUsingJs(showMoreAction);
		} else {
			util.clickUsingJs(By.xpath("//div[@class='slds-grid primaryFieldRow']//div//ul//li[4]//button"));
		}
		util.waitFor(getUploadBulkOption(), 10, true);
		getUploadBulkOption().waitForEnabled(10000);
		getUploadBulkOption().click();
		Reporter.log("On case page clicked on upload bulk file..");
		util.waitFor(By.xpath("//title[.='Data Import Wizard ~ salesforce.com']"), 5, true);
	}

	// made change by vidya
	public void manualEligibilityCheckPerform(String location) {
		Set<String> windows = driver.getWindowHandles();
		for (String handle : windows) {
			driver.switchTo().window(handle);
		}
		util.waitForBulkUploadPage();
		util.refreshSwitchToFrame();
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(MNPPortabilityCheckBtn);
		util.clickUsingJs(UpdateExistingRecord);
		Select s = new Select(MatchBy);
		s.selectByIndex(1);
		util.clickUsingJs(CSVOption);
		driver.findElement(chooseFile).sendKeys(location);
		Reporter.logWithScreenShot("Choosed file..");
		util.clickUsingJs(ImportFileNextBtn);
		util.clickUsingJs(EditMappingFieldNextBtn);
		util.clickUsingJs(StartImport);
		getOkButton().waitForVisible(15000);
		util.clickUsingJs(OkButton);
		util.waitFor(5);
		util.refreshSwitchToFrame();
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//a[text()='View Result']"));
		String uploadresult = driver.findElementByXPath("//th[text()='Records Failed']//following::tr/td[9]").getText();
		if (!uploadresult.equals("0")) {
			Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
		} else {
			Reporter.log("Performed Manual Eligibility check..");
			driver.navigate().to(CASEURL);
			util.waitForCasePage();
		}
	}

	public void afterUploadVerifyEligibilityCheckbox() {
		String listOFAutoCheck = "Active,FraudulentSubscriber,PortingActivity,PendingTransfer,OpenServiceOrders,OutstandingFinancialObligation,Blacklisted,Disputes";
		String[] split = Arrays.stream(listOFAutoCheck.split(",")).map(String::trim).toArray(String[]::new);
		for (String AutoCheck : split) {
			System.out.println(AutoCheck);
			QAFWebElement Checks = new QAFExtendedWebElement(
					"//input[@name='" + AutoCheck + "__c' and @type='checkbox']");
			Checks.isSelected();
			Reporter.logWithScreenShot("Checked all checkboxes..");
		}
		new QAFExtendedWebElement("//span[text()='" + CASENUMBER + "']").click();
		// new QAFExtendedWebElement("//span[text()='00830499']").click();
	}

	public void clickOnGenerateLOU() {
		util.waitForCasePage();
		util.clickOnActionToolBarButton("Quick Actions", "Generate LOU");
		util.waitForVlocityOmniScript();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//p[text()='Back to Case']"), 10, true);
		util.clickUsingJs(By.xpath("//p[text()='Back to Case']"));
		Reporter.log("In quick action toolbar clicked on Generate LOU..");
	}

	public void verifyTransactionAsset() {
		util.refreshPage();
		util.waitForCasePage();
		util.waitFor(relatedSection, 10, true);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scroll(0,2500)", driver.findElement(relatedSection));
		if (!util.getTextFromPage(transactionAsset).equals("(0)")) {
			System.out.println("pass");
		} else {
			Reporter.log("Transaction Asset is not created", MessageTypes.Fail);
		}
		System.out.println("Transaction asset has been verified");
	}

	public void scrolltoRelatedSection(String sectionname) {
		util.waitForCasePage();
		util.waitFor(5);
		QAFWebElement RelatedAttachmentSec = new QAFExtendedWebElement(
				"//span[@title=" + "'" + sectionname + "'" + "]/parent::a");
		List<WebElement> listOfSection = driver.findElements(By.xpath("//div[@class='container']/div"));
		System.out.println(listOfSection.size());
		JavascriptExecutor js = (JavascriptExecutor) driver;
		for (int i = 0; i < listOfSection.size(); i++) {
			js.executeScript("arguments[0].scrollIntoView(true)", listOfSection.get(i));
			util.waitFor(1);
			if (RelatedAttachmentSec.isPresent()) {
				Reporter.logWithScreenShot("Verified sectionname is present..");
				break;
			}
		}
	}

	public void clickOnResolInProgress() {
		app.markCaseStatus(ResolutionInProgress);
		util.clickUsingJs(MarkStatusComplete);
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot("Made case status as resolution in progress..");
		getMessage().waitForNotVisible(200000);
	}

	public void requestSIMReplacement() {
		util.clickOnActionToolBarButton("Quick Actions", "SIM Replacement");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.clickUsingJs(doneButton);
		util.waitForCasePage();
	}

	public void clickOnGenerateUSC() {
		util.waitForCasePage();
		util.clickOnActionToolBarButton("Quick Actions", "Generate USC");
		util.waitForVlocityOmniScript();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//p[text()='Done']"));
		Reporter.log("In quick action toolbar clicked on Generate USC..");
	}

	public void verifyOrders(String sectionname, int ordercount) throws InterruptedException {
		QAFWebElement RelatedAttachmentSec = new QAFExtendedWebElement(
				"//span[@title=" + "'" + sectionname + "'" + "]/parent::a");
		RelatedAttachmentSec.waitForVisible(15000);
		RelatedAttachmentSec.click();
		app.refreshOrders(20, ordercount);
		Reporter.logWithScreenShot("Order is generated..");
	}

	public void clickOnCaseNoBulkMNPPotabilityCheck() {
		util.scrollTillVisible(By.xpath("//span[@title='MNPPortabilityChecks']/parent::a"));
		util.waitFor(5);
		QAFWebElement RelatedSection = new QAFExtendedWebElement("//span[@title='MNPPortabilityChecks']/parent::a");
		RelatedSection.click();
		new QAFExtendedWebElement("//a[text()='" + CASENUMBER + "']").click();
		// new QAFExtendedWebElement("//a[text()='00830365']").click();
		Reporter.log("Clicked on case number from MNPPortablilityCheck page..");
	}

	public void changeOwner(String ownerNameValue) {
		util.clickUsingJs(changeOwnerEdit);
		util.waitFor(By.xpath("//input[@placeholder='Search Users...']"), 10, true);
		util.enterText(searchUser, ownerNameValue);
		util.clickUsingJs(By.xpath("//ul/li//div[@title='" + ownerNameValue + "']"));
		util.clickUsingJs(changeOwnerButton);
		Reporter.logWithScreenShot(util.waitForGenericToastMessage());
	}

	// made change vidya
	public void bulkCreateTransAsset(String location) {
		String winHandleBefore = driver.getWindowHandle();
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		System.out.println(tabs.size());
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.waitForBulkUploadPage();
		util.refreshSwitchToFrame();
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(TransAssetBtn);
		util.clickUsingJs(AddNewRec);
		util.clickUsingJs(CSVOption);
		driver.findElement(chooseFile).sendKeys(location);
		Reporter.logWithScreenShot("Choosed file..");
		util.clickUsingJs(ImportFileNextBtn);
		util.clickUsingJs(EditMappingFieldNextBtn);
		util.clickUsingJs(StartImport);
		getOkButton().waitForVisible(15000);
		util.clickUsingJs(OkButton);
		util.waitFor(3);
		util.refreshSwitchToFrame();
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//a[text()='View Result']"));
		String uploadresult = driver.findElementByXPath("//th[text()='Records Failed']//following::tr/td[9]").getText();
		if (!uploadresult.equals("0")) {
			Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
		} else {
			Reporter.log("Created Bulk transaction asset..");
			driver.navigate().to(CASEURL);
			util.waitForCasePage();
		}
	}

	public void click_moveAvailableDocuments() {
		util.clickUsingJs(moveDocumentArrow);
	}

	public void caseModification(Map<String, String> data) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		util.type("Remarks");
		// OfferMigrationType.click();
		if (data.get("Plan").contains("5G")) {
			// util.clickDropdownValue("Legacy to 5G");
			util.selectDropdownValue(OfferMigrationType, "Legacy to 5G");
		} else {
			// util.clickDropdownValue("Legacy to Legacy");
			util.selectDropdownValue(OfferMigrationType, "Legacy to Legacy");
		}
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	// created by waseem to click on new case on Cases window
	public void ClickOnNewCaseOnCase() {
		List<WebElement> NewCaseButton = driver.findElements(By.xpath("//a[@title='New']"));
		for (int i = 0; i < NewCaseButton.size(); i++) {
			if (NewCaseButton.get(i).isDisplayed()) {
				NewCaseButton.get(i).click();
			}
		}
	}
//			private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	// took from aftersalespage
//			public void click_availableDocuments() {
//			util.scrollIntoElement(availableDocuments);
//			util.moveToElement(availableDocuments);
//			util.clickUsingActions(availableDocuments);
//			}
	// took from aftersalespage
//			public void click_moveAvailableDocuments() {
//			util.clickUsingJs(moveDocumentArrow);
//			}

	public void caseModification() {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		// util.scrollIntoElement(EditButton);
		// EditButton.click();
		util.clickUsingJs(EditButton);
		// util.type("Remarks/Comments");
		util.typeIntoTextArea("Remarks/Comments");
		// OfferMigrationType.click();
		util.clickUsingJs(OfferMigrationType);
		// util.clickDropdownValue("Legacy to Legacy");
		util.clickDropdownValue("Legacy to 5G");
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

//Nimesh
	public void changeStatustoResolutionInProgress() {
		QAFWebElement markStatus = new QAFExtendedWebElement(By.xpath("//span[text()='Mark as Current Stage']"));
		util.ChangeStatus(ResolutionInProgress, markStatus);
	}

	// Nimesh
	public void featurecasemodification(String FeaturesAvailable) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		// util.scrollIntoElement(EditButton);
		// EditButton.click();
		util.clickUsingJs(EditButton);
		util.type("Remarks");
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		driver.findElementByXPath("//span[@title='" + FeaturesAvailable + "']").click();
		util.clickUsingJs(moveDocumentArrow);
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
//				String[] split = Arrays.stream(FeaturesAvailable.split(","))
//						.map(String::trim)
//						.toArray(String[]::new);
//
//				for (String feature : split) {
//
//				WebElement ele;
//				switch (feature) {
//				case "Roaming":
//					ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Roaming']"));
//					ele.click();
//					break;
//
//				case "IDD":
//			
//					ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='IDD']"));
//					ele.click();
//					break;
//
//				case "VoiceOutgoing":
//					ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Voice Outgoing']"));
//					ele.click();
//					break;
//
//				case "VoiceIncoming&Outgoing":
//					ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Voice Incoming & Outgoing']"));
//					ele.click();
//					break;
//
//				case "SMSOutgoing":
//					ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='SMS Outgoing']"));
//					ele.click();
//					break;
//
//				case "SMSIncoming&Outgoing":
//					ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='SMS Incoming & Outgoing']"));
//					ele.click();
//					break;
//
//				case "Data":
//					ele = driver.findElement(By.xpath("//ul[@class='slds-listbox slds-listbox_vertical']/li[@class='slds-listbox__item']/div/span/span[text()='Data']"));
//					ele.click();
//					break;
//
//				default:
//				
//					System.out.println("Did not select any features");
//					break;
//				}
	}

	public void acceptCase(String CaseID) {
		getListview().click();
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		// driver.findElement(By.xpath("//input[@class='slds-input default input uiInput
		// uiInputTextForAutocomplete uiInput--default
		// uiInput--input']")).sendKeys("SMART Enterprise Support");
		getFilterCaseSearchBox().sendKeys("SMART Enterprise Support");
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		driver.findElement(By.xpath("//mark[text()='SMART Enterprise Support']")).click();
		util.waitTillLoaderDissapear();
		getSearchInput().click();
		util.typeDataTo(getSearchInput(), CaseID);
		// getSearchInput().sendKeys(Subject);
		util.waitTillLoaderDissapear();
		// getSearchInput().sendKeys(Subject);
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		getSearchInput().sendKeys(Keys.ENTER);
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		util.waitFor(By.xpath("(//span[@class='slds-checkbox--faux'])[2]"), 10, true);
		driver.findElement(By.xpath("(//span[@class='slds-checkbox--faux'])[2]")).click();
		driver.findElement(By.xpath("//div[@title='Accept']")).click();
		util.waitForGenericToastMessage();
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		getListview().click();
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		getFilterCaseSearchBox().sendKeys("My Cases");
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		driver.findElement(By.xpath("//mark[text()='My Cases']")).click();
		util.waitTillLoaderDissapear();
		String Case = "//a[text()='" + CaseID + "']";
		util.clickUsingJs(By.xpath(Case));
	}

	public void features(String features) {
		if (features.equalsIgnoreCase("Feature Activation")) {
			util.clickOnActionToolBarButton("Quick Actions", "Feature Activation");
//				try {
//					Thread.sleep(7000);
//				} catch (Exception e) {}
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
			util.refreshSwitchToFrame();
			util.AttachFrame();
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
			util.scrollTillVisible(By.xpath("//p[text()='Done']"));
			util.clickUsingJs(By.xpath("//p[text()='Done']"));
		} else {
			util.clickOnActionToolBarButton("Quick Actions", "Feature Deactivation");
//					try {
//						Thread.sleep(7000);
//					} catch (Exception e) {}
			util.refreshSwitchToFrame();
			util.AttachFrame();
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
			util.scrollTillVisible(By.xpath("//p[text()='Done']"));
			util.clickUsingJs(By.xpath("//p[text()='Done']"));
		}
	}

	public void createNewFA_FDCase(String billingAccountNumber) {
		util.selectAndClickCaseSuggestedValue(billingAccountName, billingAccountNumber);
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Transaction Type");
		// util.select("Transaction Sub Type");
		util.select("Case Origin");
		click_availableDocuments();
		click_moveAvailableDocuments();
		getSave().click();
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public boolean bulkUpload() {
		String winHandleBefore = driver.getWindowHandle();
		String path = System.getProperty("user.dir") + "\\resources\\testdata\\BulkFile.csv";
		util.waitForCasePage();
		util.waitFor(By.xpath("(//span[text()='Show more actions'])"), 10, true);
		util.waitFor(5);
		try {
			util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])"));
		} catch (Exception e) {
			util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[last()]"));
		}
		util.clickUsingJs(By.xpath("(//span[text()='Upload Bulk File'])[last()]"));
		util.waitFor(By.xpath("(//span[text()='Upload Bulk File'])[last()]"), 10, false);
		util.waitFor(5);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		System.out.println(tabs.size());
		// Use the list of window handles to switch between windows
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.waitForBulkUploadPage();
		util.refreshPage();
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(By.xpath("//a[.='Transaction Assets']"));
		util.clickUsingJs(By.xpath("//a[.='Add new records']"));
		util.clickUsingJs(By.xpath("//span[@class='csvType uiOutputText']"));
		driver.findElement(By.xpath("//input[@name='file']")).sendKeys(path);
		util.clickUsingJs(By.xpath("//a[.='Next']"));
		util.clickUsingJs(By.xpath("//a[.='Next']"));
		util.clickUsingJs(By.xpath("//a[.='Start Import']"));
		util.clickUsingJs(By.xpath("//a[.='OK']"));
//				util.switchToLoginFrame();
//				util.waitFor(By.xpath("(//label[contains(text(),'Records Failed')]/following::td[1])"), 20, true);
//				String Records = util.getTextFromPage(By.xpath("(//label[contains(text(),'Records Failed')]/following::td[1])"));
//				if(Records.equalsIgnoreCase("0")) {
//					driver.close();
//					driver.switchTo().window(winHandleBefore);
//					return true;
//				}
//				else {
//					System.out.println("Records Failed");
//					return true;
//				}
		driver.close();
		driver.switchTo().window(winHandleBefore);
		return true;
	}

	// created by vidya
	private static By billingAccountName = By
			.xpath("//span[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");

	public void createRetentionNewCase(String billingAccountNumber) {
		util.selectAndClickCaseSuggestedValue(billingAccountName, billingAccountNumber);
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Transaction Type");
		util.select("Transaction Sub Type");
		util.select("Case Origin");
		click_availableDocuments();
		click_moveAvailableDocuments();
		getSave().click();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");

	// took from aftersalespage by vidya
	public void click_availableDocuments() {
		util.scrollIntoElement(availableDocuments);
		util.moveToElement(availableDocuments);
		util.clickUsingActions(availableDocuments);
	}

	public void requestRetention(String plan) {
		util.clickOnActionToolBarButton("Quick Actions", "Retention");
		util.refreshSwitchToFrame();
		util.waitFor(PlanName, 10, true);
		PlanName.click();
		util.typeDataTo(PlanName, plan);
		QAFWebElement planname = new QAFExtendedWebElement("//ul//li//a[contains(text(),'" + plan + "')]");
		planname.click();
		Reporter.logWithScreenShot("Selected plan..");
		util.AttachFrame();
		util.vlocityNextButton();
		Reporter.logWithScreenShot("Click on Retention button and selected plan in vlocity page..");
		util.waitFor(By.xpath("//title[text()='vlocity_cmt__HybridCPQ | Salesforce']"), 60, true);
	}

//	private static By billingAccountName = By.xpath("//span[text()='Billing Account']/following::div[1]//input[@placeholder='Search Accounts...']");
	public void createChangePlanNewCase(String billingAccountNumber) {
		util.selectAndClickCaseSuggestedValue(billingAccountName, billingAccountNumber);
		util.type("Subject");
		util.select("Line of Business");
		util.select("Type of Customer Request");
		util.select("Type");
		util.select("High Level Transaction Classification");
		util.select("Transaction Type");
		util.select("Transaction Sub Type");
		util.select("Case Origin");
		click_availableDocuments();
		click_moveAvailableDocuments();
		getSave().click();
		util.waitTillLoaderDissapear();
		getMessage().waitForVisible(150000);
		Reporter.logWithScreenShot(getMessage().getText());
		Reporter.logWithScreenShot("Entered mandatory fields and case got created..");
	}

	public void markCaseStatusToResolutionInprogress() {
		// markCaseStatus(resolutionInProg,"Resolution In Progress");
		util.clickUsingJs(By
				.xpath("(//div[@aria-label='Path Header']/ul/li/a[@data-tab-name='Resolution In Progress'])[last()]"));
		util.clickUsingJs(markCurrentStatus);
		util.waitForGenericToastMessage();
	}

	public boolean verifyTransactionDetailsForConnectionScenarios(String assetValue, String transactionReasonValue,
			String transactiontype, String caseOrigin) {
		util.clickUsingJs(transactionDetails);
		util.clickUsingJs(editButton);
		if (transactiontype.contains("Reconnection")) {
			if (!transactiontype.contains("Involuntary") && caseOrigin.contains("Internal User")) {
				util.clickUsingJs(servicereq);
				util.clickUsingJs(
						By.xpath("(//lightning-base-combobox-item[@data-value='" + transactionReasonValue + "'])"));
			}
		} else {
			if (caseOrigin.contains("Internal User")) {
				util.clickUsingJs(highLevelDisconnection);
				util.clickUsingJs(
						By.xpath("(//lightning-base-combobox-item[@data-value='" + transactionReasonValue + "'])"));
			}
		}
		util.clickUsingJs(saveRecord);
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		if (caseOrigin.contains("Internal User")) {
			check.add(util.isElementDisplayed(MINNumber));
		}
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public void numberReservationCheck() {
		System.out.println("Click on Number Reservation..");
		util.clickOnActionToolBarButton("Quick Actions", "Reserve Numbers");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//span[text()='Number/Pattern Search']"), 5, true);
		util.refreshSwitchToFrame();
		util.clickUsingJs(By.xpath("//span[text()='Number/Pattern Search']"));
		util.clickUsingJs(By.xpath("//p[text()='Next']"));
		util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")), "Regular");
		util.waitFor(By.xpath("(//p[.='Search MIN'])[1]"), 10, true);
		util.clickUsingJs(By.xpath("(//p[.='Search MIN'])[1]"));
		util.clickUsingJs(By.xpath("(//th/button)[1]"));
		util.clickUsingJs(By.xpath("//div[@id='StepMINSearchNo_nextBtn']"));
		util.clickUsingJs(By.xpath("(//p[text()='Next'])[3]"));
		util.AttachFrame();
		util.waitFor(By.xpath("//span[.='Number Reservation is successful.']"), 3, true);
		if (util.isElementDisplayed(By.xpath("//span[.='Number Reservation is successful.']"))) {
			util.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
		} else {
			for (int i = 0; i < 4; i++) {
				if (util.isElementDisplayed(By.xpath("//span[.='Number Reservation is successful.']"))) {
					util.clickUsingJs(By.xpath("//div[@id='SuccessfulReservation_nextBtn']"));
					break;
				}
				util.AttachFrame();
				util.vlocityPreviousButton();
				util.AttachFrame();
				util.vlocityPreviousButton();
				util.AttachFrame();
				util.selectBy(driver.findElement(By.xpath("//select[@id='NumberTypeMin']")), "Regular");
				driver.findElement(By.xpath("(//p[.='Search MIN'])[1]")).click();
				driver.findElement(By.xpath("(//th/button)[1]")).click();
				driver.findElement(By.xpath("//div[@id='StepMINSearchNo_nextBtn']")).click();
				driver.findElement(By.xpath("(//p[text()='Next'])[3]")).click();
			}
		}
		util.waitForQuotePage();
	}

	public String getIDFromNotificationText() {
		util.waitFor(By.xpath("//*[@data-aura-class='forceToastMessage']"), 15, true);
		String text = util.getTextFromPage(By.xpath("//*[@data-aura-class='forceActionsText']"));
		return text.split(" ")[1];
	}

	// vidya
	public void createSUNInfinityAsset() throws InterruptedException {
		util.waitForCasePage();
		util.clickOnActionToolBarButton("Quick Actions", "Create SUN Infinity Assets");
		util.waitForVlocityOmniScript();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		QAFWebElement spinner = new QAFExtendedWebElement(
				"//div[@class='slds-spinner--brand slds-spinner slds-spinner--large']");
		spinner.waitForNotVisible(150000);
		util.waitFor(By.xpath("//div[contains(text(),'Back to Case')]"), 10, true);
		util.clickUsingJs(By.xpath("//div[contains(text(),'Back to Case')]"));
		if (SUNOkBtn.isDisplayed()) {
			util.clickUsingJs(SUNOkBtn);
		}
		Reporter.log("Created SUN Infinity Asset..");
	}

	public void redirectCaseByClickOnCaseNo() {
		new QAFExtendedWebElement("//a[text()='" + CASENUMBER + "']").click();
		// new QAFExtendedWebElement("//a[text()='00830365']").click();
		Reporter.log("Clicked on case number..");
		util.waitForCasePage();
	}

	// made change vidya
	public void SUNInfinityEligibilityCheckPerform(String location) {
		String winHandleBefore = driver.getWindowHandle();
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		System.out.println(tabs.size());
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.waitForBulkUploadPage();
		util.refreshPage();
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(MNPPortabilityCheckBtn);
		util.clickUsingJs(AddNewRec);
		Select s = new Select(CaseLookupField);
		s.selectByIndex(0);
		TriggerCheckbox.click();
		util.clickUsingJs(CSVOption);
		driver.findElement(chooseFile).sendKeys(location);
		Reporter.logWithScreenShot("Choosed file..");
		util.clickUsingJs(ImportFileNextBtn);
		util.clickUsingJs(EditMappingFieldNextBtn);
		util.clickUsingJs(StartImport);
		getOkButton().waitForVisible(15000);
		util.clickUsingJs(OkButton);
		util.waitFor(3);
		util.refreshSwitchToFrame();
		util.waitFor(3);
		util.clickUsingJs(By.xpath("//a[text()='View Result']"));
		String uploadresult = driver.findElementByXPath("//th[text()='Records Failed']//following::tr/td[9]").getText();
		if (!uploadresult.equals("0")) {
			Reporter.log("Bulk Processing Failed", MessageTypes.Fail);
		} else {
			Reporter.log("Perform Eligibility check..");
			driver.navigate().to(CASEURL);
			util.waitForCasePage();
		}
	}

	public String retriveCaseNumberFromURL() {
		String URL = driver.getCurrentUrl();
		String CaseNumber = StringUtils.substringBetween(URL, "Case/", "/view");
		return CaseNumber;
	}
//			private static By availableDocuments = By.xpath("//span[text()='Available']/following-sibling::div/ul/li[1]");
	// took from aftersalespage
//			public void click_availableDocuments() {
//			util.scrollIntoElement(availableDocuments);
//			util.moveToElement(availableDocuments);
//			util.clickUsingActions(availableDocuments);
//			}
	// took from aftersalespage
//			public void click_moveAvailableDocuments() {
//			util.clickUsingJs(moveDocumentArrow);
//			}

//Nimesh
	public void requestChangePlan(String Plan, String Addons) {
		util.clickOnActionToolBarButton("Quick Actions", "Change Of Plan");
		// util.clickUsingJs(doneButton);
		// util.waitForCasePage();
		util.refreshSwitchToFrame();
		util.clickUsingJs(getPlanName());
		util.typeDataTo(getPlanName(), Plan);
		// util.clickUsingJs(By.xpath("//ul//li//*[text()='" + Plan + "']"));
		QAFWebElement planname = new QAFExtendedWebElement(By.xpath("//ul//li//a[contains(text(),'" + Plan + "')]"));
		util.waitTillLoaderDissapear();
		planname.click();
		getSelectPlanNextButton().waitForEnabled(10);
		util.clickUsingJs(getSelectPlanNextButton());
		// util.waitTillLoaderDissapear();
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 60, false);
		if (Plan.contains("5G")) {
			util.waitFor(By.xpath("//title[text()='vlocity_cmt__HybridCPQ | Salesforce']"), 40, true);
			util.waitForCartPage();
			util.refreshSwitchToFrame();
			util.AttachFrame();
			addAddonsto5GPlans(Addons);
			util.clickUsingJs(getViewRecord());
		}
		util.waitForQuotePage();
		// util.waitFor(By.xpath("(//div[contains(@class,'profilePicWrapper
		// ')]/following::h1/div[.='Quote'])[1]"), 80, true);
		try {
			Thread.sleep(10000);
			// util.refreshPage();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void goToCaseOrdersSearchPage(String caseURL) {
		String orderSearchPage = caseURL.replaceFirst("/view", "/related/Orders__r/view");
		driver.get(orderSearchPage);
	}

	public void verifyOrdersFromCasePage(String caseURL) {
		goToCaseOrdersSearchPage(caseURL);
	}

	public void addAddonsto5GPlans(String Addons) {
		util.clickUsingJs(By.xpath("(//button[@class='slds-button slds-button_icon-small'])[4]"));
		String[] split = Arrays.stream(Addons.split(",")).map(String::trim).toArray(String[]::new);
		for (String Addon : split) {
			System.out.println("Add Addons to 5G Plan | " + Addon);
			driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).sendKeys(Addon);
			String selectAddon = "//div[text()='" + Addon + "']";
			util.clickUsingJs(By.xpath(selectAddon));
			util.waitForCartPageToastMessage();
			util.waitFor(By.xpath("//div[@class='cpq-product-name-block cpq-item-child-product-name-wrapper']"), 10,
					true);
			// util.clickDropdownValue(selectAddon);
			driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).clear();
		}
	}

	public boolean verifyTransactionDetailsForChangeMIN(String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		System.out.println(util.getTextFromPage(transactionStatus));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			System.out.println("Transaction details are verified");
			return false;
		}
		System.out.println("Transaction details are not verified");
		return true;
	}

	public boolean verifyTransactionDetailsForSIMReplacement(String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		System.out.println(util.getTextFromPage(simReplacementFee));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)
				&& util.getTextFromPage(simReplacementFee).equals("0.00")) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public void transactionActionForConnectionScenarios(String transactionType) {
		try {
			System.out.println("Click on Disconnection..");
			util.refreshPage();
			if (transactionType.contains("Termination")) {
				util.clickOnActionToolBarButton("Quick Actions", "Disconnect");
			} else {
				if (transactionType.contains("Reconnection")) {
					util.clickOnActionToolBarButton("Quick Actions", "Resume");
				} else {
					if (transactionType.contains("Temporary"))
						util.clickOnActionToolBarButton("Quick Actions", "Suspend");
				}
			}
			util.waitForVlocityOmniScript();
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.clickUsingJs(doneButton);
			util.waitForCasePage();
		} catch (Exception e) {
		}
	}
	
	public void changeDevice() {
		util.clickOnActionToolBarButton("Quick Actions", "Change of Device");
		util.waitForVlocityOmniScript();
		util.waitForCasePage();
		util.waitFor(10);
	}
	
	
}
