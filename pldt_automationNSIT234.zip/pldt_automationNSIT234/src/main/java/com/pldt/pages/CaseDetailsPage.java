package com.pldt.pages;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import com.common.utilities.WebUtilities;
import com.pldt.lib.PageLib;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class CaseDetailsPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	public static By transactionDetails = By.xpath("//a[text()='Transaction Details']");
	public static By assetID = By.xpath("//span[.='Asset ID']/following::div[1]");
	public static By MINNumber = By.xpath("//span[.='MIN Number']/following::div[1]");
	public static By transactionStatus = By.xpath("//span[.='Transaction Status']/following::div[1]");
	public static By markCurrentStatus = By.xpath("//span[text()='Mark as Current Status']");
	private static By changeOwnerEdit = By.xpath("//button[@title='Change Owner']");
	private static By searchUser = By.xpath("//input[@placeholder='Search Users...']");
	private static By changeOwnerButton = By.xpath("//button[@name='change owner']");
	private static By simReplacementFee = By.xpath("//span[.='SIM Replacement Fee']/following::div[1]");
	private static By transactionAsset = By.xpath("(//span[text()='Transaction Asset'])[1]/following-sibling::span");
	private static By relatedSection = By.xpath("(//flexipage-record-home-scrollable-column)[3]");
	private static By doneButton = By.xpath("//p[.='Done']");
	private static By editButton = By.xpath("//button[text()='Edit'][@class='slds-button slds-button_brand']");
	private static By servicereq = By
			.xpath("(//label[text()='Services Requested']/following::button[@name='Services_Requested__c'])");
	private static By highLevelDisconnection = By.xpath(
			"(//label[text()='High Level Disconnection Reason']/following::button[@name='High_Level_Disconnection_Reason__c'])");
	private static By saveRecord = By.xpath("//button[@class='slds-button slds-button_brand'][@type='submit']");
	static final String PlanName = "xpath=//span[contains(text(),'Plan Name')]/parent::label/parent::div/input";
	static final String SelectPlanNextButton = "xpath=//p[text()='Next']";
	static final String transactionDetailsC = "xpath=//a[text()='Transaction Details']";
	static final String ViewRecord = "xpath=//button[@title='View Record']";
	@FindBy(locator = transactionDetailsC)
	private QAFWebElement TransactionDetails;
	@FindBy(locator = "//button[text()='Edit'][@class='slds-button slds-button_brand']")
	private QAFWebElement EditButton;
	@FindBy(locator = "//label[text()='Offer Migration Type']/following::div/div/button[@name='Offer_Migration_Type__c']")
	private QAFWebElement OfferMigrationType;
	@FindBy(locator = "//button[text()='Save Record']")
	private QAFWebElement SaveRecord;
	@FindBy(locator = PlanName)
	private QAFWebElement planName;
	@FindBy(locator = SelectPlanNextButton)
	private QAFWebElement selectPlanNextButton;
	@FindBy(locator = ViewRecord)
	private QAFWebElement viewRecord;
	@FindBy(locator = "//button[@title='Move selection to Chosen']")
	private QAFWebElement moveDocumentArrow;
	@FindBy(locator = "//div[@class='vlc-control-wrapper ng-binding']//input[@name='loopname']")
	private QAFWebElement planname;
	// added by vidya
	@FindBy(locator = "//span[@title='Quotes']/parent::a/following::a[2]")
	private QAFWebElement quoteLink;

	public QAFWebElement getPlanName() {
		return planName;
	}

	public QAFWebElement getSelectPlanNextButton() {
		return selectPlanNextButton;
	}

	public QAFWebElement getViewRecord() {
		return viewRecord;
	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public boolean verifyTransactionDetailsForChangeMIN(String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		System.out.println(util.getTextFromPage(transactionStatus));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			System.out.println("Transaction details are verified");
			return false;
		}
		System.out.println("Transaction details are not verified");
		return true;
	}

	public boolean verifyTransactionDetailsForSIMReplacement(String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		System.out.println(util.getTextFromPage(simReplacementFee));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)
				&& util.getTextFromPage(simReplacementFee).equals("0.00")) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public boolean verifyTransactionDetailsForChangeofDevice(String assetValue) {
		util.clickUsingJs(transactionDetails);
		util.waitFor(5);
		System.out.println(util.getTextFromPage(assetID));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)
				&& util.getTextFromPage(simReplacementFee).equals("0.00")) {
			check.add(true);
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public boolean verifyTransactionDetailsForSIMActivation(Map<String, String> data, String assetValue) {
		util.clickUsingJs(transactionDetails);
		System.out.println(util.getTextFromPage(assetID));
		System.out.println(util.getTextFromPage(MINNumber));
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		check.add(util.isElementDisplayed(MINNumber));
		if (data.get("Case Origin").contains("Internal User")) {
			util.clickUsingJs(editButton);
			util.waitFor(By.xpath("//label[text()='ICCID']/following::input[@name='ICCID__c']"), 20, true);
			driver.findElement(By.xpath("//label[text()='ICCID']/following::input[@name='ICCID__c']"))
					.sendKeys(data.get("ICCID"));
			driver.findElement(By.xpath("//label[text()='MIN']/following::input[@name='MIN__c']"))
					.sendKeys(data.get("MINNumber"));
			util.clickUsingJs(saveRecord);
		}
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public boolean verifyTransactionDetailsForConnectionScenarios(String assetValue, String transactionReasonValue,
			String transactiontype, String caseOrigin) {
		util.clickUsingJs(transactionDetails);
		util.clickUsingJs(editButton);
		if (transactiontype.contains("Reconnection")) {
			if (!transactiontype.contains("Involuntary") && caseOrigin.contains("Internal User")) {
				util.clickUsingJs(servicereq);
				util.clickUsingJs(
						By.xpath("(//lightning-base-combobox-item[@data-value='" + transactionReasonValue + "'])"));
			}
		} else {
			if (caseOrigin.contains("Internal User")) {
				util.clickUsingJs(highLevelDisconnection);
				util.clickUsingJs(
						By.xpath("(//lightning-base-combobox-item[@data-value='" + transactionReasonValue + "'])"));
			}
		}
		util.clickUsingJs(saveRecord);
		ArrayList<Boolean> check = new ArrayList<>();
		if (util.isElementDisplayed(assetID) && util.getTextFromPage(assetID).equals(assetValue)) {
			check.add(true);
		}
		if (caseOrigin.contains("Internal User")) {
			check.add(util.isElementDisplayed(MINNumber));
		}
		if (check.contains(false)) {
			System.out.println("Transaction details are not populated correctly");
			return false;
		}
		System.out.println("Transaction details are verified");
		return true;
	}

	public void transactionActionForConnectionScenarios(String transactionType) {
		try {
			System.out.println("Click on Disconnection..");
			util.refreshPage();
			if (transactionType.contains("Termination")) {
				util.clickOnActionToolBarButton("Quick Actions", "Disconnect");
			} else {
				if (transactionType.contains("Reconnection")) {
					util.clickOnActionToolBarButton("Quick Actions", "Resume");
				} else {
					if (transactionType.contains("Temporary"))
						util.clickOnActionToolBarButton("Quick Actions", "Suspend");
				}
			}
			util.waitForVlocityOmniScript();
			util.refreshSwitchToFrame();
			util.AttachFrame();
			util.clickUsingJs(doneButton);
			util.waitForCasePage();
		} catch (Exception e) {
		}
	}

	public void markCaseStatusToResolutionInprogress() {
		// markCaseStatus(resolutionInProg,"Resolution In Progress");
		util.clickUsingJs(By
				.xpath("(//div[@aria-label='Path Header']/ul/li/a[@data-tab-name='Resolution In Progress'])[last()]"));
		util.clickUsingJs(markCurrentStatus);
		util.waitForGenericToastMessage();
	}

	public void verifyTransactionAsset() {
		util.refreshPage();
		util.waitForCasePage();
		util.waitFor(relatedSection, 10, true);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scroll(0,2500)", driver.findElement(relatedSection));
		if (!util.getTextFromPage(transactionAsset).equals("(0)")) {
			System.out.println("pass");
		} else {
			Reporter.log("Transaction Asset is not created", MessageTypes.Fail);
		}
		System.out.println("Transaction asset has been verified");
	}

	public void requestSIMReplacement() {
		util.clickOnActionToolBarButton("Quick Actions", "SIM Replacement");
		util.waitForVlocityOmniScript();
		util.waitFor(3);
		util.AttachFrame();
		util.clickUsingJs(doneButton);
		util.waitForCasePage();
	}

	public void requestSIMActivation() {
		util.clickOnActionToolBarButton("Quick Actions", "SIM Activation");
		util.waitForVlocityOmniScript();
		util.AttachFrame();
		util.clickUsingJs(doneButton);
		util.waitForCasePage();
	}

	public void changeOwner(String ownerNameValue) {
		util.clickUsingJs(changeOwnerEdit);
		util.waitFor(By.xpath("//input[@placeholder='Search Users...']"), 10, true);
		util.enterText(searchUser, ownerNameValue);
		util.clickUsingJs(By.xpath("//ul/li//div[@title='" + ownerNameValue + "']"));
		util.clickUsingJs(changeOwnerButton);
		Reporter.logWithScreenShot(util.waitForGenericToastMessage());
	}

	public boolean bulkUpload(Map<String, String> data) {
		String winHandleBefore = driver.getWindowHandle();
		String path;
		if (!data.get("Transaction Type").contains("SIM Activation")) {
			path = System.getProperty("user.dir") + "\\resources\\testdata\\BulkFile.csv";
		} else {
			path = System.getProperty("user.dir") + ".\\resources\\testdata\\Bulk_Transaction Asset_SIM Activation.csv";
		}
		util.waitForCasePage();
		util.waitFor(By.xpath("(//span[text()='Show more actions'])"), 10, true);
		util.waitFor(5);
		try {
			util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])"));
		} catch (Exception e) {
			util.clickUsingJs(By.xpath("(//span[text()='Show more actions'])[last()]"));
		}
		util.waitFor(By.xpath("(//span[text()='Upload Bulk File'])[last()]"), 10, true);
		util.clickUsingJs(By.xpath("(//span[text()='Upload Bulk File'])[last()]"));
		util.waitFor(By.xpath("(//span[text()='Upload Bulk File'])[last()]"), 10, false);
		util.waitFor(5);
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		System.out.println(tabs.size());
		// Use the list of window handles to switch between windows
		driver.switchTo().window(tabs.get(tabs.size() - 1));
		util.waitForBulkUploadPage();
		util.refreshPage();
		util.waitFor(By.xpath("//a[text()='Custom objects']"), 10, true);
		util.clickUsingJs(By.xpath("//a[text()='Custom objects']"));
		util.clickUsingJs(By.xpath("//a[.='Transaction Assets']"));
		util.clickUsingJs(By.xpath("//a[.='Add new records']"));
		util.clickUsingJs(By.xpath("//span[@class='csvType uiOutputText']"));
		driver.findElement(By.xpath("//input[@name='file']")).sendKeys(path);
		util.clickUsingJs(By.xpath("//a[.='Next']"));
		util.clickUsingJs(By.xpath("//a[.='Next']"));
		util.clickUsingJs(By.xpath("//a[.='Start Import']"));
		util.clickUsingJs(By.xpath("//a[.='OK']"));
//	util.switchToLoginFrame();
//	util.waitFor(By.xpath("(//label[contains(text(),'Records Failed')]/following::td[1])"), 20, true);
//	String Records = util.getTextFromPage(By.xpath("(//label[contains(text(),'Records Failed')]/following::td[1])"));
//	if(Records.equalsIgnoreCase("0")) {
//		driver.close();
//		driver.switchTo().window(winHandleBefore);
//		return true;
//	}
//	else {
//		System.out.println("Records Failed");
//		return true;
//	}
		driver.close();
		driver.switchTo().window(winHandleBefore);
		return true;
	}

	public void caseModification(Map<String, String> data, String MigrationType) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(EditButton, 10, true);
		util.clickUsingJs(EditButton);
		if (!data.get("Case Origin").equalsIgnoreCase("Bulk")) {
			util.type("Remarks");
		}
		util.selectDropdownValue(OfferMigrationType, MigrationType);
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
		Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
	}

	public void requestRetention(String plan, Map<String, String> data) {
		if (data.get("Transaction Type").equalsIgnoreCase("Brand Migration")) {
			util.clickOnActionToolBarButton("Quick Actions", "Brand Migration");
		} else {
			util.clickOnActionToolBarButton("Quick Actions", "Retention");
		}
		util.refreshSwitchToFrame();
		if (!data.get("Case Origin").equalsIgnoreCase("Bulk")) {
			util.waitFor(planname, 10, true);
			planname.waitForEnabled(10000);
			planname.click();
			util.typeDataTo(planname, plan);
			QAFWebElement planname = new QAFExtendedWebElement("//ul//li//a[contains(text(),'" + plan + "')]");
			planname.click();
			Reporter.logWithScreenShot("Selected plan..");
			util.AttachFrame();
			util.vlocityNextButton();
			Reporter.logWithScreenShot("Click on Retention button and selected plan in vlocity page..");
		}
		QAFWebElement spinner = new QAFExtendedWebElement(
				"//div[@class='slds-spinner--brand slds-spinner slds-spinner--large']");
		spinner.waitForNotVisible(100000);
		util.AttachFrame();
		util.vlocityNextButton();
		util.waitForCasePage();
	}

	public void caseModification(String MigrationType, Map<String, String> data) {
        util.waitForCasePage();
        TransactionDetails.click();
        util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
        // util.scrollIntoElement(EditButton);
        // EditButton.click();
        util.clickUsingJs(EditButton);
        // util.type("Remarks/Comments");
        if (!data.get("Case Origin").equalsIgnoreCase("Bulk")) {
            util.typeIntoTextArea("Remarks/Comments");
        }
        // util.typeIntoTextArea("Remarks/Comments");
        util.selectDropdownValue(OfferMigrationType, MigrationType);
        util.waitFor(SaveRecord, 10, true);
        util.clickUsingJs(SaveRecord);
        Reporter.logWithScreenShot("Click on Transaction details and modified some fields..");
    }

	public void requestChangePlan(String Plan, String Addons, Map<String, String> data) {
		util.clickOnActionToolBarButton("Quick Actions", "Change Of Plan");
		// util.clickUsingJs(doneButton);
		// util.waitForCasePage();
		util.waitFor(5); // new
		util.refreshSwitchToFrame();
		util.waitFor(2);
		util.AttachFrame(); // new
		if (!data.get("Case Origin").equalsIgnoreCase("Bulk")) {
			util.clickUsingJs(getPlanName());
			util.typeDataTo(getPlanName(), Plan);
			// util.clickUsingJs(By.xpath("//ul//li//*[text()='" + Plan + "']"));
			QAFWebElement planname = new QAFExtendedWebElement(
					By.xpath("//ul//li//a[contains(text(),'" + Plan + "')]"));
			util.waitTillLoaderDissapear();
			planname.click();
			util.AttachFrame();
			getSelectPlanNextButton().waitForEnabled(10);
			util.clickUsingJs(getSelectPlanNextButton());
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 60, false);
			util.waitFor(5);
			util.AttachFrame();
			util.vlocityNextButton(); /// NEW
			util.waitForCasePage();
			util.waitFor(3);
			navigateToQuoteFromCart();
		} else {
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 60, false);
			util.waitFor(5);
			util.AttachFrame();
			// util.vlocityNextButton(); /// NEW
			getSelectPlanNextButton().waitForEnabled(10);
			util.clickUsingJs(getSelectPlanNextButton());
			util.waitForCasePage();
			util.waitFor(3);
			navigateToQuoteFromCart();
		}

		if (Plan.contains("5G")) {
			QuoteDetailsPage quote = new QuoteDetailsPage();
			quote.modifyProductsbyduplicates(data);
			util.waitFor(By.xpath("//title[text()='vlocity_cmt__HybridCPQ | Salesforce']"), 20, true);
			util.waitForCartPage();
			util.refreshSwitchToFrame();
			util.AttachFrame();
			addAddonsto5GPlans(Addons);
		}
		try {
			Thread.sleep(10000);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void addAddonsto5GPlans(String Addons) {
		util.clickUsingJs(By.xpath("(//button[@class='slds-button slds-button_icon-small'])[4]"));
		String[] split = Arrays.stream(Addons.split(",")).map(String::trim).toArray(String[]::new);
		for (String Addon : split) {
			System.out.println("Add Addons to 5G Plan | " + Addon);
			driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).sendKeys(Addon);
			String selectAddon = "//div[text()='" + Addon + "']";
			util.clickUsingJs(By.xpath(selectAddon));
			util.waitForCartPageToastMessage();
			util.waitFor(By.xpath("//div[@class='cpq-product-name-block cpq-item-child-product-name-wrapper']"), 10,
					true);
			// util.clickDropdownValue(selectAddon);
			driver.findElement(By.xpath("(//input[@placeholder='Search'])[5]")).clear();
		}
	}

	public void featurecasemodification(String FeaturesAvailable) {
		util.waitForCasePage();
		TransactionDetails.click();
		util.waitFor(By.xpath("//button[@class='slds-button slds-button_brand' and text()='Edit']"), 10, true);
		// util.scrollIntoElement(EditButton);
		// EditButton.click();
		util.clickUsingJs(EditButton);
		util.type("Remarks");
		try {
			Thread.sleep(3000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		driver.findElementByXPath("//span[@title='" + FeaturesAvailable + "']").click();
		util.clickUsingJs(moveDocumentArrow);
		util.waitFor(SaveRecord, 10, true);
		util.clickUsingJs(SaveRecord);
	}

	public void features(String features) {
		if (features.equalsIgnoreCase("Feature Activation")) {
			util.clickOnActionToolBarButton("Quick Actions", "Feature Activation");
//	try {
//		Thread.sleep(7000);
//	} catch (Exception e) {}
//	util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
			util.refreshSwitchToFrame();
			util.AttachFrame();
//	util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
			util.scrollTillVisible(By.xpath("//p[text()='Done']"));
			util.clickUsingJs(By.xpath("//p[text()='Done']"));
		} else {
			util.clickOnActionToolBarButton("Quick Actions", "Feature Deactivation");
//		try {
//			Thread.sleep(7000);
//		} catch (Exception e) {}
			util.refreshSwitchToFrame();
			util.AttachFrame();
			// util.waitTillLoaderDissapear();
			util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 30, false);
			util.scrollTillVisible(By.xpath("//p[text()='Done']"));
			util.clickUsingJs(By.xpath("//p[text()='Done']"));
		}
	}

	// created by Vidya
	public void navigateToQuoteFromCart() {
		util.waitFor(relatedSection, 10, true);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scroll(0,3000)", driver.findElement(relatedSection));
		util.waitFor(8);
		util.waitFor(quoteLink, 10, true);
		quoteLink.isDisplayed();
		util.clickUsingJs(quoteLink);
		util.waitForQuotePage();
	}
}
