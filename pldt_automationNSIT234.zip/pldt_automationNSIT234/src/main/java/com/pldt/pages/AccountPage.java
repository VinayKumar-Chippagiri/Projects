package com.pldt.pages;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.pldt.locators.AccountPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;
import com.qmetry.qaf.automation.util.Reporter;

public class AccountPage extends WebDriverBaseTestPage<WebDriverTestPage> implements AccountPageLocators {
	WebUtilities util = new WebUtilities();
	TestDataBean bean = new TestDataBean();
	DateUtil date=new DateUtil();
	
	@FindBy(locator = show_All)
	private QAFWebElement AccountShowAll;
	@FindBy(locator = Opportunities)
	private QAFWebElement AccountOpportunities;
	@FindBy(locator = Asset)
	private QAFWebElement AccountAsset;
	@FindBy(locator = listview)
	private QAFWebElement listviewArrow;
	@FindBy(locator = allaccount)
	private QAFWebElement allaccountbutton;
	@FindBy(locator = AllAccountEE)
	private QAFWebElement allAccountEE;
	@FindBy(locator = "xpath=(//span[text()='All Accounts - Business Accounts'])[1]")
	private QAFWebElement AllAccountBusiness;
	@FindBy(locator = searchInput)
	private QAFWebElement searchAccountInput;
	@FindBy(locator = Quotes)
	private QAFWebElement quotes;
	@FindBy(locator = "xpath=(//*[text()='Select List View'])/parent::*)")
	private QAFWebElement filter;
	@FindBy(locator = "xpath=//input[@placeholder='Search this list...']")
	private QAFWebElement searchList;
	@FindBy(locator = "xpath=//span[text()='Next']")
	private QAFWebElement nextButton;
	@FindBy(locator = "xpath=(//ul/li//records-hoverable-link//slot//*[contains(text(),'Contacts')])[1]")
	private QAFWebElement contacts;
	@FindBy(locator = Cases)
	private QAFWebElement CasesButton;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getNextButton() {
		return nextButton;
	}

	public QAFWebElement getAccountShowAll() {
		return AccountShowAll;
	}

	public QAFWebElement getAccountAsset() {
		return AccountAsset;
	}

	public QAFWebElement getAccountOpportunities() {
		return AccountOpportunities;
	}

	public QAFWebElement getAccountContacts() {
		return contacts;
	}

	public QAFWebElement getListviewArrow() {
		return listviewArrow;
	}

	public QAFWebElement getAllaccountbutton() {
		return allaccountbutton;
	}

	public QAFWebElement getAllAccountEE() {
		return allAccountEE;
	}

	public QAFWebElement getAllAccountBusiness() {
		return AllAccountBusiness;
	}

	public QAFWebElement getSearchAccountInput() {
		return searchAccountInput;
	}

	public QAFWebElement getCasesButton() {
		return CasesButton;
	}

	public void searchAndSelectAccount() {
		util.clickUsingJs(filter);
		util.clickDropdownValue("All Accounts - Business Accounts");
//			util.typeDataTo(searchList, acountNameValue);
//			util.waitFor(By.xpath("//table[1]"), 5, true);
		util.enterKey();
//			String path = "//a[text()=" + "'" + acountNameValue + "'" + "]";
//			QAFWebElement path = new QAFExtendedWebElement("//a[text()=\" + \"'\" + acountNameValue + \"'\" + \"]");
//			util.clickUsingJs(path);
	}

	public void clickAssetLink() {
		getAccountShowAll().click();
		getAccountAsset().click();
		Reporter.log("Opened asset page..");
	}

	public void clickCaseLink() {
		getAccountShowAll().click();
		getCasesButton().click();
		Reporter.log("Opened case page..");
	}

	public void clickAccount(String accountName) {
		getListviewArrow().click();
		getSearchAccountInput().sendKeys(accountName);
		getSearchAccountInput().sendKeys(Keys.ENTER);
		QAFWebElement AccountInRowOne = new QAFExtendedWebElement("//a[text()=" + "'" + accountName + "'" + "]");
		util.clickUsingJs(AccountInRowOne);
		Reporter.logWithScreenShot("Selected account..");
	}

	public QAFWebElement getQuotes() {
		return quotes;
	}

	public void ClickAsset() {
		getAccountShowAll().click();
		getAccountAsset().click();
	}

	public void ClickOpportunities() {
		getAccountShowAll().click();
		getAccountOpportunities().click();
	}

	public void ClickContacts() {
//		getAccountShowAll().click();
		getAccountContacts().click();
	}

	public void ClickQuotes() {
		getAccountShowAll().click();
		getQuotes().click();
	}

	public void ClickOncreateEnterpriseQuote() {
		util.clickOnActionToolBarButton("AccountActionToolbar", "Create Enterprise Quote");
		util.waitFor(By.xpath("//h1[contains(@class,'slds-page-header__title vlc-slds-page-header__title')]"), 20,
				true);
		util.refreshSwitchToFrame();
	}

	public void SelectAccount(String accountName, String accountType) {
		getListviewArrow().click();
//		searchAndSelectAccount();
		QAFWebElement AccountType = new QAFExtendedWebElement(
				"//span[text()=" + "'" + accountType + "'" + "]/parent::a");
		// util.clickUsingJs(AccountInRowOne);
		AccountType.click();
		// span[text()='All Accounts - EE']/parent::a
		// getAllAccountBusiness().click();
		// getAllAccountEE().click();
		getSearchAccountInput().sendKeys(accountName);
		getSearchAccountInput().sendKeys(Keys.ENTER);
		// Thread.sleep(3000);
		QAFWebElement AccountInRowOne = new QAFExtendedWebElement("//a[text()=" + "'" + accountName + "'" + "]");
		util.clickUsingJs(AccountInRowOne);
	}

	// created by vidya for clicking on account
	public void clickAccount(String accountName, String type) {
		getListviewArrow().click();
		ClickTypeOfAccount(type);
		getSearchAccountInput().sendKeys(accountName);
		getSearchAccountInput().sendKeys(Keys.ENTER);
		QAFWebElement AccountInRowOne = new QAFExtendedWebElement("//a[text()=" + "'" + accountName + "'" + "]");
		if (AccountInRowOne.isDisplayed()) {
			util.clickUsingJs(AccountInRowOne);
		} else {
			getSearchAccountInput().sendKeys(Keys.ENTER);
			util.clickUsingJs(AccountInRowOne);
		}
		Reporter.logWithScreenShot("Selected account..");
	}

	// created by waseem for selecting type of account
	public void ClickTypeOfAccount(String Accounttype) {
		switch (Accounttype) {
		case "All_Accounts":
			getAllaccountbutton().click();
			break;
		case "All_Accounts_BussinessAccounts":
			getAllAccountBusiness().click();
			break;
		case "All Accounts - EE":
			getAllAccountEE().click();
		default:
			break;
		}
	}

	// Created by vinay to create a quote in account page
	public void CreateQuoteinAccountpage(Map<String, String> data, String OpportunityRecordType, String OpportunityType,
			String ContractingParty, String CurrentProvider) {
		bean.fillRandomData();
		util.clickOnActionToolBarButton("AccountActionToolbar", "Create Quote");
		util.waitForVlocityOmniScript();
		util.refreshSwitchToFrame();
		util.AttachFrame();
		util.waitFor(By.xpath("//input[@id='QuoteName']"), 20, true);
		driver.findElement(By.xpath("//input[@id='QuoteName']")).sendKeys(bean.getFirstName());
		util.selectBy(
				driver.findElement(By.xpath(
						"//span[text()='Opportunity Record Type :']/following::select[@id='OpportunityRecordType']")),
				OpportunityRecordType);
		util.selectBy(
				driver.findElement(
						By.xpath("//span[text()='Opportunity Type']/following::select[@id='OpportunityType']")),
				OpportunityType);
		util.selectBy(
				driver.findElement(
						By.xpath("//span[text()='Contracting Party']/following::select[@id='ContractingParty']")),
				ContractingParty);
		util.enterText(By.xpath("//input[@id='OpportunityCloseDate']"), date.getDate(365, "MM-dd-yyyy"));
		util.clickUsingJs(By.xpath("//input[@id='PriceList']"));
		util.waitFor(By.xpath("//input[@id='PriceList']/following::ul/li[contains(text(),'SMART')]"), 20, true);
		util.clickUsingJs(By.xpath("//input[@id='PriceList']/following::ul/li[contains(text(),'SMART')]"));
		driver.findElement(By.xpath("//input[@id='MINPort']")).sendKeys(data.get("MIN for Port In"));
		util.selectBy(
				driver.findElement(
						By.xpath("//span[text()='Current Provider']/following::select[@id='CurrentProvider']")),
				CurrentProvider);
//		util.waitFor(By.xpath("//input[@id='ContractedMonths']"), 30, true);
//		util.enterText(By.xpath("//input[@id='ContractedMonths']"), data.get("ContractedMonths"));
		util.waitFor(5);
		util.vlocityNextButton();
		util.waitForQuotePage();
	}
}
