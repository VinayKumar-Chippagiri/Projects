package com.pldt.pages;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;

import com.common.utilities.ProjectBeans;
import com.common.utilities.TestDataBean;
import com.common.utilities.WebUtilities;
import com.pldt.locators.BillingAndServiceAccountLocator;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.DateUtil;
import com.qmetry.qaf.automation.util.Reporter;

public class BillingAndServiceAccount extends WebDriverBaseTestPage<WebDriverTestPage> implements BillingAndServiceAccountLocator
{
	WebUtilities util = new WebUtilities();
	TestDataBean bean = new TestDataBean();
	DateUtil date=new DateUtil();
	
	@FindBy(locator = Save)
	private QAFWebElement save;
	@FindBy(locator = Menu)
	private QAFWebElement menu;
	@FindBy(locator = CreateBillingAccount)
	private QAFWebElement createBillingAccount;
	@FindBy(locator = CreateServiceAccount)
	private QAFWebElement createServiceAccount;
	

	@Override
	protected void openPage(PageLocator locator, Object... args) 
	{
	}
	
	public QAFWebElement getSave() {
		return save;
	}
	
	public QAFWebElement getMenu() {
		return menu;
	}

	public QAFWebElement getCreateBillingAccount() {
		return createBillingAccount;
	}

	public QAFWebElement getCreateServiceAccount() {
		return createServiceAccount;
	}

	public void fillAccountInformation()
	{
		bean.fillRandomData();
		util.type("CRM Account Number");
		
		String BillingAcName = bean.getFirstName()+"billingaccount";
		util.type("Account Name",BillingAcName);
		pageProps.setProperty("BillingAccountName", BillingAcName);
		util.type("Account Currency");
		util.select("LoB (Line of Business)");
		util.type("Parent Account");
		util.select("Parent Account Record Type");
		util.select("Status");
		util.type("Case Number");
	}
	
	public void fillCustomerProfile()
	{	
		bean.fillRandomData();
		util.type("Company Trade Name");
		util.select("Industry");
		util.select("Industry Sub Type");
		util.select("Bill Frequency");
		util.select("Bill Dispatch Method");
		util.select("Bill Cycle");
		util.click("eSOA Enrollment");
		util.select("Contact");
		util.type("Company TIN");
		util.type("Personal TIN");
		util.select("Credit Class");
		util.select("Tax Exemption");
		util.select("Tax Exemption Rules");
		util.select("Tax Profile");
		String eSOA = bean.getOther()+"@gmail.com";
		util.type("eSOA Notification Email ID",eSOA);
	}
	
	public void fillSmartBillingInformation()
	{
	
	    util.selectAndClickSuggestedValue("Account Type Code");
		util.select("Account Payment Type");
		util.select("Subscription");
		util.type("Assignee/ CI First Name");
		util.type("Assignee/ CI Middle Name");
		util.type("Assignee/ CI Last Name");
		util.type("Credit Limit");
		util.select("THS Rating");
		util.select("VIP Code");
	}
	
	public void fillPLDTBillingInformation()
	{
		util.type("Corporate Individual");
		util.type("For the Account Of");
		util.select("For the Account Of - Biz Act");
	}
	public void fillContactPreferences()
	{	
		bean.fillRandomData();
		util.click("Email Notification");
		util.click("SMS Notification");
		util.click("Payment reminder callout");	
		String email = pageProps.getPropertyValue("BillingAccountName")+"@gmail.com";
		util.type("Notify Email ID", email);
		String notifyMobile= String.format("639%s",bean.getPhone_mobile().toString());
		notifyMobile = StringUtils.rightPad(notifyMobile, 12, "0");
		util.type("Notify Mobile No", notifyMobile);
	}
	
	public void fillBillingAddressInformation()
	{
		util.type("Billing Address Line 1");
		util.type("Billing Address Line 2");
		util.type("Billing Address Line 3");
		util.select("Billing Country");
		util.select("Billing State/Province");
		util.selectAndClickSuggestedValue("Billing City");
		util.selectAndClickSuggestedValue("BARANGAY");
		util.selectAndClickSuggestedValue("Billing Zip/Postal Code");
		util.type("Billing City BackEnd");
		util.type("BARANGAY_BackEnd");
		util.type("Billing Zip/Postal Code BackEnd");
	}
	public void fillSmartIntegrationUpdates()
	{
		util.select("SFDC Collection Status");
		util.select("SFDC THS Status");

	}
	public void fillLegacyInformationReference()
	{
		util.type("Legacy CSP Parent Account Number");
		util.type("Legacy CSP Parent Account Name");
		util.type("Legacy CSP Parent Account Type Code");
		util.type("Legacy CSP Parent Account ID");
	}
	public void fillServiceAccountInformation()
	{	
		bean.fillRandomData();
		String serviceName= bean.getFirstName()+"serviceaccount";
		util.type("Account Name",serviceName);
		pageProps.setProperty("ServiceAccountName", serviceName);
		util.type("CRM Account Number");
		util.select("Parent Account Record Type");
		util.select("Status");
		
	}
	public void fillServiceAddressInformation()
	{
		util.select("Country");
		util.typeIntoTextArea("Street");
		util.type("City");
		util.select("State/Province");
		util.type("Zip/Postal Code");
	}
	
	public void selectServiceAccountCountry()
	{
	    util.click("newService_country_XPATH");
	   	  // util.clickUsingJs(By.xpath("//*[text()='"+country+"']"));
	}
	
//	Created by Vinay to create Billing Account
	public void createBillingAccount()
	{
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Create New Billing Account");
		fillAccountInformation();
		fillCustomerProfile();
		fillSmartBillingInformation();
		fillPLDTBillingInformation();
		fillContactPreferences();
		fillBillingAddressInformation();
		fillSmartIntegrationUpdates();
		fillLegacyInformationReference();
		//getSave().click();
		util.waitFor(By.xpath("(//span[text()='Save'])[last()]"), 10, true);
		Reporter.logWithScreenShot("Successfully Entered Billing account information");
		util.clickButton(driver.findElement(By.xpath("(//span[text()='Save'])[last()]")));
		util.waitForAccountPage();	
	}
	
//	Created by Vinay to createServiceAccount
	public void createServiceAccount() 
	{
		util.clickOnActionToolBarButton("QuoteActionToolbar", "Create New Service Account");
		 fillServiceAccountInformation();
		 fillServiceAddressInformation();
		//getSave().click();
			util.waitFor(By.xpath("(//span[text()='Save'])[last()]"), 10, true);
			Reporter.logWithScreenShot("Successfully Entered Service account information");
		util.clickButton(driver.findElement(By.xpath("(//span[text()='Save'])[last()]")));
		util.waitForAccountPage();
		}
}

