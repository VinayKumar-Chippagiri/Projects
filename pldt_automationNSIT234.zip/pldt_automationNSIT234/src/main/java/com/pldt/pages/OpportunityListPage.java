package com.pldt.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.common.utilities.ProjectBeans;
import com.common.utilities.WebUtilities;
import com.pldt.elements.Button;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class OpportunityListPage extends WebDriverBaseTestPage<WebDriverTestPage>{
	WebUtilities util=new WebUtilities();
	static final String OpportunityNameSearch="xpath=(//label[text()='Opportunity Name']/following::input)[1]";
	static final String QuickFilter= "xpath=//button[@title='Show quick filters']";
	@FindBy (locator =OpportunityNameSearch)
	private QAFWebElement opportunityNameSearch;
	@FindBy (locator =QuickFilter)
	private QAFWebElement quickFilter;
	public QAFWebElement getOpportunityNameSearch() {
		return opportunityNameSearch;
	}
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	public void clickNewOpportunity()
	{
		new Button().click("New");
		Reporter.log("Clicked on New button..");
	}
	public void SearchOpportunity(String OpportunityName) 
	{
		util.clickUsingJs(quickFilter);
////		getQuickFilter().click();
		getOpportunityNameSearch().sendKeys(OpportunityName);
		getOpportunityNameSearch().sendKeys(Keys.ENTER);
		String opportunity = "//a[text()='" + OpportunityName + "']";
//		QAFWebElement opportunityname = new QAFExtendedWebElement(opportunity);
		util.clickUsingJs(By.xpath(opportunity));
		ProjectBeans.setOpportunityURL(driver.getCurrentUrl());
	}
}
