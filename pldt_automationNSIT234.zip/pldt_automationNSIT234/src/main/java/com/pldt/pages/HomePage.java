package com.pldt.pages;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.common.utilities.WebUtilities;
import com.pldt.locators.HomePageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;



public class HomePage extends WebDriverBaseTestPage<WebDriverTestPage> implements HomePageLocators {
	WebUtilities util = new WebUtilities();
	private QAFWebElement UserNameSelect;
	private QAFWebElement dropdownValueSelect;
	@FindBy(locator = global_search)
	private QAFWebElement SearchGlobal;
	@FindBy(locator = global_search_input)
	private QAFWebElement SearchInput;
	@FindBy(locator = User_Detail)
	private QAFWebElement UserDetailButton;
	@FindBy(locator = login_btn)
	private QAFWebElement LoginButton;
	@FindBy(locator = frame)
	private QAFWebElement switchframe;
	@FindBy(locator = appLauncher)
	private QAFWebElement appLauncherbutton;
	@FindBy(locator = appSearch)
	private QAFWebElement appSearchinput;
	@FindBy(locator = logout_UserBtn)
	private QAFWebElement LogoutUserButton;
	@FindBy(locator = user_appLauncher)
	private QAFWebElement UserPageAppLauncher;
	@FindBy(locator = LOGIN_LOGO)
	private QAFWebElement logo;
	@FindBy(locator = SETUP_HOMEPAGEbtn)
	private QAFWebElement setup;
	@FindBy(locator = SETUP_Link)
	private QAFWebElement setlink;
	@FindBy(locator = SETUPUSERHEADING)
	private QAFWebElement setupuserheading;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getSearchGlobal() {
		return SearchGlobal;
	}

	public QAFWebElement getSearchInput() {
		return SearchInput;
	}

	public QAFWebElement getUserNameSelect() {
		return UserNameSelect;
	}

	public QAFWebElement getUserDetailButton() {
		return UserDetailButton;
	}

	public QAFWebElement getLoginButton() {
		return LoginButton;
	}

	public QAFWebElement getSwitchframe() {
		return switchframe;
	}

	public QAFWebElement getAppLauncherbutton() {
		return appLauncherbutton;
	}

	public QAFWebElement getAppSearchinput() {
		return appSearchinput;
	}

	public QAFWebElement getLogoutButton() {
		return LogoutUserButton;
	}

	public QAFWebElement getUserPageAppLauncher() {
		return UserPageAppLauncher;
	}

	public QAFWebElement getLogo() {
		return logo;
	}

	public QAFWebElement getSetup() {
		return setup;
	}

	public QAFWebElement getsetlink() {
		return setlink;
	}

	public void SwitchToUser(String username, String userProfile)   {
		if (driver.findElements(By.xpath("//input[@id=//span[contains(text(),'Search Setup')]/../@for]")).size() != 0) {
			QAFWebElement GlobalSearchSetup = new QAFExtendedWebElement(
					"xpath=//input[@id=//span[contains(text(),'Search Setup')]/../@for]");
			util.clickButton(GlobalSearchSetup);
		} else {
			QAFWebElement GlobalSearch = new QAFExtendedWebElement("xpath=(//lightning-primitive-icon)[1]");
			util.clickButton(GlobalSearch);
		}
		if (driver.findElements(By.xpath("//input[@id=//span[contains(text(),'Search Setup')]/../@for]")).size() != 0) {
			QAFWebElement GlobalSearchSetup = new QAFExtendedWebElement(
					"xpath=//input[@id=//span[contains(text(),'Search Setup')]/../@for]");
			util.enterText(GlobalSearchSetup, username);
		} else {
			QAFWebElement GlobalSearch = new QAFExtendedWebElement(
					"xpath=//input[@id=//label[contains(text(),'Search...')]/@for]");
			util.enterText(GlobalSearch, username);
		}
		QAFWebElement UserNameSelect = new QAFExtendedWebElement("//span[@title='" + username + "']");
		util.clickButton(UserNameSelect);
		if (driver.findElements(By.xpath("(//a[@title='User Detail'])[1]")).size() != 0) {

		}
		QAFWebElement userDetails = new QAFExtendedWebElement("xpath=(//a[@title='User Detail'])[1]");
		util.clickUsingJs(userDetails);
		util.switchToLoginFrame();
		getLoginButton().waitForVisible(30000);
		util.clickUsingJs(getLoginButton());
		driver.switchTo().defaultContent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public  void switchToAnyUser(String Name) {
		String urlName=Name.replace(" ", ".")+".url";
		driver.get(pageProps.getString(urlName));
		
//		 String type="User";
//		JavascriptExecutor js = (JavascriptExecutor)driver;
//		util.waitForClickable(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"), 60);
//		util.scrollIntoElement(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"));
//		util.moveToElement(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"));
//		js.executeScript(
//				"document.querySelector('button.slds-button.slds-button_neutral.search-button.slds-truncate').click()");
//		util.enterTextUsingJs(By.xpath("//*[@placeholder='Search...']"), Name);
//		String nameXpath = "//span[@title='" + Name + "']";
//		String typeXpath = nameXpath + "/following-sibling::div//span[text()='" + type + "']";
//		util.waitFor(By.xpath(nameXpath), 60, true);
//		if (util.isElementDisplayed(By.xpath(nameXpath))) {
//			if (util.isElementDisplayed(By.xpath(typeXpath))) {
//				util.clickButton(new QAFExtendedWebElement(By.xpath(nameXpath)));
//			}
//		}
//		QAFWebElement userDetails = new QAFExtendedWebElement("xpath=(//a[@title='User Detail'])[1]");
//		util.clickUsingJs(userDetails);
//		util.waitFor(By.xpath("//h1[.='Users']"), 10, true);
		util.switchToLoginFrame();
		getLoginButton().waitForVisible(30000);
		util.clickUsingJs(getLoginButton());
		util.waitFor(By.xpath("//span[contains(text(),'Logged in as')]"), 25, true);
		if(!util.isElementDisplayed(By.xpath("//span[contains(text(),'Logged in as')]")))
		{
			switchToAnyUser(Name);
		}
		driver.switchTo().defaultContent();
		
	}
	
	
	public  void switchToAnyAccount(String Name,String Number) {
		JavascriptExecutor js = (JavascriptExecutor)driver;
		util.waitForClickable(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"), 60);
		util.scrollIntoElement(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"));
		util.moveToElement(By.cssSelector("button.slds-button.slds-button_neutral.search-button.slds-truncate"));
		js.executeScript(
				"document.querySelector('button.slds-button.slds-button_neutral.search-button.slds-truncate').click()");
		util.enterTextUsingJs(By.xpath("//*[@placeholder='Search...']"), Name);
	
		String typeXpath = "//lightning-formatted-rich-text/span[contains(text(),'"+Number+"')]";
		String nameXpath = typeXpath+"/ancestor::div[2]/span";
		util.waitFor(By.xpath(nameXpath), 60, true);
		if (util.isElementDisplayed(By.xpath(nameXpath))) {
				util.clickButton(new QAFExtendedWebElement(By.xpath(nameXpath)));
			
		}
		
		util.waitForAccountPage();
	}
	
	
	

	public void SwitchToAccount(String accountname) {
		util.clickUsingJs(SearchGlobal);
		getSearchInput().sendKeys(accountname);
		UserNameSelect = new QAFExtendedWebElement("//span[@title='" + accountname + "']");
		UserNameSelect.click();
		Reporter.logWithScreenShot("Opened account..");
	}

	public void goToAPP(String app) {
		util.clickUsingJs(appLauncherbutton);
		getAppSearchinput().sendKeys(app);
		dropdownValueSelect = new QAFExtendedWebElement("//b[.='" + app + "']");
		dropdownValueSelect.click();
		Reporter.log("Clicked on appLauncher and selecting dropdown value..");
	}

	public void setUP() throws InterruptedException {
		if (!setupuserheading.isPresent()) {
			getSetup().click();
			getsetlink().click();
			Set<String> windows = driver.getWindowHandles();
			for (String handle : windows) {
				driver.switchTo().window(handle);
			}
			Reporter.log("Clicked on setUp user button..");
		}
	}

	public void clickOnViewAll()
	{
		util.clickUsingJs(By.xpath("//span[@title=\"Items to Approve\"]/ancestor::article//span[@class='viewAllLabel']"));
		//util.waitForApprovalRequestPage();
	}
	
	
	
}
