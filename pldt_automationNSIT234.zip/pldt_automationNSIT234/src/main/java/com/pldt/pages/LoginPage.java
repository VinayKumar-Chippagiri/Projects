package com.pldt.pages;

import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.pldt.locators.LoginPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class LoginPage extends WebDriverBaseTestPage<WebDriverTestPage> implements LoginPageLocators {
	WebUtilities util = new WebUtilities();
	HomePage homepage = new HomePage();
	private static String uname = null;
	private static String paswd = null;

	@FindBy(locator = user_name)
	private QAFWebElement username;

	@FindBy(locator = pass_word)
	private QAFWebElement password;

	@FindBy(locator = login_button)
	private QAFWebElement loginButton;

	@FindBy(locator = logout_UserBtn)
	private QAFWebElement LogoutUserButton;

	@FindBy(locator = LOGIN_LOGO)
	private QAFWebElement logo;

	@Override
	protected void openPage(PageLocator locator, Object... args) {

		driver.get(pageProps.getString("env.baseurl"));

	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		LoginPage.uname = uname;
	}

	public String getPaswd() {
		return paswd;
	}

	public void setPaswd(String paswd) {
		LoginPage.paswd = paswd;
	}

	public QAFWebElement getUserName() {
		return username;
	}

	public QAFWebElement getPassword() {
		return password;
	}

	public QAFWebElement getLoginButton() {
		return loginButton;
	}

	public QAFWebElement getLogoutButton() {
		return LogoutUserButton;
	}

	public QAFWebElement getLogo() {
		return logo;
	}

	public void LoginAsAdmin() {
		util.type("Username");
		util.type("Password");
		util.clickUsingJs(By.xpath("//input[@id='Login']"));
		util.refreshPage();

	}

	public void logoutCurrentUser() {
//		getLogoutButton().click();
		util.waitFor(5);
		util.clickUsingJs(getLogoutButton());

		try {
			Thread.sleep(3000);
			if (driver.findElement(By.xpath("(//span[.='Home'])[1]")).isDisplayed()) {
			}
		} catch (Exception e) {
			driver.manage().deleteAllCookies();
			util.goToURL("https://test.salesforce.com");
			LoginAsAdmin();
		}
		util.goToHomePage();

	}

	public void logoutAsCurrentUser() {
		// getLogoutButton().click();
		util.waitFor(5);
		util.clickUsingJs(getLogoutButton());

		try {
			Thread.sleep(3000);
			if (driver.findElement(By.xpath("(//span[.='Home'])[1]")).isDisplayed()) {

			}
		} catch (Exception e) {
			driver.manage().deleteAllCookies();
			util.goToURL("https://test.salesforce.com");
			LoginAsAdmin();
			util.goToHomePage();
		}
	}

}
