package com.pldt.pages;

import java.util.Map;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class SyniverseServiceDisconnectPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	@FindBy(locator= "xpath=//td[text()='Reference ID:']/following::input[@name='value(sReferenceId)']")
	private QAFWebElement ReferenceID; 
	@FindBy(locator= "xpath=//td[text()='Owner ID:']/following::input[@name='value(sOwnerId)']")
	private QAFWebElement OwnerID; 
	@FindBy(locator= "xpath=//td[text()='BRN:']/following::input[@name='value(sRegistrationCode)']")
	private QAFWebElement BRN; 
	@FindBy(locator= "xpath=//td[text()='Porting Number:']/following::input[@name='value(sSubscriberNumber)']")
	private QAFWebElement PortingNumber;
	@FindBy(locator = "xpath=//input[@name='value(FromSubDate)']")
	private QAFWebElement SubmissionDateFrom;
	@FindBy(locator = "xpath=//input[@name='value(ToSubDate)']")
	private QAFWebElement SubmissionDateTo;
	//select[@name='value(FromSubTimeHH)']
	//select[@name='value(FromSubTimeMM)']
	//select[@name='value(ToSubTimeHH)']
	//select[@name='value(ToSubTimeMM)']
	@FindBy(locator = "xpath=//select[@name='value(SortBy)']")
	private QAFExtendedWebElement SortBy;
	@FindBy(locator= "xpath=//input[@value='Search']")
	private QAFWebElement Search;
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub		
	}
	public QAFWebElement getReferenceID() {
		return ReferenceID;
	}
	public QAFWebElement getOwnerID() {
		return OwnerID;
	}
	public QAFWebElement getBRN() {
		return BRN;
	}
	public QAFWebElement getPortingNumber() {
		return PortingNumber;
	}
	public QAFWebElement getSubmissionDateFrom() {
		return SubmissionDateFrom;
	}
	public QAFWebElement getSubmissionDateTo() {
		return SubmissionDateTo;
	}
	public QAFExtendedWebElement getSortBy() {
		return SortBy;
	}
	public QAFWebElement getSearch() {
		return Search;
	}
	public void serviceDisconnect(Map<String, String> data)
	{
		getPortingNumber().sendKeys(data.get("Porting Number"));
		getSubmissionDateFrom().sendKeys(data.get("Submission Date From"));
		getSubmissionDateTo().sendKeys(data.get("Submission Date To"));
		getSearch().click();
	}
}
