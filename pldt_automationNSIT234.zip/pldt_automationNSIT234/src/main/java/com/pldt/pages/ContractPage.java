package com.pldt.pages;

import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.pldt.locators.ContractPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class ContractPage extends WebDriverBaseTestPage<WebDriverTestPage> implements ContractPageLocators {
	WebUtilities util = new WebUtilities();
	@FindBy(locator = Generate)
	private QAFWebElement generate;
	@FindBy(locator = Negotiating)
	private QAFWebElement negotiating;
	@FindBy(locator = Awaiting_Signature)
	private QAFWebElement awaiting_Signature;
	@FindBy(locator = Signed)
	private QAFWebElement signed;
	@FindBy(locator = Mark_Status_As_Complete)
	private QAFWebElement markStatusAsComplete;
	@FindBy(locator = Template_Select)
	private QAFWebElement TemplateSelect;
	@FindBy(locator = Check_In)
	private QAFWebElement checkIn;
	@FindBy(locator = Details)
	private QAFWebElement details;
	@FindBy(locator = Qoute)
	private QAFWebElement qoute;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public QAFWebElement getGenerate() {
		return generate;
	}

	public QAFWebElement getNegotiating() {
		return negotiating;
	}

	public QAFWebElement getAwaiting_Signature() {
		return awaiting_Signature;
	}

	public QAFWebElement getSigned() {
		return signed;
	}

	public QAFWebElement getMarkStatusAsComplete() {
		return markStatusAsComplete;
	}

	public QAFWebElement getTemplateSelect() {
		return TemplateSelect;
	}

	public QAFWebElement getCheckIn() {
		return checkIn;
	}

	public QAFWebElement getDetails() {
		return details;
	}

	public QAFWebElement getQoute() {
		return qoute;
	}

	public void ChangeTheStatusToAwaitingSignature() {
		// QAFWebElement MarkCurrentStatus =new
		// QAFExtendedWebElement(By.xpath("//span[text()='Mark as Current Status']"));
		getNegotiating().click();
		getMarkStatusAsComplete().click();
		// MarkCurrentStatus.click();
		getAwaiting_Signature().click();
	}

	public void GenerateContractDocument(String Template) {
		getDetails().click();
		util.waitFor(3);
		util.scrollIntoElement(By.xpath("//span[.='Address Information']"));
		util.AttachFrame();
		util.clickUsingJs(By.xpath("//span[text()='Generate']/ancestor::button"));
		util.waitFor(10);
		util.AttachFrame();
		util.waitFor(15);
		util.selectBy(driver.findElement(By.xpath("//select[@id='template-select']")), Template);
		util.waitFor(15);
		Reporter.logWithScreenShot("Template is selected");
		util.waitFor(By.xpath("//button[text()='Download Word']"), 30, true);
		util.waitFor(30);
		util.clickUsingJs(By.xpath("//button[text()='Download Word']"));
		util.waitFor(10);
		util.clickUsingJs(By.xpath("//button[text()='Check In']"));
	}

	public void GoToQuote() {
		getDetails().click();
		util.clickButton(getQoute());
	}

	public void ChangeTheStatusToSigned() {
		Reporter.logWithScreenShot(util.ChangeStatus("Negotiating"));
		util.waitFor(5);
		util.scrollUp();
		Reporter.logWithScreenShot(util.ChangeStatus("Awaiting Signature"));
		util.waitFor(5);
		util.scrollUp();
		Reporter.logWithScreenShot(util.ChangeStatus("Signed"));
		util.waitFor(5);
		util.scrollUp();
	}
}
