package com.pldt.pages;

import org.openqa.selenium.By;

import com.common.utilities.WebUtilities;
import com.pldt.locators.VlocityPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class VlocityPage extends WebDriverBaseTestPage<WebDriverTestPage> implements VlocityPageLocators  {
	WebUtilities util = new WebUtilities();
	@FindBy(locator = singleTransBtn)
	private QAFWebElement SingleTransBtn ;
	
	@FindBy(locator = headingEligibility)
	private QAFWebElement HeadingEligibility;
	
	@FindBy(locator = phoneNoInputBox)
	private QAFWebElement PhoneNoInputBox ;
	
	@FindBy(locator = checkEligiBtn)
	private QAFWebElement CheckEligiBtn;
	
	@FindBy(locator = nextBtn)
	private QAFWebElement NextBtn;
	
	@FindBy(locator = downloadAsCsvBtn)
	private QAFWebElement DownloadAsCsvBtn;
	
	@FindBy(locator = resultNextBtn)
	private QAFWebElement ResultNextBtn;

	@FindBy(locator = finalDoneBtn)
	private QAFWebElement FinalDoneBtn;
	
	@FindBy(locator = bulkTransBtn)
	private QAFWebElement BulkTransBtn;

	@FindBy(locator = uploadFile)
	private QAFWebElement UploadFile;
	
	
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	
	
	public QAFWebElement getSingleTransBtn() {
		return SingleTransBtn;
	}
	
	public QAFWebElement getHeadingEligibility() {
		return HeadingEligibility;
	}
	
	public QAFWebElement getPhoneNoInputBox() {
		return PhoneNoInputBox;
	}
	
	public QAFWebElement getCheckEligiBtn() {
		return CheckEligiBtn;
	}
	
	public QAFWebElement getNextBtn() {
		return NextBtn;
	}
	
	public QAFWebElement getDownloadAsCsvBtn() {
		return DownloadAsCsvBtn;
	}
	
	public QAFWebElement getResultNextBtn() {
		return ResultNextBtn;
	}
	
	public QAFWebElement getFinalDoneBtn() {
		return FinalDoneBtn;
	}
	
	public QAFWebElement getBulkTransBtn() {
		return BulkTransBtn;
	}


	public QAFWebElement getUploadFile() {
		return UploadFile;
	}


	public void vlocityEligibilityCheck(String Phonenum)
	{	
		
		util.waitFor(By.xpath("//title[contains(text(),'Lightning Experience | Salesforce')]"), 10, true);
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.refreshPage();
		util.waitForPageToLoad();
		getHeadingEligibility().waitForPresent(10000);
		getSingleTransBtn().click();
		getPhoneNoInputBox().sendKeys(Phonenum);
		Reporter.logWithScreenShot("entered Phone number..");
		util.waitFor(getCheckEligiBtn(), 20, true);
		getCheckEligiBtn().click();
		util.waitFor(getNextBtn(), 20, true);
		getNextBtn().waitForEnabled(10000);
		getNextBtn().click();
		getDownloadAsCsvBtn().click();
		getResultNextBtn().waitForEnabled(10000);
		getResultNextBtn().click();
		getFinalDoneBtn().waitForEnabled(10000);
		util.waitFor(getFinalDoneBtn(), 20, true);
		getFinalDoneBtn().click();
		Reporter.log("Performed manual eligibility check..");
	}
	
	//made chnage by vidya
	public void vlocityBulkEligibilityCheck(String location)
	{	
		util.waitFor(By.xpath("//title[contains(text(),'Lightning Experience | Salesforce')]"), 10, true);
		util.waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 20, false);
		util.waitTillLoaderDissapear();
		util.refreshPage();
		util.waitForPageToLoad();
		getBulkTransBtn().waitForPresent(15000);
		getBulkTransBtn().click();
		driver.findElement(uploadFile).sendKeys(location);
		util.waitFor(FinalDoneBtn, 20, true);
		getFinalDoneBtn().waitForEnabled(20000);
		util.waitFor(3);
		getFinalDoneBtn().click();
		Reporter.logWithScreenShot("uploaded bulk file..");
		getCheckEligiBtn().click();
		util.waitFor(NextBtn, 20, true);
		getNextBtn().click();
		getDownloadAsCsvBtn().click();
		getResultNextBtn().click();
		getFinalDoneBtn().click();
		Reporter.log("Performed manual eligibility check..");
	}

	

}
