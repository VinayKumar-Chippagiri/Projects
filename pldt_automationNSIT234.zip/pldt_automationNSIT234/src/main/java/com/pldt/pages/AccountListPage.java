package com.pldt.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.common.utilities.WebUtilities;
import com.pldt.locators.AccountPageLocators;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class AccountListPage extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	private final String URL_BUSINESS_ACCOUNT_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000018ZsmEAE";
	private final String URL_ALL_ACCOUNTS_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000017Z7IEAU";
	private final String URL_ALL_ACCOUNTS_BILLING_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000017evXEAQ";
	private final String URL_ALL_ACCOUNTS_EE_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000017lUiEAI";
	private final String URL_ALL_ACCOUNTS_SERVICE_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000017evYEAQ";
	private final String URL_BILLING_AGGREGATOR_PAOLO_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s000001IWqBEAW";
	private final String URL_MY_ACCOUNTS_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B2x000006W2rdEAC";
	private final String URL_ORG_ACCOUNT_HIERARCHY_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s0000016rh1EAA";
	private final String URL_RECENTLY_VIEWED_ACCOUNT_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B2x000001NAbnEAG";
	private final String URL_MIGRATED_ACCOUNTS_TAB = pageProps.getString("baseurl")
			+ "o/Account/list?filterName=00B1s000000ujZXEAY";
	private static final By TITLE_ACCOUNT_IN_PANEL = By.xpath("//h1/div[text()='Account']");
	// @PageIdentifier
	@FindBy(locator = "xpath=//h1/span[text()='Accounts']")
	private QAFWebElement Accounts;

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		//driver.navigate().to(URL_BUSINESS_ACCOUNT_TAB);
		driver.navigate().to(URL_BUSINESS_ACCOUNT_TAB);
	}

	public void openAccount(String AccountName) {
		driver.navigate().to(getAccountLink(AccountName));
		util.waituntil.until(ExpectedConditions.visibilityOfElementLocated(TITLE_ACCOUNT_IN_PANEL));
	}

	
	public String getAccountLink(String AccountName) {
//	driver.findElementByXPath("//input[@name='Account-search-input']").sendKeys(AccountName);
		driver.findElement(By.xpath("//input[@placeholder='Search this list...']")).sendKeys(AccountName);
		driver.findElementByXPath("//input[@placeholder='Search this list...']").sendKeys(Keys.ENTER);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		String accountViewURL = driver.findElement(By.xpath(String.format("//a[text()='%s']", AccountName)))
				.getAttribute("href");
		pageProps.getString(AccountName, accountViewURL);
		return accountViewURL;
	}
}
