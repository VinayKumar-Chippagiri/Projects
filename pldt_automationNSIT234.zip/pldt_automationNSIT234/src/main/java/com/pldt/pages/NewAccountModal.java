package com.pldt.pages;

import com.common.utilities.WebUtilities;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;

public class NewAccountModal extends WebDriverBaseTestPage<WebDriverTestPage> {
	WebUtilities util = new WebUtilities();
	static final String Billing = "xpath=//span[text()='Billing']";
	static final String BillingAggregator = "xpath=//span[text()='Billing Aggregator']";
	static final String Business = "xpath=//span[text()='Business']";
	static final String Consumer = "xpath=//span[text()='Consumer']";
	static final String EnterpriseExtension = "xpath=//span[text()='Enterprise Extension']";
	static final String Group = "xpath=//span[text()='Group']";
	static final String Infinity = "xpath=//span[text()='Infinity']";
	static final String Other = "xpath=//span[text()='Other']";
	static final String Service = "xpath=//span[text()='Service']";
	static final String ServiceAggregator = "xpath=//span[text()='Service Aggregator']";
	static final String ZLOC = "xpath=//span[text()='Z LOC']";
	static final String Next = "xpath=//span[text()='Next']";
	static final String Cancel = "xpath=(//span[text()='Cancel'])[2]";
	static final String Save ="xpath=//button[text()='Save']";
	@FindBy (locator =Save)
	private QAFWebElement save;
	public QAFWebElement getSave() {
		return save;
	}
	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
		
	}
	public void createNewBillingAggregatorAccount()
	{
		util.type("CRM Account Number");
		util.selectAndClickSuggestedValue("Account name");
		util.select("Account Currency");
		util.select("LoB (Line of Business)");
		util.type("Parent Account");
		util.select("Breach Notification SLA");
		util.selectAndClickSuggestedValue("Parent Account");
		util.select("Parent Account Record Type");
		util.type("Company Trade Name");
		util.select("Industry");
		util.select("Industry Sub Type");
		util.select("Bill Frequency");
		util.selectAndClickSuggestedValue("Bill Dispatch Method");
		util.selectAndClickSuggestedValue("Bill Cycle");
		util.clickCheckbox("eSOA Enrollment");
		util.selectAndClickSuggestedValue("Contact");
		util.type("Company TIN");
		util.type("Personal TIN");
		util.select("Credit Class");
		util.select("Tax Exemption");
		util.select("Tax Exemption Rules");
		util.selectAndClickSuggestedValue("Tax Profile");
		util.type("eSOA Notification Email ID");
		util.select("Account Type Code");
		util.select("Account Payment Type");
		util.selectAndClickSuggestedValue("Subscription");
		util.select("Service Provider");
		util.type("Assignee/ CI First Name");
		util.type("Assignee/ CI Middle Name");
		util.type("Assignee/ CI Last Name");
		util.type("Credit Limit");
		util.select("THS Rating");
		util.selectAndClickSuggestedValue("VIP Code");
		util.type("Corporate Individual");
		util.type("For the Account Of");
		util.selectAndClickSuggestedValue("For the Account Of - Biz Act");
		util.clickCheckbox("Email Notification");
		util.clickCheckbox("SMS Notification");
		util.type("Notify Email ID");
		util.type("Notify Mobile No");
		util.type("Billing Address Line 1");
		util.type("Billing Address Line 2");
		util.type("Billing Address Line 3");
		util.select("Billing Country");
		util.select("Billing State/Province");
		util.selectAndClickSuggestedValue("Billing City");
		util.selectAndClickSuggestedValue("BARANGAY");
		util.selectAndClickSuggestedValue("Billing Zip/Postal Code");
		util.type("Billing City BackEnd");
		util.type("BARANGAY_BackEnd");
		util.type("Billing Zip/Postal Code BackEnd");
		util.select("SFDC Collection Status");
		util.select("SFDC THS Status");
		util.type("Legacy CSP Parent Account Number");
		util.type("Legacy CSP Parent Account Name");
		util.type("Legacy CSP Parent Account Type Code");
		util.type("Legacy CSP Parent Account ID");
		getSave().click();
	}
	public void createNewBusinessAccount()
	{
		util.type("CRM Account Number");
		util.selectAndClickSuggestedValue("Account Name");
		util.type("Formerly Known As");
		util.select("Account Class");
		util.select("Industry");
		util.select("Industry Sub Type");
		util.select("Account Currency");
		util.type("Parent Account");
		util.type("Case Number");
		util.select("Status");
		util.selectAndClickSuggestedValue("Parent Account");
		util.selectAndClickSuggestedValue("Associated Account");
		util.select("Account Source");
		util.type("Account Source-Other");
		util.type("No of Cases");
		util.clickCheckbox("Payment reminder callout");	
		util.select("Breach Notification SLA");
		util.type("Others Breach Notification SLA");
		util.select("Credit Class");
		util.clickCheckbox("Skip Credit Check");
		util.select("PLDT Credit Rating");
		util.select("ePLDT Credit Rating");
		util.select("ePLDT Credit Rating");
		util.select("SMART Credit Rating");
		util.select("PLDT Credit Tagging");
		util.select("SMART Credit Tagging");
		util.select("ePLDT Credit Tagging");
		util.select("ePDS Credit Tagging");
		util.select("AGS Credit Tagging");
		util.select("CURO Credit Tagging");
		//move documents
		
		
		
	}
}
