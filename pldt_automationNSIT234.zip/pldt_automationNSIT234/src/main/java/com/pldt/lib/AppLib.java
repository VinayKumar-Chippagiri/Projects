package com.pldt.lib;



public class AppLib {
    private PageLib pagelib;
    public AppLib() {
    	//this.driver=driver;
    	pagelib=new PageLib();
    }
    
    public PageLib Pages() {
		//return pagelib;
		
		return (pagelib == null) ? pagelib = new PageLib() : pagelib;
    }
}
