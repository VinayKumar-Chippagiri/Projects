package com.pldt.elements;

import java.util.Map;



import org.openqa.selenium.By;



import com.common.utilities.JSUtils;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.Reporter;



public class Dropdown extends WebDriverBaseTestPage<WebDriverTestPage>{
JSUtils js=new JSUtils();
private static final String DROPDOWN_LOCATOR = "//button[@id=//label[span[normalize-space(text())='%s']]/@for]|"
+ "//button[@id=//label[normalize-space(text())='%s']/@for]|"
+ "//a[@aria-describedby=//span[normalize-space(text())='%s']/@id]";
private static final String DROPDOWN_VALUE = "//lightning-base-combobox-item[@data-value='%s']|//a[@title='%s']";





public void select(String fieldName) {
Map<?, ?> map = (Map<?, ?>) pageProps.getObject("testdata");
String dropdownvalue = map.get(fieldName).toString();
if (!dropdownvalue.equalsIgnoreCase("skip"))
{
js.clickUsingJavaScript( driver.findElement(By.xpath(String.format(DROPDOWN_LOCATOR, fieldName,fieldName,fieldName))));
js.clickUsingJavaScript( driver.findElement(By.xpath(String.format(DROPDOWN_VALUE, dropdownvalue,dropdownvalue))));
Reporter.log("Selected " + dropdownvalue + " from " +fieldName+ "drop-down", MessageTypes.Info);

}




}

@Override
protected void openPage(PageLocator locator, Object... args) {

}




}
