package com.pldt.elements;

import java.util.Map;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;



import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;



public class TextBox extends WebDriverBaseTestPage<WebDriverTestPage>{
JavascriptExecutor executor = (JavascriptExecutor) new WebDriverTestBase().getDriver();
@Override
protected void openPage(PageLocator locator, Object... args) {


}

public void enterText(String fieldName) {

QAFExtendedWebElement element = new QAFExtendedWebElement(
"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
+ "']/@id]");
Map<?, ?> map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
if (map.get(fieldName) != null && !map.get(fieldName).toString().equalsIgnoreCase("skip")) {
enterText(element, map.get(fieldName).toString());
Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
}

}
public void enterText(QAFWebElement element, String textToEnter) {
element.waitForVisible(300000);
executor.executeScript("arguments[0].scrollIntoViewIfNeeded(true);",element);
element.clear();
element.sendKeys(textToEnter);
}

public void enterText(By locator, String textToEnter) {
driver.findElement(locator).waitForVisible(30000);
driver.findElement(locator).executeScript("scrollIntoView(true);");
driver.findElement(locator).clear();
driver.findElement(locator).sendKeys(textToEnter);
}

public void enterTextAndEnter(String fieldName)
{

QAFExtendedWebElement element = new QAFExtendedWebElement(
"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
+ "']/@id]");
Map<?, ?> map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
if (map.get(fieldName) != null && !map.get(fieldName).toString().equalsIgnoreCase("skip")) {
enterTextUsingJavaScript(element, map.get(fieldName).toString());
element.sendKeys(Keys.BACK_SPACE);
element.sendKeys(Keys.ENTER);
Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
}
}

public void enterTextUsingJavaScript(QAFWebElement element, String value)
{
element.waitForVisible(300000);
executor.executeScript("arguments[0].scrollIntoViewIfNeeded(true)",element);
String args = "arguments[0].value=" + "'" + value + "'";
System.out.println(args);
element.clear();
executor.executeScript(args, element);
}

}