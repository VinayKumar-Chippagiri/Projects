package com.pldt.locators;

public interface LoginPageLocators {
	static final String user_name="xpath=//input[@id='username']";
	static final String pass_word="xpath=//input[@id='password']";
	static final String login_button="xpath=//input[@id='Login']";
	
	static final String logout_UserBtn = "xpath=//a[@class='action-link']";
	static final String LOGIN_LOGO = "xpath=//div[@id='logo_wrapper' and @class='standard_logo_wrapper mb24']";
}
