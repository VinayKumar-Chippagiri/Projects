package com.pldt.locators;

public interface OpportunityPageLocators 
{
	static final String Opportunity_NewButton = "xpath=(//a[@title='New'])[2]";
	static final String NextButton = "xpath=//span[text()='Next']";
	static final String Opportunity_Name = "xpath=//label[normalize-space(text())='Opportunity Name']/following::input[1]"; //new
	static final String Account_Name = "xpath=//label[normalize-space(text())='Account Name']/following::input[1]";
	static final String Contracting_Party = "xpath=//label[normalize-space(text())='Contracting Party']/following::input[1]";

	static final String Smart = "xpath=(//span[@title=\"SMART\"])"; //new
	static final String Close_Date = "xpath=//label[normalize-space(text())='Close Date']/following::input[1]";
	static final String Opportunity_type = "xpath=//label[normalize-space(text())='Opportunity Type']/following::input[1]";
	static final String Stage = "xpath=//label[normalize-space(text())='Stage']/following::input[1]";
	static final String CurrentProvider = "xpath=//label[normalize-space(text())='Current Provider']/following::input[1]";
	static final String MINforPortIn = "xpath=//label[normalize-space(text())='MIN for Port In']/following::input[1]"; //new
	static final String opportunityCurrency="xpath=//*[text()='Opportunity Currency']//following-sibling::div//input";
	static final String NumberofContractMonth="xpath=//input[contains(@name,'NumberOfContractedMonths')]";
	static final String Save ="xpath=//button[text()='Save']";
	static final String Configure="xpath=(//span[text()='Configure']/parent::div)[1]";
	static final String DeviceAvailabilityCheck="xpath=(//span[text()='Device Availability check'])[1]";//new
	static final String DeviceAvailabilityNextBtn = "xpath=//button[@id='InventoryDetails_nextBtn']";//new
	static final String OppoSearchInput="xpath=//input[@name='Opportunity-search-input']";
	static final String CreateQuotebtn="xpath=(//span[text()='Create Quote'])[1]";
//	static final String CreateOrderBTN="xpath=//button/span[text()='Create Order']";
//	static final String Submitorderbtn="xpath=//button/span[text()='Submit Order']";
//	static final String NoProductAvailable="xpath=//div[@class='slds-text-align_center slds-m-vertical_medium cpq-no-products-msg']";
//	static final String OrderSubmitionResult="xpath=//div[@id='OrderSubmissionResults']/h1/p[1]";
	static final String EstablishNeedStage="xpath=//span[@class='ahead slds-path__stage']/following-sibling::span[text()='Establish Need']";
	static final String QualificationStage="xpath//span[@class='ahead slds-path__stage']/following-sibling::span[text()='Qualification']";
	static final String CreateQuote="xpath=//span[text()='Create Quote']/parent::div";
	static final String OpportunitySave="xpath=//button[text()='Save']";
	static final String creditCheckButton="xpath=(//span[text()='Credit Check'])[1]/parent::div/i/following-sibling::div/following-sibling::span";
	static final String ccStatusNextButton="xpath=//p[text()='Next']/parent::div";
	static final String ContractTerm="xpath=(//form[@name='productconfig']//select)[1]";
	static final String Speed="xpath=(//form[@name='productconfig']//select)[2]";
	static final String PaymentMethod="xpath=(//form[@name='productconfig']//select)[3]";
	static final String PlanName="xpath=(//form[@name='productconfig']//select)[4]";
	static final String PaymentFrequency="xpath=(//form[@name='productconfig']//select)[5]";
	static final String ETSSolutionDesignNeededLabel="xpath=(//form[@name='productconfig']//label)[14]";
	static final String ETSSolutionDesignNeeded="xpath=(//form[@name='productconfig']//select)[14]";
	static final String PriceBook="xpath=//input[@title='Search Price Books']";
	static final String QuickFilter= "xpath=//button[@title='Show quick filters']"; //new
	static final String OpportunityNameSearch="xpath=(//label[text()='Opportunity Name']/following::input)[1]"; //new
}
