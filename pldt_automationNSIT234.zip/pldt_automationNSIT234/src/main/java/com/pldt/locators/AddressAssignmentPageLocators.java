package com.pldt.locators;

public interface AddressAssignmentPageLocators 
{
	static final String SearchBillAccount="xpath=(//p[normalize-space(text())='Billing Account']/following::input[1])";
	static final String BillAccountCheckBox ="xpath=(//span[@class='slds-radio'])[1]";
	static final String SearchServiceAccount ="xpath=(//p[normalize-space(text())='Site A Address / Delivery Address / Installation Address']/following::input[1])";
	static final String ServiceAccountCheckBox ="xpath=((//table/tbody)[2]//span[@class='slds-radio'])[1]";
	static final String Save ="xpath=//button[@title='Save']";

}
