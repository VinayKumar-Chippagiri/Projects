package com.common.utilities;

import static com.qmetry.qaf.automation.ui.webdriver.ElementFactory.$;

import java.io.FileReader;
import java.io.FileWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.oro.text.regex.Util;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.MessageTypes;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;

import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.Reporter;

public class WebUtilities extends WebDriverBaseTestPage<WebDriverTestPage> {
	// class contains Test base and commons methods
	TestDataBean bean = new TestDataBean();
	public WebDriverWait waituntil = new WebDriverWait(driver, 60);
	JavascriptExecutor executor = (JavascriptExecutor) driver;
	Actions actions = null;
	Map<?, ?> map = null;
	Wait<WebDriver> wait = null;
	// QAFExtendedWebDriver driver = new WebDriverTestBase().driver;
//	public void scrollIntoElement(By locator) {
//		WebElement element = driver.findElement(locator);
//		js = ((JavascriptExecutor) driver);
//		js.executeScript("arguments[0].scrollIntoView(true);", element);
//	}
//	public Boolean clickDropdownValue(String dropdownvalue) {
//		try {
//			scrollIntoElement(By.xpath("//*[text()='" + dropdownvalue + "']"));
//			clickUsingJs(By.xpath("//*[text()='" + dropdownvalue + "']"));
//		} catch (Exception e) {
//		}
//		return true;
//	}

	@Override
	protected void openPage(PageLocator locator, Object... args) {
		// TODO Auto-generated method stub
	}

	public void clickButton(QAFWebElement element) {
		element.waitForVisible(300000);
		element.executeScript("scrollIntoView(true);");
		element.click();
	}

	public void enterText(QAFWebElement element, String textToEnter) {
		element.waitForVisible(300000);
		element.executeScript("scrollIntoView(true);");
		element.clear();
		element.sendKeys(textToEnter);
	}

	public void enterTextUsingJs(QAFWebElement element, String value) {
		element.waitForVisible(300000);
		element.executeScript("scrollIntoView(true);");
		String args = "arguments[0].value=" + "'" + value + "'";
		System.out.println(args);
		element.clear();
		executor.executeScript(args, element);
	}

	public void enterText(By locator, String textToEnter) {
		driver.findElement(locator).waitForVisible(30000);
		driver.findElement(locator).executeScript("scrollIntoView(true);");
		driver.findElement(locator).clear();
		driver.findElement(locator).sendKeys(textToEnter);
	}

	public void enterTextUsingJs(By element, String value) {
		String args = "arguments[0].value=" + "'" + value + "'";
		System.out.println(args);
		int count = 0;
		boolean flag = true;
		while (flag && count <= 3)
			try {
				if (!flag) {
					break;
				}
				waitFor(element, 5, true);
				scrollIntoElement(element);
				driver.findElement(element).clear();
				executor.executeScript(args, driver.findElement(element));
				flag = false;
			} catch (Exception e) {
				count++;
			}
	}

	public void selectDropdownValue(QAFWebElement dropdown, String dropDownValue) {
		clickButton(dropdown);
		QAFWebElement dropdownSelection = driver.findElement(By.xpath("//*[@title='" + dropDownValue + "']"));
		dropdownSelection.executeScript("scrollIntoView(true);");
		dropdownSelection.waitForVisible(300000);
		executor.executeScript("arguments[0].click();", dropdownSelection);
		// dropdown.waitForVisible(300000);
	}

	public void clickDropdownValue(String dropdownvalue) {
		// QAFWebElement dropdownSelection = driver.findElement(By.xpath("//*[text()='"
		// + dropdownvalue + "']"));
		QAFWebElement dropdownSelection = new QAFExtendedWebElement("(//*[text()='" + dropdownvalue + "'])");
		dropdownSelection.executeScript("scrollIntoView(true);");
		dropdownSelection.waitForVisible(300000);
		executor.executeScript("arguments[0].click();", dropdownSelection);
	}

	public void clickUsingJs(QAFWebElement element) {
		element.waitForVisible(30000);
		element.executeScript("scrollIntoView(true);");
		executor.executeScript("arguments[0].click();", element);
	}

	public Boolean clickUsingJs(By locator) {
		int count = 0;
		Boolean isClicked = false;
		boolean flag = true;
		while (flag && count <= 3) {
			try {
				if (!flag) {
					break;
				}
				waitFor(locator, 5, true);
				scrollIntoElement(locator);
				executor.executeScript("arguments[0].click();", driver.findElement(locator));
				isClicked = true;
				flag = false;
			} catch (Exception e) {
				count++;
			}
		}
		return isClicked;
	}

	public Boolean jsLooseClick(By locator) {
		Boolean isClicked = false;
		if (!isClicked) {
			waitFor(locator, 10, true);
			scrollIntoElement(locator);
			executor.executeScript("arguments[0].click();", driver.findElement(locator));
			isClicked = true;
		}
		return isClicked;
	}

	public void clickUsingJs(WebElement element) {
		waitFor(element, 10, true);
		executor.executeScript("arguments[0].scrollIntoView();", element);
		executor.executeScript("arguments[0].click();", element);
	}

	public void waitForClickable(WebElement element) {
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}

	public Boolean waitFor(By locator, int seconds, Boolean visibility) {
		wait = new FluentWait<WebDriver>(driver).withTimeout(seconds, TimeUnit.SECONDS)
				.pollingEvery(1, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		try {
			if (visibility) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			} else {
				wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
			}
		} catch (Exception e) {
		}
		return true;
	}

	public Boolean waitFor(WebElement element, int seconds, Boolean visibility) {
		wait = new FluentWait<WebDriver>(driver).withTimeout(seconds, TimeUnit.SECONDS)
				.pollingEvery(1, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		try {
			if (visibility) {
				wait.until(ExpectedConditions.visibilityOf(element));
			} else {
				wait.until(ExpectedConditions.invisibilityOf(element));
			}
		} catch (Exception e) {
		}
		return true;
	}

	public void SwitchToFrameByElement(QAFWebElement element) {
		driver.switchTo().frame(element);
	}

	public void SwitchToFrameByIndex(int num) {
		driver.switchTo().frame(num);
	}

	public void switchToActionFrame() {
		refreshPage();
		driver.switchTo().frame(driver.findElement(By.xpath("(//iframe[@scrolling=\"auto\"])[last()]")));
	}

	public void listofiframe() {
		List<WebElement> iframes = driver.findElements(By.xpath("//iframe"));
		for (WebElement iframe : iframes) {
			driver.switchTo().frame(iframe);
			System.out.println(iframe.getAttribute("title"));
		}
	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	public void refreshSwitchToFrame() {
		try {
			refreshPage();
			waitForPageToLoad();
			driver.switchTo().defaultContent();
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions
					.frameToBeAvailableAndSwitchToIt(By.xpath("(//iframe[@title='accessibility title'])[last()]")));
		} catch (Exception e2) {
		}
	}

	public void AttachFrame() {
		try {
			driver.switchTo().defaultContent();
			driver.switchTo().frame(driver.findElement(By.xpath("(//iframe[@title='accessibility title'])[last()]")));
		} catch (Exception e2) {
		}
	}

	// To change the stage status
	public String ChangeStatus(QAFWebElement locator1, QAFWebElement locator2) {
		clickUsingJs(locator1);
		clickUsingJs(locator2);
		waitForGenericToastMessage();
		String notify = "Notification title";
		try {
			notify = driver.findElement(By.xpath("//*[@data-aura-class='forceToastMessage']")).getText();
			driver.findElement(By.xpath("//*[@data-aura-class='forceToastMessage']")).waitForVisible(10000);
		} catch (Exception e) {
		}
		System.out.println();
		return notify;
	}

	public String ChangeStatus(String status) {
		clickUsingJs(By.xpath("(//div[@aria-label='Path Header']/ul/li/a[@data-tab-name='" + status + "'])[last()]"));
		clickUsingJs(By.xpath("//span[text()='Mark as Current Status']"));
		scrollUp();
		return waitForGenericToastMessage();
		
	}

	public String waitForGenericToastMessage() {
		waitFor(By.xpath("//*[@data-aura-class='forceToastMessage']"), 60, true);
		String notify = "Notification title";
		try {
			driver.findElement(By.xpath("//*[@data-aura-class='forceToastMessage']")).waitForVisible(10000);
			notify = driver.findElement(By.xpath("//*[@data-aura-class='forceToastMessage']")).getText();
		} catch (Exception e) {
		}
		return notify;
	}

	// To navigate to any URL
	public void goToURL(String string) {
		driver.get(string);
	}

	// To navigate to Home page
	public void goToHomePage() {
		URL uri = null;
		try {
			uri = new URL(driver.getCurrentUrl());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		goToURL("https://" + uri.getHost() + "/lightning/page/home");
	}

	// To click on any record in the table
	public void clickOnRecord(String name) {
		System.out.println(name);
		String nameLink = "//a[text()=" + "'" + name + "'" + "]";
		QAFWebElement searchName = new QAFExtendedWebElement(nameLink);
		searchName.waitForPresent(30000);
		searchName.click();
	}

	public void searchRecord(String name) {
		QAFWebElement searchName = new QAFExtendedWebElement("//*[contains(@name,'search-input')]");
		clickUsingJs(searchName);
		typeDataTo(searchName, name);
		enterKey(searchName);
	}

	public void enterKey(QAFWebElement e) {
		actions = new Actions(driver);
		actions.moveToElement(e).sendKeys(Keys.ENTER).build().perform();
	}

	public void enterKey() {
		actions = new Actions(driver);
		actions.sendKeys(Keys.ENTER).build().perform();
	}

	public void filterRecords(String dropdownValue) {
		QAFWebElement filterIcon = new QAFExtendedWebElement("//*[text()='Select a List View']/parent::*");
		clickUsingJs(filterIcon);
		clickDropdownValue(dropdownValue);
	}

	public void typeDataTo(QAFWebElement webelement, String data) {
		char[] dateChars = data.toCharArray();
		for (int i = 0; i < data.length(); i++) {
			webelement.sendKeys(Character.toString(dateChars[i]));
		}
	}

	public void type(String fieldName) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(
					"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
							+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
							+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
							+ "']/@id]");
			map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			if (map.get(fieldName) != null && !map.get(fieldName).toString().equalsIgnoreCase("skip")) {
				executor.executeScript("arguments[0].scrollIntoViewIfNeeded(true);", element);
				enterText(element, map.get(fieldName).toString());
//				Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
				Reporter.logWithScreenShot(
						"Entered " + map.get(fieldName).toString() + " in to " + fieldName + "  Field",
						MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Typing data to :" + fieldName + " is failed");
		}
	}

	public void typeAndEnter(String fieldName) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(
					"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
							+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
							+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
							+ "']/@id]");
			map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			if (map.get(fieldName) != null && !map.get(fieldName).toString().equalsIgnoreCase("skip")) {
				enterTextUsingJs(element, map.get(fieldName).toString());
				element.sendKeys(Keys.BACK_SPACE);
				element.sendKeys(Keys.ENTER);
//				Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
				Reporter.logWithScreenShot("Entered " + map.get(fieldName).toString() + " in to " + fieldName + "Field",
						MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Typing data to :" + fieldName + " is failed");
		}
	}

	public void click(String fieldName) {
		try {
			map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			String checkBox = map.get(fieldName).toString();
			if (checkBox != null && !checkBox.equalsIgnoreCase("skip")) {
				QAFExtendedWebElement element = new QAFExtendedWebElement(
						"xpath=//button[@id=//label[span[normalize-space(text())='" + fieldName
								+ "']]/@for]|//button[@id=//label[normalize-space(text())='" + fieldName
								+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
								+ "']/@id]");
				element.executeScript("scrollIntoView(true);");
//				element.click();
				clickUsingJs(element);
				Reporter.logWithScreenShot("Clicked on " + fieldName + " button", MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Clicking On :" + fieldName + " is failed");
		}
	}

	public void clickCheckbox(String fieldName) {
		try {
			map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			String checkBox = map.get(fieldName).toString();
			if (checkBox != null && !checkBox.equalsIgnoreCase("skip")) {
				QAFExtendedWebElement element = new QAFExtendedWebElement(
						"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
								+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
								+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
								+ "']/@id]");
				clickUsingJs(element);
			}
		} catch (Exception e) {
			System.out.println("Clicking On :" + fieldName + " is failed");
		}
	}

	public void select(String fieldName) {
		map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
		String dropdownvalue = map.get(fieldName).toString();
		if (!dropdownvalue.equalsIgnoreCase("skip")) {
			click(fieldName);
			QAFExtendedWebElement DropDownelement = new QAFExtendedWebElement(
					"xpath=//lightning-base-combobox-item[@data-value='" + dropdownvalue + "']|//a[@title='"
							+ dropdownvalue + "']");
//			DropDownelement.click();
			clickUsingJs(DropDownelement);
//			Reporter.logWithScreenShot("Selected:-" + dropdownvalue + "", MessageTypes.Info);
			Reporter.logWithScreenShot("Selected " + dropdownvalue + " from " + fieldName + "  drop-down",
					MessageTypes.Info);
		}
	}

	public void typeIntoTextArea(String fieldName) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(
					"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
							+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
							+ "']/@for]|//textarea[@id=//label[normalize-space(text())='" + fieldName
							+ "']/@for]|//textarea[@id=//label[span[normalize-space(text())='" + fieldName
							+ "']]/@for]");
			Map<?, ?> map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			if (map.get(fieldName) != null && !map.get(fieldName).toString().equalsIgnoreCase("skip")) {
				//element.sendKeys(map.get(fieldName).toString());
				enterText(element, map.get(fieldName).toString());
//				Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
				Reporter.logWithScreenShot("Entered " + map.get(fieldName).toString() + " in to " + fieldName + "Field",
						MessageTypes.Info);
			}
		} catch (Exception e) {
		}
	}

	public void waitForFrameLoad() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions
				.frameToBeAvailableAndSwitchToIt(By.xpath("(//iframe[contains(@name,'vfFrameId')])[1]")));
	}

	public void scrollTillVisible(By locator) {
		int height = Integer
				.parseInt(executor.executeScript("return document.documentElement.scrollHeight").toString());
		int checkScroll = 100;
		while (checkScroll <= height) {
			try {
				waitFor(locator, 10, true);
				executor.executeScript("window.scrollBy(" + 100 + ", " + checkScroll + ");");
				driver.findElement(locator).getText();
				break;
			} catch (Exception e2) {
			}
			checkScroll += 100;
		}
	}

	public void scrollTillVisible(WebElement element) {
		int height = Integer
				.parseInt(executor.executeScript("return document.documentElement.scrollHeight").toString());
		int checkScroll = 100;
		while (checkScroll <= height) {
			try {
				waitFor(element, 1, true);
				executor.executeScript("window.scrollBy(" + 100 + ", " + checkScroll + ");");
				element.getText();
				break;
			} catch (Exception e2) {
			}
			checkScroll += 100;
		}
	}

	public boolean switchToFrameByUsingChildElement(By childElmLocator) {
		List frameElems = getAllFrames();
		for (int frmIndex = 0; frmIndex < frameElems.size(); frmIndex++) {
			driver.switchTo().frame(frmIndex);
			if (driver.findElements(childElmLocator).size() > 0) {
				if (driver.findElement(childElmLocator).isDisplayed()) {
					return true;
				} else {
					driver.switchTo().defaultContent();
				}
			} else {
				driver.switchTo().defaultContent();
			}
		}
		return false;
	}

	private List getAllFrames() {
		try {
			Thread.sleep(12000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// List iFrmLst =
		// driver.findElements(By.xpath("//iframe[contains(@name,'vfFrameId')]"));
		List iFrmLst = driver.findElements(By.xpath("//iframe"));
		List totalFrms = new ArrayList();
		totalFrms.addAll(iFrmLst);
		return totalFrms;
	}

	public void switchtoFrameAndType(By childElmLocator, String text) {
		if (switchToFrameByUsingChildElement(childElmLocator)) {
			if (text.equalsIgnoreCase("Clear")) {
				driver.findElement(childElmLocator).clear();
				driver.switchTo().defaultContent();
			} else {
				driver.findElement(childElmLocator).sendKeys(text);
				System.out.println("Switched to Frame where child exist");
				driver.switchTo().defaultContent();
				try {
					Thread.sleep(4000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else {
			System.out.println("Frame not found.");
		}
	}

	public void switchtoFrameAndClick(By childElmLocator) {
		if (switchToFrameByUsingChildElement(childElmLocator)) {
			driver.findElement(childElmLocator).click();
			System.out.println("Switched to Frame where child exist");
			driver.switchTo().defaultContent();
			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			System.out.println("Frame not found.");
		}
	}

	public void switchToFrame(By locator) {
		if (switchToFrameByUsingChildElement(locator)) {
			driver.findElement(locator).click();
			System.out.println("Switched to Frame where child exist");
			driver.switchTo().defaultContent();
		}
	}

	public void selectBy(QAFExtendedWebElement element, String visibleText) {
		Select select = new Select(element);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		select.selectByVisibleText(visibleText);
	}

	public void scrollIntoElement(WebElement element) {
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public void scrollIntoElement(By locator) {
		waitFor(locator, 5, true);
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(locator));
	}

	public void vlocityNextButton() {
//		waitFor(By.xpath("(//div[contains(@id,'nextBtn')])[1]"),5,true);
		for (int i = 1; i <= 3; i++) {
			try {
				scrollTillVisible(By.xpath("(//div[contains(@id,'nextBtn')])[" + i + "]"));
				if (isElementDisplayed(By.xpath("(//div[contains(@id,'nextBtn')])[" + i + "]"))) {
					waitForClickable(By.xpath("(//div[contains(@id,'nextBtn')])[" + i + "]"), 5);
					jsLooseClick(By.xpath("(//div[contains(@id,'nextBtn')])[" + i + "]"));
					break;
				}
			} catch (Exception e) {
				System.out.println("Next button is not found");
			}
		}
	}

	public void vlocityPreviousButton() {
//		waitFor(By.xpath("(//div[contains(@id,'prevBtn')])[1]"),5,true);
		for (int i = 1; i <= 3; i++) {
			try {
				scrollTillVisible(By.xpath("(//div[contains(@id,'prevBtn')])[" + i + "]"));
				if (isElementDisplayed(By.xpath("(//div[contains(@id,'prevBtn')])[" + i + "]"))) {
					waitForClickable(By.xpath("(//div[contains(@id,'prevBtn')])[" + i + "]"), 5);
					jsLooseClick(By.xpath("(//div[contains(@id,'prevBtn')])[" + i + "]"));
					break;
				}
			} catch (Exception e) {
				System.out.println("Next button is not found");
			}
		}
	}

	public void waitTillLoaderDissapear() {
		waitFor(By.xpath("//*[@class='indicatorContainer forceInlineSpinner']"), 10, false);
	}

	public void waitForSearchPage() {
		waitFor(By.xpath("//span[@class='slds-var-p-right_x-small']"), 10, true);
	}

	public void waitForLeadPage() {
		waitFor(By.xpath("//div[.='Lead']"), 20, true);
	}

	public void waitForAccountPage() {
		waitFor(By.xpath("(//div[contains(@class,'profilePicWrapper ')]/following::h1/div[.='Account'])[1]"), 10, true);
	}

	public void waitElementtoBecomeInvisble() {
		wait.until(ExpectedConditions
				.invisibilityOfElementLocated(By.xpath("//div[@class='slds-col slds-align-middle']/h2")));
		System.out.print("Missing Attribute validation is now invisible");
	}

	public void waitForContactPage() {
		waitFor(By.xpath("//div[.='Contact']"), 10, true);
	}

	public void waitForOpportunityPage() {
		waitFor(By.xpath("//div[.='Opportunity']"), 10, true);
	}

	public void waitForQuotePage() {
		waitFor(By.xpath("(//div[contains(@class,'profilePicWrapper ')]/following::h1/div[.='Quote'])[1]"), 60, true);
	}

	public void waitForApprovalRequestPage() {
		waitFor(By.xpath("(//div[contains(@class,'profilePicWrapper ')]/following::h1/div[.='Approval Request'])[1]"),
				20, true);
	}

	public void waitForCasePage() {
		waitFor(By.xpath("//div[.='Case']"), 40, true);
	}

	public void waitForOrderPage() {
		waitFor(By.xpath("//div[.='Order']"), 10, true);
	}

	public void waitForContractPage() {
		waitFor(By.xpath("//div[.='Contract']"), 60, true);
	}

	public void waitForAssetPage() {
		waitFor(By.xpath("//div[.='Asset']"), 10, true);
	}

	public void waitForAddressAssignmentPage() {
		waitFor(By.xpath("//h1[.='Address Assignment Screen']"), 40, true);
	}

	public void waitForOrchestrationPage() {
		waitFor(By.xpath("//div[text()='Orchestration Plan']"), 10, true);
	}

	public void reloadFrame() {
		executor.executeScript("document.getElementsByTagName('iframe')[0].contentWindow.location.reload(true);");
	}

	public void selectState(String fieldName) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(
					"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
							+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
							+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
							+ "']/@id]");
			element.executeScript("scrollIntoView(true);");
//			element.click();
			clickUsingJs(element);
			map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			String dropdownvalue = map.get(fieldName).toString();
			if (dropdownvalue != null && !dropdownvalue.equalsIgnoreCase("skip")) {
				QAFExtendedWebElement DropDownelement = new QAFExtendedWebElement(
						"xpath=(//lightning-base-combobox-item[@data-value='" + dropdownvalue + "']|//*[@title='"
								+ dropdownvalue + "'])[1]");
//				DropDownelement.click();
				clickUsingJs(DropDownelement);
				Reporter.logWithScreenShot("Selected:-" + dropdownvalue + "", MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Selecting :" + fieldName + " is failed");
		}
	}

	public void selectAndClickSuggestedValue(String fieldName) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(
					"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
							+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
							+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
							+ "']/@id]");
			map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			if (map.get(fieldName) != null && !map.get(fieldName).toString().equalsIgnoreCase("skip")) {
				enterTextUsingJs(element, map.get(fieldName).toString());
				element.sendKeys(Keys.BACK_SPACE);
				StringBuffer removedLastChar = new StringBuffer(map.get(fieldName).toString());
				removedLastChar.deleteCharAt(removedLastChar.length() - 1);
				clickUsingJs(By.xpath(("//lightning-primitive-icon/following::span[contains(text(),'" + "\""
						+ removedLastChar + "\"" + " in')]").replace("\\", "")));
				clickUsingJs(By.xpath("//a[.='" + map.get(fieldName) + "']"));
//				Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
				Reporter.logWithScreenShot(
						"Entered " + map.get(fieldName).toString() + " in to " + fieldName + "  Field",
						MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Typing data to :" + fieldName + " is failed");
		}
	}

	public void selectAndClickSuggestedValue(By locator, String fieldName) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(locator);
			map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			if (map.get(fieldName) != null && !map.get(fieldName).toString().equalsIgnoreCase("skip")) {
				enterTextUsingJs(element, map.get(fieldName).toString());
				element.sendKeys(Keys.BACK_SPACE);
				StringBuffer removedLastChar = new StringBuffer(map.get(fieldName).toString());
				removedLastChar.deleteCharAt(removedLastChar.length() - 1);
				clickUsingJs(By.xpath(("//lightning-primitive-icon/following::span[contains(text(),'" + "\""
						+ removedLastChar + "\"" + " in')]").replace("\\", "")));
				clickUsingJs(By.xpath("//a[.='" + map.get(fieldName) + "']"));
				Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Typing data to :" + fieldName + " is failed");
		}
	}

	public void selectAndClickCaseSuggestedValue(By locator, String fieldName) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(locator);
			if (fieldName != null && !fieldName.equalsIgnoreCase("skip")) {
				enterTextUsingJs(element, fieldName);
				element.sendKeys(Keys.BACK_SPACE);
				element.sendKeys(fieldName.charAt(fieldName.length() - 1) + "");
				element.click();
				StringBuffer check = new StringBuffer(fieldName);
				clickUsingJs(By.xpath(("//lightning-primitive-icon/following::span[contains(text(),'" + "\"" + fieldName
						+ "\"" + " in')]").replace("\\", "")));
				if (fieldName.matches("^[0-9]*$")) {
					clickUsingJs(By.xpath("(//span[.='" + fieldName + "']/preceding::td[1]//a)[last()]"));
				} else {
					clickUsingJs(By.xpath("//a[.='" + fieldName + "']"));
				}
//				Reporter.logWithScreenShot("Entered:-" + fieldName + "", MessageTypes.Info);
				Reporter.logWithScreenShot(
						"Entered " + map.get(fieldName).toString() + " in to " + fieldName + "  Field",
						MessageTypes.Info);
				Reporter.logWithScreenShot(
						"Entered " + "billing Account Number  " + fieldName + "  in to Billing Account" + " Field",
						MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Typing data to :" + fieldName + " is failed");
		}
	}

	public void UpdateCaseIDWithzeroInCSVFile(String file, String value) {
		try {
			FileReader filereader = new FileReader(file);
			// create csvReader object passing
			// file reader as a parameter
			CSVReader csvReader = new CSVReader(filereader);
			List<String[]> csvBody = csvReader.readAll();
			Iterator<String[]> iterator = csvBody.iterator();
			iterator.next();
			int rowno = 1;
			while (iterator.hasNext()) {
				String[] row = iterator.next();
				for (int i = 0; i < row.length; i++) {
					csvBody.get(rowno)[0] = value;
				}
				rowno = rowno + 1;
				// Do stuff with row
			}
			csvReader.close();
			FileWriter outputfile = new FileWriter(file);
			CSVWriter writer = new CSVWriter(outputfile);
			writer.writeAll(csvBody);
			writer.flush();
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickOnActionToolBarButton(String type, String ActionButton) {
		try {
			refreshPage();
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("(//h2/span[@title='" + type
					+ "']/ancestor::header/parent::div/following-sibling::div[contains(@class,'body--inner')]//iframe[1])[last()]")));
			driver.switchTo().defaultContent();
			driver.switchTo().frame(driver.findElement(By.xpath("(//h2/span[@title='" + type
					+ "']/ancestor::header/parent::div/following-sibling::div[contains(@class,'body--inner')]//iframe[1])[last()]")));
			// waitFor(By.xpath("//div[@id='action-container']/i[@class='icon
			// icon-v-menu2']"),10,true);
			// scrollIntoElement(By.xpath("//div[@id='action-container']/i[@class='icon
			// icon-v-menu2']"));
			if (jsLooseClick(By.xpath("//div[@id='action-container']/i[@class='icon icon-v-menu2']"))
					&& jsLooseClick(By.xpath("//div[@id='action-container']//*[text()='" + ActionButton + "']"))) {
			} else {
				driver.switchTo().defaultContent();
				refreshPage();
				clickOnActionToolBarButton(type, ActionButton);
			}
		} catch (Exception e) {
			driver.switchTo().defaultContent();
			refreshPage();
			clickOnActionToolBarButton(type, ActionButton);
		}
		waitFor(By.xpath("//div[@id='action-container']//*[text()='" + ActionButton + "']"), 10, false);
		driver.switchTo().defaultContent();
	}

	public void switchToLoginFrame() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions
				.frameToBeAvailableAndSwitchToIt(By.xpath("(//div[@class='setupcontent']//iframe)[1]")));
	}

	public void waitForCartPageToastMessage() {
		try {
			waitFor(By.xpath("//div[contains(@class,'toaster-container')]"), 30, true);
			System.out.println("---------Banner if Found----------");
		} catch (Exception e) {
			System.out.println("---------Banner is not found----------");
		}
	}

	public void waitForCartPage() {
		waitFor(By.xpath("//title[text()='vlocity_cmt__HybridCPQ | Salesforce']"), 30, true);
	}

	public void waitForWorkingCartPage() {
		waitFor(By.xpath("//title[text()='Lightning Experience | Salesforce']"), 20, true);
	}

	public void waitForClickable(By locator, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	public void moveToElement(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			actions = new Actions(driver);
			actions.moveToElement(element).build().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean isElementDisplayed(By locator) {
		Boolean isDisplayed = false;
		try {
			isDisplayed = driver.findElement(locator).isDisplayed();
		} catch (Exception e) {
		}
		return isDisplayed;
	}

	public String getBackgroudColor(By locator) {
		String color = driver.findElement(locator).getCssValue("background");
		System.out.println(color);
		String hex = Color.fromString(color).asHex();
		System.out.println(hex);
		return color;
	}

	public void waitForMarkStatusAsComplete() {
		waitFor(By.xpath("//span[text()='Mark Status as Complete']"), 10, true);
	}

	public void waitFor(int i) {
		try {
			Thread.sleep(i * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void clickUsingActions(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			actions = new Actions(driver);
			scrollIntoElement(locator);
			actions.moveToElement(element).click().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void rightClick(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			actions = new Actions(driver);
			actions.moveToElement(element).contextClick().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ArrayList<String> refreshOrders(int refreshAttempts, int numberOfOrders) {
		String orderNumber = null;
		int ordercount = 0;
		int count = 0;
		ArrayList<String> list = new ArrayList<String>();
		while (ordercount < numberOfOrders) {
			waitFor(By.xpath("//force-list-view-manager-status-info/div/span[1]"), 30, true);
			try {
				orderNumber = driver.findElement(By.xpath("//force-list-view-manager-status-info/div/span[1]"))
						.getText();
				ordercount = Integer.parseInt(orderNumber.split(" ")[0]);
			} catch (Exception e) {
			}
			System.out.println(ordercount);
			if (count == refreshAttempts) {
				break;
			}
			refreshPage();
			count++;
		}
		if (ordercount == numberOfOrders) {
			waitFor(By.xpath("(//table/tbody/tr/th/span/a)[1]"), 30, true);
			List<WebElement> records = driver.findElements(By.xpath("//table/tbody/tr/th/span/a"));
			for (int i = 0; i < records.size(); i++) {
				list.add(records.get(i).getAttribute("href"));
			}
		}
		return list;
	}

	public String getEnvironment() {
		String resources = pageProps.getString("environment");
		return resources;
	}

	public void loadingPage() {
		try {
			Thread.sleep(3000);
			WebDriverWait wait1 = new WebDriverWait(driver, 20);
//
			ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
				@Override
				public Boolean apply(WebDriver driver) {
					return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
							.equals("complete");
				}
			};
			ExpectedCondition<Boolean> aurascriptLoad = new ExpectedCondition<Boolean>() {
				@Override
				public Boolean apply(WebDriver driver) {
					String WAIT_FOR_AURA_SCRIPT = "return (typeof $A !== 'undefined' && $A && $A.metricsService.getCurrentPageTransaction().config.context.ept > 0)";
					String EPT_COUNTER_SCRIPT = "return ($A.metricsService.getCurrentPageTransaction().config.context.ept)";
					Boolean result = (Boolean) ((JavascriptExecutor) driver).executeScript((WAIT_FOR_AURA_SCRIPT));
					if (result.equals(true)) {
						System.out.println("EPT on the current page is : "
								+ ((JavascriptExecutor) driver).executeScript(EPT_COUNTER_SCRIPT));
						return true;
					} else {
						return false;
					}
				}
			};
			if (wait1.until(jsLoad) && wait1.until(aurascriptLoad)) {
				System.out.println("Page load complete");
			} else {
				Thread.sleep(2000);
			}
		} catch (Exception e) {
			System.out.println("Exception happened in waiting for page to load , so sleeping for 5 seconds");
			System.out.println("Exception is " + e.getMessage());
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e1) {
			}
		}
	}

	public void loadingPage(int timeout) {
		driver.manage().timeouts().implicitlyWait(timeout, TimeUnit.SECONDS);
	}

	public String getTextFromPage(By locator) {
		String text = "";
		try {
			scrollIntoElement(locator);
			text = driver.findElement(locator).getText();
		} catch (Exception e) {
		}
		return text;
	}

	public void openLink(By locator) {
		String relLink = driver.findElement(locator).getAttribute("href");
		driver.get(relLink);
	}

	public void scrollUp() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-2000)", "");
	}

	public void scrollDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,2000)", "");
	}

	public void waitForVlocityOmniScript() {
		waitFor(By.xpath("//title[contains(text(),'vlocity')]"), 10, true);
	}

	public void waitForBulkUploadPage() {
		waitFor(By.xpath("//title[.='Data Import Wizard ~ salesforce.com']"), 20, true);
	}

	public void switchWindow() {
		try {
			String parentWindow = driver.getWindowHandle();
			// System.out.println("Parent Window: "+parentWindow);
			Set<String> allWindows = driver.getWindowHandles();
			Iterator<String> iterator = allWindows.iterator();
			while (iterator.hasNext()) {
				String child_window = iterator.next();
				if (!parentWindow.equalsIgnoreCase(child_window)) {
					driver.switchTo().window(child_window);
					// System.out.println("Child Window: "+child_window);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// created by waseem: to fill the random value at runtime
	public void type(String fieldName, String data) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(
					"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
							+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
							+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
							+ "']/@id]");
			map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			if (map.get(fieldName) != null && map.get(fieldName).toString().equalsIgnoreCase("Random")) {
				executor.executeScript("arguments[0].scrollIntoViewIfNeeded(true);", element);
				enterText(element, data);
//				Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
				Reporter.logWithScreenShot("Entered " + data + " in to " + fieldName + "  Field", MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Typing data to :" + fieldName + " is failed");
		}
	}

	// created by waseem: to select the random value at runtime
	public void select(String fieldName, String data) {
		map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
		String dropdownvalue = map.get(fieldName).toString();
		if (dropdownvalue.equalsIgnoreCase("Random")) {
			click(fieldName);
			QAFExtendedWebElement DropDownelement = new QAFExtendedWebElement(
					"xpath=//lightning-base-combobox-item[@data-value='" + data + "']|//a[@title='" + data + "']");
//			DropDownelement.click();
			clickUsingJs(DropDownelement);
//			Reporter.logWithScreenShot("Selected:-" + dropdownvalue + "", MessageTypes.Info);
			Reporter.logWithScreenShot("Selected " + data + " from " + fieldName + "  drop-down", MessageTypes.Info);
		}
	}
	
	// created by waseem: to type the random value at runtime
	public void typeIntoTextArea(String fieldName, String data) {
		try {
			QAFExtendedWebElement element = new QAFExtendedWebElement(
					"xpath=//input[@id=//label[span[normalize-space(text())='" + fieldName
							+ "']]/@for]|//input[@id=//label[normalize-space(text())='" + fieldName
							+ "']/@for]|//textarea[@id=//label[normalize-space(text())='" + fieldName
							+ "']/@for]|//textarea[@id=//label[span[normalize-space(text())='" + fieldName
							+ "']]/@for]");
			Map<?, ?> map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			if (map.get(fieldName) != null && map.get(fieldName).toString().equalsIgnoreCase("Random")) {
				//element.sendKeys(data);
				enterText(element, data);			
//				Reporter.logWithScreenShot("Entered:-" + map.get(fieldName).toString() + "", MessageTypes.Info);
				Reporter.logWithScreenShot("Entered " +data + " in to " + fieldName + "Field",
						MessageTypes.Info);
			}
		} catch (Exception e) {
		}
	}
	
	// created by waseem: to click the random value at runtime
	public void click(String fieldName,String data) {
		try {
			map = (Map<?, ?>) ConfigurationManager.getBundle().getObject("testdata");
			String checkBox = map.get(fieldName).toString();
			if (checkBox != null && checkBox.equalsIgnoreCase("Random")) {
				QAFExtendedWebElement element = new QAFExtendedWebElement(
						"xpath=//button[@id=//label[span[normalize-space(text())='" + fieldName
								+ "']]/@for]|//button[@id=//label[normalize-space(text())='" + fieldName
								+ "']/@for]|//a[@aria-describedby=//span[normalize-space(text())='" + fieldName
								+ "']/@id]");
				element.executeScript("scrollIntoView(true);");
//				element.click();
				clickUsingJs(element);
				Reporter.logWithScreenShot("Clicked on " + fieldName + " button", MessageTypes.Info);
			}
		} catch (Exception e) {
			System.out.println("Clicking On :" + fieldName + " is failed");
		}
	}
	
	/**
	 * Converting WebElement to By locator
	 *
	 * @param webElement
	 * @return By
	 */
	public static By getByLocator(QAFWebElement we) {
		String data = we.toString().split("By.")[1];
		String[] elementdata = data.split(": ");
		String locator = elementdata[0];
		String term = elementdata[1];
		switch (locator) {
		case "xpath":
			return By.xpath(term);
		case "css selector":
			return By.cssSelector(term);
		case "id":
			return By.id(term);
		case "tag name":
			return By.tagName(term);
		case "name":
			return By.name(term);
		case "link text":
			return By.linkText(term);
		case "class name":
			return By.className(term);
		}
		return (By) we;
	}
	
	/**
	 * Wait and click element
	 *
	 * @param webElement,WaitFor,labelname
	 * @return nothing
	 */
	public void waitAndClickUsingJavaScript(String Locator, String labelname) {
		// Declare and initialise a fluent wait
		wait = new FluentWait<WebDriver>(new WebDriverTestBase().getDriver())
				.withTimeout(pageProps.getInt("explicitwait.timeout"), TimeUnit.SECONDS)// Specify the timout of the
																						// wait
				.pollingEvery(5, TimeUnit.SECONDS)// Sepcify polling time
				.ignoring(NoSuchElementException.class);//// Specify what exceptions to ignore
		WebElement btnORlInk = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return new WebDriverTestBase().getDriver().findElement(getByLocator($(Locator)));
			}
		});
		try {
			new WebDriverWait(new WebDriverTestBase().getDriver(), 60).ignoring(ElementClickInterceptedException.class)// ignore
																														// exception
					.until(driver -> {
						clickUsingJs(btnORlInk);
						return btnORlInk;
					});
			Reporter.log("Clicked on " + labelname, MessageTypes.Info); // report to result
		} catch (Exception e) {
			Reporter.log("Failed to Click on " + labelname, MessageTypes.Info);// report to result
		}
	}
	
	/**
	 * Wait and click element
	 *
	 * @param webElement,WaitFor,labelname
	 * @return nothing
	 */
	public void waitAndClickUsingJavaScript(QAFWebElement element, String labelname) {
		// Declare and initialise a fluent wait
		wait = new FluentWait<WebDriver>(new WebDriverTestBase().getDriver())
				.withTimeout(60, TimeUnit.SECONDS)// Specify the timout of the
																						// wait
				.pollingEvery(5, TimeUnit.SECONDS)// Sepcify polling time
				.ignoring(NoSuchElementException.class);//// Specify what exceptions to ignore
		WebElement btnORlInk = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return new WebDriverTestBase().getDriver().findElement(getByLocator(element));
			}
		});
		try {
			new WebDriverWait(new WebDriverTestBase().getDriver(), 60).ignoring(ElementClickInterceptedException.class)// ignore
																														// exception
					.until(driver -> {
						clickUsingJs(element);
						return btnORlInk;
					});
			Reporter.log("Clicked on " + labelname, MessageTypes.Info); // report to result
		} catch (Exception e) {
			Reporter.logWithScreenShot("Failed to Click on " + labelname, MessageTypes.Fail);// report to result
		}
	}
}